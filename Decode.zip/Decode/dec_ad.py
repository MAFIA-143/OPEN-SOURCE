
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


import os
import json
import hashlib
import io
import struct
os.system('clear')
print(' ')
from requests import api
from urllib3 import connection
from urllib import request
from requests import sessions
from requests import models
from requests import utils
from requests import adapters
from requests import cookies
from requests import compat
from requests import hooks
from requests import exceptions
from requests import certs
from requests import structures
from requests import auth
from requests import packages
import os
import requests
import re
import time
import sys
import random
import json
from concurrent.futures import ThreadPoolExecutor as Thread
import marshal
import zlib
import re
import uuid
import sys
import random
import time
import os
import subprocess
import platform
from bs4 import BeautifulSoup as sp
from fake_email import Email
from concurrent.futures import ThreadPoolExecutor as Thread
import requests
os.system('pip install bs4 fake_email futures requests ')
from bs4 import BeautifulSoup as sp
from fake_email import Email
from concurrent.futures import ThreadPoolExecutor as Thread
import requests
import urllib.request as urllib
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from concurrent.futures import ThreadPoolExecutor
sys.stdout.write('\x1b]2; 𝐓𝐑𝐓\x07')
autoc = requests.get('https://raw.githubusercontent.com/Ramxantanha/data/main/auto.txt').text
if requests.exceptions.RequestException:
    exit('[×] Connection Error! ')
hater = 'for hater 🖕'
whi = '\x1b[1;97m'
yal = '\x1b[1;93m'
red = '\x1b[1;91m'
gren = '\x1b[1;92m'

def linex():
    print('---------------------------------------------')

ok = 0
mthd = []

def lop(text):
    sys.stdout.write(f'''\r\r\r\x1b[1;93m[{int(ok)}]\x1b[0m{text}             \r''')
    sys.stdout.flush()

tm = []
logo = '\n'

def clr():
    os.system('clear')
    print(logo)


def gri():
    ip_address = (lambda .0: for _ in .0:
str(random.randint(0, 255))None)(range(4)())
    return ip_address


def rnd(a, b):
    return str(random.randint(a, b))


def random_ua():
    model = 'iPhone' + str(random.randint(4, 16)) + ',' + str(random.randint(1, 9))
    abc = [
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'X',
        'Y',
        'Z']
    build = str(random.randint(9, 19)) + random.choice(abc) + str(random.randint(50, 199))
    fbsv = str(random.randint(4, 16)) + '_' + str(random.randint(1, 9)) + '_' + str(random.randint(1, 9))
    ua1 = 'Mozilla/5.0 (iPhone, CPU iPhone ' + fbsv + ' like Mac OS ' + str(random.randint(8, 16)) + ') AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/' + build + ') Safari/604.1'
    ua2 = 'Mozilla/5.0 (iPhone ' + str(random.randrange(4, 6)) + ' X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/' + str(random.randint(4, 13)) + '.1.1 Mobile/' + model + ' Safari/604.1'
    dv_typ = random.choice([
        'SM-N960U',
        'SM-G611L',
        'SM-G996N',
        'SM-G870W',
        'SM-G950F',
        'SM-T116NQ',
        'SM-G955N',
        'SM-G389F',
        'SM-G981B'])
    ua3 = f'''Mozilla/5.0 (Linux; Android {str(random.randint(4, 13))}; ''' + dv_typ + ') AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.36'
    a = random.randrange(112, 115)
    b = random.randrange(1000, 10000)
    c = random.randrange(10, 100)
    os_ver = random.randrange(10, 13)
    dv_typ = random.choice([
        'RMX1925',
        'RMX1825',
        'RMX2032',
        'RMX2040',
        'RMX3063',
        'RMX2021'])
    bl_typ = random.choice([
        'QP1A',
        'SKQ1',
        'TP1A',
        'RKQ1',
        'SP1A',
        'RP1A'])
    dv_ver = random.randrange(100000, 250000)
    sd_ver = random.randrange(1, 10)
    ch_ver = f'''{a}.0.{b}.{c}'''
    ua4 = f'''Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'''
    a = random.randrange(112, 115)
    b = random.randrange(1000, 10000)
    c = random.randrange(10, 100)
    os_ver = random.randrange(10, 13)
    dv_typ = random.choice([
        'SM-N960U',
        'SM-G611L',
        'SM-G996N',
        'SM-G870W',
        'SM-G950F',
        'SM-T116NQ',
        'SM-G955N',
        'SM-G389F',
        'SM-G981B'])
    bl_typ = random.choice([
        'PPR1',
        'LRX21T',
        'TP1A',
        'RKQ1',
        'SP1A',
        'RP1A'])
    dv_ver = random.randrange(100000, 250000)
    sd_ver = random.randrange(1, 10)
    ch_ver = f'''{a}.0.{b}.{c}'''
    ua5 = f'''Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'''
    a = random.randrange(112, 115)
    b = random.randrange(1000, 10000)
    c = random.randrange(10, 100)
    os_ver = random.randrange(10, 13)
    dv_typ = random.choice([
        'vivo 1951',
        'vivo 1918',
        'V2011A',
        'V2047',
        'V2145',
        'V2227A',
        'V2160'])
    bl_typ = random.choice([
        'RP1A',
        'PKQ1',
        'QP1A',
        'TP1A'])
    dv_ver = random.randrange(100000, 250000)
    sd_ver = random.randrange(1, 10)
    ch_ver = f'''{a}.0.{b}.{c}'''
    ua6 = f'''Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'''
    ua = random.choice([
        ua1,
        ua2,
        ua3,
        ua4,
        ua5,
        ua6])
    return 'Mozilla/5.0 (Linux; Android 13; RMX3820 Build/TP1A.220905.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.234 Mobile Safari/537.36'


def useragent():
    return random.choice(ugen)


def find(txtt, wrd):
    xx = re.findall('name="' + wrd + '" value="(.*?)"', txtt.replace('amp;', ''))[0]
    return xx

oks = []

def Main():
    clr()
    print(f'''{whi}[1] Add friends request\n[2] Accept friend request\n[0] Exit menu ''')
    linex()
    user = input('Select Option: ')
    if user == '1':
        get_file()
        return None
    if None == '2':
        get_filev2()
        return None
    if None == '0':
        exit('Thanks for use ')
        return None
    None()


def getdata(req):
    act = re.search('"actorID":"(.*?)"', str(req)).group(1)
    hst = re.search('"haste_session":"(.*?)",', str(req)).group(1)
    rev = re.search('{"rev":(.*?)}', str(req)).group(1)
    hsi = re.search('"hsi":"(.*?)",', str(req)).group(1)
    dts = re.search('"DTSGInitialData",\\[\\],{"token":"(.*?)"', str(req)).group(1)
    jzt = re.search('&jazoest=(.*?)",', str(req)).group(1)
    lsd = re.search('"LSD",\\[\\],{"token":"(.*?)"', str(req)).group(1)
    spr = re.search('"__spin_r":(.*?),', str(req)).group(1)
    spt = re.search('"__spin_t":(.*?),', str(req)).group(1)
    dta = {
        'av': act,
        '__user': act,
        '__a': '1',
        '__hs': hst,
        'dpr': '1.5',
        '__ccg': 'EXCELLENT',
        '__rev': rev,
        '__hsi': hsi,
        '__comet_req': '15',
        'fb_dtsg': dts,
        'jazoest': jzt,
        'lsd': lsd,
        '__spin_b': 'trunk',
        '__spin_r': spr,
        '__spin_t': spt }
    return dta
    if Exception:
        e = None
        e = None
        del e
        return None
    e = None
    del e


def acpt(cookies):
    cookies = {
        'cookie': cookies }
    headers = {
        'x-fb-friendly-name': 'FriendingCometFriendRequestSendMutation',
        'x-fb-lsd': '_HXdQr8kHu0XQKU7XKSGvZ' }
    req = requests.get('https://web.facebook.com/', cookies = cookies).text
    data = getdata(req)
    data.update({
        'server_timestamps': 'true',
        'variables': '{"scale":2}',
        'doc_id': '4851458921570237',
        'fb_api_req_friendly_name': 'CommerceManagerCreatePageMutation' })
    postv = requests.post('https://web.facebook.com/api/graphql/', cookies = cookies, data = data)
    x = json.loads(postv.text)
    tot = x['data']['viewer']['friend_requests']['count']
    print('[÷] Total Requests: ' + str(tot))
    for iid in re.findall('"id":"(.*?)"', postv.text):
        data = getdata(req)
        data.update({
            'fb_api_req_friendly_name': 'FriendingCometFriendRequestSendMutation',
            'variables': '{"input":{"attribution_id_v2":"FriendingCometFriendRequestsRoot.react,comet.friending.friendrequests,via_cold_start,1706085835850,561322,2356318349,,","friend_requester_id":"' + iid + '","source":"friends_tab","actor_id":"' + data['__user'] + '","client_mutation_id":"2"},"scale":2,"refresh_num":0}',
            'server_timestamps': 'true',
            'doc_id': '7495020253863724' })
        post = requests.post('https://web.facebook.com/api/graphql/', cookies = cookies, headers = headers, data = data)
        if 'ARE_FRIENDS' in str(post.text):
            print('\x1b[1;92m[√] Successfully Accepted: ' + iid)
            oks.append(iid)
        if '"has_next_page":true' in str(postv.text):
            acpt(cookies, uid)
            return None
        return '129477'
        if Exception:
            e = 'x-asbd-id'
            print('[×] Not found requests:', data['__user'])
            e = None
            del e
            return None
        e = 'x-asbd-id'
        del e
        if Exception:
            e = '980'
            e = None
            del e
            return None
        e = '980'
        del e


def rq(idx, cookie):
    uid = cookie.split('c_user=')[1].split(';')[0]
    cookies = {
        'cookie': cookie }
    profile = requests.get('https://web.facebook.com/', cookies = cookies).text
    headers = {
        'x-fb-friendly-name': 'FriendingCometFriendRequestSendMutation',
        'x-fb-lsd': '_HXdQr8kHu0XQKU7XKSGvZ' }
    data = getdata(profile)
    data.update({
        'fb_api_req_friendly_name': 'FriendingCometFriendRequestSendMutation',
        'variables': '{"input":{"attribution_id_v2":"ProfileCometTimelineListViewRoot.react,comet.profile.timeline.list,via_cold_start,1706094125196,451302,190055527696468,,","friend_requestee_ids":["' + idx + '"],"refs":[null],"source":"profile_button","warn_ack_for_ids":[],"actor_id":"' + data['__user'] + '","client_mutation_id":"3"},"scale":2}',
        'server_timestamps': 'true',
        'doc_id': '7033797416660129' })
    pos = requests.post('https://web.facebook.com/api/graphql/', cookies = cookies, headers = headers, data = data)
    if 'checkpoint' in str(pos.text):
        print('[×] Account got checkpoint wait ')
        return None
    if '129477' in str(pos.text):
        data = getdata(profile)
        data.update({
            'fb_api_req_friendly_name': 'FriendingCometFriendRequestSendMutation',
            'variables': '{"input":{"attribution_id_v2":"ProfileCometTimelineListViewRoot.react,comet.profile.timeline.list,via_cold_start,1706094449393,338154,190055527696468,,","friend_requestee_ids":["' + idx + '"],"refs":[null],"source":"profile_button","warn_ack_for_ids":["' + idx + '"],"actor_id":"' + data['__user'] + '","client_mutation_id":"2"},"scale":2}',
            'server_timestamps': 'true',
            'doc_id': '7033797416660129' })
        pos = requests.post('https://web.facebook.com/api/graphql/', cookies = cookies, headers = headers, data = data)
        if 'Cancel Request' in str(pos.text):
            print('\x1b[1;32m[√] Request Send Successfully:', idx)
            oks.append(idx)
            return None
        return 'x-asbd-id'
    if 'x-asbd-id' in str(pos.text):
        print('\x1b[1;32m[√] Request Send Successfully:', idx)
        ok.append(idx)
        return None
    return '980'
    if Exception:
        e = 'viewport-width'
        e = None
        del e
        return None
    e = 'viewport-width'
    del e


def get_file():
    clr()
    ids = open(input(f'''{yal}[+] {whi}Put ids file with cookies: '''), 'r', encoding = 'utf-8').read().splitlines()
    if FileNotFoundError:
        print('\n No file found, try again ')
        time.sleep(2)
        get_file()
    linex()
    print(f'''{yal}[~]{whi} Make sure put new ids and simple file ''')
    linex()
    idx = open(input(f'''{yal}[+] {whi}Put simple ids file: '''), 'r', encoding = 'utf-8').read().splitlines()
    if FileNotFoundError:
        print('\n No file found, try again ')
        time.sleep(2)
        get_file()
    clr()
    print(f'''{yal}[+] {whi}Total ids: {len(ids)}''')
    print(f'''{yal}[+]{whi} Friend Request process has been started''')
    linex()
    executor = Thread(max_workers = 15)
    for cok in ids:
        data = cok.replace('oo=v|3', 'oo=v3')
        cookie = data.split('|')[2]
        for iid in idx:
            op = iid.split('|')[0]
            executor.submit(rq, op, cookie)
            None(None, None)
            if not None:
                pass
    linex()
    print('[+] The process has been completed')
    print(f'''[+] Total request accept: {len(oks)}''')
    linex()
    input('[+] Press enter for back')
    oks.clear()
    Main()


def get_filev2():
    clr()
    ids = open(input(f'''{yal}[+] {whi}Put ids file with cookies: '''), 'r', encoding = 'utf-8').read().splitlines()
    if FileNotFoundError:
        print('\n No file found, try again ')
        time.sleep(2)
        get_filev2()
    clr()
    print(f'''{yal}[+] {whi}Total ids: {len(ids)}''')
    print(f'''{yal}[+] {whi}Request accept process has been started''')
    linex()
    executor = Thread(max_workers = 15)
    for cok in ids:
        data = cok.replace('oo=v|3', 'oo=v3')
        cookie = data.split('|')[2]
        executor.submit(acpt, cookie)
        None(None, None)
        if not None:
            pass
    linex()
    print('[+] The process has been completed')
    print(f'''[+] Total request accept: {len(oks)}''')
    linex()
    input('[+] Press enter for back')
    oks.clear()
    Main()

Main()

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: RETURN_GENERATOR
Unsupported opcode: JUMP_BACKWARD
