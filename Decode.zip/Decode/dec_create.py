# Source Generated with ShoaibxAmer Pycdc
# File: create.cpython-311.pyc (Python 3.11)

import requests
import random
import string
import json
import hashlib
from faker import Faker
import os
import sys
import glob
import tempfile
import string
import random
import subprocess
import platform
import uuid
import os
import shutil
import zlib
import smtplib
import base64
import uuid
import time
import json
import re
import hashlib
import datetime
import subprocess
from uuid import uuid4
from time import sleep as sp
import os
import sys
import re
import requests
import bs4
import time
import random
import json
import string
from bs4 import BeautifulSoup
from datetime import datetime
import requests
if ImportError:
    os.system('pip install requests > /dev/null')
import bs4
if ImportError:
    print('\n [×] Modul Bs4 Not installed!...\n')
    os.system('pip install bs4')
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
from string import *
from concurrent.futures import ThreadPoolExecutor as tred
if ModuleNotFoundError:
    print('\n Installing missing modules ...')
    os.system('pip install requests futures==2 > /dev/null')
    os.system('python AKING.py')

def convert(cok):
    __for = 'datr=' + cok['datr'] + ';' + 'sb=' + cok['sb'] + ';' + 'fr=' + cok['fr'] + ';' + 'c_user=' + cok['c_user'] + ';' + 'xs=' + cok['xs']
    return _ode


def inbox(session):
    time.sleep(1)
    ses = requests.Session()
    __ = str(time.time()).replace('.', '')[:13]
    data = ses.get(f'''https://10minutemail.net/address.api.php?sessionid={session}&_={str(__)}''').json()
    if len(data['mail_list']) != 1:
        address = data['mail_list'][0]['subject']
        session = address.replace('FB-', '').replace('is your Facebook confirmation code', '')
        return session

ugen = []
for xd in range(5000):
    aa = 'Mozilla/5.0 (Linux; U; Android'
    b = random.choice([
        '5',
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12'])
    if b in ('5', '6', '7', '8', '9'):
        z = random.choice([
            '0',
            '1'])
        bv = b + '.' + z + '.' + z
    bv = b
    B = [
        'GT-',
        'SM-']
    c = random.choice(B)
    d = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.randrange(1, 999)
    f = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h = random.randrange(73, 100)
    i = '0'
    j = random.randrange(4200, 4900)
    k = random.randrange(40, 150)
    l = 'Mobile Safari/537.36'
    application_version = str(random.randint(111, 396)) + '.0.0.' + str(random.randrange(10, 49)) + '.' + str(random.randint(111, 396))
    V = str(random.randrange(11, 99))
    uas = f'''{aa} {bv}; {c}{d}{e}{f} Build/{d}{f}{V}{f}; wv) {g}{h}.{i}.{j}.{k} {l}'''
    ugen.append(uas)
    
    def random_ua():
        model = 'iPhone' + str(random.randint(4, 16)) + ',' + str(random.randint(1, 9))
        abc = [
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'X',
            'Y',
            'Z']
        build = str(random.randint(9, 19)) + random.choice(abc) + str(random.randint(50, 199))
        fbsv = str(random.randint(4, 16)) + '_' + str(random.randint(1, 9)) + '_' + str(random.randint(1, 9))
        ua1 = 'Mozilla/5.0 (iPhone, CPU iPhone ' + fbsv + ' like Mac OS ' + str(random.randint(8, 16)) + ') AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/' + build + ') Safari/604.1'
        ua2 = 'Mozilla/5.0 (iPhone ' + str(random.randrange(4, 6)) + ' X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/' + str(random.randint(4, 13)) + '.1.1 Mobile/' + model + ' Safari/604.1'
        dv_typ = random.choice([
            'SM-S911B',
            'SM-S908B',
            'SM-G998B',
            'SM-G988B',
            'SM-G973B',
            'SM-N986B'])
        ua3 = f'''Mozilla/5.0 (Linux; Android {str(random.randint(4, 13))}; ''' + dv_typ + ') AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Mobile Safari/537.36'
        a = random.randrange(112, 115)
        b = random.randrange(1000, 10000)
        c = random.randrange(10, 100)
        os_ver = random.randrange(10, 13)
        dv_typ = random.choice([
            'RMX3686',
            'RMX3393',
            'RMX3081',
            'RMX2170',
            'RMX2061',
            'RMX2020'])
        bl_typ = random.choice([
            'QP1A',
            'SKQ1',
            'TP1A',
            'RKQ1',
            'SP1A',
            'RP1A'])
        dv_ver = random.randrange(100000, 250000)
        sd_ver = random.randrange(1, 10)
        ch_ver = f'''{a}.0.{b}.{c}'''
        ua4 = f'''Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'''
        a = random.randrange(112, 115)
        b = random.randrange(1000, 10000)
        c = random.randrange(10, 100)
        os_ver = random.randrange(10, 13)
        dv_typ = random.choice([
            'SM-S911B',
            'SM-S908B',
            'SM-G998B',
            'SM-G988B',
            'SM-G973B',
            'SM-N986B'])
        bl_typ = random.choice([
            'PPR1',
            'LRX21T',
            'TP1A',
            'RKQ1',
            'SP1A',
            'RP1A'])
        dv_ver = random.randrange(100000, 250000)
        sd_ver = random.randrange(1, 10)
        ch_ver = f'''{a}.0.{b}.{c}'''
        ua5 = f'''Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'''
        a = random.randrange(112, 115)
        b = random.randrange(1000, 10000)
        c = random.randrange(10, 100)
        os_ver = random.randrange(10, 13)
        dv_typ = random.choice([
            'vivo 1951',
            'vivo 1918',
            'V2011A',
            'V2047',
            'V2145',
            'V2227A',
            'V2160'])
        bl_typ = random.choice([
            'RP1A',
            'PKQ1',
            'QP1A',
            'TP1A'])
        dv_ver = random.randrange(100000, 250000)
        sd_ver = random.randrange(1, 10)
        ch_ver = f'''{a}.0.{b}.{c}'''
        ua6 = f'''Mozilla/5.0 (Linux; Android {os_ver}; {dv_typ} Build/{bl_typ}.{dv_ver}.00{sd_ver}; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{ch_ver} Mobile Safari/537.36'''
        ua = random.choice([
            ua1,
            ua2,
            ua3,
            ua4,
            ua5,
            ua6])
        return ua

    
    def rando_ua():
        model = 'iPhone' + str(random.randint(4, 16)) + ',' + str(random.randint(1, 9))
        abc = [
            'A',
            'B',
            'C',
            'D',
            'E',
            'F',
            'G',
            'H',
            'I',
            'J',
            'K',
            'L',
            'M',
            'N',
            'O',
            'P',
            'Q',
            'R',
            'S',
            'T',
            'U',
            'V',
            'X',
            'Y',
            'Z']
        build = str(random.randint(9, 19)) + random.choice(abc) + str(random.randint(50, 199))
        fbsv = str(random.randint(4, 16)) + '_' + str(random.randint(1, 9)) + '_' + str(random.randint(1, 9))
        ua1 = 'Mozilla/5.0 (Linux; Android 10; SM-T837V) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5745.212 Mobile Safari/537.36'
        ua2 = 'Mozilla/5.0 (Linux; Android 10; SM-P200) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.5736.220 Mobile Safari/537.36'
        dv_typ = random.choice([
            'SM-S911B',
            'SM-S908B',
            'SM-G998B',
            'SM-G988B',
            'SM-G973B',
            'SM-N986B'])
        ua3 = 'Mozilla/5.0 (Linux; Android 10; A860) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.5752.212 Mobile Safari/537.36'
        a = random.randrange(112, 115)
        b = random.randrange(1000, 10000)
        c = random.randrange(10, 100)
        os_ver = random.randrange(10, 13)
        dv_typ = random.choice([
            'RMX3686',
            'RMX3393',
            'RMX3081',
            'RMX2170',
            'RMX2061',
            'RMX2020'])
        bl_typ = random.choice([
            'QP1A',
            'SKQ1',
            'TP1A',
            'RKQ1',
            'SP1A',
            'RP1A'])
        dv_ver = random.randrange(100000, 250000)
        sd_ver = random.randrange(1, 10)
        ch_ver = f'''{a}.0.{b}.{c}'''
        ua4 = 'Mozilla/5.0 (Linux; Android 10; SM-P205) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5833.202 Mobile Safari/537.36'
        a = random.randrange(112, 115)
        b = random.randrange(1000, 10000)
        c = random.randrange(10, 100)
        os_ver = random.randrange(10, 13)
        dv_typ = random.choice([
            'SM-S911B',
            'SM-S908B',
            'SM-G998B',
            'SM-G988B',
            'SM-G973B',
            'SM-N986B'])
        bl_typ = random.choice([
            'PPR1',
            'LRX21T',
            'TP1A',
            'RKQ1',
            'SP1A',
            'RP1A'])
        dv_ver = random.randrange(100000, 250000)
        sd_ver = random.randrange(1, 10)
        ch_ver = f'''{a}.0.{b}.{c}'''
        ua5 = 'Mozilla/5.0 (Linux; Android 11; X104-EEA) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.5810.218 Mobile Safari/537.36'
        a = random.randrange(112, 115)
        b = random.randrange(1000, 10000)
        c = random.randrange(10, 100)
        os_ver = random.randrange(10, 13)
        dv_typ = random.choice([
            'vivo 1951',
            'vivo 1918',
            'V2011A',
            'V2047',
            'V2145',
            'V2227A',
            'V2160'])
        bl_typ = random.choice([
            'RP1A',
            'PKQ1',
            'QP1A',
            'TP1A'])
        dv_ver = random.randrange(100000, 250000)
        sd_ver = random.randrange(1, 10)
        ch_ver = f'''{a}.0.{b}.{c}'''
        ua6 = 'Mozilla/5.0 (Linux; Android 10; J5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5816.208 Mobile Safari/537.36'
        ua = random.choice([
            ua1,
            ua2,
            ua3,
            ua4,
            ua5,
            ua6])
        return ua

    sys.stdout.write('\x1b]2; Mr.Malik\x07')
    M = '\x1b[1;37m'
    A = '\x1b[38;5;208m'
    L = '\x1b[38;5;46m'
    I = '\x1b[38;5;48m'
    K = '\x1b[1;33m'
    head = {
        'Host': 'adsmanager.facebook.com',
        'sec-ch-ua': '"Chromium";v="107", "Not=A?Brand";v="24"',
        'viewport-width': '980' }
    logo4 = "           \n\x1b[1;37m  _____     _ _ _   \n \x1b[1;92m|     |___| |_| |_ \n \x1b[1;37m| | | | .'| | | '_|\n \x1b[1;92m|_|_|_|__,|_|_|_,_|\n\x1b[1;32m┏━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓\n\x1b[1;32m┃\x1b[1;34mUse :\x1b[1;97m Mr-Malik-803       \x1b[1;32m┃\x1b[1;36m  TYPE : \x1b[1;34mPaid  \x1b[1;32m┃\n\x1b[1;32m┃\x1b[1;36mCode written : \x1b[1;97mSohail    \x1b[1;32m┃ \x1b[1;34m Version : \x1b[1;97m1.1\x1b[1;32m┃\n\x1b[1;32m┣━━━━━━━━━━━━━━━━━━━━━━┳━━┻━━━━━━━━━━━━━━━┫\n\x1b[1;32m┃\x1b[1;36mGithub : \x1b[1;97mMr-Jani-906  \x1b[1;32m┃\x1b[1;36mTool : \x1b[1;97m\x1b[1;32mFb CREATE  \x1b[1;32m┃\n\x1b[1;32m┗━━━━━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━━┛\n"
    boy = [
        'Ali Tahir',
        'Sohail Khan',
        'Faisal Malik',
        'Afzal Malik',
        'Haider Khan',
        'Waseem Khan',
        'Nadeem Khan',
        'Nazeer Malik',
        'Nazeer Khan',
        'Nazeer Rehmani',
        'Safdar Malik',
        'Intzar Khan',
        'Saleem Malik',
        'Abdullah Malik',
        'Naseer Jutt',
        'Muzammil Malik',
        'Fiaz Ahmad',
        'Asghar Ali',
        'Shabeer Ahmad',
        'Irfan Ali',
        'Ahmad Gujjar']
    girl = [
        'Sajida Malik',
        'Ayesha Khan',
        'Nabeela Malik',
        'Kinza Fatima',
        'Arooj Khan',
        'Muskan Khan',
        'Ayesha Malik',
        'Safina Malik',
        'Nida Ali',
        'Rimsha Ali']
    ok = []
    cp = []
    import pycurl
    from io import BytesIO
    
    def get_response(url):
        response_buffer = BytesIO()
        curl = pycurl.Curl()
        curl.setopt(curl.URL, url)
        curl.setopt(curl.WRITEDATA, response_buffer)
        curl.perform()
        if pycurl.error:
            e = None
            e = None
            del e
            return f'''Error: {e}'''
        e = None
        del e
        response = response_buffer.getvalue().decode('utf-8')
        curl.close()
        return response

    
    def remove_symbols_and_spaces(input_string):
        cleaned_string = re.sub('[^a-zA-Z0-9#]', '', input_string)
        return cleaned_string

    
    def approval():
        os.system('clear')
        print(logo4)
        import platform
        uuid = str(os.geteuid()) + '#' + platform.uname().machine + platform.uname().version + platform.uname().release
        id = remove_symbols_and_spaces(uuid)
        (k1, k2, k3, k4) = (id[:4], id[3:6], id[4:9], id[9:])
        intuid = int(id.split('#')[0])
        pref = str(((intuid - 104729) * 2 - 37) + -127)
        suff = str((intuid - 523217) % 104729)
        realid = (suff + k3 + k1 + k4 + k2 + pref).encode().hex()
        httpCaht = get_response('https://github.com/Mr-Malik803/Auto_Create_Facebook/blob/main/Approval.txt')
        if realid in httpCaht:
            return None
        None('\x1b[1;32m YOUR KEY :\x1b[38;5;46m ' + id)
        print('-----------------------------------------------')
        print('\t\x1b[1;37mWELLCOME TO AUTO CREATE FACEBOOK TOOLS \x1b[1;37m')
        print('-----------------------------------------------')
        print('\t \x1b[1;37m   FIRST GET APPROVEL\x1b[1;37m ')
        print('-----------------------------------------------')
        print('\t \x1b[1;37mPlease Copy Your Key And Send Admin\x1b[1;37m ')
        print('-----------------------------------------------')
        print('\t \x1b[1;37mNote:  Mails System is Manuel \x1b[1;37m ')
        print('-----------------------------------------------')
        print("This is Tool Not Free Please Don't Waste Your Time.. ")
        print('-----------------------------------------------')
        input('\x1b[1;37m Press Enter For Contact To Admin ')
        tks = 'HA%20MR-JANI%20Sir%20!%20Please%20Approve%20My%20Key%20The%20MXS%20Key%20Is%20:%20' + id
        os.system('am start https://wa.me/+923077681556?text=' + tks)
        sys.exit()
        time.sleep(1)
        approval()
        return None
        if Exception:
            error = None
            print(error)
            error = None
            del error
            return None
        error = None
        del error

    
    def menu():
        os.system('clear')
        print(logo4)
        approval()
        print('-----------------------------------------------')
        print('[1] FB Create ')
        print('[2] 2F LIVE ON SOON ')
        print('[3] CHENGE PASSWORD SOON')
        print('[4] AUTO UPDATE SCRIPT')
        print('[5] EXIT')
        print('-----------------------------------------------')
        sel = input('Select: ')
        if sel in ('1', '01'):
            create().start()
            return None
        if None in ('2', '02'):
            menu()
            return None
        if None in ('3', '03'):
            menu()
            return None
        if None in ('4', '04'):
            print('Again Run Tool python createfb_enc.py ')
            exit()
            return None
        None('select valid option')
        time.sleep(3)
        menu()

    
    class create:
        
        def __init__(self):
            self.loop = 0
            self.gender = []

        
        def start(self):
            os.system('clear')
            print(logo4)
            print('-----------------------------------------------')
            print('[1] Boys name ids')
            print('[2] girls name ids')
            print('-----------------------------------------------')
            gen = input('select: ')
            print('-----------------------------------------------')
            if gen in ('1', '01'):
                self.gender.append('boy')
            if gen in ('2', '02'):
                self.gender.append('girl')
            self.gender.append('boy')
            print('Example 1000, 2000, 5000, 10000')
            print('-----------------------------------------------')
            lim = int(input('limit: '))
            os.system('clear')
            print(logo4)
            ua = rando_ua()
            headers = '980'
            headers1 = {
                'authority': 'm.facebook.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
                'sec-ch-prefers-color-scheme': 'light',
                'sec-ch-ua': '"Not:A-Brand";v="99", "Chromium";v="112"',
                'sec-ch-ua-full-version-list': '"Not:A-Brand";v="99.0.0.0", "Chromium";v="112.0.5615.137"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-ch-ua-platform-version': '"11.0.0"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'upgrade-insecure-requests': '1',
                'user-agent': rando_ua() }
            OO = '\x1b[0;97m'
            for x in range(lim):
                (self.loop += 1).loop = 'viewport-width'
                (sys.stdout.write(f'''\r {OO}[Creation-Start] {OO}{self.loop}|{str(lim)} OK:{len(ok)}|{len(cp)}{OO} '''),)
                sys.stdout.flush()
                if 'boy' in self.gender:
                    name = random.choice(boy).split(' ')
                    sex = '2'
                if 'girl' in self.gender:
                    name = random.choice(girl).split(' ')
                    sex = '1'
                ses = requests.Session()
                buildses = (lambda .0: for i in .0:
random.SystemRandom().choice('qwertyuiopasdfghjklzxcvbnm0987654321')None)(range(26)())
                user = ''.join
                create = ses.get(f'''https://10minutemail.net/address.api.php?new=1&sessionid={buildses}&_={int(datetime.now().timestamp() * 1000)}''').json()
                mail = {
                    'mail': create['permalink']['mail'],
                    'session': create['session_id'] }
                email = mail['mail']
                session = mail['session']
                if KeyError:
                    rando_ua()
                if requests.exceptions.ConnectionError:
                    'user-agent'
                    time.sleep(1)
                if Exception:
                    e = '1'
                    e = None
                    del e
                    e = None
                    del e
                bank = '@#'
                passw = name[0] + name[1] + bank + str(random.randint(111, 999))
                self.ses = requests.Session()
                a = self.ses.get('https://m.facebook.com/reg?_fb_noscript', headers = headers)
                loger = re.search('name="logger_id" value="(.*?)"', str(a.text)).group(1)
                ref = BeautifulSoup(a.text, 'html.parser').find('form', {
                    'action': True,
                    'id': 'mobile-reg-form',
                    'method': 'post' })
                bl = [
                    'lsd',
                    'jazoest',
                    'cpp',
                    'reg_instance',
                    'submission_request']
                bz = [
                    'reg_impression_id',
                    'ns']
                self.data = { }
                for v in ref('input'):
                    if v.get('name') in bl:
                        self.data.update({
                            v.get('name'): v.get('value') })
                        'upgrade-insecure-requests'
                    self.data.update({
                        'helper': '' })
                    for v in ref('input'):
                        if v.get('name') in bz:
                            self.data.update({
                                v.get('name'): v.get('value') })
                            '?1'
                        ''({
                            'custom_gender': '',
                            'field_names[]': 'reg_passwd__',
                            'reg_passwd__': passw,
                            'submit': 'Sign Up',
                            'name_suggest_elig': 'false',
                            'was_shown_name_suggestions': 'false',
                            'did_use_suggested_name': 'false',
                            'use_custom_gender': '',
                            'guid': '',
                            'pre_form_step': '' })
                        gett = self.ses.post('https://m.facebook.com' + ref['action'], headers = headers1, data = self.data)
                        getts = self.ses.get('https://m.facebook.com/login/save-device/?login_source=account_creation&logger_id=' + loger + '&app_id=103', headers = headers1)
                        data1 = { }
                        data2 = { }
                        data3 = { }
                        cok = self.ses.cookies.get_dict()
                        if 'checkpoint' in getts.url:
                            cp.append(email + passw)
                            print('\r\x1b[1;91m[MALIK-CP] ' + cok['c_user'] + ' | ' + passw + '\x1b[1;97m      ')
                dbl = [
                    'fb_dtsg',
                    'jazoest',
                    'flow',
                    'next',
                    'nux_source']
                for x in BeautifulSoup(getts.text, 'html.parser').find_all('form', {
                    'method': 'post' }):
                    if '/login/device-based/update-nonce/' in str(x):
                        for v in x('input'):
                            if v.get('name') in dbl:
                                data1.update({
                                    v.get('name'): v.get('value') })
                                'preferred_pronoun'
                            data1.update({
                                'submit': 'OK' })
                            po = self.ses.post('https://m.facebook.com' + x.get('action'), headers = headers1, data = data1)
                            for x in BeautifulSoup(po.text, 'html.parser').find_all('form', {
                                'method': 'post' }):
                                if 'confirmation_event_location=cliff' in str(x):
                                    for v in x('input'):
                                        if v.get('name') in dbl:
                                            data2.update({
                                                v.get('name'): v.get('value') })
                                            sex
                                        code = inbox(session)
                                        data2.update({
                                            'c': code,
                                            'submit': 'Confirm' })
                                        rex = self.ses.post('https://m.facebook.com' + x.get('action'), headers = headers1, data = data2)
                                        if 'checkpoint' in rex.url:
                                            cok = self.ses.cookies.get_dict()
                                            cp.append(email + passw)
                                            print('\r\x1b[1;91m[CP] ' + cok['c_user'] + ' | ' + passw + '\x1b[1;97m      ')
                                    coki = (lambda .0: for key, value in .0:
[ f'''{key!s}={value!s}''' ])(self.ses.cookies.get_dict().items()())
                                    cok = self.ses.cookies.get_dict()
                                    print('\r\x1b[1;32m[OK] ' + cok['c_user'] + ' | ' + passw + ' | ' + coki + '\x1b[0;97m     ')
                                    open('/sdcard/Auto/JANI-OK-COKI.txt', 'a').write(cok + '|' + passw + '|' + coki + '\n')
                                    ok.append(email + passw)
                                if requests.exceptions.ConnectionError:
                                    ';'.join
                                    time.sleep(1)
                if Exception:
                    e = 'sex'
                    e = None
                    del e
                    e = None
                    del e
                print('process has been completed')
                print('-----------------------------------------------')
                print('\x1b[1;32mTotal ids > Ok/' + str(len(ok)) + ' CP/' + str(len(cp)))
                print('-----------------------------------------------')
                input('back')
                menu()
                return None


    menu()
    return None
